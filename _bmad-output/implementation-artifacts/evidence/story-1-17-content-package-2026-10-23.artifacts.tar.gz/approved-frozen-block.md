<frozen-after-approval reason="human-owned intent — do not modify unless human renegotiates">

## Intent

**Problem:** Folders' package build fails with 43 errors because EventStore 3.126.1 lacks required content APIs. Published 3.127.0 restores both solution builds under an override. The REST golden lifecycle also fails in source and package modes because its AddFile fixture predates the content contract.

**Approach:** Adopt the published package and exercise the authoritative content pipeline in the golden fixture. This prerequisite leaves parent conformance and operational gates open.

## Boundaries & Constraints

**Always:** Limit catalog edits to EventStore properties. Separate audited Release/package and Debug/source validation. Preserve real REST, gateway `/process`, authorization, 202/correlation assertions and persisted publication/content checks. Bind evidence to exact packages and assemblies.

**Never:** Change product behavior, contracts, gitlinks, unrelated versions, assertions or timeouts; publish/deploy; mutate Git; initialize nested submodules; reseal conformance or amend approvals/tracking. Preserve user work, history, `V1Only`, unset T0, accepted rollout branches, original baseline and seven-day limit. Local checks establish no hosted acceptance or parent closure.

## I/O & Edge-Case Matrix

| Scenario | Input / State | Expected Output / Behavior | Error Handling |
|---|---|---|---|
| Package graph | EventStore 3.127.0 | Both solutions build without override | Missing API/mixed graph blocks acceptance |
| Golden AddFile | Valid hash/version/fence, principal, policy/store | 202 crosses `/process`; publication/bytes persist | Keep rejection assertions |
| Security negatives | Invalid authority/content/fence | Existing safe rejection | Never relax validation |

</frozen-after-approval>