
- source_spec: `spec-1-17-restore-published-content-package-and-golden-lifecycle.md`
  summary: Restore explicit checked-in generation equality, canonical CLI/MCP error mappings and metadata-only evidence guidance in the compiled Epic 1 context.
  evidence: Review B1/B2/B3 verified these concrete constraints were omitted during cache regeneration while canonical contracts and gates remain intact; workflow routes agent-context changes to deferred work.
