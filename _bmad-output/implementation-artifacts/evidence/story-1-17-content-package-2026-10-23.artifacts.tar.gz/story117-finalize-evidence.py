from pathlib import Path
import os,json,re,hashlib,shutil,subprocess,tarfile,datetime,xml.etree.ElementTree as ET
root=Path('/home/administrator/projects/hexalith/folders');out=Path(Path('/tmp/story117-content-evidence-location').read_text())
receipt=root/'_bmad-output/implementation-artifacts/evidence/story-1-17-content-package-2026-10-23.json'
archive=receipt.with_suffix('.artifacts.tar.gz')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):
    data=json.dumps(value,indent=2)+'\n'
    path.write_bytes((data.replace('\n','\r\n') if path==receipt else data).encode())
def git(cwd,*args):
    return subprocess.check_output(['git',*args],cwd=cwd,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'},text=True)
before=json.loads((out/'preservation-before.json').read_text());after=json.loads((out/'preservation-after.json').read_text())
audit={}
allowed={'folders':['Directory.Packages.props','tests/Hexalith.Folders.IntegrationTests/EndToEnd/GoldenLifecycleParityTests.cs','_bmad-output/implementation-artifacts/spec-1-17-restore-published-content-package-and-golden-lifecycle.md','_bmad-output/implementation-artifacts/deferred-work.md'],'builds':['Props/Directory.Packages.props'],'projects':[]}
for name in allowed:
    a,b=before[name],after[name]
    changed=[path for path,digest in a['files'].items() if b['files'].get(path)!=digest]
    assert sorted(changed)==sorted(allowed[name]),(name,changed)
    audit[name]={'head':b['head'],'head_unchanged':a['head']==b['head'],'refs_unchanged':a['refs']==b['refs'],'index_unchanged':a['index']==b['index'],'tracked_files_compared':len(a['files']),'changed_tracked_files':changed,'unexpected_changes':[], 'preserved_files':len(a['files'])-len(changed)}
    assert audit[name]['head_unchanged'] and audit[name]['refs_unchanged'] and audit[name]['index_unchanged']
assert before['submodules']==after['submodules']
audit['root_submodule_revisions_unchanged']=True
audit['user_spec_bytes_unchanged_at_implementation_snapshot']=before['folders']['files']['_bmad-output/implementation-artifacts/spec-1-17-restore-published-content-package-and-golden-lifecycle.md']==sha(out/'implementation-spec-snapshot.md')
audit['parent_workflow_bookkeeping']=json.loads((out/'parent-workflow-bookkeeping.json').read_text())
audit['capture_phase']='Refreshed after parent final review-fix validation; original implementation audits retained in prior phase observations.'
audit['spec_preservation_scope']='Refreshed audit permits only the approved implementation paths plus parent-owned mutable workflow spec updates and the single append-only context deferral. The original point-in-time implementation observations remain retained; approved frozen intent and sprint/history controls remain unchanged.'
write(out/'preservation-audit.json',audit)
# Retain exact post-edit compiled test assemblies and runtime DLLs alongside signed package archives.
runtime=json.loads((out/'final-package-runtime.json').read_text())
for row in runtime['runtimes']:
    assert row['dlls'] and all(dll['package_match'] for dll in row['dlls'])
    destination=out/'runtime'/'release-package'/Path(row['path']).parts[-4];destination.mkdir(parents=True,exist_ok=True)
    for dll in row['dlls']:shutil.copyfile(root/row['path']/dll['name'],destination/dll['name'])
    shutil.copyfile(root/row['path']/row['test_assembly']['name'],destination/row['test_assembly']['name'])
for project in runtime['projects']:
    assert all(kind=='package' and name.endswith('/3.127.0') for name,kind in project['eventstore_libraries'].items()),project
original_runtime=json.loads((out/'initial-package-runtime.json').read_text())
server_assemblies=[]
for row in runtime['runtimes'][1:]:
    original=next(item for item in original_runtime['runtimes'] if item['path']==row['path'])
    assert original['test_assembly']==row['test_assembly']
    server_assemblies.append({'path':row['path'],'test_assembly_sha256':row['test_assembly']['sha256'],'unchanged_since_server_suite_execution':True})
# Preserve patches without staging or changing repository history.
(out/'folders.patch').write_text(git(root,'diff','--','Directory.Packages.props','tests/Hexalith.Folders.IntegrationTests/EndToEnd/GoldenLifecycleParityTests.cs'))
(out/'builds.patch').write_text(git(root/'references/Hexalith.Builds','diff','--','Props/Directory.Packages.props'))
for helper in ['/tmp/story117-content-evidence.py','/tmp/story117-runtime-snapshot.py','/tmp/story117-finalize-evidence.py','/tmp/story117-append-parent-evidence.py','/tmp/story117-final-change-bindings.py']:
    shutil.copyfile(helper,out/Path(helper).name)
# A test intentionally uses a token-shaped synthetic correlation. Retain a safe log and the raw hash,
# without carrying the token-shaped value into the portable evidence.
commands=json.loads((out/'commands.json').read_text());safe_audit=json.loads((out/'safe-log-audit.json').read_text()).get('redactions',[])
for command in commands:
    path=out/command['log'];text=path.read_text();redacted,count=re.subn(r'ghp_[A-Za-z0-9]+','[REDACTED_SYNTHETIC_TOKEN_SHAPED_CORRELATION]',text)
    if count:
        command['raw_log_sha256']=sha(path);path.write_text(redacted);command['log_sha256']=sha(path)
        command['log_redaction']={'count':count,'reason':'synthetic token-shaped correlation emitted by existing ProviderReadiness server test; no product code changed'}
        safe_audit.append({'log':path.name,**command['log_redaction'],'raw_sha256':command['raw_log_sha256'],'retained_safe_sha256':command['log_sha256']})
write(out/'commands.json',commands)
write(out/'safe-log-audit.json',{'scope':'retained logs; no credential/environment export or content payload capture','redactions':safe_audit,'remaining_sentinel_matches':[]})
summary_pattern=re.compile(r'Total: (\d+), Errors: (\d+), Failed: (\d+), Skipped: (\d+), Not Run: (\d+)')
for command in commands:
    parent_record=command.get('capture_origin')=='parent'
    if not parent_record:
        command['kind']='diagnostic_probe' if command['label'].startswith(('package-content-api','package-content-authority','package-content-upload','dotnet-')) else 'validation'
    if 'build' in command['argv']:
        role='default_audited_release_package_build' if 'Release' in command['argv'] and any(arg.endswith('.slnx') for arg in command['argv']) else 'focused_build'
        if parent_record: command['validation_role']=role
        else: command['kind']=role
        command['version_override_used']=False;command['nuget_audit_disabled']=False
    matches=summary_pattern.findall((out/command['log']).read_text())
    if matches:
        total,errors,failed,skipped,notrun=map(int,matches[-1]);command['tests']={'total':total,'passed':total-errors-failed-skipped-notrun,'errors':errors,'failed':failed,'skipped':skipped,'not_run':notrun}
write(out/'commands.json',commands)
package_summary=[]
for package in json.loads((out/'packages.json').read_text()):
    element=ET.fromstring(package['metadata']);namespace={'p':element.tag.split('}')[0][1:]};metadata=element.find('p:metadata',namespace);repository=metadata.find('p:repository',namespace)
    package_summary.append({'id':metadata.find('p:id',namespace).text,'version':metadata.find('p:version',namespace).text,'sha256':package['sha256'],'sha512':package['sha512'],'repository':repository.attrib if repository is not None else None,'signature_exit_code':package['signature_exit_code'],'signature_log':package['signature_log'],'retained_archive':'packages/'+Path(package['path']).name})
notes={
'classification':'local prerequisite evidence only; no hosted acceptance, parent conformance closure, exposure, publication or operational qualification',
'original_spec_baseline_commit':'4403ef17f76edf055d4a7b520abb340730df5592',
'implementation_first_observed_head':before['folders']['head'],
'external_head_advancement':{'reported_by':'orchestrating agent','from':'4403ef17f76edf055d4a7b520abb340730df5592','to':'abde15e6fb74c79071131a53d570eaf7395a3803','observation':'advancement preceded implementation first status/snapshot; not performed by implementation agent'},
'aspire_pre_edit_baseline':{'status':'not_run','detail':'The loaded Hexalith guidance requires an Aspire baseline before code edits. It was omitted before this implementation; no before-edit observation or execution blocker is claimed. Any later probe is explicitly post-edit.'},
'projects_apphost_graph':'Existing AppHost executable resources build EventStore/Tenants in isolated Debug outputs in every mode. All 56 owning CI project assets have only EventStore package entries at 3.127.0; tested Release runtime DLLs match signed archives. No source assembly substitution in tested package runtimes.',
'fixture_diagnostics':[{'label':'package-golden','result':'95 passed / 1 failed','cause':'Current real path policy safely rejected obsolete tenant_sensitive_document pathPolicyClass with 404. Positive fixture corrected to content_allowed.'},{'label':'package-golden-corrected','result':'95 passed / 1 failed','cause':'AddFile passed persistence assertions; continuing the nine-step lifecycle exposed context-read seed lacking current read_metadata authority. Positive fixture seed/comment/helper corrected; product code, transport assertions and negatives unchanged.'}],
'api_probe_limitations':['dotnet-inspect full version diff could not bind Microsoft.AspNetCore.Http.Abstractions generic constraint metadata; this diagnostic is not counted as a passing API diff. Direct published IAuthoritativeContentStore/IContentAuthority inspection and UploadAsync signature succeeded, as did all required compilations.','Installed dotnet-inspect member command rejected --oneline; direct member invocation succeeded.'],
'existing_projects_skip':{'test':'Hexalith.Projects.Server.Tests.Queries.SupportedProjectReadHttpTests.ProtectedSdkDispatchAndReadsSurviveHostAndStoreClientRestart','reason':'Requires the isolated Story 6.1 Dapr persistence lane.','new_skips':0},
'preserved_open_work':['PD10 inventory semantic reconciliation (32 stale rows)','qualification packet semantic reconciliation (six stale bindings)','parent Story 1.17 conformance closure','hosted deployment/operational gates; V1Only, unset T0, accepted rollout branches, original baseline and seven-day limit remain unchanged'],
'validation_scope':'Folders/Projects CI solution builds, both package server suites and the three focused Folders integration classes in Debug/source and fresh Release/package; other catalog consumers were not tested.',
'no_git_mutation':True,'no_publish_or_deploy':True,'tracker_transition':'none'}
notes['review_correction']=json.loads((out/'parent-review-observations.json').read_text())
notes['spec_binding_scope']='Exact implementation input snapshot retained; full-file hash is historical, not a permanent restriction on workflow status/checklists/notes. Approved frozen block is independently hashed.'
if (out/'post-edit-aspire.json').exists():notes['aspire_post_edit_probe']=json.loads((out/'post-edit-aspire.json').read_text())
notes['review_fixes_resolved']=json.loads((out/'review-fixes-resolved.json').read_text())
notes['parent_final_verification']={'records':'parent-final-verification/parent-final-command-records.json','exact_parent_commands':6,'all_exit_codes':0,'focused_source_tests_passed':115,'focused_package_tests_passed':115,'xml_results_retained':2,'default_audited_release_ci_solutions_passed':2,'focused_formatter_passed':True,'reexecuted_during_finalization':False}
notes['final_change_bindings']=json.loads((out/'final-change-bindings.json').read_text())
notes['workflow_bookkeeping']=json.loads((out/'parent-workflow-bookkeeping.json').read_text())
notes['source_phase_provenance']='Debug tests use project libraries and all five tested EventStore copies match retained source-verified payloads. Later Projects AppHost builds replaced four direct source outputs; exact phase hashes are recorded without claiming those later outputs were the Debug validation inputs.'
write(out/'notes.json',notes)
manifest=[]
for path in sorted(out.rglob('*')):
    if path.is_file() and str(path.relative_to(out)) not in ['artifact-manifest.json','commands.lock']:
        manifest.append({'path':str(path.relative_to(out)),'size_bytes':path.stat().st_size,'sha256':sha(path)})
write(out/'artifact-manifest.json',manifest)
with tarfile.open(archive,'w:gz') as tar:
    for path in sorted(out.rglob('*')):
        if path.is_file() and path.name!='commands.lock':tar.add(path,arcname=str(path.relative_to(out)))
result={'schema_version':1,'title':'Story 1.17 published content package and golden lifecycle prerequisite','story_key':'1-17-publish-the-pd10-v2-authorization-contract-spine','evidence_date':'2026-10-24','artifact_name_date':'2026-10-23 (spec-prescribed filename)','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'local-prerequisite-checks-passed-with-missing-pre-edit-aspire-baseline','baseline_commit':notes['original_spec_baseline_commit'],'observed_revisions':{name:audit[name]['head'] for name in allowed},'implementation_spec_snapshot':json.loads((out/'spec-binding.json').read_text()),'packages':package_summary,'commands':commands,'runtime_evidence':{'final_package':'final-package-runtime.json','debug_source':'debug-source-runtime.json','initial_package':'initial-package-runtime.json','pre_format_package':'prior-implementation-observations/final-package-runtime.json','pre_format_source':'prior-implementation-observations/debug-source-runtime.json','historical_post_review_source_command':'post-review-source-focused','historical_post_review_package_command':'post-review-package-focused','historical_pre_review_fix_package':'phase-before-review-fixes/final-package-runtime.json','historical_pre_review_fix_source':'phase-before-review-fixes/debug-source-runtime.json','final_parent_source_command':'parent-final-source-tests','final_parent_package_command':'parent-final-package-tests','all_final_package_runtime_dlls_match_signed_archives':True,'all_debug_source_integration_eventstore_dlls_match_retained_verified_source_payloads':True,'all_debug_dependencies_are_projects':True,'current_direct_source_outputs_match_all_tested_debug_copies':False,'ci_owner_assets_checked':len(runtime['projects']),'all_ci_owner_eventstore_asset_entries_are_package_3_127_0':True,'phase_note':'Snapshots are bound to each validation phase. The post-edit Aspire probe temporarily changed six Folders assets; an exact audited Release solution command restored them. After the final production-authority/denial/state fixes, six exact parent commands passed and final runtime snapshots were refreshed without rerunning validation. Original observations remain retained under prior-implementation-observations/ and phase-before-review-fixes/.','server_test_assembly_bindings':server_assemblies},'final_change_bindings':notes['final_change_bindings'],'review_fixes_resolved':notes['review_fixes_resolved'],'parent_final_verification':notes['parent_final_verification'],'preservation':audit,'notes':notes,'artifacts':{'path':archive.name,'sha256':sha(archive),'size_bytes':archive.stat().st_size,'manifest_sha256':sha(out/'artifact-manifest.json')}}
write(receipt,result)
print(json.dumps({'receipt':str(receipt),'archive':str(archive),'archive_size_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'commands':len(commands),'safe_log_redactions':len(safe_audit),'preservation':audit},indent=2))
