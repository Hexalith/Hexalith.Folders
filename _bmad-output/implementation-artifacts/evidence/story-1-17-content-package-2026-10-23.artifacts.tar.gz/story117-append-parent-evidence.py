from pathlib import Path
import json,hashlib,shutil,tarfile,re,subprocess,os,datetime
root=Path('/home/administrator/projects/hexalith/folders');out=Path(Path('/tmp/story117-content-evidence-location').read_text());parent=Path('/tmp/story117-content-20261024-p23zx585');receipt=root/'_bmad-output/implementation-artifacts/evidence/story-1-17-content-package-2026-10-23.json';archive=receipt.with_suffix('.artifacts.tar.gz')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
old_receipt=json.loads(receipt.read_text());assert sha(archive)==old_receipt['artifacts']['sha256']
# Preserve every prior mutable observation/payload by content, without carrying an old archive.
mutable={'commands.json','artifact-manifest.json','final-package-runtime.json','debug-source-runtime.json','preservation-after.json','preservation-audit.json','notes.json','safe-log-audit.json','folders.patch','builds.patch','story117-content-evidence.py','story117-runtime-snapshot.py','story117-finalize-evidence.py'}
phase=out/'phase-before-review-fixes';phase.mkdir(exist_ok=True)
with tarfile.open(archive,'r:gz') as tar:
    old_manifest=json.load(tar.extractfile('artifact-manifest.json'))
    for member in tar.getmembers():
        if member.isfile() and (member.name in mutable or member.name.startswith(('runtime/','assets/release-package/'))):
            destination=phase/member.name;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(tar.extractfile(member).read())
    (phase/'artifact-manifest.json').write_bytes(tar.extractfile('artifact-manifest.json').read())
    for row in old_manifest:
        candidates=[out/row['path'],phase/row['path']]
        if not any(path.is_file() and sha(path)==row['sha256'] for path in candidates):
            destination=phase/row['path'];destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(tar.extractfile(row['path']).read())
(phase/'receipt.json').write_bytes(receipt.read_bytes())
records=json.loads((parent/'parent-final-command-records.json').read_text());assert len(records)==6 and all(row['exit_code']==0 for row in records)
destination=out/'parent-final-verification';destination.mkdir(exist_ok=True)
shutil.copyfile(parent/'parent-final-command-records.json',destination/'parent-final-command-records.json');shutil.copyfile(parent/'final-parent-verification.py',destination/'final-parent-verification.py')
commands=json.loads((out/'commands.json').read_text());existing={row['label'] for row in commands}
for row in records:
    log=Path(row['log']);assert sha(log)==row['log_sha256'];shutil.copyfile(log,destination/log.name)
    appended={**row,'log':str((destination/log.name).relative_to(out)),'capture_origin':'parent','original_record_path':'parent-final-verification/parent-final-command-records.json','original_log_path':row['log']}
    if 'xml' in row:
        xml=Path(row['xml']['path']);assert sha(xml)==row['xml']['sha256'];shutil.copyfile(xml,destination/xml.name)
        appended['xml']={**row['xml'],'retained_path':str((destination/xml.name).relative_to(out))}
        assert row['tests']=={'total':115,'passed':115,'errors':0,'failed':0,'skipped':0,'not_run':0}
    assert row['label'] not in existing;commands.append(appended)
write(out/'commands.json',commands)
# Bind unchanged pins and exact frozen intent independently from mutable workflow bookkeeping.
binding=json.loads((out/'spec-binding.json').read_text());spec=root/binding['source_path'];frozen=re.search(rb'<frozen-after-approval\b[^>]*>.*?</frozen-after-approval>',spec.read_bytes(),re.S).group();assert hashlib.sha256(frozen).hexdigest()==binding['approved_frozen_block_sha256']
(out/'workflow-spec-after-review.md').write_bytes(spec.read_bytes())
before=json.loads((out/'preservation-before.json').read_text());deferred='_bmad-output/implementation-artifacts/deferred-work.md'
original=subprocess.check_output(['git','show','HEAD:'+deferred],cwd=root,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'});assert hashlib.sha256(original).hexdigest()==before['folders']['files'][deferred]
current=(root/deferred).read_bytes();assert current.startswith(original);append=current[len(original):];assert append.count(b'- source_spec:')==1 and b'compiled Epic 1 context' in append
(out/'deferred-context-only-append.md').write_bytes(append)
bookkeeping={'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'owner':'parent workflow, Step 4','scope':'Mutable spec status/checklists/implementation notes/review triage and one grouped context-only append to deferred-work.md; not a tracker transition or frozen-intent amendment.','paths':[binding['source_path'],deferred],'spec_snapshot':{'path':'workflow-spec-after-review.md','sha256':sha(out/'workflow-spec-after-review.md'),'historical_implementation_snapshot_sha256':binding['snapshot_sha256'],'approved_frozen_block_sha256':binding['approved_frozen_block_sha256'],'approved_frozen_block_unchanged':True},'deferred_work':{'baseline_sha256':hashlib.sha256(original).hexdigest(),'current_sha256':hashlib.sha256(current).hexdigest(),'append_path':'deferred-context-only-append.md','append_sha256':hashlib.sha256(append).hexdigest(),'baseline_prefix_preserved':True,'new_grouped_entries':1},'original_archive_sha256':old_receipt['artifacts']['sha256'],'original_observations_manifest':'phase-before-review-fixes/artifact-manifest.json','original_observations_count':len(old_manifest)}
write(out/'parent-workflow-bookkeeping.json',bookkeeping)
source=root/'tests/Hexalith.Folders.IntegrationTests/EndToEnd/GoldenLifecycleParityTests.cs';review=json.loads((out/'review-fixes-observations.json').read_text());assert sha(source)==review['source_sha256']
resolved={'status':'resolved and independently verified by parent final commands','source_file':str(source.relative_to(root)),'source_sha256':sha(source),'resolutions':{'B4':'Mutate-files-only v2 context request asserts safe redacted 404/resource_unavailable and zero context-source calls before legitimate read_metadata grants; REST and SDK success checks retained.','B5':'Removed IContentAuthority authorization substitute; registered production WorkspaceContentAuthority now enforces current principal/resource/task/policy checks.','B6/E1':'Removed CommandId-only publication matcher; production authority performs complete scope/task/fence/version/receipt/metadata matching.','B8':'Immediately after accepted AddFile, its own folder must remain ChangesStaged before publication/byte checks and unrelated commit.'},'actor_snapshot':'Golden host supplies its legitimate seeded in-memory actor snapshot to /process using web JSON casing, and supplies null snapshot for an uncreated aggregate. Shared gateway and product code unchanged.','diagnostics':'review-fixes-observations.json','final_parent_records':'parent-final-verification/parent-final-command-records.json','parent_full_focused_results':{'Debug/source':115,'Release/package':115},'new_parent_commands_executed_by_implementation_agent':0}
write(out/'review-fixes-resolved.json',resolved)
print(json.dumps({'appended_parent_records':len(records),'all_original_observations_preserved':len(old_manifest),'approved_frozen_block_unchanged':True,'deferred_group_append_count':1,'source_sha256':sha(source)},indent=2))
