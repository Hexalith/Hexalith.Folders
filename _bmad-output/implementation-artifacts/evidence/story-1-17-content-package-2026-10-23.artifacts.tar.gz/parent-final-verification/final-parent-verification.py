import datetime,hashlib,json,pathlib,re,subprocess,sys
root=pathlib.Path('/home/administrator/projects/hexalith/folders')
work=pathlib.Path('/tmp/story117-content-20261024-p23zx585')
project='tests/Hexalith.Folders.IntegrationTests/Hexalith.Folders.IntegrationTests.csproj'
classes=['Hexalith.Folders.IntegrationTests.WorkspaceContentProcessWiringTests','Hexalith.Folders.IntegrationTests.Routing.FoldersApiRoutingModeTests','Hexalith.Folders.IntegrationTests.EndToEnd.GoldenLifecycleParityTests']
filters=[part for name in classes for part in ('-class',name)]
commands=[('parent-final-source-build',root,['dotnet','build',project,'--configuration','Debug','-p:UseNuGetDeps=false','-m:1']),('parent-final-source-tests',root,['dotnet','tests/Hexalith.Folders.IntegrationTests/bin/Debug/net10.0/Hexalith.Folders.IntegrationTests.dll',*filters,'-xml',str(work/'parent-final-source-tests.xml')]),('parent-final-folders-release-build',root,['dotnet','build','Hexalith.Folders.CI.slnx','--configuration','Release','-p:UseNuGetDeps=true','-warnaserror','-m:1']),('parent-final-projects-release-build',root/'references/Hexalith.Projects',['dotnet','build','Hexalith.Projects.CI.slnx','--configuration','Release','-p:UseNuGetDeps=true','-warnaserror','-m:1']),('parent-final-package-tests',root,['dotnet','tests/Hexalith.Folders.IntegrationTests/bin/Release/net10.0/Hexalith.Folders.IntegrationTests.dll',*filters,'-xml',str(work/'parent-final-package-tests.xml')]),('parent-final-format',root,['dotnet','format','whitespace',project,'--no-restore','--verify-no-changes','--include','tests/Hexalith.Folders.IntegrationTests/EndToEnd/GoldenLifecycleParityTests.cs'])]
records=[]
for label,cwd,argv in commands:
 print('Running '+label,flush=True); started=datetime.datetime.now(datetime.timezone.utc).isoformat(); p=work/(label+'.log')
 with p.open('wb') as out: r=subprocess.run(argv,cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
 data=p.read_bytes(); output=data.decode(errors='replace')
 record={'label':label,'cwd':str(cwd),'argv':argv,'started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'log':str(p),'log_sha256':hashlib.sha256(data).hexdigest(),'kind':'parent_final_validation'}
 matches=re.findall(r'Total:\s*(\d+), Errors:\s*(\d+), Failed:\s*(\d+), Skipped:\s*(\d+), Not Run:\s*(\d+)',output)
 if matches:
  total,errors,failed,skipped,not_run=map(int,matches[-1]); record['tests']={'total':total,'passed':total-errors-failed-skipped-not_run,'errors':errors,'failed':failed,'skipped':skipped,'not_run':not_run}
 if '-xml' in argv:
  xml=pathlib.Path(argv[argv.index('-xml')+1]); record['xml']={'path':str(xml),'sha256':hashlib.sha256(xml.read_bytes()).hexdigest()}
 records.append(record); (work/'parent-final-command-records.json').write_text(json.dumps(records,indent=2)+'\n')
 summaries=[line.strip() for line in output.splitlines() if 'Total:' in line or line.strip() in ('Build succeeded.','Build FAILED.')]
 print(label+': exit '+str(r.returncode)+'; '+' | '.join(summaries),flush=True)
 if r.returncode:
  for line in output.splitlines():
   if '[FAIL]' in line or 'error ' in line or 'Error:' in line: print(line[:800],flush=True)
  sys.exit(r.returncode)
print('All parent final commands passed.',flush=True)
