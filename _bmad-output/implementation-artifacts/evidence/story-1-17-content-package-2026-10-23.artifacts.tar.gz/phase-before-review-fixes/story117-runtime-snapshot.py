from pathlib import Path
import sys,json,hashlib,xml.etree.ElementTree as ET,zipfile
root=Path('/home/administrator/projects/hexalith/folders');out=Path(Path('/tmp/story117-content-evidence-location').read_text());label=sys.argv[1];config=sys.argv[2]
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
packages=json.loads((out/'packages.json').read_text());dlls={Path(name).name.lower():{'package':Path(package['path']).name,'entry':name,'sha256':digest} for package in packages for name,digest in package['dlls'].items()}
results={'label':label,'configuration':config,'projects':[],'runtimes':[]}
for owner,base,solution in [('folders',root,'Hexalith.Folders.CI.slnx'),('projects',root/'references/Hexalith.Projects','Hexalith.Projects.CI.slnx')]:
    for element in ET.fromstring((base/solution).read_bytes()).iter('Project'):
        project=base/element.attrib['Path'];assets=project.parent/'obj/project.assets.json'
        if not assets.exists(): continue
        data=json.loads(assets.read_text());eventstore={name:value.get('type') for name,value in data['libraries'].items() if name.startswith('Hexalith.EventStore.')}
        results['projects'].append({'owner':owner,'project':str(project.relative_to(root)),'assets_sha256':sha(assets),'eventstore_libraries':eventstore})
relatives = ['tests/Hexalith.Folders.IntegrationTests'] if config == 'Debug' else ['tests/Hexalith.Folders.IntegrationTests','tests/Hexalith.Folders.Server.Tests','references/Hexalith.Projects/tests/Hexalith.Projects.Server.Tests']
for relative in relatives:
    path=root/relative/'bin'/config/'net10.0';runtime={'path':str(path.relative_to(root)),'dlls':[]}
    for dll in sorted(path.glob('Hexalith.EventStore.*.dll')):
        digest=sha(dll);expected=dlls.get(dll.name.lower());source=root/'references/Hexalith.EventStore/src'/dll.stem/'bin/Debug/net10.0'/dll.name;runtime['dlls'].append({'name':dll.name,'sha256':digest,'package_match':bool(expected and expected['sha256']==digest),'source_match':source.exists() and sha(source)==digest,'source_path':str(source.relative_to(root)),'signed_package':expected})
    for artifact in path.glob('*.deps.json'):
        name=label+'-'+artifact.name; (out/name).write_bytes(artifact.read_bytes());runtime.setdefault('deps',[]).append({'path':str(artifact.relative_to(root)),'sha256':sha(artifact),'retained':name})
    main=next((path/name for name in ['Hexalith.Folders.IntegrationTests.dll','Hexalith.Folders.Server.Tests.dll','Hexalith.Projects.Server.Tests.dll'] if (path/name).exists()),None)
    if main: runtime['test_assembly']={'name':main.name,'sha256':sha(main)}
    results['runtimes'].append(runtime)
(out/(label+'-runtime.json')).write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'label':label,'asset_projects':len(results['projects']),'runtime_matches':{item['path']:all(dll['package_match'] for dll in item['dlls']) for item in results['runtimes']}},indent=2))
