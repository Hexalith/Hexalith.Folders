import sys, os, json, pathlib, hashlib, subprocess, datetime, tempfile, fcntl
ROOT = pathlib.Path('/home/administrator/projects/hexalith/folders')
LOCATION = pathlib.Path('/tmp/story117-content-evidence-location')
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def git(cwd,*args):
    result = subprocess.run(['git',*args],cwd=cwd,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'},capture_output=True,text=True)
    if result.returncode: raise RuntimeError(result.stderr)
    return result.stdout

def snapshot():
    owners = { 'folders': ROOT, 'builds': ROOT/'references/Hexalith.Builds', 'projects':ROOT/'references/Hexalith.Projects' }
    result={}
    for name,cwd in owners.items():
        files={}
        for relative in git(cwd,'ls-files','-z').split('\0'):
            path=cwd/relative
            if relative and path.is_file(): files[relative]=sha(path)
        result[name]={'root':str(cwd),'head':git(cwd,'rev-parse','HEAD').strip(),'refs':git(cwd,'show-ref'),'status':git(cwd,'status','--short'),'index':git(cwd,'ls-files','--stage'),'files':files}
    result['submodules'] = git(ROOT,'submodule','status')
    return result
if sys.argv[1]=='init':
    directory=pathlib.Path(tempfile.mkdtemp(prefix='story117-content-'))
    LOCATION.write_text(str(directory))
    (directory/'preservation-before.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
    (directory/'commands.json').write_text('[]\n')
    print(directory)
elif sys.argv[1]=='run':
    directory=pathlib.Path(LOCATION.read_text()); label=sys.argv[2]; cwd=sys.argv[3]; args=sys.argv[4:]
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (directory/(label+'.log')).open('w') as log:
        proc=subprocess.run(args,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
    with (directory/'commands.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        records=json.loads((directory/'commands.json').read_text())
        records.append({'label':label,'cwd':cwd,'argv':args,'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':proc.returncode,'log':label+'.log','log_sha256':sha(directory/(label+'.log'))})
        (directory/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print((directory/(label+'.log')).read_text()[-2500:])
    sys.exit(proc.returncode)
elif sys.argv[1]=='after':
    directory=pathlib.Path(LOCATION.read_text())
    (directory/'preservation-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
    print(directory)
