import ast, datetime, hashlib, json, shutil, subprocess, tarfile
from pathlib import Path

ROOT=Path('/home/administrator/projects/hexalith/folders')
BASE=ROOT/'_bmad-output/implementation-artifacts'
OUT=Path(__file__).parent
NAME='story-1-17-cli-4-38-loader-root-preflight-2026-10-26'
def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def bind(path):return dict(path=str(path.relative_to(ROOT)),sha256=sha(path),bytes=path.stat().st_size)
def write(path,value):Path(path).write_text(json.dumps(value,indent=2)+'\n')
def git(repo,*args):return subprocess.check_output(['git','-C',str(ROOT/repo),*args])
pre=json.loads((OUT/'preflight.json').read_text())
plan_path=BASE/'story-1-17-cli-4-38-loader-root-rebind-plan-2026-10-26.json'
plan=json.loads(plan_path.read_text())
adapter=ROOT/plan['adapter']['path'];ast.parse(adapter.read_text())
assert sha(adapter)==plan['adapter']['sha256']
for item in pre['verifiedOriginalBindings']+[plan['originalPlan'],plan['originalExecutionApproval']]:
    p=ROOT/item['path'];assert sha(p)==item['sha256'] and p.stat().st_size==item['bytes']
baseline=plan['rootBaselineRevision'];assert git('.','rev-parse','HEAD').decode().strip()==baseline
assert len(plan['rootRecordingPaths'])==8 and len(set(plan['rootRecordingPaths']))==8
assert plan['separatelyAllowedApprovalPath'] not in plan['rootRecordingPaths']
assert all('*' not in path and '?' not in path for path in plan['rootRecordingPaths'])
assert plan['originalPlan']['sha256']=='83fec7a858d1e1a8e9a9e1f514803a7ccb5408f56b1ef15c7c5bad12e4c42e7f'
old_plan=json.loads((ROOT/plan['originalPlan']['path']).read_text())
old_inputs=json.loads((ROOT/next(x['path'] for x in old_plan['artifacts'] if x['path'].endswith('/inputs.json'))).read_text())
control=json.loads(json.dumps(old_inputs));control['repositories']['.']=plan['inputDerivation']['currentConcreteValues']
assert hashlib.sha256((json.dumps(control,indent=2)+'\n').encode()).hexdigest()==plan['inputDerivation']['currentConcreteSha256']
old_root=old_inputs['repositories']['.'];control['repositories']['.']=old_root;assert control==old_inputs
states={}
for rel,expected in pre['repositories'].items():
    actual=dict(revision=git(rel,'rev-parse','HEAD').decode().strip(),indexEntriesSha256=hashlib.sha256(git(rel,'ls-files','--stage')).hexdigest(),
        status=git(rel,'status','--porcelain=v2','--untracked-files=all').decode(),staged=git(rel,'diff','--cached','--raw').decode())
    assert actual['revision']==expected['revision'] and actual['indexEntriesSha256']==expected['indexEntriesSha256']
    assert actual['staged']=='' and git(rel,'diff','--name-only')==b''
    if rel!='.':assert actual['status']==''
    states[rel]=actual
untracked=[x.decode() for x in git('.','ls-files','--others','--exclude-standard','-z').split(b'\0') if x]
assert set(untracked)<=set(plan['rootRecordingPaths']),untracked
validation=dict(recordedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),newAdapterAstParsed=True,
    originalBindingsPreserved=True,originalExecutionApprovalPreserved=True,
    rebindSourceFieldsExactlyTwo=True,recordingPathsExactlyEight=True,noWildcardPredicate=True,
    actualRootRevision=baseline,repositories=states,
    sdkCommandsExecuted=0,probeCompilerExecuted=False,modelBuildExecuted=False,modelOrHostLoaded=False,
    adapterExecuted=False,originalDriverInvoked=False,rebindAuthorityPending=True,
    limitation='Static syntax/hash/data and read-only Git checks only. Root predicate, adapter and sandbox have not been executed as a qualification lane.')
write(OUT/'validation.json',validation)
authored=[BASE/'story-1-17-cli-4-38-loader-authorization-2026-10-26.json',adapter,plan_path,
    BASE/'story-1-17-cli-4-38-loader-root-rebind-2026-10-26.md',BASE/'spec-1-17-cli-4-38-loader-root-rebind.md']
for p in authored:
    target=OUT/'proposal'/p.name;target.parent.mkdir(exist_ok=True);shutil.copyfile(p,target)
files=sorted(p for p in OUT.rglob('*') if p.is_file())
manifest=dict(format='sha256-file-members-v1',members=[dict(path=str(p.relative_to(OUT)),bytes=p.stat().st_size,sha256=sha(p)) for p in files])
manifest_path=BASE/'evidence'/f'{NAME}.members.json';write(manifest_path,manifest)
archive_path=BASE/'evidence'/f'{NAME}.artifacts.tar.gz'
with tarfile.open(archive_path,'w:gz') as archive:
    for p in files:archive.add(p,arcname=str(p.relative_to(OUT)),recursive=False)
with tarfile.open(archive_path) as archive:
    assert len([v for v in archive.getmembers() if v.isfile()])==len(manifest['members'])
    for item in manifest['members']:
        member=archive.getmember(item['path']);assert member.size==item['bytes']
        assert hashlib.file_digest(archive.extractfile(member),'sha256').hexdigest()==item['sha256']
receipt=dict(recordId='STORY-1-17-CLI-4-38-LOADER-ROOT-PREFLIGHT-2026-10-26',recordedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    status='PRE_SDK_ROOT_GATE_STOP_REBIND_PROPOSED',approval=bind(authored[0]),approvedOriginalPlan=plan['originalPlan'],
    stopCondition='Root revision drift, including a later proposal-only commit: stop for explicit revised tuple disposition; do not amend approval automatically.',
    actualBlocker=dict(approvedRootRevision=old_plan['rootRevision'],observedRootRevision=baseline,
        approvedRootIndexSha256=old_inputs['repositories']['.']['indexEntriesSha256'],observedRootIndexSha256=pre['repositories']['.']['indexEntriesSha256'],
        onlyAddsNineBoundProposalArtifacts=True,originalDriverInvoked=False),
    originalApprovalAuthorized=True,originalApprovalRevoked=False,rootRebindAuthorized=False,
    readonlyPreflight=pre,validation=validation,
    rebindProposal=bind(plan_path),authoredArtifacts=[bind(p) for p in authored],
    artifactArchive=bind(archive_path),memberManifest=bind(manifest_path),membersVerified=len(manifest['members']),
    proposedOperationalPatch=None,qualificationInputDerivation=plan['inputDerivation'],
    retainedHolds=dict(ordinaryMapping=None,ContentHash=None,parentStatus='in-progress',trackerStatus='backlog',routeMode='V1Only',T0=None,activationAuthority=None,
        stagingChecks=dict(total=14,executed=0),historicalAcceptedCli='4.35.2',candidateCli='4.38.0',currentTupleAccepted=False,packageAccepted=False,hostedAccepted=False),
    executionCounts=dict(sdkCommands=0,probeCompiler=0,modelBuilds=0,modelOrHostLoads=0,loaderCases=0,ordinaryCliAttempts=0,stagingChecks=0),
    unchangedHistoricalLimitations='Original compile immediate SDK identity gate remains incomplete; certificate, inherited environment, overwritten failure/PDB and bounded process-observation limitations all retained. No historical check or build repeated.',
    staged=False,committed=False,pushed=False,published=False,deployed=False,dependenciesChanged=False,nestedSubmodulesInitialized=False)
receipt_path=BASE/'evidence'/f'{NAME}.json';write(receipt_path,receipt)
print(json.dumps(dict(result=receipt['status'],receipt=str(receipt_path),receiptSha256=sha(receipt_path),
    rebindPlanSha256=sha(plan_path),verifiedArchiveMembers=len(manifest['members']),
    approvals='Original execution yes preserved; new root predicate pending',SDKCommands=0,loaderCases=0)))
