import datetime, hashlib, json, subprocess, tarfile
from pathlib import Path

ROOT = Path('/home/administrator/projects/hexalith/folders')
BASE = ROOT / '_bmad-output/implementation-artifacts'
OUT = Path(__file__).parent
def sha(path):
    with Path(path).open('rb') as stream: return hashlib.file_digest(stream, 'sha256').hexdigest()
def bind(path): return dict(path=str(path.relative_to(ROOT)), bytes=path.stat().st_size, sha256=sha(path))
def save(name, data): (OUT / name).write_text(json.dumps(data, indent=2) + '\n')
def command(label, repo, *argv):
    args=['git','-C',str(ROOT/repo),*argv]
    result=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (OUT/(label+'.stdout')).write_bytes(result.stdout);(OUT/(label+'.stderr')).write_bytes(result.stderr)
    save(label+'.command.json',dict(atUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),argv=args,
        exitCode=result.returncode,stdoutSha256=hashlib.sha256(result.stdout).hexdigest(),stderrSha256=hashlib.sha256(result.stderr).hexdigest()))
    assert result.returncode==0,(args,result.stderr.decode());return result.stdout

plan_path=BASE/'story-1-17-cli-4-38-runtime-resolution-plan-2026-10-26.json'
plan=json.loads(plan_path.read_text());inputs=json.loads((ROOT/plan['artifacts'][2]['path']).read_text())
assert sha(plan_path)=='83fec7a858d1e1a8e9a9e1f514803a7ccb5408f56b1ef15c7c5bad12e4c42e7f'
repos={}
for i,(repo,expected) in enumerate(inputs['repositories'].items()):
    revision=command(f'repo-{i}-revision',repo,'rev-parse','HEAD').decode().strip()
    index=command(f'repo-{i}-index',repo,'ls-files','--stage')
    status=command(f'repo-{i}-status',repo,'status','--porcelain=v2','--untracked-files=all').decode()
    staged=command(f'repo-{i}-staged',repo,'diff','--cached','--raw').decode()
    repos[repo]=dict(revision=revision,indexEntriesSha256=hashlib.sha256(index).hexdigest(),status=status,staged=staged,
        revisionMatches=revision==expected['revision'],indexMatches=hashlib.sha256(index).hexdigest()==expected['indexEntriesSha256'])
    assert status=='' and staged==''
    if repo!='.': assert repos[repo]['revisionMatches'] and repos[repo]['indexMatches']
revision=repos['.']['revision'];assert revision=='43423a9849c82a3a526590b0fa6e613768e7eb24'
diff=command('root-transition','.', 'diff','--name-status','--no-renames',plan['rootRevision'],revision).decode()
entries=[line.split('\t') for line in diff.splitlines()]
prior=json.loads((BASE/'evidence/story-1-17-cli-4-38-runtime-resolution-2026-10-26.json').read_text())
expected={x['path'] for x in prior['authoredArtifacts']+[prior['artifactArchive'],prior['memberManifest']]}
expected.add('_bmad-output/implementation-artifacts/evidence/story-1-17-cli-4-38-runtime-resolution-2026-10-26.json')
assert len(entries)==9 and {p for status,p in entries}==expected and all(status=='A' for status,p in entries)
verified=[]
for item in plan['artifacts']+plan['supportingArtifacts']+inputs['preservedFiles']+[prior['artifactArchive'],prior['memberManifest']]:
    p=ROOT/item['path'];assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256'];verified.append(item)
for item in inputs['sdk']['files']:
    p=Path(item['path']);assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256']
for item in [inputs['package'],inputs['modelArchive']]:
    p=Path(item['path']) if Path(item['path']).is_absolute() else ROOT/item['path']
    assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256']
manifest=json.loads((ROOT/prior['memberManifest']['path']).read_text())['members']
with tarfile.open(ROOT/prior['artifactArchive']['path']) as archive:
    files=[m for m in archive.getmembers() if m.isfile()];assert len(files)==len(manifest)
    for item in manifest:
        m=archive.getmember(item['path']);assert m.size==item['bytes']
        assert hashlib.file_digest(archive.extractfile(m),'sha256').hexdigest()==item['sha256']
save('preflight.json',dict(recordedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    approvedPlan=bind(plan_path),repositories=repos,transition=dict(old=plan['rootRevision'],new=revision,entries=entries,
        onlyAddsNineBoundProposalArtifacts=True,files=[bind(ROOT/p) for _,p in entries]),
    verifiedOriginalBindings=verified,sdkFilesRehashed=len(inputs['sdk']['files']),packageAndModelArchiveRehashed=True,
    reusedStaticArchiveMembersVerified=len(manifest),
    stoppedBeforeSdk=True,sdkCommandsExecuted=0,probeCompilerExecuted=False,modelBuildExecuted=False,
    hostOrModelAssemblyLoaded=False,probeCasesExecuted=0,executionDriverInvoked=False,
    blocker='Approved plan explicitly stops on any root revision drift, including proposal-only commits. Root revision and stage-entry hash differ; direct repositories and all inspected bytes match.'))
approval=dict(recordId='STORY-1-17-CLI-4-38-LOADER-AUTHORIZATION-2026-10-26',decisionMaker='Jerome',reply='yes',
    recordedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),authorized=True,
    scope=plan['scope'],planSha256=sha(plan_path),sha256={Path(x['path']).name:x['sha256'] for x in plan['artifacts']},
    approvedRootRevision=plan['rootRevision'],observedRootRevision=revision,
    repositoryState={k:{f:v[f] for f in ['revision','indexEntriesSha256','status']} for k,v in repos.items()},
    executionCleared=False,rootRevisionRebindingAuthorized=False,
    disposition='Owner approved exact original two-case plan. Its root-drift gate failed in read-only preflight before SDK/driver/probe execution. Approval is retained, not widened to the new root.',
    publicationAuthorized=False,deploymentAuthorized=False,trackerTransitionAuthorized=False,currentTupleAccepted=False)
approval_path=BASE/'story-1-17-cli-4-38-loader-authorization-2026-10-26.json'
assert not approval_path.exists();approval_path.write_text(json.dumps(approval,indent=2)+'\n')
print(json.dumps(dict(result='ROOT_REVISION_GATE_STOP',old=plan['rootRevision'],current=revision,
    directRepositoriesPreserved=12,bindingsVerified=len(verified),sdkFilesRehashed=len(inputs['sdk']['files']),
    sdkCommandsExecuted=0,probeCasesExecuted=0,approval=str(approval_path))))
