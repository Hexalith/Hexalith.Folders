Verify the external archive SHA-256 and member-manifest SHA-256 from the receipt before extraction.
Extract into a disposable directory, then run:
  PYTHONDONTWRITEBYTECODE=1 python3 replay.py
  PYTHONDONTWRITEBYTECODE=1 python3 -O replay.py
  PYTHONDONTWRITEBYTECODE=1 python3 test_replay.py
Optional current-workspace drift check:
  python3 replay.py --workspace /absolute/path/to/Hexalith.Folders

Replay reads retained artifacts only and performs no network, publication, deployment or orchestration.
The optional workspace check additionally rehashes current workspace source/build artifacts and refuses drift.
Compiler inputs, actual compiler arguments, generator/analyzer/configuration identities, portable-PDB document
checksums and equivalent-profile expanded-import observations are retained in compiled-inputs.json and source-bindings.json.
Expanded XML was a disposable derivation; only its observed hash, full import map and hashed source inputs are retained.
The exact PDBs, DLLs, runtime manifests, signed retained archives and unsigned diagnostic archives are present.
To inspect PDB metadata independently, the BCL-only inspector source and executable are in capture-tools/.
Capture-tools scripts record the historical commands/recipes, including corrected failed attempts; they use
portable placeholders and are not automatic provisioning/publication entry points. replay.py is the runnable verifier.

The ordinary Projects source workspace gate remains failed on missing source roots; the separate full-CI
explicit-root probe uses an existing exact clean Conversations snapshot and isolated build outputs. Its
initial 42 environment failures are retained separately from the final 140/140 owned-state result.
The Redis/daprd harness was temporary, local and loopback-only; exact cleanup is retained. It qualifies no
hosted runtime, identity, deployment or operational acceptance. Dated Folders topology readiness is reused
only for its inspected unchanged source/configuration closure and retains its authentication limits.

Local source/package preparation is distinct from the retained released 1.3.1 pair and absent hosted artifacts.
Actual changed-tuple tool/catalog/composition acceptance and all owner/intake/operational handoffs remain open.
V1Only; T0 unset; activation authority null; 0 staging checks executed; parent in-progress; tracker backlog.
