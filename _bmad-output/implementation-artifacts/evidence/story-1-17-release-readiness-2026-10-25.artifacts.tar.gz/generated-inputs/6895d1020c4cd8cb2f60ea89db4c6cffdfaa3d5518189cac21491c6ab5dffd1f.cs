// <copyright file="ConversationProjectionMaterializer.cs" company="ITANEO">
// Copyright (c) ITANEO. All rights reserved.
// Licensed under the MIT License.
// </copyright>

using Hexalith.Conversations.Contracts.Events;
using Hexalith.Conversations.Contracts.Governance;
using Hexalith.Conversations.Contracts.Identifiers;
using Hexalith.Conversations.Contracts.Participants;
using Hexalith.Conversations.Contracts.Projections;
using Hexalith.Conversations.Contracts.Queries;
using Hexalith.Conversations.Contracts.TrustStates;
using Hexalith.Conversations.Contracts.Versioning;

namespace Hexalith.Conversations.Server.Projections;

/// <summary>
/// Builds tenant-scoped conversation read models from public conversation events.
/// </summary>
/// <remarks>
/// This is the conversation-specific kept logic (field selection, freshness formula, evidence construction, and
/// the idempotent per-event accumulator) that survives the FR-6 projection-seam adoption. It is the single shared
/// materialization entry point invoked by both the platform projection-seam handler
/// (<see cref="ConversationProjectionHandler"/>) and <see cref="ConversationProjectionRebuildVerifier"/>; the
/// generic replay/dispatch/discovery orchestration is owned by the platform SDK, not duplicated here.
/// </remarks>
public sealed class ConversationProjectionMaterializer
{
    private const string ArchivedState = "Archived";
    private const string ClosedState = "Closed";
    private const string InitializingState = "Initializing";
    private const string OpenState = "Open";

    /// <summary>
    /// Projects a summary/detail pair from an ordered public event sequence.
    /// </summary>
    /// <param name="tenantId">The tenant this projection is allowed to materialize.</param>
    /// <param name="conversationId">The conversation this projection is allowed to materialize.</param>
    /// <param name="events">The public event sequence.</param>
    /// <param name="projectionGeneratedAt">The projection generation time.</param>
    /// <param name="staleAfter">The freshness threshold.</param>
    /// <param name="isRebuilding">A value indicating whether rebuild or catch-up work is active.</param>
    /// <param name="metadataWriteFailed">A value indicating whether projection mutation succeeded but metadata update failed.</param>
    /// <returns>The projected summary/detail pair.</returns>
    public ConversationProjectedReadModels Project(
        TenantId tenantId,
        ConversationId conversationId,
        IEnumerable<ConversationProjectionEventRecord> events,
        DateTimeOffset projectionGeneratedAt,
        TimeSpan staleAfter,
        bool isRebuilding = false,
        bool metadataWriteFailed = false)
    {
        ArgumentNullException.ThrowIfNull(tenantId);
        ArgumentNullException.ThrowIfNull(conversationId);
        ArgumentNullException.ThrowIfNull(events);
        ArgumentOutOfRangeException.ThrowIfLessThanOrEqual(staleAfter, TimeSpan.Zero);

        ProjectionBuilder builder = new(tenantId, conversationId);
        foreach (ConversationProjectionEventRecord record in events)
        {
            builder.Apply(record);
        }

        ProjectionFreshnessV1 freshness = CreateFreshness(
            builder,
            projectionGeneratedAt,
            staleAfter,
            isRebuilding,
            metadataWriteFailed);
        ConversationSearchTrustPreviewV1 searchTrustPreview = CreateSearchTrustPreview(builder, freshness);
        ConversationEvidenceTrustPostureV1 trustPosture = CreateTrustPosture(builder, freshness);
        IReadOnlyList<ConversationEvidenceEntryV1> evidenceEntries = CreateEvidenceEntries(builder, freshness);

        ConversationSummaryProjectionV1 summary = new(
            SchemaVersion.Current,
            tenantId,
            conversationId,
            freshness,
            builder.LifecycleState,
            builder.Label,
            builder.BusinessReference,
            builder.ProjectId,
            builder.FolderId,
            builder.ParticipantPartyIds,
            builder.Messages.Count,
            builder.FileReferences.Count,
            builder.ProviderCorrelation,
            searchTrustPreview);

        ConversationDetailProjectionV1 detail = new(
            SchemaVersion.Current,
            tenantId,
            conversationId,
            freshness,
            builder.LifecycleState,
            builder.Label,
            builder.BusinessReference,
            builder.ProjectId,
            builder.FolderId,
            builder.ProviderCorrelation,
            builder.Participants,
            builder.Messages,
            builder.FileReferences,
            builder.Attributes,
            builder.ActiveRetentionPolicy,
            builder.SensitivityMarks,
            builder.Redactions,
            trustPosture,
            evidenceEntries);

        return new(summary, detail) { ResolutionScoringLabel = builder.ResolutionScoringLabel };
    }

    private static ProjectionFreshnessV1 CreateFreshness(
        ProjectionBuilder builder,
        DateTimeOffset projectionGeneratedAt,
        TimeSpan staleAfter,
        bool isRebuilding,
        bool metadataWriteFailed)
    {
        // ProjectionFreshnessV1 requires position >= 1; clamp here for the no-events case so the
        // freshness can still be constructed. The empty-stream path is non-current by definition
        // (WasCreated is false, so the projection is Rebuilding), and consumers must not trust the
        // synthesized cursor for ordering.
        long position = Math.Max(builder.LastAppliedPosition, 1);
        DateTimeOffset lastApplied = builder.LastAppliedTimestamp ?? projectionGeneratedAt;
        bool contradictoryTimestamp = projectionGeneratedAt < lastApplied;

        // When metadata is contradictory the projection is reported as Unavailable. The public
        // ProjectionGeneratedAt is clamped to lastApplied so the contract invariant
        // (generatedAt >= lastApplied) holds; consumers must not treat the clamped value as truth.
        DateTimeOffset publicGeneratedAt = contradictoryTimestamp ? lastApplied : projectionGeneratedAt;
        TimeSpan lag = publicGeneratedAt - lastApplied;

        ProjectionTrustState state = ProjectionTrustState.Current;
        ProjectionFreshnessReasonCode reason = ProjectionFreshnessReasonCode.Current;
        bool stale = false;

        if (metadataWriteFailed)
        {
            state = ProjectionTrustState.Unavailable;
            reason = ProjectionFreshnessReasonCode.MetadataWriteFailed;
        }
        else if (builder.SourceDeleted)
        {
            state = ProjectionTrustState.Unavailable;
            reason = ProjectionFreshnessReasonCode.Unavailable;
        }
        else if (builder.Poisoned)
        {
            state = ProjectionTrustState.Unavailable;
            reason = ProjectionFreshnessReasonCode.PoisonEvent;
        }
        else if (builder.UnsupportedVersion)
        {
            state = ProjectionTrustState.Unavailable;
            reason = ProjectionFreshnessReasonCode.Unavailable;
        }
        else if (contradictoryTimestamp)
        {
            state = ProjectionTrustState.Unavailable;
            reason = ProjectionFreshnessReasonCode.MetadataContradictory;
        }
        else if (builder.HasGap)
        {
            state = ProjectionTrustState.Rebuilding;
            reason = ProjectionFreshnessReasonCode.GapDetected;
        }
        else if (builder.HasOutOfOrderEvent)
        {
            state = ProjectionTrustState.Rebuilding;
            reason = ProjectionFreshnessReasonCode.OutOfOrderEvent;
        }
        else if (isRebuilding || !builder.WasCreated)
        {
            state = ProjectionTrustState.Rebuilding;
            reason = ProjectionFreshnessReasonCode.Rebuilding;
        }
        else if (lag > staleAfter)
        {
            state = ProjectionTrustState.Stale;
            reason = ProjectionFreshnessReasonCode.StaleThresholdExceeded;
            stale = true;
        }

        return new ProjectionFreshnessV1(
            SchemaVersion.Current,
            FormatCursor(position),
            position,
            lastApplied,
            publicGeneratedAt,
            lag,
            stale,
            state,
            reason);
    }

    private static string FormatCursor(long position)
        => FormattableString.Invariant($"pos:{position:D10}");

    private static ConversationSearchTrustPreviewV1 CreateSearchTrustPreview(
        ProjectionBuilder builder,
        ProjectionFreshnessV1 freshness)
    {
        bool current = freshness.AllowsTrustBearingDecision();
        ProjectionTrustState redactionState = builder.Redactions.Count > 0
            ? ProjectionTrustState.Redacted
            : current ? ProjectionTrustState.Current : ProjectionTrustState.Unavailable;
        ConversationCitationAvailability citationAvailability = current && builder.WasCreated
            ? ConversationCitationAvailability.Available
            : ConversationCitationAvailability.Unavailable;
        ConversationAuditReadinessState auditReadiness = current && builder.HasAuditEvidence
            ? ConversationAuditReadinessState.Ready
            : current ? ConversationAuditReadinessState.Incomplete : ConversationAuditReadinessState.Unknown;

        return new(
            freshness.FreshnessState,
            freshness.ReasonCode,
            redactionState,
            builder.ParticipantPartyIds.Count == 0 ? ProjectionTrustState.Current : ProjectionTrustState.Unavailable,
            citationAvailability,
            auditReadiness,
            ConversationVerificationState.Unknown,
            ConversationSearchMatchSource.TenantScope,
            current
                ? "Visible through authorized tenant scope."
                : "Visible through authorized tenant scope with non-current metadata.");
    }

    private static ConversationEvidenceTrustPostureV1 CreateTrustPosture(
        ProjectionBuilder builder,
        ProjectionFreshnessV1 freshness)
    {
        bool current = freshness.AllowsTrustBearingDecision();
        ProjectionTrustState completeness = current && builder.WasCreated
            ? ProjectionTrustState.Current
            : freshness.FreshnessState == ProjectionTrustState.Current ? ProjectionTrustState.Unavailable : freshness.FreshnessState;
        ConversationAuditReadinessState auditReadiness = current && builder.HasAuditEvidence
            ? ConversationAuditReadinessState.Ready
            : current ? ConversationAuditReadinessState.Incomplete : ConversationAuditReadinessState.Unknown;
        ConversationCitationAvailability citationAvailability = current && builder.WasCreated
            ? ConversationCitationAvailability.Available
            : ConversationCitationAvailability.Unavailable;

        return new(
            SchemaVersion.Current,
            builder.TenantId,
            builder.ConversationId,
            freshness.ProjectionCursor,
            freshness,
            completeness,
            builder.ParticipantPartyIds.Count == 0 ? ProjectionTrustState.Current : ProjectionTrustState.Unavailable,
            citationAvailability,
            auditReadiness,
            ConversationVerificationState.Unknown,
            DefaultCommandEligibility(freshness, auditReadiness));
    }

    private static IReadOnlyList<ConversationCommandAvailabilityV1> DefaultCommandEligibility(
        ProjectionFreshnessV1 freshness,
        ConversationAuditReadinessState auditReadiness)
        =>
        [
            new ConversationCommandAvailabilityV1(
                "set-retention-policy",
                ProjectionTrustState.Unavailable,
                "conversations.governance",
                freshness.FreshnessState,
                "governance",
                ProjectionTrustState.Current,
                auditReadiness,
                "Command execution is blocked from the governed read surface.",
                freshness.ProjectionGeneratedAt),
            new ConversationCommandAvailabilityV1(
                "mark-content-sensitive",
                ProjectionTrustState.Unavailable,
                "conversations.governance",
                freshness.FreshnessState,
                "governance",
                ProjectionTrustState.Current,
                auditReadiness,
                "Command execution is blocked from the governed read surface.",
                freshness.ProjectionGeneratedAt),
            new ConversationCommandAvailabilityV1(
                "redact-message-content",
                ProjectionTrustState.Unavailable,
                "conversations.governance",
                freshness.FreshnessState,
                "governance",
                ProjectionTrustState.Current,
                auditReadiness,
                "Command execution is blocked from the governed read surface.",
                freshness.ProjectionGeneratedAt),
        ];

    private static IReadOnlyList<ConversationEvidenceEntryV1> CreateEvidenceEntries(
        ProjectionBuilder builder,
        ProjectionFreshnessV1 freshness)
    {
        List<ConversationEvidenceEntryV1> entries = [];
        ProjectionTrustState currentOrUnavailable = freshness.AllowsTrustBearingDecision()
            ? ProjectionTrustState.Current
            : ProjectionTrustState.Unavailable;
        ConversationCitationAvailability citationAvailability = freshness.AllowsTrustBearingDecision()
            ? ConversationCitationAvailability.Available
            : ConversationCitationAvailability.Unavailable;
        ConversationAuditReadinessState auditReadiness = freshness.AllowsTrustBearingDecision() && builder.HasAuditEvidence
            ? ConversationAuditReadinessState.Ready
            : freshness.AllowsTrustBearingDecision() ? ConversationAuditReadinessState.Incomplete : ConversationAuditReadinessState.Unknown;

        entries.Add(new ConversationEvidenceEntryV1(
            $"freshness:{freshness.ProjectionCursor}",
            "Freshness",
            null,
            freshness.ProjectionGeneratedAt,
            freshness.FreshnessState,
            citationAvailability,
            auditReadiness,
            freshness.FreshnessState,
            SafeSourcePosition: freshness.LastAppliedEventPosition));

        foreach (ConversationParticipantProjectionV1 participant in builder.Participants)
        {
            entries.Add(new ConversationEvidenceEntryV1(
                $"participant:{participant.ParticipantPartyId.Value}",
                "Participant",
                participant.ParticipantPartyId,
                participant.OccurredAt ?? freshness.LastAppliedEventTimestamp,
                currentOrUnavailable,
                citationAvailability,
                auditReadiness,
                currentOrUnavailable,
                SafeSourcePosition: builder.SourcePositionForParticipant(participant.ParticipantPartyId) ?? freshness.LastAppliedEventPosition));
        }

        Dictionary<string, ConversationRedactionProjectionV1> redactionsByTarget = builder.Redactions
            .ToDictionary(redaction => redaction.Target.ToTargetKey(), StringComparer.Ordinal);
        HashSet<MessageId> redactedMessageIds = builder.Redactions
            .Where(redaction => redaction.Target.MessageId is not null)
            .Select(redaction => redaction.Target.MessageId!)
            .ToHashSet();

        foreach (ConversationTimelineMessageProjectionV1 message in builder.Messages)
        {
            GovernanceTarget messageTarget = new(GovernedTargetKind.Message, MessageId: message.MessageId);
            string messageTargetKey = messageTarget.ToTargetKey();
            bool redacted = redactedMessageIds.Contains(message.MessageId);
            redactionsByTarget.TryGetValue(messageTargetKey, out ConversationRedactionProjectionV1? redaction);
            ProjectionTrustState state = redacted ? ProjectionTrustState.Redacted : currentOrUnavailable;
            ConversationAuditReadinessState messageAuditReadiness = redacted
                ? RedactionAuditReadiness(redaction, freshness)
                : auditReadiness;
            entries.Add(new ConversationEvidenceEntryV1(
                $"message:{message.MessageId.Value}",
                "Message",
                message.AuthorPartyId,
                message.CreatedAt,
                state,
                citationAvailability,
                messageAuditReadiness,
                state,
                MessageId: message.MessageId,
                VisibleText: message.Text,
                ProviderCorrelation: ConversationProviderCorrelationV1.From(message.ProviderCorrelation),
                GovernedTarget: messageTarget,
                RationaleClass: redaction?.ReasonClass,
                AuditEvidence: redaction?.AuditEvidence,
                SafeSummaryLabel: redacted ? "Redacted message evidence" : "Message evidence",
                SafeDetailLabel: redacted ? "Redaction audit detail" : null,
                SafeAccessibilityLabel: redacted
                    ? "Redacted message evidence with governed attribution"
                    : "Message evidence",
                SafeNextAction: redacted
                    ? SafeAuditNextAction(messageAuditReadiness)
                    : null,
                RedactionAttribution: redaction is null ? null : CreateRedactionAttribution(redaction, freshness),
                SafeSourcePosition: builder.SourcePositionForMessage(message.MessageId) ?? freshness.LastAppliedEventPosition));
        }

        foreach (ConversationFileReferenceProjectionV1 file in builder.FileReferences)
        {
            entries.Add(new ConversationEvidenceEntryV1(
                $"attachment:{file.FileId.Value}",
                "Attachment",
                null,
                file.OccurredAt ?? freshness.LastAppliedEventTimestamp,
                currentOrUnavailable,
                citationAvailability,
                auditReadiness,
                currentOrUnavailable,
                FileId: file.FileId,
                SafeSourcePosition: builder.SourcePositionForFile(file.FileId) ?? freshness.LastAppliedEventPosition));
        }

        if (builder.ActiveRetentionPolicy is not null)
        {
            ConversationRetentionPolicyProjectionV1 retention = builder.ActiveRetentionPolicy;
            entries.Add(new ConversationEvidenceEntryV1(
                $"retention:{retention.PolicyReference}",
                "RetentionPolicy",
                retention.ActorPartyId,
                retention.AppliedAt,
                currentOrUnavailable,
                citationAvailability,
                AuditReadinessFor(retention.AuditEvidence, freshness),
                currentOrUnavailable,
                PolicyReference: retention.PolicyReference,
                GovernedTarget: new GovernanceTarget(GovernedTargetKind.Conversation),
                RationaleClass: retention.Rationale,
                AuditEvidence: retention.AuditEvidence,
                SafeSummaryLabel: "Retention policy evidence",
                SafeDetailLabel: "Retention policy audit detail",
                SafeAccessibilityLabel: "Retention policy evidence with governed audit detail",
                SafeNextAction: SafeAuditNextAction(AuditReadinessFor(retention.AuditEvidence, freshness)),
                SafeSourcePosition: builder.ActiveRetentionPolicyPosition ?? freshness.LastAppliedEventPosition));
        }

        foreach (ConversationSensitivityMarkProjectionV1 sensitivity in builder.SensitivityMarks)
        {
            ConversationAuditReadinessState sensitivityReadiness = AuditReadinessFor(sensitivity.AuditEvidence, freshness);
            entries.Add(new ConversationEvidenceEntryV1(
                $"sensitivity:{sensitivity.Target.ToTargetKey()}",
                "SensitivityMark",
                sensitivity.ActorPartyId,
                sensitivity.MarkedAt,
                sensitivity.TrustState,
                citationAvailability,
                sensitivityReadiness,
                sensitivity.TrustState,
                MessageId: sensitivity.Target.MessageId,
                PolicyReference: sensitivity.PolicyReference,
                GovernedTarget: sensitivity.Target,
                RationaleClass: sensitivity.Rationale,
                AuditEvidence: sensitivity.AuditEvidence,
                SafeSummaryLabel: "Sensitivity mark evidence",
                SafeDetailLabel: "Sensitivity mark audit detail",
                SafeAccessibilityLabel: "Sensitivity mark evidence with governed audit detail",
                SafeNextAction: SafeAuditNextAction(sensitivityReadiness),
                SafeSourcePosition: builder.SourcePositionForSensitivity(sensitivity.Target.ToTargetKey()) ?? freshness.LastAppliedEventPosition));
        }

        foreach (ConversationRedactionProjectionV1 redaction in builder.Redactions)
        {
            ConversationAuditReadinessState redactionReadiness = RedactionAuditReadiness(redaction, freshness);
            entries.Add(new ConversationEvidenceEntryV1(
                $"redaction:{redaction.Target.ToTargetKey()}",
                "Redaction",
                redaction.ActorPartyId,
                redaction.RedactedAt,
                redaction.TrustState,
                citationAvailability,
                redactionReadiness,
                redaction.TrustState,
                MessageId: redaction.Target.MessageId,
                VisibleText: redaction.Placeholder,
                PolicyReference: redaction.PolicyReference,
                GovernedTarget: redaction.Target,
                RationaleClass: redaction.ReasonClass,
                AuditEvidence: redaction.AuditEvidence,
                SafeSummaryLabel: "Redaction evidence",
                SafeDetailLabel: "Redaction audit detail",
                SafeAccessibilityLabel: "Redaction evidence with governed attribution",
                SafeNextAction: SafeAuditNextAction(redactionReadiness),
                RedactionAttribution: CreateRedactionAttribution(redaction, freshness),
                SafeSourcePosition: builder.SourcePositionForRedaction(redaction.Target.ToTargetKey()) ?? freshness.LastAppliedEventPosition));
        }

        return entries
            .OrderBy(entry => entry.OccurredAt)
            .ThenBy(entry => entry.EntryId, StringComparer.Ordinal)
            .ToArray();
    }

    private static ConversationRedactionAttributionV1 CreateRedactionAttribution(
        ConversationRedactionProjectionV1 redaction,
        ProjectionFreshnessV1 freshness)
    {
        ConversationAuditReadinessState auditReadiness = RedactionAuditReadiness(redaction, freshness);
        return new(
            redaction.Category,
            redaction.PolicyReference,
            redaction.ReasonClass,
            redaction.ActorPartyId,
            redaction.RedactedAt,
            redaction.Target,
            redaction.Target.ToTargetKey(),
            redaction.AuditEvidence,
            auditReadiness,
            redaction.TrustState,
            redaction.Placeholder,
            "Redaction attribution",
            "Redacted evidence with governed attribution",
            SafeAuditNextAction(auditReadiness));
    }

    private static ConversationAuditReadinessState AuditReadinessFor(
        GovernanceAuditEvidenceReference? auditEvidence,
        ProjectionFreshnessV1 freshness)
    {
        if (!freshness.AllowsTrustBearingDecision())
        {
            return ConversationAuditReadinessState.Unknown;
        }

        return auditEvidence is null
            ? ConversationAuditReadinessState.Incomplete
            : ConversationAuditReadinessState.Ready;
    }

    private static ConversationAuditReadinessState RedactionAuditReadiness(
        ConversationRedactionProjectionV1? redaction,
        ProjectionFreshnessV1 freshness)
        => redaction is null
            ? ConversationAuditReadinessState.Unavailable
            : AuditReadinessFor(redaction.AuditEvidence, freshness);

    private static string SafeAuditNextAction(ConversationAuditReadinessState readiness)
    {
        if (readiness == ConversationAuditReadinessState.Ready)
        {
            return "Open governed audit detail when authorized.";
        }

        if (readiness == ConversationAuditReadinessState.Incomplete)
        {
            return "Show incomplete audit detail state.";
        }

        if (readiness == ConversationAuditReadinessState.Unavailable)
        {
            return "Show unavailable audit detail state.";
        }

        return "Wait for current governed evidence before opening detail.";
    }

    private sealed class ProjectionBuilder(TenantId tenantId, ConversationId conversationId)
    {
        private readonly Dictionary<string, string> _attributes = new(StringComparer.Ordinal);
        private readonly Dictionary<FileId, ConversationFileReferenceProjectionV1> _fileReferences = [];
        private readonly Dictionary<MessageId, (long Position, ConversationTimelineMessageProjectionV1 Message)> _messages = [];
        private readonly Dictionary<PartyId, ConversationParticipantProjectionV1> _participants = [];
        private readonly Dictionary<FileId, long> _filePositions = [];
        private readonly Dictionary<PartyId, long> _participantPositions = [];
        private readonly HashSet<string> _processedEventIds = new(StringComparer.Ordinal);
        private readonly Dictionary<string, long> _redactionPositions = new(StringComparer.Ordinal);
        private readonly Dictionary<string, ConversationRedactionProjectionV1> _redactions = new(StringComparer.Ordinal);
        private readonly Dictionary<string, long> _sensitivityPositions = new(StringComparer.Ordinal);
        private readonly Dictionary<string, ConversationSensitivityMarkProjectionV1> _sensitivityMarks = new(StringComparer.Ordinal);
        private string _lifecycleState = InitializingState;

        public IReadOnlyDictionary<string, string> Attributes
            => new Dictionary<string, string>(
                _attributes.OrderBy(attribute => attribute.Key, StringComparer.Ordinal),
                StringComparer.Ordinal);

        public ConversationRetentionPolicyProjectionV1? ActiveRetentionPolicy
        {
            get; private set;
        }

        public long? ActiveRetentionPolicyPosition
        {
            get; private set;
        }

        public BusinessReference? BusinessReference
        {
            get; private set;
        }

        public ConversationId ConversationId => conversationId;

        public IReadOnlyList<ConversationFileReferenceProjectionV1> FileReferences
            => _fileReferences
                .Values
                .OrderBy(reference => reference.FileId.Value, StringComparer.Ordinal)
                .ToArray();

        public FolderId? FolderId
        {
            get; private set;
        }

        public bool HasGap
        {
            get; private set;
        }

        /// <summary>Gets whether logical source deletion hides legacy public content.</summary>
        public bool SourceDeleted
        {
            get; private set;
        }

        public bool HasAuditEvidence
            => SourceDeleted || ActiveRetentionPolicy?.AuditEvidence is not null
                || Redactions.Any(redaction => redaction.AuditEvidence is not null)
                || SensitivityMarks.Any(mark => mark.AuditEvidence is not null);

        public bool HasOutOfOrderEvent
        {
            get; private set;
        }

        public long LastAppliedPosition
        {
            get; private set;
        }

        public DateTimeOffset? LastAppliedTimestamp
        {
            get; private set;
        }

        /// <summary>Gets the explicitly classified native label folded with this owner prefix.</summary>
        public ConversationResolutionScoringLabel? ResolutionScoringLabel { get; private set; }

        public string? Label
        {
            get; private set;
        }

        public string LifecycleState => _lifecycleState;

        public IReadOnlyList<ConversationTimelineMessageProjectionV1> Messages
            => _messages
                .Values
                .OrderBy(entry => entry.Message.CreatedAt)
                .ThenBy(entry => entry.Position)
                .Select(entry => entry.Message)
                .ToArray();

        public IReadOnlyList<PartyId> ParticipantPartyIds
            => _participants
                .Keys
                .OrderBy(partyId => partyId.Value, StringComparer.Ordinal)
                .ToArray();

        public IReadOnlyList<ConversationParticipantProjectionV1> Participants
            => _participants
                .Values
                .OrderBy(participant => participant.ParticipantPartyId.Value, StringComparer.Ordinal)
                .ToArray();

        public bool Poisoned
        {
            get; private set;
        }

        public ProjectId? ProjectId
        {
            get; private set;
        }

        public ProviderCorrelationMetadata? ProviderCorrelation
        {
            get; private set;
        }

        public TenantId TenantId => tenantId;

        public IReadOnlyList<ConversationRedactionProjectionV1> Redactions
            => _redactions
                .Values
                .OrderBy(redaction => redaction.Target.ToTargetKey(), StringComparer.Ordinal)
                .ToArray();

        public IReadOnlyList<ConversationSensitivityMarkProjectionV1> SensitivityMarks
            => _sensitivityMarks
                .Values
                .OrderBy(mark => mark.Target.ToTargetKey(), StringComparer.Ordinal)
                .ToArray();

        public bool UnsupportedVersion
        {
            get; private set;
        }

        public bool WasCreated
        {
            get; private set;
        }

        public void Apply(ConversationProjectionEventRecord record)
        {
            if (record.Event is ConversationProjectionPositionOnlyEvent positionOnly)
            {
                AdvancePosition(record.Position, positionOnly.Timestamp);
                return;
            }

            ConversationEventMetadata? metadata = TryGetMetadata(record.Event);
            if (metadata is null)
            {
                // Unknown event type: cannot mutate state, downgrade to non-current.
                HasOutOfOrderEvent = true;
                return;
            }

            // Tenant/conversation mismatch is checked before dedup so a same-EventId legitimate
            // follow-up event in the same pass is not silently swallowed by a poison dedup entry.
            if (!tenantId.Equals(metadata.TenantId) || !conversationId.Equals(metadata.ConversationId))
            {
                Poisoned = true;
                return;
            }

            if (metadata.SchemaVersion != SchemaVersion.Current)
            {
                UnsupportedVersion = true;
                return;
            }

            if (!_processedEventIds.Add(metadata.EventId))
            {
                return;
            }

            if (!WasCreated && record.Event is not ConversationCreated)
            {
                HasOutOfOrderEvent = true;
            }

            AdvancePosition(record.Position, metadata.CommittedAt);

            try
            {
                Dispatch(record);
            }
            catch (ArgumentException)
            {
                // Contract-validation failure from an event payload (e.g., whitespace text):
                // treat as poison rather than crashing the projection pass.
                Poisoned = true;
            }
        }

        private void AdvancePosition(long position, DateTimeOffset timestamp)
        {
            if (LastAppliedPosition == 0)
            {
                if (position != 1)
                {
                    HasGap = true;
                }
            }
            else if (position != LastAppliedPosition + 1)
            {
                if (position <= LastAppliedPosition)
                {
                    HasOutOfOrderEvent = true;
                }
                else
                {
                    HasGap = true;
                }
            }

            LastAppliedPosition = Math.Max(LastAppliedPosition, position);
            LastAppliedTimestamp = MaxTimestamp(LastAppliedTimestamp, timestamp);
        }

        private void Dispatch(ConversationProjectionEventRecord record)
        {
            switch (record.Event)
            {
                case ConversationCreated created:
                    Apply(created);
                    break;
                case AgentParticipantRemoved removed:
                    _participants.Remove(removed.ParticipantPartyId);
                    _participantPositions.Remove(removed.ParticipantPartyId);
                    break;
                case MessageEdited edited:
                    if (!_messages.TryGetValue(edited.MessageId, out var original))
                    {
                        Poisoned = true;
                        break;
                    }
                    var existingRedaction = _redactions.Values.FirstOrDefault(r => r.Target.Kind == GovernedTargetKind.Conversation
                        || r.Target.Kind == GovernedTargetKind.ContentSegment || r.Target.MessageId == edited.MessageId);
                    _messages[edited.MessageId] = (original.Position, new ConversationTimelineMessageProjectionV1(
                        original.Message.MessageId, original.Message.AuthorPartyId, existingRedaction?.Placeholder ?? edited.Text,
                        original.Message.CreatedAt, original.Message.ProviderCorrelation));
                    break;
                case MessageDeleted deleted:
                    if (!_messages.Remove(deleted.MessageId))
                    {
                        Poisoned = true;
                    }
                    break;
                case ConversationDeletionApproved approved:
                    if (approved.AuditEvidence is null || approved.Signal.TenantId != TenantId
                        || approved.Signal.ConversationId != conversationId || approved.Signal.SourceRevision != record.Position)
                    {
                        Poisoned = true;
                        break;
                    }
                    SourceDeleted = true;
                    _lifecycleState = ClosedState;
                    _messages.Clear();
                    _fileReferences.Clear();
                    _participants.Clear();
                    _attributes.Clear();
                    Label = null;
                    ResolutionScoringLabel = null;
                    BusinessReference = null;
                    ProviderCorrelation = null;
                    break;
                case ConversationDeletionDeliveryRecorded delivery:
                    if (!SourceDeleted || delivery.Signal.TenantId != TenantId || delivery.Signal.ConversationId != conversationId)
                    {
                        Poisoned = true;
                    }
                    break;
                case ParticipantAdded participant:
                    Apply(participant, record.Position);
                    break;
                case MessageAppended message:
                    Apply(message, record.Position);
                    break;
                case FileReferenceAttached file:
                    Apply(file, record.Position);
                    break;
                case ConversationMetadataUpdated update:
                    Apply(update);
                    break;
                case ConversationProjectChanged projectChanged:
                    Apply(projectChanged);
                    break;
                case ConversationClosed:
                    if (_lifecycleState != ArchivedState)
                    {
                        _lifecycleState = ClosedState;
                    }

                    break;
                case ConversationArchived:
                    _lifecycleState = ArchivedState;
                    break;
                case ConversationLifecycleChanged lifecycle:
                    Apply(lifecycle);
                    break;
                case RetentionPolicySet retentionSet:
                    Apply(retentionSet, record.Position);
                    break;
                case RetentionPolicyReplaced retentionReplaced:
                    Apply(retentionReplaced, record.Position);
                    break;
                case ConversationContentMarkedSensitive sensitive:
                    Apply(sensitive, record.Position);
                    break;
                case MessageContentRedacted redacted:
                    Apply(redacted, record.Position);
                    break;
                default:
                    HasOutOfOrderEvent = true;
                    break;
            }
        }

        private static ConversationEventMetadata? TryGetMetadata(object e)
            => e switch
            {
                ConversationCreated created => created.Metadata,
                ParticipantAdded participant => participant.Metadata,
                AgentParticipantRemoved event0 => event0.Metadata,
                MessageEdited event1 => event1.Metadata,
                MessageDeleted event2 => event2.Metadata,
                ConversationDeletionApproved event3 => event3.Metadata,
                ConversationDeletionDeliveryRecorded event4 => event4.Metadata,

                MessageAppended message => message.Metadata,
                FileReferenceAttached file => file.Metadata,
                ConversationMetadataUpdated update => update.Metadata,
                ConversationProjectChanged projectChanged => projectChanged.Metadata,
                ConversationClosed closed => closed.Metadata,
                ConversationArchived archived => archived.Metadata,
                ConversationLifecycleChanged lifecycle => lifecycle.Metadata,
                RetentionPolicySet retentionSet => retentionSet.Metadata,
                RetentionPolicyReplaced retentionReplaced => retentionReplaced.Metadata,
                ConversationContentMarkedSensitive sensitive => sensitive.Metadata,
                MessageContentRedacted redacted => redacted.Metadata,
                _ => null,
            };

        private static DateTimeOffset MaxTimestamp(DateTimeOffset? current, DateTimeOffset next)
            => current is null || next > current ? next : current.Value;

        private void Apply(ConversationCreated e)
        {
            if (WasCreated || e.ResolutionScoringLabel is { } scoring && scoring.Value != e.Label)
            {
                Poisoned = true;
                return;
            }

            WasCreated = true;
            if (_lifecycleState == InitializingState)
            {
                _lifecycleState = OpenState;
            }

            Label ??= e.Label;
            ResolutionScoringLabel = e.ResolutionScoringLabel;
            BusinessReference ??= e.BusinessReference;
            ProjectId ??= e.ProjectId;
            FolderId ??= e.FolderId;
            ProviderCorrelation ??= e.ProviderCorrelation;
        }

        private void Apply(ConversationProjectChanged e)
        {
            ProjectId = e.CurrentProjectId;
        }

        public long? SourcePositionForFile(FileId fileId)
            => _filePositions.TryGetValue(fileId, out long position) ? position : null;

        public long? SourcePositionForMessage(MessageId messageId)
            => _messages.TryGetValue(messageId, out (long Position, ConversationTimelineMessageProjectionV1 Message) entry)
                ? entry.Position
                : null;

        public long? SourcePositionForParticipant(PartyId partyId)
            => _participantPositions.TryGetValue(partyId, out long position) ? position : null;

        public long? SourcePositionForRedaction(string targetKey)
            => _redactionPositions.TryGetValue(targetKey, out long position) ? position : null;

        public long? SourcePositionForSensitivity(string targetKey)
            => _sensitivityPositions.TryGetValue(targetKey, out long position) ? position : null;

        private void Apply(ParticipantAdded e, long position)
        {
            if (_participants.ContainsKey(e.ParticipantPartyId))
            {
                Poisoned = true;
                return;
            }

            _participants[e.ParticipantPartyId] = new ConversationParticipantProjectionV1(
                e.ParticipantPartyId,
                e.ParticipantType,
                e.ParticipantRole,
                e.Metadata.CommittedAt);
            _participantPositions[e.ParticipantPartyId] = position;
        }

        private void Apply(MessageAppended e, long position)
        {
            if (_messages.ContainsKey(e.MessageId))
            {
                Poisoned = true;
                return;
            }

            string targetKey = new GovernanceTarget(GovernedTargetKind.Message, MessageId: e.MessageId).ToTargetKey();
            string text = _redactions.TryGetValue(targetKey, out ConversationRedactionProjectionV1? redaction)
                ? redaction.Placeholder
                : e.Text;

            _messages[e.MessageId] = (position, new ConversationTimelineMessageProjectionV1(
                e.MessageId,
                e.AuthorPartyId,
                text,
                e.Metadata.CommittedAt,
                e.ProviderCorrelation));
        }

        private void Apply(FileReferenceAttached e, long position)
        {
            if (_fileReferences.ContainsKey(e.FileId))
            {
                Poisoned = true;
                return;
            }

            _fileReferences[e.FileId] = new ConversationFileReferenceProjectionV1(
                e.FileId,
                e.FolderId,
                e.MessageId,
                e.Metadata.CommittedAt);
            _filePositions[e.FileId] = position;
        }

        private void Apply(ConversationMetadataUpdated e)
        {
            // Replace-all semantics: empty/null Attributes = no-op; non-empty = full replace.
            // Producers cannot signal per-key deletion through this event.
            if (e.ResolutionScoringLabel is { } scoring && (scoring.Value != e.Label || scoring.Value != (e.Label ?? Label)))
            {
                Poisoned = true;
                return;
            }
            if (e.Label is not null)
            {
                Label = e.Label;
                ResolutionScoringLabel = null;
            }
            if (e.ResolutionScoringLabel is not null)
            {
                ResolutionScoringLabel = e.ResolutionScoringLabel;
            }

            if (e.BusinessReference is not null)
            {
                BusinessReference = e.BusinessReference;
            }

            if (e.Attributes is null || e.Attributes.Count == 0)
            {
                return;
            }

            _attributes.Clear();
            foreach (KeyValuePair<string, string> attribute in e.Attributes.OrderBy(a => a.Key, StringComparer.Ordinal))
            {
                _attributes[attribute.Key] = attribute.Value;
            }
        }

        private void Apply(ConversationLifecycleChanged e)
        {
            _lifecycleState = e.CurrentState.Value;
        }

        private void Apply(RetentionPolicySet e, long position)
        {
            ActiveRetentionPolicy = new ConversationRetentionPolicyProjectionV1(
                e.PolicyReference,
                e.Rationale,
                e.Metadata.ActorPartyId,
                e.Metadata.CommittedAt,
                e.AuditEvidence);
            ActiveRetentionPolicyPosition = position;
        }

        private void Apply(RetentionPolicyReplaced e, long position)
        {
            ActiveRetentionPolicy = new ConversationRetentionPolicyProjectionV1(
                e.PolicyReference,
                e.Rationale,
                e.Metadata.ActorPartyId,
                e.Metadata.CommittedAt,
                e.AuditEvidence,
                e.PreviousPolicyReference);
            ActiveRetentionPolicyPosition = position;
        }

        private void Apply(ConversationContentMarkedSensitive e, long position)
        {
            _sensitivityMarks[e.Target.ToTargetKey()] = new ConversationSensitivityMarkProjectionV1(
                e.Target,
                e.Category,
                e.PolicyReference,
                e.Rationale,
                e.Metadata.ActorPartyId,
                e.Metadata.CommittedAt,
                e.AuditEvidence,
                ProjectionTrustState.Current);
            _sensitivityPositions[e.Target.ToTargetKey()] = position;
        }

        private void Apply(MessageContentRedacted e, long position)
        {
            ConversationRedactionProjectionV1 redaction = new(
                e.Target,
                e.Category,
                e.PolicyReference,
                e.Rationale,
                e.Metadata.ActorPartyId,
                e.Metadata.CommittedAt,
                e.AuditEvidence,
                ProjectionTrustState.Redacted);
            _redactions[e.Target.ToTargetKey()] = redaction;
            _redactionPositions[e.Target.ToTargetKey()] = position;

            if (e.Target.Kind == GovernedTargetKind.Message
                && e.Target.MessageId is not null
                && _messages.TryGetValue(e.Target.MessageId, out (long Position, ConversationTimelineMessageProjectionV1 Message) existing))
            {
                _messages[e.Target.MessageId] = (
                    existing.Position,
                    new ConversationTimelineMessageProjectionV1(
                        existing.Message.MessageId,
                        existing.Message.AuthorPartyId,
                        redaction.Placeholder,
                        existing.Message.CreatedAt,
                        existing.Message.ProviderCorrelation));
            }
        }
    }
}
