// <copyright file="ConversationCommandFingerprint.cs" company="ITANEO">
// Copyright (c) ITANEO. All rights reserved.
// Licensed under the MIT License.
// </copyright>

using Hexalith.Conversations.Contracts.Commands;
using Hexalith.Conversations.Contracts.Governance;
using Hexalith.Conversations.Contracts.Identifiers;
using Hexalith.Conversations.Contracts.Results;

namespace Hexalith.Conversations.Idempotency;

/// <summary>
/// Combines the scoped idempotency key with the canonical command fingerprint.
/// </summary>
/// <param name="Scope">The scoped idempotency key.</param>
/// <param name="PayloadFingerprint">The bounded canonical command fingerprint.</param>
public sealed record ConversationCommandFingerprint(
    ConversationIdempotencyScope Scope,
    ConversationPayloadFingerprint PayloadFingerprint)
{
    /// <summary>
    /// Gets the scoped idempotency key.
    /// </summary>
    public ConversationIdempotencyScope Scope { get; } = Scope ?? throw new ArgumentNullException(nameof(Scope));

    /// <summary>
    /// Gets the bounded canonical command fingerprint.
    /// </summary>
    public ConversationPayloadFingerprint PayloadFingerprint { get; } =
        PayloadFingerprint ?? throw new ArgumentNullException(nameof(PayloadFingerprint));

    /// <summary>
    /// Creates the fingerprint for a supported public command contract.
    /// </summary>
    /// <param name="command">The public command contract.</param>
    /// <param name="createAllocationScope">The Conversations-owned create allocation scope.</param>
    /// <returns>The scoped command fingerprint.</returns>
    public static ConversationCommandFingerprint Create(object command, ConversationId createAllocationScope)
    {
        ArgumentNullException.ThrowIfNull(command);
        ArgumentNullException.ThrowIfNull(createAllocationScope);

        return command switch
        {
            CreateConversationCommand create => CreateForCreateConversation(create, createAllocationScope),
            AppendMessageCommand append => CreateForAppendMessage(append),
            AddParticipantCommand add => CreateForAddParticipant(add),
            ReassignConversationProjectCommand reassignProject => CreateForReassignConversationProject(reassignProject),
            AttachFileReferenceCommand attach => CreateForAttachFileReference(attach),
            UpdateConversationMetadataCommand update => CreateForUpdateMetadata(update),
            CloseConversationCommand close => CreateForClose(close),
            ArchiveConversationCommand archive => CreateForArchive(archive),
            SetConversationRetentionPolicyCommand retention => CreateForSetRetentionPolicy(retention),
            MarkConversationContentSensitiveCommand sensitivity => CreateForMarkSensitive(sensitivity),
            RedactMessageContentCommand redaction => CreateForRedaction(redaction),
            _ => throw new ArgumentException($"Unsupported conversation command type '{command.GetType().FullName}'.", nameof(command)),
        };
    }

    private static ConversationCommandFingerprint CreateForCreateConversation(
        CreateConversationCommand command,
        ConversationId allocationScope)
    {
        ConversationCommandMetadata metadata = RequireMetadata(command.Metadata);
        return new ConversationCommandFingerprint(
            BuildScope(
                metadata,
                ConversationCommandType.CreateConversationCommand,
                ConversationIdempotencyScope.CreateAllocationScopeKind,
                allocationScope.Value),
            Fingerprint(
                MetadataParts(metadata)
                    .Concat(Optional("business.system", command.BusinessReference?.System))
                    .Concat(Optional("business.value", command.BusinessReference?.Value))
                    .Concat(Optional("project.id", command.ProjectId?.Value))
                    .Concat(Optional("folder.id", command.FolderId?.Value))
                    .Concat(Optional("label", command.Label))
                    .Concat(Optional("resolution.label.value", command.ResolutionScoringLabel?.Value))
                    .Concat(Optional("resolution.label.purpose", command.ResolutionScoringLabel?.Purpose))
                    .Concat(Optional("resolution.label.classification", command.ResolutionScoringLabel?.Classification))));
    }

    private static ConversationCommandFingerprint CreateForAppendMessage(AppendMessageCommand command)
    {
        ConversationCommandMetadata metadata = RequireMetadata(command.Metadata);
        return new ConversationCommandFingerprint(
            BuildScope(
                metadata,
                ConversationCommandType.AppendMessageCommand,
                ConversationIdempotencyScope.ConversationScopeKind,
                RequireNonNull(command.ConversationId, nameof(command.ConversationId)).Value),
            Fingerprint(
                MetadataParts(metadata)
                    .Concat(Required("message.id", command.MessageId?.Value))
                    .Concat(Required("author.party.id", command.AuthorPartyId?.Value))
                    .Concat(Required("text", command.Text))));
    }

    private static ConversationCommandFingerprint CreateForAddParticipant(AddParticipantCommand command)
    {
        ConversationCommandMetadata metadata = RequireMetadata(command.Metadata);
        return new ConversationCommandFingerprint(
            BuildScope(
                metadata,
                ConversationCommandType.AddParticipantCommand,
                ConversationIdempotencyScope.ConversationScopeKind,
                RequireNonNull(command.ConversationId, nameof(command.ConversationId)).Value),
            Fingerprint(
                MetadataParts(metadata)
                    .Concat(Required("participant.party.id", command.ParticipantPartyId?.Value))
                    .Concat(Required("participant.type", command.ParticipantType?.Value))
                    .Concat(Required("participant.role", command.ParticipantRole?.Value))));
    }

    private static ConversationCommandFingerprint CreateForReassignConversationProject(
        ReassignConversationProjectCommand command)
    {
        ConversationCommandMetadata metadata = RequireMetadata(command.Metadata);
        return new ConversationCommandFingerprint(
            BuildScope(
                metadata,
                ConversationCommandType.ReassignConversationProjectCommand,
                ConversationIdempotencyScope.ConversationScopeKind,
                RequireNonNull(command.ConversationId, nameof(command.ConversationId)).Value),
            Fingerprint(
                MetadataParts(metadata)
                    .Concat(Required("project.assignment.operation", command.Target?.Operation?.Value))
                    .Concat(Optional("project.target.id", command.Target?.ProjectId?.Value))
                    .Concat(Optional("project.expected.current.id", command.ExpectedCurrentProjectId?.Value))));
    }

    private static ConversationCommandFingerprint CreateForAttachFileReference(AttachFileReferenceCommand command)
    {
        ConversationCommandMetadata metadata = RequireMetadata(command.Metadata);
        return new ConversationCommandFingerprint(
            BuildScope(
                metadata,
                ConversationCommandType.AttachFileReferenceCommand,
                ConversationIdempotencyScope.ConversationScopeKind,
                RequireNonNull(command.ConversationId, nameof(command.ConversationId)).Value),
            Fingerprint(
                MetadataParts(metadata)
                    .Concat(Required("file.id", command.FileId?.Value))
                    .Concat(Optional("folder.id", command.FolderId?.Value))
                    .Concat(Optional("message.id", command.MessageId?.Value))));
    }

    private static ConversationCommandFingerprint CreateForUpdateMetadata(UpdateConversationMetadataCommand command)
    {
        ConversationCommandMetadata metadata = RequireMetadata(command.Metadata);
        return new ConversationCommandFingerprint(
            BuildScope(
                metadata,
                ConversationCommandType.UpdateConversationMetadataCommand,
                ConversationIdempotencyScope.ConversationScopeKind,
                RequireNonNull(command.ConversationId, nameof(command.ConversationId)).Value),
            Fingerprint(
                MetadataParts(metadata)
                    .Concat(Optional("label", command.Label))
                    .Concat(Optional("business.system", command.BusinessReference?.System))
                    .Concat(Optional("business.value", command.BusinessReference?.Value))
                    .Concat(SafeAttributes(command.Attributes))
                    .Concat(Optional("resolution.label.value", command.ResolutionScoringLabel?.Value))
                    .Concat(Optional("resolution.label.purpose", command.ResolutionScoringLabel?.Purpose))
                    .Concat(Optional("resolution.label.classification", command.ResolutionScoringLabel?.Classification))));
    }

    private static ConversationCommandFingerprint CreateForClose(CloseConversationCommand command)
    {
        ConversationCommandMetadata metadata = RequireMetadata(command.Metadata);
        return new ConversationCommandFingerprint(
            BuildScope(
                metadata,
                ConversationCommandType.CloseConversationCommand,
                ConversationIdempotencyScope.ConversationScopeKind,
                RequireNonNull(command.ConversationId, nameof(command.ConversationId)).Value),
            Fingerprint(MetadataParts(metadata).Concat(Optional("reason.code", command.ReasonCode))));
    }

    private static ConversationCommandFingerprint CreateForArchive(ArchiveConversationCommand command)
    {
        ConversationCommandMetadata metadata = RequireMetadata(command.Metadata);
        return new ConversationCommandFingerprint(
            BuildScope(
                metadata,
                ConversationCommandType.ArchiveConversationCommand,
                ConversationIdempotencyScope.ConversationScopeKind,
                RequireNonNull(command.ConversationId, nameof(command.ConversationId)).Value),
            Fingerprint(MetadataParts(metadata).Concat(Optional("reason.code", command.ReasonCode))));
    }

    private static ConversationCommandFingerprint CreateForSetRetentionPolicy(SetConversationRetentionPolicyCommand command)
    {
        ConversationCommandMetadata metadata = RequireMetadata(command.Metadata);
        return new ConversationCommandFingerprint(
            BuildScope(
                metadata,
                ConversationCommandType.SetConversationRetentionPolicyCommand,
                ConversationIdempotencyScope.ConversationScopeKind,
                RequireNonNull(command.ConversationId, nameof(command.ConversationId)).Value),
            Fingerprint(
                MetadataParts(metadata)
                    .Concat(Required("retention.policy.reference", command.PolicyReference))
                    .Concat(Required("retention.rationale", command.Rationale))
                    .Concat(Required(
                        "retention.operation.timestamp",
                        command.OperationTimestamp.ToString("O", System.Globalization.CultureInfo.InvariantCulture)))));
    }

    private static ConversationCommandFingerprint CreateForMarkSensitive(MarkConversationContentSensitiveCommand command)
    {
        ConversationCommandMetadata metadata = RequireMetadata(command.Metadata);
        return new ConversationCommandFingerprint(
            BuildScope(
                metadata,
                ConversationCommandType.MarkConversationContentSensitiveCommand,
                ConversationIdempotencyScope.ConversationScopeKind,
                RequireNonNull(command.ConversationId, nameof(command.ConversationId)).Value),
            Fingerprint(
                MetadataParts(metadata)
                    .Concat(TargetParts(command.Target))
                    .Concat(Required("sensitivity.category", command.Category?.Value))
                    .Concat(Required("sensitivity.policy.reference", command.PolicyReference))
                    .Concat(Required("sensitivity.rationale", command.Rationale))
                    .Concat(Required(
                        "sensitivity.operation.timestamp",
                        command.OperationTimestamp.ToString("O", System.Globalization.CultureInfo.InvariantCulture)))));
    }

    public static ConversationCommandFingerprint CreateForRedaction(RedactMessageContentCommand command)
    {
        ArgumentNullException.ThrowIfNull(command);
        ConversationCommandMetadata metadata = RequireMetadata(command.Metadata);
        return new ConversationCommandFingerprint(
            BuildScope(
                metadata,
                ConversationCommandType.RedactMessageContentCommand,
                ConversationIdempotencyScope.ConversationScopeKind,
                RequireNonNull(command.ConversationId, nameof(command.ConversationId)).Value),
            Fingerprint(
                MetadataParts(metadata)
                    .Concat(TargetParts(command.Target))
                    .Concat(Required("redaction.target.key", command.Target?.ToTargetKey()))
                    .Concat(Required("redaction.category", command.Category?.Value))
                    .Concat(Required("redaction.policy.reference", command.PolicyReference))
                    .Concat(Required("redaction.rationale", command.Rationale))
                    .Concat(Required(
                        "redaction.operation.timestamp",
                        command.OperationTimestamp.ToString("O", System.Globalization.CultureInfo.InvariantCulture)))));
    }

    private static ConversationIdempotencyScope BuildScope(
        ConversationCommandMetadata metadata,
        ConversationCommandType commandType,
        string scopeKind,
        string scopeValue)
        => new(
            metadata.TenantId,
            commandType,
            scopeKind,
            scopeValue,

            // P9 review fix (2026-05-19): nameof previously misreported the parameter (the public entry point binds
            // 'command', not 'metadata'). Use a stable parameter label that matches the public surface.
            ValidateRequiredIdempotencyKey(metadata.IdempotencyKey),
            metadata.SchemaVersion);

    private static ConversationPayloadFingerprint Fingerprint(IEnumerable<KeyValuePair<string, string?>> parts)
        => ConversationPayloadFingerprint.FromParts(parts);

    private static IEnumerable<KeyValuePair<string, string?>> MetadataParts(ConversationCommandMetadata metadata)
    {
        yield return new KeyValuePair<string, string?>("actor.party.id", metadata.ActorPartyId.Value);
    }

    private static IEnumerable<KeyValuePair<string, string?>> SafeAttributes(IReadOnlyDictionary<string, string>? attributes)
    {
        if (attributes is null || attributes.Count == 0)
        {
            yield break;
        }

        foreach (KeyValuePair<string, string> attribute in attributes.OrderBy(a => a.Key, StringComparer.Ordinal))
        {
            yield return new KeyValuePair<string, string?>($"attribute.{attribute.Key}", attribute.Value);
        }
    }

    private static IEnumerable<KeyValuePair<string, string?>> TargetParts(GovernanceTarget? target)
    {
        if (target is null)
        {
            throw new ArgumentNullException(nameof(target));
        }

        GovernanceTarget safeTarget = target;
        yield return new KeyValuePair<string, string?>("target.kind", safeTarget.Kind.Value);
        if (safeTarget.MessageId is not null)
        {
            yield return new KeyValuePair<string, string?>("target.message.id", safeTarget.MessageId.Value);
        }

        if (safeTarget.FileId is not null)
        {
            yield return new KeyValuePair<string, string?>("target.file.id", safeTarget.FileId.Value);
        }

        if (safeTarget.PartyId is not null)
        {
            yield return new KeyValuePair<string, string?>("target.party.id", safeTarget.PartyId.Value);
        }

        if (safeTarget.SegmentReference is not null)
        {
            yield return new KeyValuePair<string, string?>("target.segment.reference", safeTarget.SegmentReference);
        }
    }

    private static IEnumerable<KeyValuePair<string, string?>> Required(string key, string? value)
    {
        // P47 review fix (2026-05-20): surface the canonical field name in ArgumentException.ParamName so callers can identify
        // which canonical field failed (e.g., 'text', 'author.party.id') instead of the uninformative literal 'value'.
        if (string.IsNullOrWhiteSpace(value))
        {
            throw new ArgumentException(
                $"Required canonical field '{key}' is missing or whitespace.",
                paramName: key);
        }

        return [new KeyValuePair<string, string?>(key, value)];
    }

    private static IEnumerable<KeyValuePair<string, string?>> Optional(string key, string? value)
    {
        if (value is not null)
        {
            yield return new KeyValuePair<string, string?>(key, value);
        }
    }

    private static ConversationCommandMetadata RequireMetadata(ConversationCommandMetadata? metadata)
        => metadata ?? throw new ArgumentNullException(nameof(metadata));

    private static string ValidateRequiredIdempotencyKey(string? idempotencyKey)
    {
        if (string.IsNullOrWhiteSpace(idempotencyKey))
        {
            throw new ArgumentException(
                "Conversations command idempotency key is required when constructing a scoped fingerprint.",
                paramName: "command.Metadata.IdempotencyKey");
        }

        return idempotencyKey;
    }

    private static T RequireNonNull<T>(T value, string parameterName) where T : class
        => value ?? throw new ArgumentNullException(parameterName);
}
