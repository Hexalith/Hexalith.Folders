from pathlib import Path
exec(Path('/tmp/story117_release_readiness_phase2.py').read_text().split("source=['--configuration'")[0])
directories=[ROOT/'tests/Hexalith.Folders.Server.Tests/bin/Debug/net10.0',ROOT/'references/Hexalith.Platform/tests/Hexalith.Platform.Composition.Tests/bin/Debug/net10.0']
def identities():
 return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for d in directories for p in d.iterdir() if p.suffix=='.dll' or p.name.endswith(('.deps.json','.runtimeconfig.json'))}
before=identities()
cmd('folders-source-production-final-binaries',['dotnet','tests/Hexalith.Folders.Server.Tests/bin/Debug/net10.0/Hexalith.Folders.Server.Tests.dll','-class','Hexalith.Folders.Server.Tests.WorkspaceContentProductionTests','-xml',str(RUN/'folders-source-production-final-binaries.xml')])
cmd('platform-source-refusal-final-binaries',['dotnet','tests/Hexalith.Platform.Composition.Tests/bin/Debug/net10.0/Hexalith.Platform.Composition.Tests.dll','-method','Hexalith.Platform.Composition.Tests.PlatformHostedPublishingTests.HostedEntryRefusesRunModeBeforeGeneratingLocalResourcesOrSecrets','-xml',str(RUN/'platform-source-refusal-final-binaries.xml')],ROOT/'references/Hexalith.Platform')
after=identities();(RUN/'final-tested-binary-identities.json').write_text(json.dumps({'before':before,'after':after,'unchanged':before==after},indent=2)+'\n')
cmd('final-packet-verifier',['python3','eng/story117-platform-qualification-current/verify.py'])
cmd('final-root-diff-check',['git','diff','--check'])
cmd('final-projects-diff-check',['git','diff','--check'],ROOT/'references/Hexalith.Projects')
cmd('final-platform-diff-check-crlf',['git','-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol','diff','--check'],ROOT/'references/Hexalith.Platform')
print('FINAL_CHECKS_COMPLETE',flush=True)
