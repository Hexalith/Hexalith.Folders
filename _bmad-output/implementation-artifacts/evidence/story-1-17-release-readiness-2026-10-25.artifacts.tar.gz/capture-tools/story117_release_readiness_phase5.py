from pathlib import Path
exec(Path('/tmp/story117_release_readiness_phase2.py').read_text().split("source=['--configuration'")[0])
probe=RUN/'projects-candidate';(RUN/'compiled-candidate-probe').mkdir(exist_ok=True)
target=RUN/'candidate-identity.targets';target.write_text((RUN/'identity-full.targets').read_text().replace(str(RUN/'compiled-full'),str(RUN/'compiled-candidate-probe')))
props=['--configuration','Release','-p:UseHexalithProjectReferences=false','-m:1','-warnaserror','--artifacts-path',str(probe),'-p:HexalithFoldersVersion=0.0.0-story117.20261025',f'-p:RestoreAdditionalProjectSources={RUN / "diagnostic-packages"}',f'-p:CustomAfterMicrosoftCommonTargets={target}']
code=cmd('projects-diagnostic-candidate-build',['dotnet','build','Hexalith.Projects.CI.slnx',*props],ROOT/'references/Hexalith.Projects')
if code==0:
 dll=next(probe.glob('bin/Hexalith.Projects.Server.Tests/**/Hexalith.Projects.Server.Tests.dll'))
 cmd('projects-diagnostic-candidate-adapters',['dotnet',str(dll),'-class','Hexalith.Projects.Server.Tests.ProjectFolderDirectoryTests','-class','Hexalith.Projects.Server.Tests.ProjectFileReferenceDirectoryTests','-class','Hexalith.Projects.Server.Tests.DelegatedProjectDirectoryRegistrationTests','-xml',str(RUN/'projects-diagnostic-candidate-adapters.xml')],ROOT/'references/Hexalith.Projects')
# Capture generator/analyzer/configuration and actual Csc arguments, forcing compilation through a nonexistent declared output rather than cleaning user artifacts.
# Hash all binaries already exercised so exact unchanged-binary test reuse can be independently checked.
files=[]
for base in ['tests/Hexalith.Folders.Server.Tests/bin','tests/Hexalith.Folders.IntegrationTests/bin','tests/Hexalith.Folders.Contracts.Tests/bin','references/Hexalith.Projects/tests/Hexalith.Projects.Server.Tests/bin','references/Hexalith.Platform/tests/Hexalith.Platform.Composition.Tests/bin']:
 files.extend(p for p in (ROOT/base).rglob('*.dll') if p.name.startswith('Hexalith.'))
(RUN/'tested-binaries-before-full-capture.json').write_text(json.dumps({str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2)+'\n')
for label,solution,cwd,config,mode in [('folders-source-complete-inputs','Hexalith.Folders.CI.slnx',ROOT,'Debug','true'),('folders-package-complete-inputs','Hexalith.Folders.CI.slnx',ROOT,'Release','false'),('projects-package-complete-inputs','Hexalith.Projects.CI.slnx',ROOT/'references/Hexalith.Projects','Release','false'),('platform-source-complete-inputs','tests/Hexalith.Platform.Composition.Tests/Hexalith.Platform.Composition.Tests.csproj',ROOT/'references/Hexalith.Platform','Debug','true'),('platform-package-complete-inputs','tests/Hexalith.Platform.Composition.Tests/Hexalith.Platform.Composition.Tests.csproj',ROOT/'references/Hexalith.Platform','Release','false')]:
 cmd(label,['dotnet','build',solution,'--configuration',config,f'-p:UseHexalithProjectReferences={mode}','-m:1','-warnaserror',f'-p:CustomAfterMicrosoftCommonTargets={RUN / "identity-full.targets"}',f'-p:NonExistentFile={RUN / "deliberately-absent-compiler-output"}'],cwd)
print('PHASE5_COMPLETE',RUN,flush=True)
