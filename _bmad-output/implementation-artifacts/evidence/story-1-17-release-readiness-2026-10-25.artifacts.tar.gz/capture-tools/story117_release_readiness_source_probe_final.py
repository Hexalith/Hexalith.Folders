from pathlib import Path
exec(Path('/tmp/story117_release_readiness_phase2.py').read_text().split("source=['--configuration'")[0])
import io,tarfile
origin=Path('<home>/projects/hexalith/projects/references/Hexalith.Conversations')
def identity():
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=origin).decode().strip(),'stagedEntriesSha256':hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=origin)).hexdigest(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=origin).decode().strip()}
before=identity()
if before['head']!='8444207001d6ad3cd197c2ffba519317effa8b37' or before['status']:raise RuntimeError('Conversations exact clean source unavailable')
# Read-only existing source; Git archive writes no checkout, revision or index.
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=origin).decode().split('\0')
paths=['src']+[p for p in ['Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json','nuget.config','.editorconfig','.gitattributes','README.md','AGENTS.md'] if p in tracked]
raw=subprocess.check_output(['git','archive','--format=tar',before['head'],*paths],cwd=origin)
snapshot=RUN/'conversations-source';snapshot.mkdir(exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
 for m in t.getmembers():
  dst=(snapshot/m.name).resolve()
  if not dst.is_relative_to(snapshot.resolve()) or not(m.isfile() or m.isdir()):raise RuntimeError('Unexpected archive member')
  if m.isdir():dst.mkdir(parents=True,exist_ok=True)
  else:dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(t.extractfile(m).read())
# Keep the exact snapshot as source identity evidence; no nested repositories are initialized.
import gzip
(RUN/'conversations-source-snapshot.tar.gz').write_bytes(gzip.compress(raw,mtime=0))
extra={
 'HexalithConversationsRoot':snapshot,
 'HexalithFoldersRoot':ROOT,
 'HexalithEventStoreRoot':ROOT/'references/Hexalith.EventStore',
 'HexalithTenantsRoot':ROOT/'references/Hexalith.Tenants',
 'HexalithCommonsRoot':ROOT/'references/Hexalith.Commons',
 'HexalithFrontComposerRoot':ROOT/'references/Hexalith.FrontComposer',
 'Hexalith1BuildPackageProps':ROOT/'references/Hexalith.Builds/Props/Directory.Packages.props',
}
output=RUN/'projects-source-explicit';capture=RUN/'compiled-source-explicit';capture.mkdir(exist_ok=True)
target=RUN/'source-explicit-identity.targets';target.write_text((RUN/'identity-full.targets').read_text().replace(str(RUN/'compiled-full'),str(capture)))
args=['dotnet','build','Hexalith.Projects.CI.slnx','--configuration','Debug','-p:UseHexalithProjectReferences=true','-p:UseNuGetDeps=false','-m:1','-warnaserror','--artifacts-path',str(output),f'-p:CustomAfterMicrosoftCommonTargets={target}',*['-p:'+k+'='+str(v) for k,v in extra.items()]]
code=cmd('projects-explicit-source-build-final',args,ROOT/'references/Hexalith.Projects')
if code==0:
 dll=next(output.glob('bin/Hexalith.Projects.Server.Tests/**/Hexalith.Projects.Server.Tests.dll'))
 cmd('projects-explicit-source-adapters-final',['dotnet',str(dll),'-class','Hexalith.Projects.Server.Tests.ProjectFolderDirectoryTests','-class','Hexalith.Projects.Server.Tests.ProjectFileReferenceDirectoryTests','-class','Hexalith.Projects.Server.Tests.DelegatedProjectDirectoryRegistrationTests','-class','Hexalith.Projects.Server.Tests.Queries.DelegatedProjectAdvisoryConversationDirectoryTests','-class','Hexalith.Projects.Server.Tests.Queries.SupportedProjectAuthorityHttpTests','-xml',str(RUN/'projects-explicit-source-adapters-final.xml')],ROOT/'references/Hexalith.Projects')
after=identity();data={'origin':'<sibling-projects-workspace>/references/Hexalith.Conversations','before':before,'after':after,'unchanged':before==after,'requestedProjectsGitlink':'8444207001d6ad3cd197c2ffba519317effa8b37','snapshotSha256':hashlib.sha256((RUN/'conversations-source-snapshot.tar.gz').read_bytes()).hexdigest(),'suppliedRoots':{k:str(v).replace(str(ROOT),'<workspace>').replace(str(RUN),'<capsule>') for k,v in extra.items()},'exitCode':code,'scope':'Explicit isolated source probe only; does not repair the default root-declared workspace or supply tool enrollment/hosted acceptance.'}
(RUN/'explicit-source-probe-final.json').write_text(json.dumps(data,indent=2)+'\n')
if before!=after:raise RuntimeError('Sibling Conversations identity changed')
print(json.dumps(data,indent=2),flush=True)
