from pathlib import Path
import subprocess,json,hashlib,datetime,sys,os,tempfile
ROOT=Path('<workspace>')
RUN=Path(tempfile.mkdtemp(prefix='story117-release-readiness-'))
Path('/tmp/story117-release-readiness-current-path').write_text(str(RUN))
(RUN/'logs').mkdir(); (RUN/'compiled').mkdir()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def cmd(label,args,cwd=ROOT,timeout=1200):
 t=datetime.datetime.now(datetime.timezone.utc).isoformat();print('RUN',label,flush=True)
 try:
  r=subprocess.run(args,cwd=cwd,capture_output=True,timeout=timeout)
  out=r.stdout+r.stderr;code=r.returncode
 except subprocess.TimeoutExpired as e:out=(e.stdout or b'')+(e.stderr or b'')+b'\nBounded command timed out.\n';code=124
 out=out.replace(str(ROOT).encode(),b'<workspace>').replace(str(Path.home()).encode(),b'<home>').replace(str(RUN).encode(),b'<capsule>')
 (RUN/'logs'/f'{label}.txt').write_bytes(out)
 entry=dict(label=label,command=args,workingDirectory=str(cwd.relative_to(ROOT)) or '.',startedAtUtc=t,completedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exitCode=code,log=f'logs/{label}.txt',sha256=hashlib.sha256(out).hexdigest())
 with (RUN/'commands.jsonl').open('a') as f:f.write(json.dumps(entry)+'\n')
 print(label,'exit',code, out.decode(errors='replace')[-1800:],flush=True)
 return code
# Bind actual per-project compiler inputs immediately before C# compilation.
target=RUN/'identity.targets'
target.write_text('''<Project><Target Name="Story117CaptureCompiledInputs" BeforeTargets="CoreCompile"><WriteLinesToFile File="'''+str(RUN/'compiled')+'''/$(MSBuildProjectName).$(Configuration).txt" Overwrite="true" Lines="PROJECT|$(MSBuildProjectFullPath);CONFIG|$(Configuration);SOURCE_MODE|$(UseHexalithProjectReferences);TFM|$(TargetFramework);IMPORTS|$(MSBuildAllProjects);@(Compile->'COMPILE|%(FullPath)');@(ReferencePath->'REFERENCE|%(FullPath)');@(AdditionalFiles->'ADDITIONAL|%(FullPath)');@(RazorComponent->'RAZOR|%(FullPath)');@(Content->'CONTENT|%(FullPath)')" /></Target></Project>''')
# Repo metadata: read only, no network.
repos=['.']+[line.split(' = ',1)[1] for line in (ROOT/'.gitmodules').read_text().splitlines() if line.strip().startswith('path = ')]
state={}
for name in repos:
 p=ROOT/name
 def git(*a):return subprocess.check_output(['git','-C',str(p),*a]).decode().strip()
 index=Path(git('rev-parse','--git-path','index'));index=index if index.is_absolute() else p/index
 state[name]={'head':git('rev-parse','HEAD'),'branch':git('branch','--show-current'),'status':git('status','--porcelain=v1'),'indexSha256':sha(index),'remotes':git('remote','-v'),'recentHistory':git('log','-3','--format=%H %s')}
 if name!='.':
  state[name]['rootGitlink']=subprocess.check_output(['git','ls-tree','HEAD','--',name],cwd=ROOT).decode().split()[2]
 (RUN/f'{p.name if name != "." else "Folders"}.diff').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=p))
(RUN/'repositories-before.json').write_text(json.dumps(state,indent=2)+'\n')
cmd('toolchain',['dotnet','--info'])
cmd('packet-verifier',['python3','eng/story117-platform-qualification-current/verify.py'])
cmd('packet-tests',['python3','-m','unittest','discover','-s','eng/story117-platform-qualification-current','-p','test_*.py','-v'])
# fresh Debug/source tests, followed by independent full package gates.
source=['--configuration','Debug','-p:UseHexalithProjectReferences=true','-p:UseNuGetDeps=false','-m:1','-warnaserror',f'-p:CustomAfterMicrosoftCommonTargets={target}']
cmd('folders-debug-source-build',['dotnet','build','Hexalith.Folders.CI.slnx',*source])
# Capture independently executable focused source behavior even if unrelated source graph fails.
cmd('folders-debug-server-build',['dotnet','build','tests/Hexalith.Folders.Server.Tests/Hexalith.Folders.Server.Tests.csproj',*source])
cmd('folders-debug-production-tests',['dotnet','tests/Hexalith.Folders.Server.Tests/bin/Debug/net10.0/Hexalith.Folders.Server.Tests.dll','-class','*ProductionWorkspaceFileContentSourceTests*'])
cmd('projects-debug-source-build',['dotnet','build','Hexalith.Projects.CI.slnx',*source],ROOT/'references/Hexalith.Projects')
cmd('platform-debug-composition-build',['dotnet','build','tests/Hexalith.Platform.Composition.Tests/Hexalith.Platform.Composition.Tests.csproj',*source],ROOT/'references/Hexalith.Platform')
release=['--configuration','Release','-m:1','-warnaserror',f'-p:CustomAfterMicrosoftCommonTargets={target}']
cmd('folders-release-package-build',['dotnet','build','Hexalith.Folders.CI.slnx',*release,'-p:UseNuGetDeps=true'])
cmd('projects-release-package-build',['dotnet','build','Hexalith.Projects.CI.slnx',*release,'-p:UseHexalithProjectReferences=false'],ROOT/'references/Hexalith.Projects')
cmd('platform-release-composition-build',['dotnet','build','tests/Hexalith.Platform.Composition.Tests/Hexalith.Platform.Composition.Tests.csproj',*release,'-p:UseHexalithProjectReferences=false'],ROOT/'references/Hexalith.Platform')
print('RUN_DIRECTORY',RUN,flush=True)
