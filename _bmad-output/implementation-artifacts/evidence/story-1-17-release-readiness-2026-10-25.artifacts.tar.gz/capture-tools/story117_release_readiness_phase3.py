from pathlib import Path
exec(Path('/tmp/story117_release_readiness_phase2.py').read_text().split("source=['--configuration'")[0])
source=['--configuration','Debug','-p:UseHexalithProjectReferences=true','-p:UseNuGetDeps=false','-m:1','-warnaserror',f'-p:CustomAfterMicrosoftCommonTargets={RUN / "identity.targets"}']
release=['--configuration','Release','-p:UseHexalithProjectReferences=false','-m:1','-warnaserror',f'-p:CustomAfterMicrosoftCommonTargets={RUN / "identity.targets"}']
owner=ROOT/'references/Hexalith.Platform'
cmd('platform-debug-composition-final',['dotnet','build','tests/Hexalith.Platform.Composition.Tests/Hexalith.Platform.Composition.Tests.csproj',*source],owner)
cmd('platform-debug-run-refusal-final',['dotnet','tests/Hexalith.Platform.Composition.Tests/bin/Debug/net10.0/Hexalith.Platform.Composition.Tests.dll','-method','Hexalith.Platform.Composition.Tests.PlatformHostedPublishingTests.HostedEntryRefusesRunModeBeforeGeneratingLocalResourcesOrSecrets','-xml',str(RUN/'platform-debug-run-refusal-final.xml')],owner)
cmd('platform-release-composition-final',['dotnet','build','tests/Hexalith.Platform.Composition.Tests/Hexalith.Platform.Composition.Tests.csproj',*release],owner)
cmd('platform-release-run-refusal-final',['dotnet','tests/Hexalith.Platform.Composition.Tests/bin/Release/net10.0/Hexalith.Platform.Composition.Tests.dll','-method','Hexalith.Platform.Composition.Tests.PlatformHostedPublishingTests.HostedEntryRefusesRunModeBeforeGeneratingLocalResourcesOrSecrets','-xml',str(RUN/'platform-release-run-refusal-final.xml')],owner)
# The released tool's safe static commands start no resources and execute no publication/deployment.
for name,manifest in [('folders','../../module/hexalith.module-manifest.v2.json'),('projects','../Hexalith.Projects/module/hexalith.module-manifest.v2.json'),('eventstore','../Hexalith.EventStore/module/hexalith.module-manifest.v2.json'),('tenants','../Hexalith.Tenants/module/hexalith.module-manifest.v2.json'),('memories','../Hexalith.Memories/module/hexalith.module-manifest.v2.json')]:
 for mode in ['declaration','adoption']:
  args=['dotnet','tool','run','hexalith-module','--','validate','--manifest',manifest,'--output','json']
  if mode=='adoption':args.append('--adoption')
  cmd('intake-'+name+'-'+mode,args,owner,timeout=90)
cmd('pdb-inspector-build',['dotnet','build',str(Path('/tmp/story117-pdb-inspector/Inspector.csproj')),'--configuration','Debug','-m:1','-warnaserror'],Path('/tmp/story117-pdb-inspector'))
# Candidate-only# package override and isolated artifacts; the owning catalog and ordinary output remain unchanged.
probe=RUN/'projects-candidate';(RUN/'compiled-candidate-probe').mkdir()
target=RUN/'candidate-identity.targets';target.write_text((RUN/'identity.targets').read_text().replace(str(RUN/'compiled'),str(RUN/'compiled-candidate-probe')))
props=['--configuration','Release','-p:UseHexalithProjectReferences=false','-m:1','-warnaserror','--artifacts-path',str(probe),'-p:HexalithFoldersVersion=0.0.0-story117.20261025',f'-p:RestoreAdditionalProjectSources={RUN / "diagnostic-packages"}',f'-p:CustomAfterMicrosoftCommonTargets={target}']
code=cmd('projects-diagnostic-candidate-build',['dotnet','build','Hexalith.Projects.CI.slnx',*props],ROOT/'references/Hexalith.Projects')
if code==0:
 dll=next(probe.glob('bin/Hexalith.Projects.Server.Tests/**/Hexalith.Projects.Server.Tests.dll'))
 cmd('projects-diagnostic-candidate-adapters',['dotnet',str(dll),'-class','Hexalith.Projects.Server.Tests.ProjectFolderDirectoryTests','-class','Hexalith.Projects.Server.Tests.ProjectFileReferenceDirectoryTests','-class','Hexalith.Projects.Server.Tests.DelegatedProjectDirectoryRegistrationTests','-xml',str(RUN/'projects-diagnostic-candidate-adapters.xml')],ROOT/'references/Hexalith.Projects')
print('PHASE3_COMPLETE',RUN,flush=True)
