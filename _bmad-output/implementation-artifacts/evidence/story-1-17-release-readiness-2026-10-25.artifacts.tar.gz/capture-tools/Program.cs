using System.Reflection.Metadata;
using System.Text.Json;

var result = new List<object>();
foreach (string path in args)
{
    using FileStream stream = File.OpenRead(path);
    using MetadataReaderProvider provider = MetadataReaderProvider.FromPortablePdbStream(stream);
    MetadataReader reader = provider.GetMetadataReader();
    var documents = new List<object>();
    foreach (DocumentHandle handle in reader.Documents)
    {
        Document document = reader.GetDocument(handle);
        documents.Add(new { name = reader.GetString(document.Name), algorithm = reader.GetGuid(document.HashAlgorithm), hash = Convert.ToHexString(reader.GetBlobBytes(document.Hash)).ToLowerInvariant() });
    }
    result.Add(new { pdb = path, documents });
}
Console.WriteLine(JsonSerializer.Serialize(result));
