from pathlib import Path
exec(Path('/tmp/story117_release_readiness_phase2.py').read_text().split("source=['--configuration'")[0])
record=json.loads((RUN/'explicit-source-probe-final.json').read_text());extra=record['suppliedRoots'];roots={k:v.replace('<workspace>',str(ROOT)).replace('<capsule>',str(RUN)) for k,v in extra.items()}
files=[]
for p in (RUN/'compiled-source-explicit').glob('*.txt'):
 if p.name.endswith('.args.txt'):continue
 a=p.with_name(p.stem+'.args.txt')
 if not a.exists() or not a.stat().st_size:files.append(p)
print('MISSING_COMPILER_ARGUMENT_PROFILES',len(files),flush=True)
for p in files:
 fields=dict(l.split('|',1) for l in p.read_text().splitlines() if l.startswith(('PROJECT|','CONFIG|')))
 args=['dotnet','msbuild',fields['PROJECT'],'-t:Compile',f'-p:Configuration={fields["CONFIG"]}','-p:UseHexalithProjectReferences=true','-p:UseNuGetDeps=false','-p:SkipCompilerExecution=true','-p:ProvideCommandLineArgs=true','-p:BuildProjectReferences=false',f'-p:ArtifactsPath={RUN / "projects-source-explicit"}',f'-p:CustomAfterMicrosoftCommonTargets={RUN / "source-explicit-identity.targets"}',f'-p:NonExistentFile={RUN / "absent-for-argument-evaluation"}',*['-p:'+k+'='+v for k,v in roots.items()]]
 cmd('compiler-arguments-only-'+p.stem,args,timeout=120)
print('ARGUMENT_CAPTURE_COMPLETE',flush=True)
