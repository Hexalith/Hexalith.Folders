from pathlib import Path
exec(Path('/tmp/story117_release_readiness_phase2.py').read_text().split("source=['--configuration'")[0])
owner=ROOT/'references/Hexalith.Projects'
cmd('projects-package-final-fixtures',['dotnet','build','Hexalith.Projects.CI.slnx','--configuration','Release','-p:UseHexalithProjectReferences=false','-m:1','-warnaserror'],owner)
cmd('projects-retained-pair-final-tests',['dotnet','tests/Hexalith.Projects.Server.Tests/bin/Release/net10.0/Hexalith.Projects.Server.Tests.dll','-class','Hexalith.Projects.Server.Tests.ProjectFolderDirectoryTests','-class','Hexalith.Projects.Server.Tests.ProjectFileReferenceDirectoryTests','-class','Hexalith.Projects.Server.Tests.DelegatedProjectDirectoryRegistrationTests','-class','Hexalith.Projects.Server.Tests.Queries.DelegatedProjectAdvisoryConversationDirectoryTests','-xml',str(RUN/'projects-retained-pair-final-tests.xml')],owner)
probe=RUN/'projects-candidate'
cmd('projects-diagnostic-pair-final-fixtures',['dotnet','build','Hexalith.Projects.CI.slnx','--configuration','Release','-p:UseHexalithProjectReferences=false','-m:1','-warnaserror','--artifacts-path',str(probe),'-p:HexalithFoldersVersion=0.0.0-story117.20261025',f'-p:RestoreConfigFile={RUN / "candidate-nuget.config"}'],owner)
dll=next(probe.glob('bin/Hexalith.Projects.Server.Tests/**/Hexalith.Projects.Server.Tests.dll'))
cmd('projects-diagnostic-pair-final-tests',['dotnet',str(dll),'-class','Hexalith.Projects.Server.Tests.ProjectFolderDirectoryTests','-class','Hexalith.Projects.Server.Tests.ProjectFileReferenceDirectoryTests','-class','Hexalith.Projects.Server.Tests.DelegatedProjectDirectoryRegistrationTests','-class','Hexalith.Projects.Server.Tests.Queries.DelegatedProjectAdvisoryConversationDirectoryTests','-xml',str(RUN/'projects-diagnostic-pair-final-tests.xml')],owner)
print('PROJECTS_FINAL_COMPLETE',flush=True)
