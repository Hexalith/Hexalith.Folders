from pathlib import Path
exec(Path('/tmp/story117_release_readiness_phase2.py').read_text().split("source=['--configuration'")[0])
probe=RUN/'projects-candidate';target=RUN/'candidate-identity.targets'
props=['--configuration','Release','-p:UseHexalithProjectReferences=false','-m:1','-warnaserror','--artifacts-path',str(probe),'-p:HexalithFoldersVersion=0.0.0-story117.20261025',f'-p:RestoreConfigFile={RUN / "candidate-nuget.config"}','-p:RestoreForce=true',f'-p:CustomAfterMicrosoftCommonTargets={target}']
code=cmd('projects-diagnostic-candidate-build-mapped',['dotnet','build','Hexalith.Projects.CI.slnx',*props],ROOT/'references/Hexalith.Projects')
if code==0:
 dll=next(probe.glob('bin/Hexalith.Projects.Server.Tests/**/Hexalith.Projects.Server.Tests.dll'))
 cmd('projects-diagnostic-candidate-adapters-mapped',['dotnet',str(dll),'-class','Hexalith.Projects.Server.Tests.ProjectFolderDirectoryTests','-class','Hexalith.Projects.Server.Tests.ProjectFileReferenceDirectoryTests','-class','Hexalith.Projects.Server.Tests.DelegatedProjectDirectoryRegistrationTests','-xml',str(RUN/'projects-diagnostic-candidate-adapters-mapped.xml')],ROOT/'references/Hexalith.Projects')
# Narrow evaluated catalog/root values, not environment dumps.
properties='Configuration,TargetFramework,UseHexalithProjectReferences,UseNuGetDeps,HexalithFoldersVersion,HexalithEventStoreVersion,HexalithTenantsVersion,HexalithMemoriesVersion,HexalithProjectsVersion,HexalithFrontComposerVersion,HexalithBuildsRoot,HexalithBuildsResolvedRoot,HexalithConversationsRoot,HexalithEventStoreRoot,HexalithFoldersRoot,HexalithEventStoreFromSource,DirectoryBuildPropsPath,DirectoryPackagesPropsPath,NuGetAudit,DefineConstants,LangVersion,Nullable,TreatWarningsAsErrors'
for name,cwd,project in [('folders',ROOT,'src/Hexalith.Folders.Server/Hexalith.Folders.Server.csproj'),('projects',ROOT/'references/Hexalith.Projects','src/Hexalith.Projects.Server/Hexalith.Projects.Server.csproj'),('platform',ROOT/'references/Hexalith.Platform','src/Hexalith.Platform.Composition/Hexalith.Platform.Composition.csproj')]:
 for configuration in ['Debug','Release']:
  cmd(name+'-'+configuration.lower()+'-evaluation',['dotnet','msbuild',project,f'-p:Configuration={configuration}',f'-p:UseHexalithProjectReferences={str(configuration=="Debug").lower()}',f'-getProperty:{properties}','-getItem:PackageReference,PackageVersion,ProjectReference'],cwd)
cmd('root-diff-check',['git','diff','--check'])
cmd('platform-diff-check-crlf',['git','-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol','diff','--check'],ROOT/'references/Hexalith.Platform')
print('PHASE6_COMPLETE',RUN,flush=True)
