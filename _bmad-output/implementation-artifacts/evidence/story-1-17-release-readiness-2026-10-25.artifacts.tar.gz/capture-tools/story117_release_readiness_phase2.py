from pathlib import Path
import subprocess,json,hashlib,datetime,shutil,re
ROOT=Path('<workspace>');RUN=Path('/tmp/story117-release-readiness-current-path').read_text();RUN=Path(RUN)
def cmd(label,args,cwd=ROOT,timeout=1200):
 print('RUN',label,flush=True);start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 try:r=subprocess.run(args,cwd=cwd,capture_output=True,timeout=timeout);out=r.stdout+r.stderr;code=r.returncode
 except subprocess.TimeoutExpired as e:out=(e.stdout or b'')+(e.stderr or b'')+b'\nBounded command timed out.\n';code=124
 out=out.replace(str(ROOT).encode(),b'<workspace>').replace(str(Path.home()).encode(),b'<home>').replace(str(RUN).encode(),b'<capsule>')
 (RUN/'logs'/f'{label}.txt').write_bytes(out)
 d=dict(label=label,command=args,workingDirectory=str(cwd.relative_to(ROOT)) or '.',startedAtUtc=start,completedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exitCode=code,log=f'logs/{label}.txt',sha256=hashlib.sha256(out).hexdigest())
 xml=RUN/(label+'.xml')
 if xml.exists():
  import xml.etree.ElementTree as ET
  node=ET.parse(xml).getroot().find('assembly');d['testCounts']={k:int(node.attrib[k]) for k in ['total','passed','failed','skipped','errors']}
 with (RUN/'commands.jsonl').open('a') as f:f.write(json.dumps(d)+'\n')
 print(label,'exit',code,out.decode(errors='replace')[-1300:],flush=True)
 return code
source=['--configuration','Debug','-p:UseHexalithProjectReferences=true','-p:UseNuGetDeps=false','-m:1','-warnaserror',f'-p:CustomAfterMicrosoftCommonTargets={RUN / "identity.targets"}']
cmd('platform-debug-composition-build-fixed',['dotnet','build','tests/Hexalith.Platform.Composition.Tests/Hexalith.Platform.Composition.Tests.csproj',*source],ROOT/'references/Hexalith.Platform')
cmd('folders-debug-production-tests-corrected',['dotnet','tests/Hexalith.Folders.Server.Tests/bin/Debug/net10.0/Hexalith.Folders.Server.Tests.dll','-class','Hexalith.Folders.Server.Tests.WorkspaceContentProductionTests','-xml',str(RUN/'folders-debug-production-tests-corrected.xml')])
# Existing safe unit method rejects run mode before creating local resources or reading module roots.
cmd('platform-debug-run-refusal-test',['dotnet','tests/Hexalith.Platform.Composition.Tests/bin/Debug/net10.0/Hexalith.Platform.Composition.Tests.dll','-method','Hexalith.Platform.Composition.Tests.PlatformHostedPublishingTests.HostedEntryRefusesRunModeBeforeGeneratingLocalResourcesOrSecrets','-xml',str(RUN/'platform-debug-run-refusal-test.xml')],ROOT/'references/Hexalith.Platform')
# Reuse exact test filters from the final dependency receipt, with new logs and XML.
old=json.loads((ROOT/'_bmad-output/implementation-artifacts/evidence/story-1-17-current-dependency-qualification-2026-10-25.json').read_text())
for oldid,newid in [('server-release-tests','folders-release-server-tests'),('authorization-routing','folders-release-authorization-routing'),('contracts-release-tests','folders-release-contracts'),('projects-adapter-tests','projects-released-adapter-tests')]:
 c=next(c for c in old['checks'] if c['id']==oldid);args=c['command'];args[-1]=str(RUN/(newid+'.xml'));cwd=ROOT/'references/Hexalith.Projects' if oldid.startswith('projects') else ROOT
 cmd(newid,args,cwd)
cmd('parity',['pwsh','tests/tools/run-contract-parity-ci-gates.ps1','-NoRestore','-OutputReportPath',str(RUN/'parity-report.json')])
cmd('governance',['pwsh','tests/tools/run-governance-completeness-gates.ps1','-SkipRestoreBuild'])
for n in ['one','two']:cmd('candidate-'+n,['python3','scripts/generate-pd10-v2-conformance-set.py','--repository-root',str(ROOT),'--output',str(RUN/('candidate-'+n+'.yaml'))])
cmd('platform-tool-list',['dotnet','tool','list','--local'],ROOT/'references/Hexalith.Platform')
cmd('platform-tool-version',['dotnet','tool','run','hexalith-module','--version'],ROOT/'references/Hexalith.Platform')
# Preserve the user's existing ignored diagnostic artifacts and report before the existing DryRun lane writes them.
if (ROOT/'nupkgs').exists():shutil.copytree(ROOT/'nupkgs',RUN/'preexisting-nupkgs')
report=ROOT/'_bmad-output/gates/release-packages/latest.json'
if report.exists():shutil.copy2(report,RUN/'preexisting-release-report.json')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()
cmd('release-package-dry-run',['pwsh','tests/tools/run-release-package-gates.ps1','-Version','0.0.0-story117.20261025','-SourceRevisionId',head,'-SkipRestoreBuild'])
if report.exists():shutil.copy2(report,RUN/'release-package-report.json')
shutil.copytree(ROOT/'nupkgs',RUN/'diagnostic-packages')
# Restore the generated directories to their precise pre-run contents after retaining this run's artifacts.
shutil.rmtree(ROOT/'nupkgs')
if (RUN/'preexisting-nupkgs').exists():shutil.copytree(RUN/'preexisting-nupkgs',ROOT/'nupkgs')
if (RUN/'preexisting-release-report.json').exists():shutil.copy2(RUN/'preexisting-release-report.json',report)
print('PHASE2_COMPLETE',RUN,flush=True)
