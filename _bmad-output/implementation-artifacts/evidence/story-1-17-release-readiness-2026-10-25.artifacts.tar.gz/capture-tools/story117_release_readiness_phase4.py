from pathlib import Path
exec(Path('/tmp/story117_release_readiness_phase2.py').read_text().split("source=['--configuration'")[0])
cmd('pdb-inspector-build-recorded',['dotnet','build','/tmp/story117-pdb-inspector/Inspector.csproj','--configuration','Debug','-m:1','-warnaserror'])
# Adoption audits use the working directory as repository scope. Call the already installed exact released tool in each owning root.
tool=Path.home()/'.nuget/packages/hexalith.builds.module.cli/4.35.2/tools/net10.0/any/Hexalith.Builds.Module.Cli.dll'
cmd('exact-cached-tool-version',['dotnet',str(tool),'--version'])
for name,cwd in [('folders',ROOT),('projects',ROOT/'references/Hexalith.Projects'),('eventstore',ROOT/'references/Hexalith.EventStore'),('tenants',ROOT/'references/Hexalith.Tenants'),('memories',ROOT/'references/Hexalith.Memories')]:
 cmd('owning-intake-'+name+'-adoption',['dotnet',str(tool),'validate','--manifest','module/hexalith.module-manifest.v2.json','--adoption','--output','json'],cwd,timeout=90)
exec(Path('/tmp/story117_release_readiness_phase3.py').read_text().split('# Candidate-only')[1])
