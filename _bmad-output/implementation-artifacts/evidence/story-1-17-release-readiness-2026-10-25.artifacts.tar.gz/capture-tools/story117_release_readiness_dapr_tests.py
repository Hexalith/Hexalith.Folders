from pathlib import Path
import subprocess,datetime,hashlib,json,os,socket,time,urllib.request,xml.etree.ElementTree as ET,uuid
ROOT=Path('<workspace>');RUN=Path(Path('/tmp/story117-release-readiness-current-path').read_text());owner=ROOT/'references/Hexalith.Projects'
name='story117-state-'+uuid.uuid4().hex[:12];dapr=Path.home()/'.dapr/bin/daprd';component=RUN/'isolated-state-components';component.mkdir(exist_ok=True)
def port():
 with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
redisPort,http,grpc,internal,metrics=[port() for _ in range(5)]
image=subprocess.check_output(['docker','image','inspect','redis:7.4-alpine','--format','{{.Id}}']).decode().strip()
version=subprocess.check_output([str(dapr),'--version']).decode().strip()
(component/'statestore.yaml').write_text(f'apiVersion: dapr.io/v1alpha1\nkind: Component\nmetadata:\n  name: statestore\nspec:\n  type: state.redis\n  version: v1\n  metadata:\n    - name: redisHost\n      value: "127.0.0.1:{redisPort}"\n    - name: actorStateStore\n      value: "false"\n')
container=None;process=None;record={'scope':'Owned disposable local test persistence only; no existing stores, AppHosts, hosted release or staging used.','appId':name,'daprdVersion':version,'daprdSha256':hashlib.sha256(dapr.read_bytes()).hexdigest(),'cachedRedisImage':image,'pullPolicy':'never','loopbackOnly':True,'environmentInputs':['STORY61_DAPR_HTTP_ENDPOINT','STORY61_DAPR_GRPC_ENDPOINT'],'environmentValuesRetained':False,'startedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
try:
 container=subprocess.check_output(['docker','run','--pull','never','--rm','--detach','--name',name,'--publish',f'127.0.0.1:{redisPort}:6379',image],stderr=subprocess.STDOUT).decode().strip();record['containerId']=container
 args=[str(dapr),'--mode','standalone','--app-id',name,'--dapr-http-port',str(http),'--dapr-grpc-port',str(grpc),'--dapr-internal-grpc-port',str(internal),'--dapr-listen-addresses','127.0.0.1','--dapr-internal-grpc-listen-address','127.0.0.1','--metrics-port',str(metrics),'--metrics-listen-address','127.0.0.1','--enable-metrics=false','--enable-api-logging=false','--scheduler-host-address=127.0.0.1:1','--placement-host-address=127.0.0.1:1','--log-level','error','--resources-path',str(component)]
 log=(RUN/'dapr-isolated.txt').open('wb');process=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT)
 deadline=time.monotonic()+40
 while True:
  if process.poll() is not None:raise RuntimeError('Owned daprd exited before readiness')
  try:
   with urllib.request.urlopen(f'http://127.0.0.1:{http}/v1.0/healthz/outbound',timeout=1) as response:
    if response.status==204:break
  except Exception:pass
  if time.monotonic()>deadline:raise RuntimeError('Owned daprd readiness timed out')
  time.sleep(.2)
 record['outboundReady']=True
 dll=next((RUN/'projects-source-explicit').glob('bin/Hexalith.Projects.Server.Tests/**/Hexalith.Projects.Server.Tests.dll'))
 xml=RUN/'projects-explicit-source-owned-state-tests.xml'
 command=['dotnet',str(dll),'-class','Hexalith.Projects.Server.Tests.ProjectFolderDirectoryTests','-class','Hexalith.Projects.Server.Tests.ProjectFileReferenceDirectoryTests','-class','Hexalith.Projects.Server.Tests.DelegatedProjectDirectoryRegistrationTests','-class','Hexalith.Projects.Server.Tests.Queries.DelegatedProjectAdvisoryConversationDirectoryTests','-class','Hexalith.Projects.Server.Tests.Queries.SupportedProjectAuthorityHttpTests','-xml',str(xml)]
 env=dict(os.environ);env['STORY61_DAPR_HTTP_ENDPOINT']=f'http://127.0.0.1:{http}';env['STORY61_DAPR_GRPC_ENDPOINT']=f'http://127.0.0.1:{grpc}'
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();print('RUN projects-explicit-source-owned-state-tests',flush=True)
 r=subprocess.run(command,cwd=owner,capture_output=True,env=env,timeout=300);out=r.stdout+r.stderr
 for a,b in [(str(ROOT),'<workspace>'),(str(RUN),'<capsule>'),(str(Path.home()),'<home>')]:out=out.replace(a.encode(),b.encode())
 out=out.replace(str(http).encode(),b'<owned-http-port>').replace(str(grpc).encode(),b'<owned-grpc-port>')
 logfile=RUN/'logs/projects-explicit-source-owned-state-tests.txt';logfile.write_bytes(out)
 counts={k:int(ET.parse(xml).getroot().find('assembly').get(k)) for k in ['total','passed','failed','skipped','errors']}
 result={'label':'projects-explicit-source-owned-state-tests','command':[s.replace(str(RUN),'<capsule>') for s in command],'workingDirectory':'references/Hexalith.Projects','startedAtUtc':started,'completedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode,'log':'logs/projects-explicit-source-owned-state-tests.txt','sha256':hashlib.sha256(out).hexdigest(),'testCounts':counts,'environmentInputNames':record['environmentInputs'],'environmentValuesRetained':False}
 with (RUN/'commands.jsonl').open('a') as f:f.write(json.dumps(result)+'\n')
 record['testResult']=result;print('TEST_RESULT',r.returncode,counts,flush=True)
except Exception as error:
 record['failureType']=type(error).__name__;record['failure']=str(error);print('HARNESS_BLOCKER',type(error).__name__,str(error),flush=True)
finally:
 if process is not None:
  process.terminate()
  try:process.wait(timeout=15)
  except subprocess.TimeoutExpired:process.kill();process.wait(timeout=5)
  record['ownedDaprdExitCode']=process.returncode;record['ownedDaprdStopped']=process.poll() is not None
 if container:
  stop=subprocess.run(['docker','stop','--time','5',container],capture_output=True,timeout=20);record['ownedRedisStopExitCode']=stop.returncode
  check=subprocess.run(['docker','container','inspect',container,'--format','{{.Id}}'],capture_output=True,timeout=10);record['ownedRedisAbsent']=check.returncode!=0
 record['finishedAtUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(RUN/'isolated-state-harness.json').write_text(json.dumps(record,indent=2)+'\n')
 print('HARNESS_CLEANUP',record.get('ownedDaprdStopped'),record.get('ownedRedisAbsent'),flush=True)
