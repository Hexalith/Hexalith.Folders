import ast, datetime, hashlib, json, os, shutil, subprocess, tarfile
from pathlib import Path

ROOT=Path('/home/administrator/projects/hexalith/folders')
BASE=ROOT/'_bmad-output/implementation-artifacts'
OUT=Path(__file__).parent
NAME='story-1-17-cli-4-38-filter-reset-analysis-2026-10-26'
def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def bind(path):return dict(path=str(path.relative_to(ROOT)),sha256=sha(path),bytes=path.stat().st_size)
def write(path,value):Path(path).write_text(json.dumps(value,indent=2)+'\n')
def git(repo,*args):return subprocess.check_output(['git','-C',str(ROOT/repo),*args])

execution_path=BASE/'evidence/story-1-17-cli-4-38-loader-execution-2026-10-26.json'
assert sha(execution_path)=='565555482f5f607d07fd26dd927b15cf2640a0fdb29755891879a6737bf3fc19'
execution=json.loads(execution_path.read_text())
for item in [execution['evidence']['archive'],execution['evidence']['memberManifest']]:
    p=ROOT/item['path'];assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256']
members=json.loads((ROOT/execution['evidence']['memberManifest']['path']).read_text())['members']
with tarfile.open(ROOT/execution['evidence']['archive']['path']) as archive:
    assert len([m for m in archive.getmembers() if m.isfile()])==315==len(members)
    for item in members:
        member=archive.getmember(item['path']);assert member.size==item['bytes']
        assert hashlib.file_digest(archive.extractfile(member),'sha256').hexdigest()==item['sha256']

plan_path=BASE/'story-1-17-cli-4-38-filter-reset-plan-2026-10-26.json'
plan=json.loads(plan_path.read_text());adapter=ROOT/plan['adapter']['path'];tests=ROOT/plan['guardTests']['source']['path']
assert sha(adapter)==plan['adapter']['sha256'];assert sha(tests)==plan['guardTests']['source']['sha256']
ast.parse(adapter.read_text());ast.parse(tests.read_text())
test_result=json.loads((OUT/'guard-tests.command.json').read_text())
assert test_result['exitCode']==0 and test_result['testedAdapterSha256']==sha(adapter) and test_result['testedSourceSha256']==sha(tests)
source=ROOT/plan['driverRepair']['beforePath'];assert sha(source)==plan['driverRepair']['beforeSha256']
before=source.read_text();repair=plan['driverRepair'];assert before.count(repair['anchor'])==1
after=before.replace(repair['anchor'],repair['replacement']).encode()
assert hashlib.sha256(after).hexdigest()==repair['afterSha256'] and len(after)==repair['afterBytes'];ast.parse(after.decode())
assert sha(ROOT/repair['patch']['path'])==repair['patch']['sha256']
assert not Path(plan['authorization']['path']).exists()
assert not Path(plan['attemptClaimDirectory']).exists(), 'Proposal tests must not create the actual attempt ledger.'

current={}
for repo,expected in execution['repositoryStateAtExecution'].items():
    index=git(repo,'ls-files','--stage');flags=git(repo,'ls-files','-v','-z')
    hidden=[row.decode() for row in flags.split(b'\0') if row and (row[:1]==b'S' or row[:1].islower())]
    actual=dict(revision=git(repo,'rev-parse','HEAD').decode().strip(),indexEntriesSha256=hashlib.sha256(index).hexdigest(),
        status=git(repo,'status','--porcelain=v2','--untracked-files=all').decode(),staged=git(repo,'diff','--cached','--raw').decode(),
        hiddenIndexFlags=hidden,flagObservation='Current post-execution observation only; not historical flag attestation.')
    assert actual['revision']==expected['revision'] and actual['indexEntriesSha256']==expected['indexEntriesSha256']
    assert actual['staged']=='' and git(repo,'diff','--name-only')==b'' and not hidden
    if repo!='.':assert actual['status']==''
    current[repo]=actual
untracked={p.decode() for p in git('.','ls-files','--others','--exclude-standard','-z').split(b'\0') if p}
assert untracked <= set(plan['rootRecordingPaths']), untracked-set(plan['rootRecordingPaths'])
old_plan=json.loads((ROOT/plan['originalPlan']['path']).read_text())
old_inputs=json.loads((ROOT/plan['inputDerivation']['source']['path']).read_text())
for item in old_plan['artifacts']+old_plan['supportingArtifacts']+old_inputs['preservedFiles']+[plan['originalExecutionApproval'],plan['priorRootRebindApproval']]:
    p=ROOT/item['path'];assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256']
for item in old_inputs['sdk']['files']:
    p=Path(item['path']);assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256']
write(OUT/'final-preservation.json',dict(recordedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),repositories=current,
    failedExecutionCapsuleMembersVerified=315,originalApprovalsPacketAnd503SdkFilesPreserved=True,
    approvedDriverChanged=False,modelHostLoadsSinceFailure=0,sandboxInvocationsSinceFailure=0,
    proposedAdapterMainExecuted=False,actualAttemptLedgerCreated=False,limits='Explicit bindings, indices/status and current flags only; no whole-host or all-ignored-file claim.'))
authored=[BASE/'story-1-17-cli-4-38-filter-reset-proposal-2026-10-26.md',plan_path,ROOT/repair['patch']['path'],adapter,tests]
for p in authored:
    destination=OUT/'proposal'/p.name;destination.parent.mkdir(exist_ok=True);shutil.copyfile(p,destination)
write(OUT/'actual-execution-binding.json',dict(receipt=bind(execution_path),archive=execution['evidence']['archive'],manifest=execution['evidence']['memberManifest'],verifiedMembers=315))
files=sorted(p for p in OUT.rglob('*') if p.is_file())
manifest=dict(format='sha256-file-members-v1',members=[dict(path=str(p.relative_to(OUT)),sha256=sha(p),bytes=p.stat().st_size) for p in files])
manifest_path=BASE/'evidence'/f'{NAME}.members.json';write(manifest_path,manifest)
archive_path=BASE/'evidence'/f'{NAME}.artifacts.tar.gz'
with tarfile.open(archive_path,'w:gz') as archive:
    for p in files:archive.add(p,arcname=str(p.relative_to(OUT)),recursive=False)
with tarfile.open(archive_path) as archive:
    assert len([m for m in archive.getmembers() if m.isfile()])==len(manifest['members'])
    for item in manifest['members']:
        m=archive.getmember(item['path']);assert m.size==item['bytes']
        assert hashlib.file_digest(archive.extractfile(m),'sha256').hexdigest()==item['sha256']
receipt=dict(recordId='STORY-1-17-CLI-4-38-FILTER-RESET-ANALYSIS-2026-10-26',recordedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    status='FAILED_ATTEMPT_PRESERVED_PRIVATE_REPAIR_PROPOSED_UNAPPLIED',
    actualExecution=bind(execution_path),actualExecutionCounts=execution['executionCounts'],
    actualOutcome=execution['outcome'],
    diagnosis=dict(classification='Concrete source defect and strongly supported explanation; actual historical cursor not measured.',
        defect='One shared seccomp file descriptor is read through EOF by bwrap and reused without seek. A later call can load zero filter instructions.',
        observedFilterBytes=120,observedFilterSha256='92b4ad47fbfa2d39d14bcfc40dc3354a2adabcb632a0c0cbe1b1c017b59c3e48',
        actualDescriptorOffset=None,sourceProvenance=json.loads((OUT/'source-provenance.json').read_text()),installedBinary=json.loads((OUT/'installed-bubblewrap-binding.json').read_text()),
        limitations=['Upstream tag source is not proven equivalent to Ubuntu patched binary.','No offset probe or repaired sandbox execution was performed.']),
    proposedPatch=bind(ROOT/repair['patch']['path']),beforeDriverSha256=repair['beforeSha256'],proposedAfterDriverSha256=repair['afterSha256'],
    driverAddedLines=4,driverRemovedLines=0,repositoryPatchApplied=False,proposedDriverExecuted=False,
    freshAttemptPlan=bind(plan_path),authoredArtifacts=[bind(p) for p in authored],
    review=json.loads((OUT/'review-triage.json').read_text()),
    guardTests=dict(count=13,passed=13,command=test_result,scope='Pure definitions and launch wiring only; no Git mutation, adapter main, bwrap, SDK or target assembly execution.'),
    artifactArchive=bind(archive_path),memberManifest=bind(manifest_path),membersVerified=len(manifest['members']),
    preservation=dict(all13RevisionsAndIndicesPreserved=True,all12DirectCheckoutsPreserved=True,existingApprovalsAndApprovedSpecBytesPreserved=True,
        originalFailed315MemberCapsuleUnchanged=True,currentHiddenIndexFlags=[],stagedEntries=[],freshAuthorityFileExists=False,
        sdkTargetCommandsCompleted=1,loaderCasesExecuted=0,retries=0,newGuardTestsOnly=13,scope='Hash-bound files and Git observations; no full-machine claim.'),
    ownerDecision=dict(decisionMaker='Jerome',status='PENDING',authorized=False,question='Authorize only the exact private-copy filter repair and guarded single fresh attempt?',
        previousExecutionAuthorityConsumed=True,freshAttemptAuthorityRequired=True),
    necessaryDependencyOrBuildPropertyChange=False,selectedRedisCatalogPin='3.4.5',operationalSourcePatch=None,
    ordinaryMapping=None,ContentHash=None,operationalControl=execution['operationalControl'],parentStatus='in-progress',trackerStatus='backlog',
    stagingChecks=dict(total=14,executed=0),historicalAcceptedCli='4.35.2',candidateCli='4.38.0',currentTupleAccepted=False,packageAccepted=False,hostedAccepted=False,
    historicalImmediateSdkGate='Incomplete and unchanged; no rerun of completed model build.',
    staged=False,committed=False,pushed=False,published=False,deployed=False,dependenciesChanged=False,nestedSubmodulesInitialized=False)
receipt_path=BASE/'evidence'/f'{NAME}.json';write(receipt_path,receipt)
print(json.dumps(dict(receipt=str(receipt_path),receiptSha256=sha(receipt_path),analysisMembers=len(manifest['members']),
    planSha256=sha(plan_path),patchSha256=sha(ROOT/repair['patch']['path']),proposedDriverAfterSha256=repair['afterSha256'],
    verification='13 pure guard tests pass; three review layers triaged and focused followup found no remaining blocker; patched driver/main remain unexecuted.')))
