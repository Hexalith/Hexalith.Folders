import sys,json,subprocess,hashlib,datetime,xml.etree.ElementTree as ET
from pathlib import Path
scratch=Path(__file__).parent
name=sys.argv[1]; cmd=sys.argv[2:]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
log=scratch/(name+'.log')
with log.open('w') as out:
 result=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
r={'id':name,'command':cmd,'cwd':str(Path.cwd()),'started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':result.returncode,'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
if '-xml' in cmd:
 xml=Path(cmd[cmd.index('-xml')+1])
 if xml.exists():
  r['counts']={k:sum(int(a.get(k,'0')) for a in ET.parse(xml).getroot().iter('assembly')) for k in ['total','passed','failed','skipped','errors']}
  r['xml']=xml.name;r['xml_sha256']=hashlib.sha256(xml.read_bytes()).hexdigest()
(scratch/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))
print('\n'.join(log.read_text().splitlines()[-15:]))
sys.exit(result.returncode)
