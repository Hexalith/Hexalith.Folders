from pathlib import Path
p=Path('tests/Hexalith.Folders.IntegrationTests/Authorization/ContextReadAuthorityTests.cs');s=p.read_text()
s=s.replace('status == FolderPermissionEvidenceStatus.Allowed ? 3 : 2','status == FolderPermissionEvidenceStatus.Allowed ? 4 : 2')
s=s.replace('bool delegated = false, IFolderTenantAccessProjectionStore? tenantStore = null)','bool delegated = false, IFolderTenantAccessProjectionStore? tenantStore = null,\n        bool productionValidator = false, IEventStoreAuthorizationValidator? validatorOverride = null,\n        IDaprPolicyEvidenceProvider? daprOverride = null, Action<List<Claim>>? alterClaims = null)')
s=s.replace('        Replace(builder, validator);','''        if (productionValidator)
        {
            builder.Services.RemoveAll<IEventStoreAuthorizationValidator>();
            builder.Services.AddScoped<IEventStoreAuthorizationValidator, VerifiedReceiptEventStoreAuthorizationValidator>();
        }
        else Replace(builder, validatorOverride ?? validator);''')
s=s.replace('        Replace(builder, dapr);','        Replace(builder, daprOverride ?? dapr);')
s=s.replace('            http.User = new ClaimsPrincipal', '            alterClaims?.Invoke(claims);\n            http.User = new ClaimsPrincipal')
s=s.replace('private static HttpRequestMessage Request(string operation, bool candidate)','private static HttpRequestMessage Request(string operation, bool candidate, int pathCount = 1)')
s=s.replace('object[] paths = [new { normalizedPath = "docs/a.txt", displayName = "a.txt", pathPolicyClass = "tenant_sensitive_document", unicodeNormalization = "NFC" }];','object[] paths = Enumerable.Range(0, pathCount).Select(index => (object)new { normalizedPath = $"docs/a{index}.txt", displayName = $"a{index}.txt", pathPolicyClass = "tenant_sensitive_document", unicodeNormalization = "NFC" }).ToArray();')
idx=s.index('    private static WebApplication BuildApp(')
s=s[:idx]+'''    [Theory]
    [InlineData(false, false)]
    [InlineData(false, true)]
    [InlineData(true, false)]
    [InlineData(true, true)]
    public async Task ProductionValidatorChecksTheDistinctSignedDelegator(bool candidate, bool changedDelegator)
    {
        IFolderPermissionEvidenceProvider evidence = Substitute.For<IFolderPermissionEvidenceProvider>();
        evidence.GetEvidenceAsync(Arg.Any<FolderPermissionEvidenceRequest>(), Arg.Any<CancellationToken>()).Returns(call =>
        {
            if (changedDelegator && call.Arg<FolderPermissionEvidenceRequest>().PrincipalId == "delegator-a")
            {
                var identity = (ClaimsIdentity)new HttpContextAccessor().HttpContext!.User.Identity!;
                foreach (Claim claim in identity.FindAll("eventstore:delegator").ToArray()) identity.RemoveClaim(claim);
                identity.AddClaim(new("eventstore:delegator", "another-delegator"));
            }
            return FolderPermissionEvidenceResult.Allowed("acl:1");
        });
        IWorkspaceFileContextSource source = Source();
        IWorkspaceFileSensitivityClassifier sensitivity = Sensitivity();
        await using WebApplication app = BuildApp(evidence, source, sensitivity, delegated: true, productionValidator: true);
        await app.StartAsync(TestContext.Current.CancellationToken);
        using HttpResponseMessage response = await app.GetTestClient().SendAsync(Request("metadata", candidate), TestContext.Current.CancellationToken);
        response.StatusCode.ShouldBe(changedDelegator ? HttpStatusCode.NotFound : HttpStatusCode.OK,
            await response.Content.ReadAsStringAsync(TestContext.Current.CancellationToken));
        if (changedDelegator)
        {
            await source.DidNotReceive().QueryAsync(Arg.Any<WorkspaceFileContextSourceRequest>(), Arg.Any<CancellationToken>());
            await sensitivity.DidNotReceive().ClassifyAsync(Arg.Any<PathMetadata>(), Arg.Any<CancellationToken>());
            if (candidate) await AssertCanonicalAsync(response, "tenant_access_denied", "resource_unavailable");
        }
    }

    [Theory]
    [InlineData("unavailable")]
    [InlineData("throw")]
    [InlineData("stale-allowed")]
    [InlineData("malformed-allowed")]
    [InlineData("malformed-dapr")]
    [InlineData("stateless-fresh")]
    public async Task InnerEvidenceAvailabilitySurvivesTheHttpBoundary(string state)
    {
        ArgumentNullException.ThrowIfNull(state);
        foreach (bool candidate in new[] { false, true })
        {
            int validations = 0, policies = 0;
            IEventStoreAuthorizationValidator validator = Substitute.For<IEventStoreAuthorizationValidator>();
            validator.ValidateAsync(Arg.Any<EventStoreAuthorizationValidationRequest>(), Arg.Any<CancellationToken>()).Returns(_ =>
            {
                if (candidate && ++validations == 1) return EventStoreAuthorizationValidationResult.Allowed(null);
                return state switch
                {
                    "throw" => throw new IOException("synthetic validator outage"),
                    "unavailable" => EventStoreAuthorizationValidationResult.Unavailable(),
                    "stale-allowed" => EventStoreAuthorizationValidationResult.Allowed(null) with { FreshnessClass = "stale" },
                    "malformed-allowed" => EventStoreAuthorizationValidationResult.Allowed(null) with { FreshnessClass = "malformed" },
                    _ => EventStoreAuthorizationValidationResult.Allowed(null),
                };
            });
            IDaprPolicyEvidenceProvider dapr = Substitute.For<IDaprPolicyEvidenceProvider>();
            dapr.GetEvidenceAsync(Arg.Any<DaprPolicyEvidenceRequest>(), Arg.Any<CancellationToken>()).Returns(_ =>
                state == "malformed-dapr" && (!candidate || ++policies > 1) ? DaprPolicyEvidenceResult.Malformed()
                    : DaprPolicyEvidenceResult.Allowed("folders", null));
            IFolderPermissionEvidenceProvider evidence = Substitute.For<IFolderPermissionEvidenceProvider>();
            evidence.GetEvidenceAsync(Arg.Any<FolderPermissionEvidenceRequest>(), Arg.Any<CancellationToken>())
                .Returns(FolderPermissionEvidenceResult.Allowed("acl:1"));
            IWorkspaceFileContextSource source = Source();
            IWorkspaceFileSensitivityClassifier sensitivity = Sensitivity();
            await using WebApplication app = BuildApp(evidence, source, sensitivity, validatorOverride: validator, daprOverride: dapr);
            await app.StartAsync(TestContext.Current.CancellationToken);
            using HttpResponseMessage response = await app.GetTestClient().SendAsync(Request("metadata", candidate), TestContext.Current.CancellationToken);
            response.StatusCode.ShouldBe(state == "stateless-fresh" ? HttpStatusCode.OK : HttpStatusCode.ServiceUnavailable);
            if (state != "stateless-fresh")
            {
                if (candidate) await AssertCanonicalAsync(response, "read_model_unavailable", "projection_unavailable");
                else
                {
                    using JsonDocument problem = JsonDocument.Parse(await response.Content.ReadAsStringAsync(TestContext.Current.CancellationToken));
                    problem.RootElement.GetProperty("retryable").GetBoolean().ShouldBeTrue();
                    problem.RootElement.GetProperty("details").GetProperty("visibility").GetString().ShouldBe("metadata_only");
                }
                await source.DidNotReceive().QueryAsync(Arg.Any<WorkspaceFileContextSourceRequest>(), Arg.Any<CancellationToken>());
                await sensitivity.DidNotReceive().ClassifyAsync(Arg.Any<PathMetadata>(), Arg.Any<CancellationToken>());
            }
        }
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task MissingWatermarkCannotTurnFreshNegativeTenantEvidenceIntoDefinitiveDenial(bool disabled)
    {
        foreach (bool candidate in new[] { false, true })
        {
            int reads = 0;
            IFolderTenantAccessProjectionStore tenants = Substitute.For<IFolderTenantAccessProjectionStore>();
            tenants.GetAsync(Arg.Any<string>(), Arg.Any<CancellationToken>()).Returns(_ =>
            {
                bool outer = candidate && ++reads == 1;
                return new FolderTenantAccessProjection
                {
                    TenantId = "tenant-a", Enabled = outer || !disabled, Watermark = 1,
                    ProjectionWatermark = outer ? "tenant:1" : string.Empty, LastEventTimestamp = Now,
                    Principals = outer ? new(StringComparer.Ordinal) { ["actor-a"] = new("actor-a", "Member") } : new(StringComparer.Ordinal),
                };
            });
            IFolderPermissionEvidenceProvider evidence = Substitute.For<IFolderPermissionEvidenceProvider>();
            evidence.GetEvidenceAsync(Arg.Any<FolderPermissionEvidenceRequest>(), Arg.Any<CancellationToken>()).Returns(FolderPermissionEvidenceResult.Allowed("acl:1"));
            IWorkspaceFileContextSource source = Source(); IWorkspaceFileSensitivityClassifier sensitivity = Sensitivity();
            await using WebApplication app = BuildApp(evidence, source, sensitivity, tenantStore: tenants);
            await app.StartAsync(TestContext.Current.CancellationToken);
            using HttpResponseMessage response = await app.GetTestClient().SendAsync(Request("metadata", candidate), TestContext.Current.CancellationToken);
            response.StatusCode.ShouldBe(HttpStatusCode.ServiceUnavailable);
            await source.DidNotReceive().QueryAsync(Arg.Any<WorkspaceFileContextSourceRequest>(), Arg.Any<CancellationToken>());
            await sensitivity.DidNotReceive().ClassifyAsync(Arg.Any<PathMetadata>(), Arg.Any<CancellationToken>());
        }
    }

    [Theory]
    [InlineData(WorkspaceFileSensitivityDecision.Allowed)]
    [InlineData(WorkspaceFileSensitivityDecision.Redacted)]
    [InlineData(WorkspaceFileSensitivityDecision.Unavailable)]
    public async Task EachClassificationRechecksRevocationBeforeItsResultOrTheNextPath(WorkspaceFileSensitivityDecision decision)
    {
        bool revoked = false;
        IFolderPermissionEvidenceProvider evidence = Substitute.For<IFolderPermissionEvidenceProvider>();
        evidence.GetEvidenceAsync(Arg.Any<FolderPermissionEvidenceRequest>(), Arg.Any<CancellationToken>()).Returns(_ => revoked
            ? FolderPermissionEvidenceResult.FromStatus(FolderPermissionEvidenceStatus.Denied, "acl:2") : FolderPermissionEvidenceResult.Allowed("acl:1"));
        IWorkspaceFileContextSource source = Source(); IWorkspaceFileSensitivityClassifier sensitivity = Sensitivity();
        sensitivity.ClassifyAsync(Arg.Any<PathMetadata>(), Arg.Any<CancellationToken>()).Returns(_ =>
        {
            revoked = true;
            return decision switch
            {
                WorkspaceFileSensitivityDecision.Redacted => WorkspacePathSensitivityResult.Redacted(),
                WorkspaceFileSensitivityDecision.Unavailable => WorkspacePathSensitivityResult.Unavailable(),
                _ => WorkspacePathSensitivityResult.Allowed(),
            };
        });
        await using WebApplication app = BuildApp(evidence, source, sensitivity);
        await app.StartAsync(TestContext.Current.CancellationToken);
        using HttpResponseMessage response = await app.GetTestClient().SendAsync(Request("metadata", true, pathCount: 2), TestContext.Current.CancellationToken);
        response.StatusCode.ShouldBe(HttpStatusCode.NotFound);
        await AssertCanonicalAsync(response, "tenant_access_denied", "resource_unavailable");
        await sensitivity.Received(1).ClassifyAsync(Arg.Any<PathMetadata>(), Arg.Any<CancellationToken>());
        await source.DidNotReceive().QueryAsync(Arg.Any<WorkspaceFileContextSourceRequest>(), Arg.Any<CancellationToken>());
        string body = await response.Content.ReadAsStringAsync(TestContext.Current.CancellationToken);
        body.ShouldNotContain("docs/"); body.ShouldNotContain("contentBytes");
    }

    [Theory]
    [InlineData("conflicting")]
    [InlineData("missing-permission")]
    [InlineData("missing-delegator")]
    [InlineData("blank")]
    [InlineData("self")]
    public async Task LegacyRealClaimAccessorRejectsMalformedDelegationBeforeObservation(string state)
    {
        IFolderPermissionEvidenceProvider evidence = Substitute.For<IFolderPermissionEvidenceProvider>();
        evidence.GetEvidenceAsync(Arg.Any<FolderPermissionEvidenceRequest>(), Arg.Any<CancellationToken>()).Returns(FolderPermissionEvidenceResult.Allowed("acl:1"));
        IWorkspaceFileContextSource source = Source(); IWorkspaceFileSensitivityClassifier sensitivity = Sensitivity();
        await using WebApplication app = BuildApp(evidence, source, sensitivity, delegated: true, productionValidator: true, alterClaims: claims =>
        {
            if (state == "conflicting") claims.Add(new("eventstore:delegator", "another-delegator"));
            else if (state == "missing-permission") claims.RemoveAll(claim => claim.Type == "eventstore:delegator-permission");
            else if (state == "missing-delegator") claims.RemoveAll(claim => claim.Type == "eventstore:delegator");
            else
            {
                claims.RemoveAll(claim => claim.Type == "eventstore:delegator");
                claims.Add(new("eventstore:delegator", state == "self" ? "actor-a" : " "));
            }
        });
        await app.StartAsync(TestContext.Current.CancellationToken);
        using HttpResponseMessage response = await app.GetTestClient().SendAsync(Request("metadata", false), TestContext.Current.CancellationToken);
        response.StatusCode.ShouldBe(HttpStatusCode.ServiceUnavailable);
        await source.DidNotReceive().QueryAsync(Arg.Any<WorkspaceFileContextSourceRequest>(), Arg.Any<CancellationToken>());
        await sensitivity.DidNotReceive().ClassifyAsync(Arg.Any<PathMetadata>(), Arg.Any<CancellationToken>());
    }

'''+s[idx:]
p.write_text(s)
