import datetime,json,pathlib,subprocess,sys
scratch=pathlib.Path(__file__).parent
name=sys.argv[1]; args=sys.argv[2:]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (scratch/(name+'.log')).open('w') as out:
 r=subprocess.run(args,cwd='/home/administrator/projects/hexalith/folders',stdout=out,stderr=subprocess.STDOUT)
record={'id':name,'command':args,'cwd':'/home/administrator/projects/hexalith/folders','started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':r.returncode,'log':name+'.log'}
p=scratch/'checks.json'; data=json.loads(p.read_text()) if p.exists() else [];data.append(record);p.write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(record));print((scratch/(name+'.log')).read_text()[-3500:]);sys.exit(r.returncode)
