import hashlib,json,pathlib,re,subprocess
root=pathlib.Path('/home/administrator/projects/hexalith/folders');scratch=pathlib.Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
initial=json.loads((scratch/'initial-controls.json').read_text())
controls={p:{'before':expected,'after':sha(root/p)} for p,expected in initial['protected_hashes'].items()}
assert all(v['before']==v['after'] for v in controls.values()),'Protected controls changed'
spec=(root/'_bmad-output/implementation-artifacts/spec-1-17-complete-pd10-v2-migration-and-closure.md').read_text()
assert re.search(r'<frozen-after-approval\b.*?</frozen-after-approval>',spec,re.S)[0]==initial['spec_frozen']
assert spec.split('---')[1]==initial['spec_frontmatter']
assert re.findall(r'^- \[[ x]\].*',spec,re.M)==initial['spec_tasks']
manifest=(root/'_bmad-output/planning-artifacts/planning-story-manifest.yaml').read_text()
provenance=re.search(r'(?ms)^provenance:\n.*?(?=^post_a8_finalization:)',manifest)[0]
bindings=re.findall(r'(?m)^- path: (.+)\n  sha256: ([0-9a-f]{64})$',provenance)
assert len(bindings)==20
assert all(sha(root/p)==h for p,h in bindings)
qualified=json.loads((scratch/'final-inputs-before.json').read_text())
changed=[p for p,h in qualified.items() if sha(root/p)!=h]
assert not changed,changed
candidate=root/'_bmad-output/implementation-artifacts/evidence/story-12-2-v2-source-requalification-pending.yaml'
generations=[]
for i in (1,2):
 out=scratch/f'candidate-generation-{i}.yaml'
 subprocess.run(['python3','scripts/generate-pd10-v2-conformance-set.py','--repository-root',str(root),'--output',str(out)],cwd=root,check=True)
 generations.append(out)
assert generations[0].read_bytes()==generations[1].read_bytes()
text=generations[0].read_text()
entries=[(json.loads(p),int(size),h) for p,size,h in re.findall(r'  - path: ("[^\n]+")\n    kind: file\n    bytes: (\d+)\n    sha256: ([0-9a-f]{64})\n',text)]
paths=[p for p,_,_ in entries]
assert paths==sorted(set(paths))==sorted(qualified)
assert all((root/p).stat().st_size==n and sha(root/p)==h for p,n,h in entries)
material=''.join(f'{p}\0{h}\n' for p,_,h in entries).encode()
sethash=hashlib.sha256(material).hexdigest()
assert f'candidate_set_sha256: {sethash}' in text
for key,value in [('approval_status','pending-a6b'),('source_identity_qualification','pending-after-approved-v1-addition'),('production_exposure','disabled'),('story_closure_claimed','false'),('production_routed','false')]:
 assert f'{key}: {value}' in text
# This is the only permitted inventory replacement. The historical inventory is never written.
candidate.write_bytes(generations[0].read_bytes())
result={'artifact_count':len(entries),'candidate_raw_sha256':sha(candidate),'candidate_set_sha256':sethash,'generations_identical':True,'entries_independently_rehashed':len(entries),'current_planning_bindings':len(bindings),'protected_input_count':len(controls),'protected_inputs':controls,'spec_frontmatter_frozen_tasks_unchanged':True,'final_qualified_inputs_unchanged':True,'exact_paths':paths}
(scratch/'final-input-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['protected_inputs','exact_paths']}))
