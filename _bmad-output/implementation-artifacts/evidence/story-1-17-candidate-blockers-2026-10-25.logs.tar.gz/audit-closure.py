import pathlib,re,collections
root=pathlib.Path('/home/administrator/projects/hexalith/folders')
paths=set((root/'scripts/pd10-v2-story-owned-paths.txt').read_text().splitlines())
files={p.relative_to(root).as_posix():p.read_text(encoding='utf-8-sig') for p in (root/'src').rglob('*.cs') if not {'obj','bin'}&set(p.parts)}
types=collections.defaultdict(set)
pattern=r'\b(?:class|interface|enum|struct|record(?:\s+(?:class|struct))?)\s+([A-Za-z_][A-Za-z0-9_]*)'
for p,txt in files.items():
 for name in re.findall(pattern,txt): types[name].add(p)
q=[p for p in paths if p in files]; required=set(q)
while q:
 p=q.pop()
 for word in set(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b',files[p])):
  for dep in types[word]:
   if dep not in required: required.add(dep);q.append(dep)
missing=required-paths
print('required runtime',len(required),'missing',len(missing))
print(collections.Counter(p.split('/')[1] for p in missing))
(root if False else pathlib.Path('/tmp/story117-candidate-blockers-20261025-nvst1w9h/runtime-closure.txt')).write_text('\n'.join(sorted(required))+'\n')
print('\n'.join(sorted(missing)))
