from pathlib import Path
import datetime,hashlib,json,subprocess,xml.etree.ElementTree as ET
import yaml
root=Path('/home/administrator/projects/hexalith/folders'); scratch=Path(__file__).parent
checks=json.loads((scratch/'checks.json').read_text())
def run(name,cmd):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (scratch/(name+'.log')).open('wb') as out: r=subprocess.run(cmd,cwd=root,stdout=out,stderr=subprocess.STDOUT)
 c=dict(id=name,command=cmd,cwd=str(root),started_utc=start,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit=r.returncode,log=name+'.log')
 checks.append(c);(scratch/'checks.json').write_text(json.dumps(checks,indent=2)+'\n'); print(name,r.returncode,flush=True)
 if r.returncode: raise SystemExit(r.returncode)
run('candidate-generation-reviewed',['python3','scripts/generate-pd10-v2-conformance-set.py'])
for n in [1,2]: run('candidate-generation-reviewed-'+str(n),['python3','scripts/generate-pd10-v2-conformance-set.py','--output',str(scratch/f'candidate-reviewed-{n}.yaml')])
p=root/'_bmad-output/implementation-artifacts/evidence/story-12-2-v2-source-requalification-pending.yaml'
assert p.read_bytes()==(scratch/'candidate-reviewed-1.yaml').read_bytes()==(scratch/'candidate-reviewed-2.yaml').read_bytes()
manifest=yaml.safe_load(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
actual={row['path']:sha(root/row['path']) for row in manifest['artifacts']}
for row in manifest['artifacts']:
 assert actual[row['path']]==row['sha256'],row['path']
 assert (root/row['path']).stat().st_size==row['bytes'],row['path']
assert len(actual)==manifest['artifact_count']
material=''.join(f'{k}\0{v}\n' for k,v in actual.items()).encode()
assert hashlib.sha256(material).hexdigest()==manifest['candidate_set_sha256']
(scratch/'reviewed-inputs.json').write_text(json.dumps(actual,indent=2)+'\n')
(scratch/'reviewed-inventory-audit.json').write_text(json.dumps(dict(manifest_sha256=sha(p),candidate_set_sha256=manifest['candidate_set_sha256'],artifact_count=len(actual),generation_count=2,all_hashes_and_sizes_match=True),indent=2)+'\n')
cmd=['dotnet','tests/Hexalith.Folders.Contracts.Tests/bin/Release/net10.0/Hexalith.Folders.Contracts.Tests.dll']
for cls in ['OpenApi.Pd10ConformanceSetTests','OpenApi.Pd10V2CandidateContractTests','OpenApi.Pd10V2ContractTests','Deployment.ReleasePackageConformanceTests','Deployment.NfrTraceabilityConformanceTests','Deployment.AdrRunbookDocsConformanceTests']: cmd+=['-class','Hexalith.Folders.Contracts.Tests.'+cls]
run('contracts-reviewed',cmd+['-xml',str(scratch/'contracts-reviewed.xml')])
run('parity-reviewed',['pwsh','tests/tools/run-contract-parity-ci-gates.ps1','-NoRestore','-OutputReportPath',str(scratch/'parity-reviewed.json')])
run('governance-reviewed',['pwsh','tests/tools/run-governance-completeness-gates.ps1','-SkipRestoreBuild'])
assert all(sha(root/k)==v for k,v in actual.items())
print('final inputs stable',flush=True)
