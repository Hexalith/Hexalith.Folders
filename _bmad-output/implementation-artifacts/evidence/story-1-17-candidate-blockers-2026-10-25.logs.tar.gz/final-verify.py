from pathlib import Path
import datetime,json,subprocess
root=Path('/home/administrator/projects/hexalith/folders');s=Path(__file__).parent
checks=json.loads((s/'checks.json').read_text())
def run(name,cmd):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (s/(name+'.log')).open('wb') as out:r=subprocess.run(cmd,cwd=root,stdout=out,stderr=subprocess.STDOUT)
 checks.append(dict(id=name,command=cmd,cwd=str(root),started_utc=start,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit=r.returncode,log=name+'.log'))
 (s/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('release-final-build',['dotnet','build','Hexalith.Folders.CI.slnx','--configuration','Release','-p:UseNuGetDeps=true','-warnaserror','-m:1'])
lanes=[('authorization-final','IntegrationTests',['Authorization.ContextReadAuthorityTests','Authorization.ContextReadFreshTenantTests','Routing.FoldersApiRoutingModeTests']),('server-final','Server.Tests',['FileContextEndpointTests','Pd10ProtectedOperationCatalogTests','HttpContextEventStoreClaimTransformEvidenceAccessorTests','WorkspaceContentProductionTests']),('domain-final','Tests',['Queries.FileContext.WorkspaceFileContextQueryHandlerTests','Authorization.LayeredFolderAuthorizationServiceTests','Authorization.TenantAccessAuthorizerTests'])]
for name,project,classes in lanes:
 cmd=['dotnet',f'tests/Hexalith.Folders.{project}/bin/Release/net10.0/Hexalith.Folders.{project}.dll']
 for cls in classes:cmd+=['-class',f'Hexalith.Folders.{project}.{cls}']
 run(name,cmd+['-xml',str(s/(name+'.xml'))])
run('diff-check-final',['git','diff','--check'])
