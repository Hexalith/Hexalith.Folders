import datetime, hashlib, json, os, pathlib, stat, subprocess, sys, time
ROOT=pathlib.Path('/home/administrator/projects/hexalith/folders')
OUT=pathlib.Path(__file__).parent
BASE=ROOT/'_bmad-output/implementation-artifacts'
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def h(p):
    with pathlib.Path(p).open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def write(name,obj): (OUT/name).write_text(json.dumps(obj,indent=2)+'\n')
def git(rel,*args): return subprocess.check_output(['git','-C',str(ROOT/rel),*args])
def table():
    result={}
    for p in pathlib.Path('/proc').iterdir():
        if not p.name.isdigit(): continue
        try:
            raw=(p/'stat').read_text(); f=raw[raw.rfind(')')+2:].split()
            result[int(p.name)]={'pid':int(p.name),'ppid':int(f[1]),'pgid':int(f[2]),'startTime':f[19],'rawStat':raw}
        except (FileNotFoundError,ProcessLookupError,PermissionError): pass
    return result
plan_path=BASE/'story-1-17-cli-4-38-filter-reset-plan-2026-10-26.json'
auth_path=BASE/'story-1-17-cli-4-38-filter-reset-authorization-2026-10-26.json'
plan=json.loads(plan_path.read_text()); auth=json.loads(auth_path.read_text())
assert h(plan_path)==auth['planSha256']=='efdbd430962e48d7596e8d9bb4030c5697ca02198b5f9e24c26da3a35d93ad50'
assert plan['exactExecutionCommand']==auth['exactExecutionCommand']
assert auth['authorized'] is True and auth['freshAttemptsAuthorized']==1
checks={}
for rel,b in auth['rootRecordingBindings'].items():
    p=ROOT/rel; s=p.lstat(); actual={'sha256':h(p),'bytes':s.st_size}
    assert stat.S_ISREG(s.st_mode) and actual==b,rel
    checks[rel]=actual
for k in ['originalPlan','originalExecutionApproval','adapter','priorRootRebindPlan','priorRootRebindApproval','failedExecutionReceipt']:
    b=plan[k]; p=ROOT/b['path']; actual={'sha256':h(p),'bytes':p.stat().st_size}
    assert actual=={'sha256':b['sha256'],'bytes':b['bytes']},k
    checks[b['path']]=actual
checks[str(auth_path.relative_to(ROOT))]={'sha256':h(auth_path),'bytes':auth_path.stat().st_size}
for suffix in ['.json','.artifacts.tar.gz','.members.json']:
    assert not (BASE/('evidence/story-1-17-cli-4-38-filter-reset-execution-2026-10-26'+suffix)).exists()
repos={}
for rel in ['.',*plan['allDirectRevisions']]:
    repos[rel]={'revision':git(rel,'rev-parse','HEAD').decode().strip(),'indexEntriesSha256':hashlib.sha256(git(rel,'ls-files','--stage')).hexdigest(),'status':git(rel,'status','--porcelain=v2','--untracked-files=all').decode(),'branch':git(rel,'branch','--show-current').decode().strip(),'remotes':git(rel,'remote','-v').decode(),'recentHistory':git(rel,'log','-5','--format=%H %s').decode()}
    (OUT/('repo-'+('root' if rel=='.' else rel.split('/')[-1])+'.stage.txt')).write_bytes(git(rel,'ls-files','--stage'))
    (OUT/('repo-'+('root' if rel=='.' else rel.split('/')[-1])+'.flags.z')).write_bytes(git(rel,'ls-files','-v','-z'))
write('preflight.json',{'atUtc':now(),'ownerBoundChecks':checks,'repositoryState':repos,'python':{'executable':sys.executable,'flags':str(sys.flags)},'contextPaths':[str(plan_path),str(BASE/'story-1-17-cli-4-38-filter-reset-proposal-2026-10-26.md'),str(auth_path)]})
record={'argv':plan['exactExecutionCommand'],'cwd':str(ROOT),'startedAtUtc':now(),'exitCode':None,'sdkEnvironmentPolicy':'The approved driver supplies the complete explicit SDK environment; no caller environment change.','inheritedEnvironmentVariableNames':sorted(os.environ),'inheritedEnvironmentSha256':hashlib.sha256(json.dumps(dict(os.environ),sort_keys=True).encode()).hexdigest(),'observations':[],'samplingLimit':'200ms sampled descendants and matching process group; transient/escaped processes may be missed. No whole-host preservation claim.'}
with (OUT/'invocation-start.json').open('x') as f: json.dump(record,f,indent=2)
print('INVOCATION_AUDIT='+str(OUT),flush=True)
seen=set(); process=None
try:
    with (OUT/'invocation.stdout').open('xb') as stdout,(OUT/'invocation.stderr').open('xb') as stderr:
        process=subprocess.Popen(plan['exactExecutionCommand'],cwd=ROOT,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
        record['pid']=process.pid; write('invocation.json',record)
        print('INVOCATION_PID='+str(process.pid),flush=True)
        while True:
            t=table(); owned={process.pid}
            while True:
                n=owned|{pid for pid,row in t.items() if row['ppid'] in owned}
                if n==owned: break
                owned=n
            rows=[t[pid] for pid in sorted(owned) if pid in t]
            seen.update((r['pid'],r['startTime']) for r in rows)
            record['observations'].append({'atUtc':now(),'rootPid':process.pid,'rows':rows})
            if process.poll() is not None: break
            time.sleep(.2)
        record['exitCode']=process.wait()
except BaseException as e:
    record['captureError']=repr(e)
    if process is not None: record['exitCode']=process.wait()
finally:
    record['endedAtUtc']=now()
    t=table(); record['finalOwnedProcessObservation']={'atUtc':now(),'rows':[r for r in t.values() if (r['pid'],r['startTime']) in seen]}
    for name in ['invocation.stdout','invocation.stderr']:
        p=OUT/name
        if p.exists(): record[name]={'sha256':h(p),'bytes':p.stat().st_size}
    write('invocation.json',record)
print('INVOCATION_EXIT='+str(record['exitCode']),flush=True)
print((OUT/'invocation.stdout').read_text(errors='replace'),flush=True)
print((OUT/'invocation.stderr').read_text(errors='replace'),flush=True)
