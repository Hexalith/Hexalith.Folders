"""Record and seal the actual completed single approved invocation; no target execution."""
import datetime, hashlib, io, json, os, pathlib, shutil, stat, subprocess, tarfile
ROOT=pathlib.Path('/home/administrator/projects/hexalith/folders')
BASE=ROOT/'_bmad-output/implementation-artifacts'
CAPTURE=pathlib.Path(__file__).parent
SPEC=pathlib.Path('/tmp/story117-cli438-approved-fresh-20261026-ot00opmr/SPEC.md')
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
    with pathlib.Path(p).open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def load(p): return json.loads(pathlib.Path(p).read_text())
def write(p,v):
    with pathlib.Path(p).open('x') as f: f.write(json.dumps(v,indent=2)+'\n')
def bound(p): return dict(path=str(p),bytes=pathlib.Path(p).stat().st_size,sha256=sha(p))
def regular(p):
    s=p.lstat(); assert stat.S_ISREG(s.st_mode),str(p); return s
def private(p,prefix):
    assert p.parent==pathlib.Path('/tmp') and p.name.startswith(prefix),str(p)
    s=p.lstat(); assert stat.S_ISDIR(s.st_mode) and s.st_uid==os.getuid() and not s.st_mode&0o077,str(p)
def table():
    result={}
    for p in pathlib.Path('/proc').iterdir():
        if not p.name.isdigit(): continue
        try:
            raw=(p/'stat').read_text(); f=raw[raw.rfind(')')+2:].split()
            result[int(p.name)]=dict(pid=int(p.name),ppid=int(f[1]),pgid=int(f[2]),startTime=f[19],rawStat=raw)
        except (FileNotFoundError,ProcessLookupError,PermissionError): pass
    return result
plan_path=BASE/'story-1-17-cli-4-38-filter-reset-plan-2026-10-26.json'
auth_path=BASE/'story-1-17-cli-4-38-filter-reset-authorization-2026-10-26.json'
plan=load(plan_path); auth=load(auth_path); outer=load(CAPTURE/'invocation.json')
assert outer['argv']==plan['exactExecutionCommand']==auth['exactExecutionCommand']
assert outer['cwd']==str(ROOT) and outer['exitCode']==0 and 'captureError' not in outer
adapter_lines=(CAPTURE/'invocation.stdout').read_text().splitlines(); assert len(adapter_lines)==1
ADAPTER=pathlib.Path(adapter_lines[0]); private(ADAPTER,'story117-cli438-filter-reset-20261026-')
work_lines=(ADAPTER/'driver.stdout').read_text().splitlines(); assert len(work_lines)==1
WORK=pathlib.Path(work_lines[0]); private(WORK,'story117-cli438-loader-20261026-')
driver=load(ADAPTER/'driver.command.json'); audit=load(ADAPTER/'filter-reset-audit.json')
assert driver['exitCode']==0 and not driver['postExecutionBindingErrors']
CLAIM=pathlib.Path(driver['attemptClaim'])
assert CLAIM.parent==pathlib.Path(plan['attemptClaimDirectory']) and CLAIM.name==sha(auth_path)
for p in [CLAIM.parent,CLAIM]:
    s=p.lstat(); assert stat.S_ISDIR(s.st_mode) and s.st_uid==os.getuid() and not s.st_mode&0o077
claim=load(CLAIM/'claim.json'); outcome=load(CLAIM/'outcome.json')
assert claim['authorizationSha256']==sha(auth_path) and outcome['adapter']==str(ADAPTER) and outcome['exitCode']==0
assert audit['attemptClaim']==str(CLAIM)
record_dir=ADAPTER/'recording-audit'; record_dir.mkdir(mode=0o700)
for p in sorted(CAPTURE.iterdir()):
    regular(p); shutil.copyfile(p,record_dir/p.name)
shutil.copyfile(SPEC,record_dir/'dispatched-SPEC.md')
write(record_dir/'capture-provenance.json',dict(atUtc=now(),addedAfterTargetInvocationEnded=True,
    originalCaptureDirectory=str(CAPTURE),copiedFiles=sorted(p.name for p in CAPTURE.iterdir()),
    dispatchedSpecSource=str(SPEC),purpose='Actual invocation, read-only post-execution observations and sealing source. No target commands are rerun.'))
original_plan=load(ROOT/plan['originalPlan']['path'])
original_inputs=load(ROOT/plan['inputDerivation']['source']['path']); rebound=load(ADAPTER/'inputs.json')
control=json.loads(json.dumps(rebound)); control['repositories']['.']=original_inputs['repositories']['.']; assert control==original_inputs
assert sha(ADAPTER/'execute_after_authorization.py')==plan['driverRepair']['afterSha256']
assert sha(ROOT/plan['driverRepair']['beforePath'])==plan['driverRepair']['beforeSha256']
assert sha(ADAPTER/'inputs.json')==audit['reboundInputsSha256']
owner_checks={}
def check(p,b,category):
    p=pathlib.Path(p); regular(p); actual=bound(p)
    expected={'bytes':b['bytes'],'sha256':b['sha256']}
    assert all(actual[k]==v for k,v in expected.items()),str(p)
    owner_checks[str(p)]=dict(actual,category=category,matches=True)
for rel,b in auth['rootRecordingBindings'].items(): check(ROOT/rel,b,'fresh-owner-recording-binding')
assert sha(plan_path)==auth['planSha256']
check(pathlib.Path(plan['pythonInterpreter']['path']),plan['pythonInterpreter'],'bound-Python-interpreter')
for key in ['originalPlan','originalExecutionApproval','adapter','priorRootRebindPlan','priorRootRebindApproval','failedExecutionReceipt']:
    b=plan[key]; check(ROOT/b['path'],b,key)
for b in original_plan['artifacts']+original_plan['supportingArtifacts']:
    check(ROOT/b['path'],b,'original-plan-artifact')
for b in original_inputs['preservedFiles']: check(ROOT/b['path'],b,'preserved-input')
check(pathlib.Path(original_inputs['package']['path']),original_inputs['package'],'original-package')
check(ROOT/original_inputs['modelArchive']['path'],original_inputs['modelArchive'],'original-model-archive')
owner_checks[str(auth_path)]=dict(bound(auth_path),category='actual-fresh-approval-no-self-hash',matches=sha(auth_path)==claim['authorizationSha256'])
write(record_dir/'owner-bound-rehash.json',dict(atUtc=now(),files=list(owner_checks.values()),allMatch=True))
sdk_checks=[]
for b in original_inputs['sdk']['files']:
    p=pathlib.Path(b['path']); regular(p); a=bound(p); assert a['bytes']==b['bytes'] and a['sha256']==b['sha256'],str(p)
    sdk_checks.append(dict(a,matches=True))
frameworks={p:sorted(x.name for x in pathlib.Path(p).iterdir() if x.is_dir()) for p in original_inputs['installedFrameworkDirectories']}
assert frameworks==original_inputs['installedFrameworkDirectories']
write(record_dir/'sdk-rehash.json',dict(atUtc=now(),files=sdk_checks,count=len(sdk_checks),allMatch=True,installedFrameworkDirectories=frameworks))
copy_checks={}
for prefix,items in [('host',original_inputs['hostMembers']),('model',original_inputs['modelMembers'])]:
    rows=[]
    for b in items:
        suffix=b['path'].removeprefix(original_inputs['hostPrefix'] if prefix=='host' else 'hosts/platform-model/')
        p=WORK/prefix/suffix; regular(p); a=bound(p); assert a['bytes']==b['bytes'] and a['sha256']==b['sha256'],str(p)
        rows.append(dict(a,sourceMember=b['path'],matches=True))
    copy_checks[prefix]=rows
write(record_dir/'copied-input-rehash.json',dict(atUtc=now(),files=copy_checks,allMatch=True))
for rel in original_inputs['absentPaths']: assert not (ROOT/rel).exists(),rel
read_commands=[]
def git(rel,*args):
    argv=['git','-C',str(ROOT/rel),*args]; started=now(); r=subprocess.run(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    read_commands.append(dict(argv=argv,cwd=str(ROOT),startedAtUtc=started,endedAtUtc=now(),exitCode=r.returncode,
        stdoutSha256=hashlib.sha256(r.stdout).hexdigest(),stdoutBytes=len(r.stdout),stderr=r.stderr.decode(errors='replace')))
    assert r.returncode==0,(argv,r.stderr); return r.stdout
repos={}; before=load(CAPTURE/'preflight.json')['repositoryState']
for rel in original_inputs['repositories']:
    label='root' if rel=='.' else rel.split('/')[-1]
    stage=git(rel,'ls-files','--stage'); flags=git(rel,'ls-files','-v','-z')
    assert not any(row and (row[:1]==b'S' or row[:1].islower()) for row in flags.split(b'\0')),rel
    assert stage==(CAPTURE/('repo-'+label+'.stage.txt')).read_bytes(),rel
    assert flags==(CAPTURE/('repo-'+label+'.flags.z')).read_bytes(),rel
    (record_dir/('repo-after-'+label+'.stage.txt')).write_bytes(stage)
    (record_dir/('repo-after-'+label+'.flags.z')).write_bytes(flags)
    raw=git(rel,'diff','--raw','--no-abbrev','--no-renames'); staged=git(rel,'diff','--cached','--raw','--no-abbrev','--no-renames')
    assert raw==staged==b'',rel
    repos[rel]=dict(revision=git(rel,'rev-parse','HEAD').decode().strip(),indexEntriesSha256=hashlib.sha256(stage).hexdigest(),
        indexFlagsSha256=hashlib.sha256(flags).hexdigest(),hiddenIndexFlags=[],status=git(rel,'status','--porcelain=v2','--untracked-files=all').decode(),
        branch=git(rel,'branch','--show-current').decode().strip(),remotes=git(rel,'remote','-v').decode(),recentHistory=git(rel,'log','-5','--format=%H %s').decode(),
        stageEntriesFile='filter-reset/recording-audit/repo-after-'+label+'.stage.txt',flagsFile='filter-reset/recording-audit/repo-after-'+label+'.flags.z')
    assert all(repos[rel][k]==before[rel][k] for k in ['revision','indexEntriesSha256','status','branch','remotes','recentHistory']),rel
write(record_dir/'repository-post-execution.json',dict(atUtc=now(),repositories=repos,allThirteenRevisionsIndicesFlagsStatusesPreserved=True))
write(record_dir/'read-only-git-commands.json',read_commands)
commands=[]
for p in sorted(WORK.glob('*.command.json')):
    d=load(p); label=p.name.removesuffix('.command.json'); pre=load(WORK/(label+'.prelaunch.json'))
    assert d['seccompOffsetAtLaunch']==pre['seccompOffsetAtLaunch']==0 and d['seccompOffsetBeforeReset']==pre['seccompOffsetBeforeReset']
    assert not d.get('timedOut') and not d['observedSurvivors']
    assert sha(WORK/(label+'.stdout'))==d['stdoutSha256'] and sha(WORK/(label+'.stderr'))==d['stderrSha256']
    commands.append(dict(label=label,**d))
commands.sort(key=lambda x:x['atUtc'])
assert len(commands)==9
assert [x['seccompOffsetBeforeReset'] for x in commands]==[0]+[120]*8
assert all(x['exitCode']==(10 if x['label'].startswith('probe-') else 0) for x in commands)
probe_records={}
for mode in ['cold','host-first']:
    records=[json.loads(line) for line in (WORK/('probe-'+mode+'.stdout')).read_text().splitlines()]
    failures=[r for r in records if r['kind']=='failure']; assert len(failures)==1 and failures[0]['data']['phase']=='final-EventStore3128-demand'
    assert failures[0]['data']['HResult']==-2146234304
    probe_records[mode]=dict(exitCode=10,failure=failures[0],requestAndResolutionEvents=[r for r in records if r['kind'] in ['request','resolved','resolving']],
        contextRecordMember='loader/probe-'+mode+'.stdout',fullRecordsMember='loader/probe-'+mode+'.stdout',hostTraceMember='loader/'+mode+'.host-trace.log')
seen=set(); groups=set()
for observation in outer['observations']:
    seen.update((r['pid'],r['startTime']) for r in observation['rows'])
for c in commands:
    for o in c['observations']:
        seen.update((r['pid'],r['startTime']) for r in o['rows']); groups.add(o['processGroup'])
proc=table(); survivors=[r for r in proc.values() if (r['pid'],r['startTime']) in seen or r['pgid'] in groups]
assert not survivors,survivors
process_check=dict(atUtc=now(),observedOwnedIdentities=[dict(pid=p,startTime=s) for p,s in sorted(seen)],ownedSandboxProcessGroups=sorted(groups),survivors=survivors,
    observationLimit='200ms sampled descendant/group rows and final PID+startTime/group check. Transient or escaped processes may be missed; no whole-host preservation claim.')
write(record_dir/'owned-process-final.json',process_check)
def metadata_tree(base):
    entries=[]
    def visit(p):
        for child in sorted(p.iterdir()):
            s=child.lstat(); entries.append(dict(path=str(child.relative_to(base)),mode=s.st_mode,bytes=s.st_size,mtimeNs=s.st_mtime_ns,ctimeNs=s.st_ctime_ns))
            if stat.S_ISDIR(s.st_mode): visit(child)
    exists=base.exists()
    if exists:
        assert not base.is_symlink(); visit(base)
    return dict(exists=exists,entries=entries)
certificate_now={p:metadata_tree(pathlib.Path(p)) for p in load(WORK/'certificate-before.json')}
assert certificate_now==load(WORK/'certificate-before.json')==load(WORK/'certificate-after.json')
write(record_dir/'certificate-post-seal-metadata.json',dict(atUtc=now(),stores=certificate_now,allObservedMetadataEqual=True,contentsRead=False))
preservation=load(WORK/'preservation.json')
assert preservation['gitStateEqual'] and preservation['certificateMetadataEqual'] and preservation['inputDrifts']==[]
assert (WORK/'experiment-completed.json').is_file()
output_stem=BASE/'evidence/story-1-17-cli-4-38-filter-reset-execution-2026-10-26'
receipt_path=pathlib.Path(str(output_stem)+'.json'); archive_path=pathlib.Path(str(output_stem)+'.artifacts.tar.gz'); manifest_path=pathlib.Path(str(output_stem)+'.members.json')
for p in [receipt_path,archive_path,manifest_path]: assert not p.exists(),str(p)
sources={'filter-reset':ADAPTER,'loader':WORK,'attempt-claim':CLAIM}
blocked_ext={'.pfx','.p12','.key','.pem','.crt','.cer','.der','.p7b','.p7c'}
def inventory():
    files=[]; dirs=[]; omitted=[]
    def walk(base,p,prefix):
        for child in sorted(p.iterdir()):
            rel=prefix+'/'+str(child.relative_to(base)); s=child.lstat()
            row=dict(path=rel,mode=s.st_mode,bytes=s.st_size,uid=s.st_uid,gid=s.st_gid,mtimeNs=s.st_mtime_ns,ctimeNs=s.st_ctime_ns)
            if child.name.lower() in {'x509stores','privatekeys'} or child.suffix.lower() in blocked_ext:
                omitted.append(dict(row,reason='Certificate/store/private-key content excluded before hashing; metadata only.')); continue
            if stat.S_ISLNK(s.st_mode):
                omitted.append(dict(row,reason='Symlink excluded without traversal or content hashing.')); continue
            if stat.S_ISDIR(s.st_mode): dirs.append(row); walk(base,child,prefix)
            else:
                assert stat.S_ISREG(s.st_mode),'Special file: '+str(child)
                row.update(source=str(child),sha256=sha(child)); files.append(row)
    for prefix,base in sources.items():
        s=base.lstat(); assert stat.S_ISDIR(s.st_mode) and s.st_uid==os.getuid()
        walk(base,base,prefix)
    files.sort(key=lambda x:x['path']); dirs.sort(key=lambda x:x['path']); omitted.sort(key=lambda x:x['path'])
    return files,dirs,omitted
files,dirs,omitted=inventory()
with archive_path.open('xb') as stream:
    with tarfile.open(fileobj=stream,mode='w:gz',format=tarfile.PAX_FORMAT) as archive:
        for row in files:
            p=pathlib.Path(row['source']); regular(p)
            assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],str(p)
            info=archive.gettarinfo(str(p),arcname=row['path']); assert info.isfile()
            with p.open('rb') as data: archive.addfile(info,data)
assert inventory()==(files,dirs,omitted),'Source membership/bytes/metadata changed during archival.'
expected={r['path']:r for r in files}; verified=[]
with tarfile.open(archive_path,'r:gz') as archive:
    members=archive.getmembers(); assert len(members)==len(files) and len({m.name for m in members})==len(members)
    assert set(m.name for m in members)==set(expected)
    for member in members:
        assert member.isfile() and not member.issym() and not member.islnk()
        assert not pathlib.PurePosixPath(member.name).is_absolute() and '..' not in pathlib.PurePosixPath(member.name).parts
        row=expected[member.name]
        with archive.extractfile(member) as data: actual=hashlib.file_digest(data,'sha256').hexdigest()
        assert member.size==row['bytes'] and actual==row['sha256'],member.name
        verified.append(member.name)
manifest=dict(format='sha256-file-members-v1',sources={k:str(v) for k,v in sources.items()},
    members=[dict(path=r['path'],bytes=r['bytes'],sha256=r['sha256']) for r in files],
    directoryMetadata=dirs,omittedEntries=omitted,excludedContentPolicy='No x509stores, certificate or private-key contents are read, hashed or archived. Symlinks are omitted without traversal; special files are rejected.',
    actualStoreMetadataMembers=['loader/certificate-before.json','loader/certificate-after.json','filter-reset/recording-audit/certificate-post-seal-metadata.json'],
    memberVerification=dict(atUtc=now(),uniquePaths=True,fileMemberCount=len(verified),everySizeAndSha256Matches=True,sourceMembershipAndMetadataUnchanged=True))
write(manifest_path,manifest)
root_pre_receipt=subprocess.check_output(['git','-C',str(ROOT),'status','--porcelain=v2','--untracked-files=all']).decode()
initial_status=set(before['.']['status'].splitlines())
first_additions={'? '+str(p.relative_to(ROOT)) for p in [archive_path,manifest_path]}
assert set(root_pre_receipt.splitlines())==initial_status|first_additions
receipt=dict(recordId='STORY-1-17-CLI-4-38-FILTER-RESET-EXECUTION-2026-10-26',recordedAtUtc=now(),
    status='AUTHORIZED_SINGLE_ATTEMPT_COMPLETED_TWO_EXPECTED_FINAL_EVENTSTORE_BINDING_FAILURES',
    outcome='The exact approved command ran once. All SDK gates and probe-only compilation succeeded. Both cold and host-first cases ended with the predeclared final EventStore3.128 demand FileLoadException (0x80131040), exit10. This is binding evidence only; no compatibility or operational acceptance follows.',
    authorizedInvocationCount=1,targetRetries=0,outerCommand=outer,driverCommand=driver,
    executionPlan=bound(plan_path),freshAuthorization=bound(auth_path),dispatchedSpec=bound(SPEC),
    actualAdapterDirectory=str(ADAPTER),actualWorkDirectory=str(WORK),attemptClaimDirectory=str(CLAIM),
    claimMetadata=claim,claimOutcome=outcome,claimLedgerRetained=True,claimStorageLimit=plan['oneUseRule'],
    allApprovals=dict(originalExecution=bound(ROOT/plan['originalExecutionApproval']['path']),priorRootRebind=bound(ROOT/plan['priorRootRebindApproval']['path']),fresh=bound(auth_path),derived=bound(ADAPTER/'derived-authorization.json')),
    inputDerivation=dict(original=bound(ROOT/plan['inputDerivation']['source']['path']),derived=bound(ADAPTER/'inputs.json'),
        allowedFields=plan['inputDerivation']['allowedJsonPointers'],originalRootFields=original_inputs['repositories']['.'],derivedRootFields=rebound['repositories']['.'],allOtherJsonValuesEqual=True),
    driverRepair=dict(original=bound(ROOT/plan['driverRepair']['beforePath']),derived=bound(ADAPTER/'execute_after_authorization.py'),patch=plan['driverRepair']['patch'],addedLines=4,removedLines=0,repositoryDriverUnchanged=True),
    actualRootRevision=repos['.']['revision'],actualRootIndexEntriesSha256=repos['.']['indexEntriesSha256'],repositoryStateAtExecution=audit['initialRepositoryState'],repositoryStateAfterTargetExecution=repos,
    hiddenIndexFlagsRejectedBeforeAndAfter=True,allThirteenRevisionsIndicesFlagsStatusesPreserved=True,
    sdkCommands=commands,sdkEnvironment=load(WORK/'environment.json'),sdkFileRehash=dict(count=len(sdk_checks),allMatch=True,member='filter-reset/recording-audit/sdk-rehash.json'),
    copiedInputRehash=dict(hostFiles=len(copy_checks['host']),modelFiles=len(copy_checks['model']),allMatch=True,member='filter-reset/recording-audit/copied-input-rehash.json'),
    ownerBoundRehash=dict(count=len(owner_checks),allMatch=True,member='filter-reset/recording-audit/owner-bound-rehash.json'),
    cursorObservation=dict(offsetBeforeReset=[x['seccompOffsetBeforeReset'] for x in commands],offsetAtLaunch=[x['seccompOffsetAtLaunch'] for x in commands],firstZeroThenEight120=True,everyLaunchOffsetZero=True,
        meaning='This run directly observed the shared descriptor cursor at EOF after each successful earlier sandbox reader and reset it before each launch. Historical cursor values remain unobserved.'),
    probeCompilation=dict(exitCode=0,compiledProbe=load(WORK/'compiled-probe.json'),scope='LoaderProbe only; no model build, restore or application entrypoint.'),probeCases=probe_records,
    certificateEvidence=dict(metadataBeforeAndAfterEqual=True,postRecordingMetadataEqual=True,contentsRead=False,contentsHashed=False,storeEdits=False,certificateInstallationOrTrustMessageObserved=False),
    preservation=preservation,ownedProcessObservation=process_check,
    stderrAdvisory=dict(command='sdk-msbuild-version-only',exactText=(WORK/'sdk-msbuild-version-only.stderr').read_text(),exitCode=0,followUpExecuted=False),
    archive=dict(path=str(archive_path.relative_to(ROOT)),sha256=sha(archive_path),bytes=archive_path.stat().st_size),
    manifest=dict(path=str(manifest_path.relative_to(ROOT)),sha256=sha(manifest_path),bytes=manifest_path.stat().st_size),
    archiveVerification=manifest['memberVerification'],omissions=omitted,
    recordingAdditions=[str(p.relative_to(ROOT)) for p in [receipt_path,archive_path,manifest_path]],
    statusBeforeWritingThisReceipt=dict(atUtc=now(),rootStatus=root_pre_receipt,onlyArchiveAndManifestAdded=True),
    statusAfterWritingThisReceiptExpected='The receipt is the sole remaining authorized addition. A separate read-only final check records the actual post-write status under the original /tmp invocation audit directory.',
    privateDirectoriesRetained=True,cleanupPerformed=False,priorEvidenceAndApprovalsUnchanged=True,
    limitations=['Binding-only cases do not execute application methods, ComposeRun, constructors or runtime prerequisites. Redis identity resolution does not establish Redis API behavior.',
        'Cold means no deliberate EventStore preload; it does not prove absence of incidental preload. Host-first is the predeclared deliberate order and does not claim actual host execution order.',
        'Process observations sample descendants/group every200ms; transient or escaped children may be missed. No whole-host state preservation claim.',
        'The historical immediate SDK gate and earlier failed-run missing cursor/index-flag observations remain incomplete; current observations do not repair history.',
        'The atomic claim prevents duplicate use while retained storage remains intact; external claim deletion is outside its guarantee. No retry or claim cleanup is authorized.',
        'The outer adapter inherits the caller environment; names and a full mapping hash are retained. Every actual SDK command records its complete explicit environment.'],
    operationalControl=plan['operationalControl'],parentStatus='in-progress',trackerStatus='backlog',stagingChecks=dict(total=14,executed=0),ordinaryMapping=None,ContentHash=None,
    historicalAcceptedCli='4.35.2',candidateCli='4.38.0',currentTupleAccepted=False,packageAccepted=False,hostedAccepted=False)
write(receipt_path,receipt)
final_status=subprocess.check_output(['git','-C',str(ROOT),'status','--porcelain=v2','--untracked-files=all']).decode()
expected_final=initial_status|{'? '+str(p.relative_to(ROOT)) for p in [receipt_path,archive_path,manifest_path]}
assert set(final_status.splitlines())==expected_final
proc=table(); final_survivors=[r for r in proc.values() if (r['pid'],r['startTime']) in seen or r['pgid'] in groups]; assert not final_survivors
write(CAPTURE/'final-verification.json',dict(atUtc=now(),rootStatus=final_status,onlyThreeAuthorizedEvidenceAdditions=True,
    receipt=bound(receipt_path),archive=bound(archive_path),manifest=bound(manifest_path),verifiedMemberCount=len(verified),ownedSurvivors=final_survivors,
    finalOwnedObservationAtUtc=now(),allPrivateDirectoriesAndClaimRetained=True,noTargetCommandRerun=True))
print(json.dumps(dict(receipt=str(receipt_path),archive=str(archive_path),manifest=str(manifest_path),verifiedMembers=len(verified),sdkFiles=len(sdk_checks),
    hostFiles=len(copy_checks['host']),modelFiles=len(copy_checks['model']),ownerBoundFiles=len(owner_checks),omissions=len(omitted),outerExit=outer['exitCode'],probeExits=[10,10],
    finalVerification=str(CAPTURE/'final-verification.json')),indent=2))
