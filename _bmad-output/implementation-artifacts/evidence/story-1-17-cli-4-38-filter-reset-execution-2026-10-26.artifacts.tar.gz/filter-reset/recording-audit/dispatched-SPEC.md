---
title: 'Execute the approved Story 1.17 filter-reset attempt once'
status: 'in-progress'
route: 'dispatch'
baseline_commit: '43423a9849c82a3a526590b0fa6e613768e7eb24'
context:
  - '/home/administrator/projects/hexalith/folders/_bmad-output/implementation-artifacts/story-1-17-cli-4-38-filter-reset-plan-2026-10-26.json'
  - '/home/administrator/projects/hexalith/folders/_bmad-output/implementation-artifacts/story-1-17-cli-4-38-filter-reset-proposal-2026-10-26.md'
  - '/home/administrator/projects/hexalith/folders/_bmad-output/implementation-artifacts/story-1-17-cli-4-38-filter-reset-authorization-2026-10-26.json'
---

<frozen-after-approval>
## Intent
Execute exactly the now-approved filter-reset plan once. Jerome's current reply is "approve"; the real hash-bound fresh authorization already exists at the context path. Previous approvals and failed evidence stay immutable. The plan is the executable specification; its approval creates fresh authority despite its retained historical PROPOSED label.

## Boundaries
Run only the plan's exactExecutionCommand, once, from the Folders root. Its adapter verifies hashes/root/index/flags, atomically claims the approval, repairs only a fresh private driver, runs SDK/compiler gates and the fixed cold/host-first loader-only cases. No retries or repairs after any failure. No application entrypoints/ComposeRun/runtime prerequisites/run/debug, model rebuild/restore, dependency/source changes, Git writes, nested initialization, publication/deployment or acceptance. Preserve direct Parties986a369ec26f6c5194593eb7bce12955eda54149 and all thirteen source revisions/indices. Parent in-progress, tracker backlog, V1Only, null T0/activation authority, and0/14 staging checks remain unchanged.

Do not change any existing spec, plan, helper, approval, receipt or archive bytes. Workflow status lives in new receipts, not frozen frontmatter. The twenty allowed untracked recording artifacts plus the fresh approval are expressly authorized preflight state. Do not add any other repository files before the invocation ends: keep invocation audit/temporary scripts under a fresh /tmp directory.
</frozen-after-approval>

## Tasks & Acceptance
- [ ] Verify the loaded context/owner hashes and invoke exactExecutionCommand once. Capture actual argv/cwd/start/end/exit/stdout/stderr, with all extra capture only under /tmp before the run ends. No substitute command, repeated invocation, gate bypass or new approval needed for already-bound inputs.
- [ ] Report actual adapter/WORK/claim paths and first success/failure promptly to the parent. On any gate failure, stop target execution; no retry or repair.
- [ ] Seal the actual result using the plan's sealingProcedure. Write only the three named outputs: filter-reset-execution-2026-10-26.json, .artifacts.tar.gz and .members.json under implementation-artifacts/evidence. Refuse to overwrite earlier files. No new proposal/fix files.
- [ ] Include both actual private directories, the retained claim metadata, original/derived input and driver hashes, all real approvals, every actual command/env/cursor/prelaunch/process observation, and certificate metadata only. Exclude certificate/private-key contents before hashing; do not traverse symlinks or invent missing logs. Verify every archived file member/hash/size.
- [ ] Rehash original owner-bound artifacts, SDK503 files and copied host/model inputs; retain full Git revisions/indices/flags/status and timestamped owned-process observation with sampling limits. Keep all private directories/claim records; no cleanup or certificate-store edits.

Given a failed gate, the final record describes the actual stop and zero subsequent compiler/cases rather than claiming success. Given an expected EventStore final-demand exit10, only the second predeclared case may continue. Any exit0 is a binding observation only. No ordinary mapping/ContentHash or tuple/package/hosted acceptance follows.

## Implementation Notes
You are already the dispatched bmad-build implementation agent. Implement this bounded spec directly; do not recursively invoke build workflows or delegate. Repository guidance/baseline still applies. Source/metadata inspection after the one command is read-only. Tests already passed; do not rerun tests, bwrap probes or SDK commands to debug failures. The sole currently authorized target execution is exactExecutionCommand. The parent handles review and any next owner proposal.
