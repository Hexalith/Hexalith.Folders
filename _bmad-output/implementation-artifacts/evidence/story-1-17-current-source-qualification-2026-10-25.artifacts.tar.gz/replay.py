"""Replay exact retained packet consistency against inspected source bytes; no network or Git."""
import hashlib,importlib.util,json,pathlib
root=pathlib.Path(__file__).resolve().parent
manifest=json.loads((root/'members.json').read_bytes())
for name,row in manifest.items():
 body=(root/name).read_bytes()
 assert len(body)==row['bytes'] and hashlib.sha256(body).hexdigest()==row['sha256'],name
for name,expected in [('original-packet',False),('current-packet',True)]:
 spec=importlib.util.spec_from_file_location(name,root/name/'verify.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 try:module.validate_packet(root/name,root/'inspected-sources')
 except module.PacketError as error:
  assert not expected
  assert str(error)=='source changed: src/Hexalith.Folders.Server/FoldersServerHostComposition.cs'
  print('Original packet: retained exact host-binding refusal; operational HOLD.')
 else:
  assert expected
  print('Current packet: consistency only; operational HOLD; 0 staging checks executed.')
print('All retained member hashes match.')
