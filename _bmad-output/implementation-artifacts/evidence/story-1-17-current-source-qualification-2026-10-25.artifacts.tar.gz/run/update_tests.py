from pathlib import Path
p=Path('eng/story117-platform-qualification-current/test_verify.py');s=p.read_text()
s=s.replace('for name, prop in packages.items())','for name, prop in packages.items())')
s=s.replace('        self.source_bodies[CATALOG] = (','        packages["Hexalith.Folders.Client"] = "HexalithFoldersVersion"\n        self.source_bodies[CATALOG] = (')
needle='        config["sourceInputs"] = {'
fixture='''        for owner, (relative, overrides) in verify.OWNER_CATALOGS.items():
            self.source_bodies[relative] = (
                "<Project><PropertyGroup>"
                + "".join(f"<{key}>{value}</{key}>" for key, value in verify.IMPORT_PATHS.items())
                + "".join(f"<{key}>{value}</{key}>" for key, value in overrides.items())
                + "</PropertyGroup>"
                + "".join('<Import Project="' + row["Project"] + '" Condition="' + row["Condition"] + '" />'
                          for row in verify.IMPORTS)
                + "</Project>"
            ).encode()
        self.source_bodies[verify.TOOL_MANIFEST] = json.dumps({"tools": {
            "hexalith.builds.module.cli": {"version": "4.35.2", "rollForward": False}}}).encode()
        self.source_bodies[verify.TOOL_RANGE] = json.dumps({"toolVersionRange": "[4.35.2, 5.0.0-0)"}).encode()
        self.source_bodies[verify.TOOL_RECEIPT] = json.dumps({"version": "4.35.2",
            "supportedToolRange": "[4.35.2, 5.0.0-0)",
            "buildsSourceCommit": "4248b8c70cb35ba79fdd7e4dd63049d4c73211a0"}).encode()
        self.source_bodies[verify.PLATFORM_TRACKER] = (
            "  1-8-run-and-debug-with-readiness-aware-startup-and-useful-diagno: done\\n"
            "  1-9-ratify-and-pin-the-first-platform-accepted-tool-version: done\\n").encode()
        delegated = verify.DELEGATED_OPERATIONS[0]
        for field, body in {
            "source": "VerifiedQueryCaller.Get FolderOwnerReadQuery.QueryType client().InvokeAsync",
            "transportSource": delegated["gatewayPath"] + " BoundOwnerQueryProof.Issue OriginatingAssertion",
            "queryContractSource": '"' + delegated["queryType"] + '"',
            "ownerHandlerSource": 'AuthorizeCurrentMetadataReadAsync "delegated-owner-query"',
        }.items():
            self.source_bodies[delegated[field]] = body.encode()
'''
s=s.replace(needle,fixture+needle)
s=s.replace('a["gatewaySubmission"].update(requiresDirectPublicMutation=False)','a["gatewaySubmission"].update(allowedSourceContexts=["any-public-read"])')
s=s.replace('("platformStartupStoryStatus", "done"), ("platformToolStoryStatus", "done")','("platformStartupStoryStatus", "backlog"), ("platformToolStoryStatus", "backlog")')
s=s.replace('original.replace(b"3.124.0", b"3.123.0")','original.replace(b"3.127.0", b"3.126.1")')
s=s.replace('b\'Version="3.124.0"\'','b\'Version="3.127.0"\'')
s=s.replace('test_current_proposal_binds_all_31_real_sources','test_current_proposal_binds_all_52_real_sources').replace('self.assertEqual(31,','self.assertEqual(52,')
# A now-current tool status is an observation, and content equality does not
# grant acceptance. Mutate each separately instead of accidentally reasserting it.
s=s.replace('("platformBuildsGitlinkRevision", verify.SNAPSHOTS["Builds"]),\n            ("matches", True)', '("platformBuildsGitlinkRevision", verify.SNAPSHOTS["Builds"]),\n            ("currentCatalogContentMatches", False),\n            ("acceptedToolCatalogContentMatchesCurrent", True),\n            ("recordedToolPin", "4.32.0"),\n            ("matches", True)')
new='''    def replace_source(self, relative, body):
        """Permit matching fixture fingerprints so semantic guards are tested independently."""
        (self.sources / relative).write_bytes(body)
        self.edit(CONFIG, lambda d: d["sourceInputs"].update({relative: hashlib.sha256(body).hexdigest()}))

    def test_effective_catalog_proposal_cannot_hide_override_or_owner_substitution(self):
        for owner in verify.OWNER_CATALOGS:
            for field, value in (("propertyOverrides", {"HexalithFoldersVersion": "99.0.0"}),
                                 ("packageOverrides", {"Hexalith.Folders.Client": "99.0.0"}),
                                 ("owningCatalog", CATALOG),
                                 ("importedCatalog", "unreviewed.props"),
                                 ("foldersClientContractsSelection", "1.2.1")):
                with self.subTest(owner=owner, field=field), self.case():
                    self.edit(CONFIG, lambda d: d["effectiveCatalogSelections"][owner].update({field: value}))
                    self.rejected("effective catalog " + owner)

    def test_effective_catalog_source_changes_fail_even_with_matching_fingerprints(self):
        for owner, (relative, _) in verify.OWNER_CATALOGS.items():
            original = self.source_bodies[relative]
            for body, message in (
                (original.replace(b"</PropertyGroup>", b"<HexalithFoldersVersion>1.2.1</HexalithFoldersVersion></PropertyGroup>"), "observed overrides"),
                (original.replace(b"</Project>", b'<ItemGroup><PackageVersion Update="Hexalith.Folders.Client" Version="1.2.1" /></ItemGroup></Project>'), "unsupported local catalog construct"),
                (original.replace(b"../Hexalith.Builds/", b"../Other.Builds/"), "import path changed"),
                (original.replace(b"$(Hexalith1BuildPackageProps)", b"$(Hexalith3BuildPackageProps)", 1), "guarded imports"),
                (original.replace(b" And ", b" Or "), "guarded imports"),
            ):
                with self.subTest(owner=owner, message=message), self.case():
                    self.replace_source(relative, body)
                    self.rejected(message)
        relative = verify.OWNER_CATALOGS["Folders"][0]
        original = self.source_bodies[relative]
        for body in (original.replace(b"<HexalithEventStoreVersion>3.127.0</HexalithEventStoreVersion>", b""),
                     original.replace(b"<HexalithEventStoreVersion>3.127.0", b"<HexalithEventStoreVersion>3.126.1")):
            with self.subTest(folders_override=body), self.case():
                self.replace_source(relative, body)
                self.rejected("observed overrides")

    def test_effective_client_contracts_pair_requires_shared_catalog_property(self):
        for package in ("Hexalith.Folders.Client", "Hexalith.Folders.Contracts"):
            with self.subTest(package=package), self.case():
                original = self.source_bodies[CATALOG]
                old = ('Include="' + package + '" Version="$(HexalithFoldersVersion)"').encode()
                new = ('Include="' + package + '" Version="1.3.1"').encode()
                self.replace_source(CATALOG, original.replace(old, new))
                self.rejected("catalog package binding|Client/Contracts pair binding changed")

    def test_delegated_operation_declaration_cannot_be_removed_replaced_or_made_mutating(self):
        for field, value in (("operation", "InvokeAny"), ("queryType", "UnreviewedQuery"),
                             ("gatewayPath", "/commands"), ("ownerPath", "/admin"),
                             ("ownerDomain", "projects"), ("method", "DELETE"), ("mutates", True),
                             ("source", verify.SOURCES[0]), ("transportSource", verify.SOURCES[0]),
                             ("queryContractSource", verify.SOURCES[0]), ("ownerHandlerSource", verify.SOURCES[0]),
                             ("selection", "Every caller can use delegated authority"),
                             ("outcomes", "Failures are successful"), ("hostedQualification", "accepted")):
            with self.subTest(field=field), self.case():
                self.edit(CONFIG, lambda d: d["projectsDelegatedReadOperations"][0].update({field: value}))
                self.rejected("Projects delegated operation")
        for value in ([], verify.DELEGATED_OPERATIONS * 2):
            with self.subTest(value=value), self.case():
                self.edit(CONFIG, lambda d: d.update(projectsDelegatedReadOperations=value))
                self.rejected("Projects delegated operation")

    def test_delegated_source_semantics_are_checked_independently_of_fingerprints(self):
        row = verify.DELEGATED_OPERATIONS[0]
        for field in ("source", "transportSource", "queryContractSource", "ownerHandlerSource"):
            with self.subTest(field=field), self.case():
                self.replace_source(row[field], b"An unrelated read-only implementation")
                self.rejected("Projects delegated source declaration changed")

    def test_recorded_tool_and_story_inputs_cannot_fabricate_current_acceptance(self):
        for relative in (verify.TOOL_MANIFEST, verify.TOOL_RANGE, verify.TOOL_RECEIPT):
            with self.subTest(relative=relative), self.case():
                self.replace_source(relative, self.source_bodies[relative].replace(b"4.35.2", b"4.32.0"))
                self.rejected("recorded tool")
        with self.case():
            self.replace_source(verify.PLATFORM_TRACKER, self.source_bodies[verify.PLATFORM_TRACKER].replace(b"done", b"backlog"))
            self.rejected("recorded Platform story status changed")
        with self.case():
            self.edit(CONFIG, lambda d: d["catalogCoherenceObservation"].update(acceptanceEvidence="hosted-qualified"))
            self.rejected("configuration requirements")

'''
s=s.replace('    def test_missing_module_key_preserves_hold_in_cli_failure(self):',new+'    def test_missing_module_key_preserves_hold_in_cli_failure(self):')
p.write_text(s)
