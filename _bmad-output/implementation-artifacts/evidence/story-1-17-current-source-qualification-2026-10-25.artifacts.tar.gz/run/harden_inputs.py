from pathlib import Path
import ast,re,pprint
p=Path('eng/story117-platform-qualification-current');v=p/'verify.py';s=v.read_text()
# Make every fixed allowlisted source and exact declaration independently readable.
for name in ('SOURCES','DEPENDENCIES','SNAPSHOTS','DELEGATED_OPERATIONS'):
 tree=ast.parse(s); node=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id==name for x in n.targets));value=ast.literal_eval(node.value);lines=s.splitlines(keepends=True)
 if name=='SOURCES':render='SOURCES = (\n'+''.join('    '+repr(x)+',\n' for x in value)+')\n'
 elif name=='DELEGATED_OPERATIONS':render=name+' = '+pprint.pformat(value,width=100,sort_dicts=False)+'\n'
 else:render=name+' = {\n'+''.join('    '+repr(k)+': '+repr(x)+',\n' for k,x in value.items())+'}\n'
 s=''.join(lines[:node.lineno-1])+render+''.join(lines[node.end_lineno:])
s=s.replace('def validate_effective_inputs(config, sources):','def validate_effective_inputs(config, sources, source_root):')
s=s.replace('validate_effective_inputs(config, bound_sources)','validate_effective_inputs(config, bound_sources, source_root)')
s=s.replace('        exact(local.tag, "Project", f"effective catalog {owner} root")','''        exact(local.tag, "Project", f"effective catalog {owner} root")
        exact(local.attrib, {}, f"effective catalog {owner} root attributes")
        require(all(not node.attrib for node in local.findall("./PropertyGroup")),
                f"effective catalog {owner}: conditional property group refused")''')
s=s.replace('        observed = {}\n        for node in properties:', '''        expected_properties = dict(IMPORT_PATHS, ManagePackageVersionsCentrally="true",
                                   CentralPackageTransitivePinningEnabled="true", **overrides)
        require(len(properties) == len(expected_properties) and all(not node.attrib and len(node) == 0 for node in properties),
                f"effective catalog {owner}: unsupported or duplicate local property")
        exact({node.tag: node.text for node in properties}, expected_properties,
              f"effective catalog {owner} reviewed local properties")
        # Projects' earlier nested fallback is currently absent. If it appears,
        # the same owning props would select another catalog before direct Builds.
        # Probe only this fixed candidate's metadata and never read its contents.
        if owner == "Projects":
            alternate = source_root / "references/Hexalith.Projects/references/Hexalith.Builds/Props/Directory.Packages.props"
            require(not alternate.exists() and not alternate.is_symlink() and alternate.resolve() == alternate,
                    "effective catalog Projects: earlier nested catalog substitution refused")
        observed = {}
        for node in properties:''')
s=s.replace('        require(len(properties) == 1, f"dependency {name}: unique catalog property required")','''        require(len(properties) == 1, f"dependency {name}: unique catalog property required")
        exact(properties[0].get("Condition"), f"'$(" + prop + ")' == ''",
              f"dependency {name} catalog default condition")''')
v.write_text(s)
t=p/'test_verify.py';s=t.read_text();s=s.replace('f"<{key}>{value}</{key}>" for key, value in properties.items()', 'f\'<{key} Condition="\\\'$(\' + key + f\')\\\' == \\\'\\\'">{value}</{key}>\' for key, value in properties.items()')
s=s.replace('                "<Project><PropertyGroup>"','                "<Project><PropertyGroup><ManagePackageVersionsCentrally>true</ManagePackageVersionsCentrally><CentralPackageTransitivePinningEnabled>true</CentralPackageTransitivePinningEnabled>"')
s=s.replace('"observed overrides"','"reviewed local properties|unsupported or duplicate local property|observed overrides"')
# Additional semantic negative cases target the actual effective import behavior.
needle='    def test_effective_client_contracts_pair_requires_shared_catalog_property(self):'
new='''    def test_nested_catalog_appearance_is_refused_before_reading_its_contents(self):
        alternate = self.sources / "references/Hexalith.Projects/references/Hexalith.Builds/Props/Directory.Packages.props"
        alternate.parent.mkdir(parents=True)
        alternate.write_bytes(b"PRIVATE-ALTERNATE-CATALOG")
        original_read = Path.read_bytes
        def bounded_read(candidate):
            self.assertNotEqual(alternate, candidate, "unreviewed alternate catalog must never be read")
            return original_read(candidate)
        with patch.object(Path, "read_bytes", bounded_read):
            code, output, errors = self.cli()
        self.assertEqual(1, code)
        self.assertIn("earlier nested catalog substitution refused", errors)
        self.assertNotIn("PRIVATE-ALTERNATE-CATALOG", output + errors)

    def test_conditional_duplicate_and_import_suppression_properties_are_refused(self):
        for owner, (relative, _) in verify.OWNER_CATALOGS.items():
            original = self.source_bodies[relative]
            for body in (
                original.replace(b"<PropertyGroup>", b'<PropertyGroup Condition="false">'),
                original.replace(b"</PropertyGroup>", b"<HexalithVersionsLoaded>true</HexalithVersionsLoaded></PropertyGroup>"),
                original.replace(b"</PropertyGroup>", b"<ManagePackageVersionsCentrally>false</ManagePackageVersionsCentrally></PropertyGroup>"),
            ):
                with self.subTest(owner=owner, body=body), self.case():
                    self.replace_source(relative, body)
                    self.rejected("conditional property group refused|unsupported or duplicate local property")

'''
s=s.replace(needle,new+needle);t.write_text(s)
