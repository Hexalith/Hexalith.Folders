from pathlib import Path
import ast,hashlib,json,re
p=Path('eng/story117-platform-qualification-current'); c=json.loads((p/'configuration.proposed.json').read_bytes());plan=json.loads((p/'staging-checks.json').read_bytes());s=(p/'verify.py').read_text()
s=re.sub(r'SOURCES = \(.*?\n\)', 'SOURCES = '+repr(tuple(c['sourceInputs'])),s,count=1,flags=re.S)
s=re.sub(r'DEPENDENCIES = \{.*?\n\}', 'DEPENDENCIES = '+repr({n:(x['appId'],x['catalogInputPin']) for n,x in c['dependencies'].items()}),s,count=1,flags=re.S)
s=re.sub(r'SNAPSHOTS = \{.*?\n\}', 'SNAPSHOTS = '+repr({n:x['revision'] for n,x in c['sourceSnapshots'].items()}),s,count=1,flags=re.S)
s=s.replace('"moduleConfiguration", "authenticationRequirements", "catalogCoherenceObservation",','"moduleConfiguration", "authenticationRequirements", "catalogCoherenceObservation",\n    "effectiveCatalogSelections", "projectsDelegatedReadOperations",')
s=s.replace('"authenticationRequirements", "catalogCoherenceObservation",\n    ), "configuration")','"authenticationRequirements", "catalogCoherenceObservation", "effectiveCatalogSelections",\n        "projectsDelegatedReadOperations",\n    ), "configuration")')
s=s.replace('keys(snapshots, ("Folders", "Projects", "Platform", "EventStore", "Builds"), "sourceSnapshots")','keys(snapshots, SNAPSHOTS, "sourceSnapshots")')
s=s.replace('keys(row, ("operation", "method", "path", "mutates"), "Projects operation")','keys(row, ("operation", "method", "path", "mutates", "transport", "source"), "Projects operation")\n        exact(row["transport"], "direct-sdk", f"Projects operation {operation}.transport")\n        direct_source = PROJECTS_FOLDERS + ("FoldersProjectFileReferenceDirectory.cs"\n            if operation == "GetFolderFileMetadataAsync" else "FoldersProjectFolderDirectory.cs")\n        exact(row["source"], direct_source, f"Projects operation {operation}.source")')
s=s.replace('config["dependencies"])\n    operations =', 'config["dependencies"])\n    validate_effective_inputs(config, bound_sources)\n    operations =')
s=s.replace('    exact(plan["schema"],', '    exact(config["projectsDelegatedReadOperations"], DELEGATED_OPERATIONS, "Projects delegated operation")\n\n    exact(plan["schema"],')
# Fixed semantic observations remain independent from disposable source digests.
new='''PROJECTS_FOLDERS = "references/Hexalith.Projects/src/Hexalith.Projects.Server/Folders/"
OWNER_CATALOGS = {
    "Folders": ("Directory.Packages.props", {"HexalithEventStoreVersion": "3.127.0"}),
    "Projects": ("references/Hexalith.Projects/Directory.Packages.props", {}),
}
CATALOG_SOURCE = "references/Hexalith.Builds/Props/Directory.Packages.props"
IMPORTS = [
    {"Project": "$(Hexalith1BuildPackageProps)", "Condition": "Exists('$(Hexalith1BuildPackageProps)') And '$(HexalithVersionsLoaded)' != 'true'"},
    {"Project": "$(Hexalith2BuildPackageProps)", "Condition": "Exists('$(Hexalith2BuildPackageProps)') And '$(HexalithVersionsLoaded)' != 'true'"},
    {"Project": "$(Hexalith3BuildPackageProps)", "Condition": "'$(HexalithVersionsLoaded)' != 'true'"},
]
IMPORT_PATHS = {
    "Hexalith1BuildPackageProps": "$(MSBuildThisFileDirectory)references/Hexalith.Builds/Props/Directory.Packages.props",
    "Hexalith2BuildPackageProps": "$(MSBuildThisFileDirectory)../Hexalith.Builds/Props/Directory.Packages.props",
    "Hexalith3BuildPackageProps": "$(MSBuildThisFileDirectory)../../Hexalith.Builds/Props/Directory.Packages.props",
}
TOOL_MANIFEST = "references/Hexalith.Platform/.config/dotnet-tools.json"
TOOL_RANGE = "references/Hexalith.Platform/hexalith-platform.json"
TOOL_RECEIPT = "references/Hexalith.Platform/_bmad-output/implementation-artifacts/evidence/1-13/pass-5/release/accepted-identities.json"
PLATFORM_TRACKER = "references/Hexalith.Platform/_bmad-output/implementation-artifacts/sprint-status.yaml"
DELEGATED_OPERATIONS = '''+repr(c['projectsDelegatedReadOperations'])+'''


def xml_source(body, label):
    try:
        return ET.fromstring(body)
    except ET.ParseError:
        raise PacketError(f"{label}: invalid XML") from None


def validate_effective_inputs(config, sources):
    """Check the reviewed default import/override forms; never evaluate MSBuild."""
    selections = config["effectiveCatalogSelections"]
    keys(selections, OWNER_CATALOGS, "effectiveCatalogSelections")
    catalog = xml_source(sources[CATALOG_SOURCE], "Builds catalog")
    for owner, (relative, overrides) in OWNER_CATALOGS.items():
        row = selections[owner]
        keys(row, ("owningCatalog", "importedCatalog", "scope", "propertyOverrides", "packageOverrides",
                   "foldersClientContractsSelection", "boundary"), f"effective catalog {owner}")
        exact(row["owningCatalog"], relative, f"effective catalog {owner} owningCatalog")
        exact(row["importedCatalog"], CATALOG_SOURCE, f"effective catalog {owner} importedCatalog")
        exact(row["scope"], "inspected-default-Release-package-inputs", f"effective catalog {owner} scope")
        exact(row["propertyOverrides"], overrides, f"effective catalog {owner} propertyOverrides")
        exact(row["packageOverrides"], {}, f"effective catalog {owner} packageOverrides")
        exact(row["foldersClientContractsSelection"], "1.3.1", f"effective catalog {owner} foldersClientContractsSelection")
        nonempty(row["boundary"], f"effective catalog {owner} boundary")
        local = xml_source(sources[relative], f"effective catalog {owner}")
        exact(local.tag, "Project", f"effective catalog {owner} root")
        exact([node.attrib for node in local.findall("./Import")], IMPORTS,
              f"effective catalog {owner} guarded imports")
        require(all(node.tag in ("PropertyGroup", "Import") for node in local),
                f"effective catalog {owner}: unsupported local catalog construct")
        properties = list(local.findall("./PropertyGroup/*"))
        observed = {}
        for node in properties:
            if node.tag.startswith("Hexalith") and node.tag.endswith("Version"):
                require(node.tag not in observed and not node.attrib,
                        f"effective catalog {owner}: unconditional unique override required")
                observed[node.tag] = node.text
        exact(observed, overrides, f"effective catalog {owner} observed overrides")
        # Overrides must precede the guarded catalog import; otherwise defaults
        # can be captured by earlier item evaluation rather than the declaration.
        first_import = next(index for index, node in enumerate(local) if node.tag == "Import")
        require(all(index < first_import for index, node in enumerate(local)
                    if node.tag == "PropertyGroup" and any(child.tag in overrides for child in node)),
                f"effective catalog {owner}: override order changed")
        for key, value in IMPORT_PATHS.items():
            matches = [node for node in properties if node.tag == key]
            require(len(matches) == 1 and not matches[0].attrib and matches[0].text == value,
                    f"effective catalog {owner}: import path changed")
        for package in ("Hexalith.Folders.Client", "Hexalith.Folders.Contracts"):
            rows = [node for node in catalog.findall("./ItemGroup/PackageVersion") if node.get("Include") == package]
            require(len(rows) == 1 and rows[0].get("Version") == "$(HexalithFoldersVersion)"
                    and rows[0].get("Condition") is None,
                    f"effective catalog {owner}: Client/Contracts pair binding changed")
    try:
        documents = {relative: json.loads(sources[relative].decode("utf-8"),
                         object_pairs_hook=unique_object, parse_constant=reject_constant)
                     for relative in (TOOL_MANIFEST, TOOL_RANGE, TOOL_RECEIPT)}
        manifest = documents[TOOL_MANIFEST]["tools"]["hexalith.builds.module.cli"]
        exact(manifest["version"], "4.35.2", "recorded tool pin")
        exact(manifest["rollForward"], False, "recorded tool rollForward")
        exact(documents[TOOL_RANGE]["toolVersionRange"], "[4.35.2, 5.0.0-0)", "recorded tool range")
        receipt = documents[TOOL_RECEIPT]
        for key, value in dict(version="4.35.2", supportedToolRange="[4.35.2, 5.0.0-0)",
                               buildsSourceCommit="4248b8c70cb35ba79fdd7e4dd63049d4c73211a0").items():
            exact(receipt[key], value, f"recorded tool acceptance {key}")
    except (UnicodeError, json.JSONDecodeError, KeyError, TypeError, RecursionError):
        raise PacketError("recorded tool acceptance: malformed source") from None
    tracker = sources[PLATFORM_TRACKER].decode("utf-8")
    for story in ("1-8-run-and-debug-with-readiness-aware-startup-and-useful-diagno",
                  "1-9-ratify-and-pin-the-first-platform-accepted-tool-version"):
        require(re.findall(r"(?m)^  " + re.escape(story) + r": (\\S+)\\s*$", tracker) == ["done"],
                "recorded Platform story status changed")
    delegated = DELEGATED_OPERATIONS[0]
    expected_tokens = {
        delegated["source"]: ("VerifiedQueryCaller.Get", "FolderOwnerReadQuery.QueryType", "client().InvokeAsync"),
        delegated["transportSource"]: (delegated["gatewayPath"], "BoundOwnerQueryProof.Issue", "OriginatingAssertion"),
        delegated["queryContractSource"]: ('"' + delegated["queryType"] + '"',),
        delegated["ownerHandlerSource"]: ("AuthorizeCurrentMetadataReadAsync", '"delegated-owner-query"'),
    }
    for relative, tokens in expected_tokens.items():
        require(all(token.encode("utf-8") in sources[relative] for token in tokens),
                f"Projects delegated source declaration changed: {relative}")


'''
s=s.replace('def validate_packet(',new+'def validate_packet(')
fields=ast.literal_eval(re.search(r'REQUIREMENT_FIELDS = (\(.*?\n\))',s,re.S).group(1))
sha=lambda o:hashlib.sha256(json.dumps(o,sort_keys=True,separators=(',',':')).encode()).hexdigest()
s=re.sub(r'REQUIREMENTS_SHA256 = "[a-f0-9]+"','REQUIREMENTS_SHA256 = "'+sha({k:c[k] for k in fields})+'"',s)
s=re.sub(r'STAGING_SHA256 = "[a-f0-9]+"','STAGING_SHA256 = "'+sha(plan)+'"',s)
(p/'verify.py').write_text(s)
print('Verifier reconciled with effective catalogs, retained owner status and direct/delegated operations.')
