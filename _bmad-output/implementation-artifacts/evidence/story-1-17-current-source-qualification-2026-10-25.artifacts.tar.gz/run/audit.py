"""Independent read-only inventory/provenance/preservation audit for this receipt."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
r=Path.cwd();b=Path(__file__).resolve().parent;before=json.loads((b/'preservation-before.json').read_bytes()); sha=lambda body:hashlib.sha256(body).hexdigest()
config=json.loads((r/'eng/story117-platform-qualification-current/configuration.proposed.json').read_bytes())
for name,digest in config['sourceInputs'].items():
 p=r/name;assert p.is_file() and not p.is_symlink() and sha(p.read_bytes())==digest,name
candidate='_bmad-output/implementation-artifacts/evidence/story-12-2-v2-source-requalification-pending.yaml';body=(r/candidate).read_bytes();text=body.decode();rows=re.findall(r'  - path: "([^"\n]+)"\n    kind: file\n    bytes: (\d+)\n    sha256: ([a-f0-9]{64})',text);assert len(rows)==1425
for name,size,digest in rows:
 p=r/name;data=p.read_bytes();assert len(data)==int(size) and sha(data)==digest,name
ordered=sha(''.join(f'{name}\0{digest}\n' for name,size,digest in rows).encode());assert ordered==re.search(r'^candidate_set_sha256: (\S+)',text,re.M)[1]
manifest='_bmad-output/planning-artifacts/planning-story-manifest.yaml';text=(r/manifest).read_text();section=text.split('provenance:\n',1)[1].split('\npost_a8_finalization:',1)[0];bindings=re.findall(r'- path: (.+)\n  sha256: ([a-f0-9]{64})',section);assert len(bindings)==20
for name,digest in bindings:assert sha((r/name).read_bytes())==digest,name
for name,digest in before['protected'].items():assert sha((r/name).read_bytes())==digest,name
for name,row in before['repositories'].items():
 def git(*a):return subprocess.check_output(['git','-C',str(r/row['path']),*a])
 assert git('rev-parse','HEAD').decode().strip()==row['revision'],name
 assert sha(git('ls-files','--stage','-z'))==row['indexSha256'],name
 if name!='Folders':assert git('status','--porcelain=v1','-uno').decode().splitlines()==row['status'],name
for name,filename in [('_bmad-output/implementation-artifacts/spec-1-17-complete-pd10-v2-migration-and-closure.md','spec-before-agent.md'),('_bmad-output/implementation-artifacts/story-1-17-current-candidate-technical-readiness-2026-09-24.md','readiness-before-agent.md')]:
 assert (r/name).read_bytes().startswith((b/filename).read_bytes()),name
result={'sourceBindingsMatched':len(config['sourceInputs']),'pendingCandidate':{'path':candidate,'entriesMatched':len(rows),'rawSha256':sha(body),'orderedSetSha256':ordered,'unchanged':sha(body)==before['protected'][candidate]},'planningBindingsMatched':len(bindings),'planningManifestSha256':sha((r/manifest).read_bytes()),'protectedInputsMatched':len(before['protected']),'repositoryRevisionsAndIndexDigestsMatched':len(before['repositories']),'specReadinessPrefixesPreserved':True,'operationalControl':config['productionControl'],'stagingChecksUnexecuted':len(json.loads((r/'eng/story117-platform-qualification-current/staging-checks.json').read_bytes())['checks'])}
(b/'audit-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
