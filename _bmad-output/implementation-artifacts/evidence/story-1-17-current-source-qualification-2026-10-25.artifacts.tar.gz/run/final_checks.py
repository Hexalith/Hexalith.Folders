from pathlib import Path
import datetime,json,os,subprocess
r=Path.cwd();w=Path(__file__).resolve().parent;env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');results=[]
commands=[('current-verifier',['python3','eng/story117-platform-qualification-current/verify.py']),('complete-mutation-suite',['python3','-m','unittest','discover','-s','eng/story117-platform-qualification-current','-p','test_*.py','-v']),('independent-audit',['python3',str(w/'audit.py')]),('diff-check',['git','diff','--check'])]
for label,command in commands:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();proc=subprocess.run(command,cwd=r,env=env,text=True,capture_output=True);end=datetime.datetime.now(datetime.timezone.utc).isoformat();(w/(label+'.txt')).write_text(proc.stdout+proc.stderr);results.append({'label':label,'command':command,'workingDirectory':'<workspace>','environmentNamesOnly':['PYTHONDONTWRITEBYTECODE'],'startedAtUtc':start,'completedAtUtc':end,'exitCode':proc.returncode,'log':label+'.txt'});print(label,proc.returncode)
(w/'commands.json').write_text(json.dumps(results,indent=2)+'\n');assert all(x['exitCode']==0 for x in results)
(w/'reviewed-working-tree.diff').write_bytes(subprocess.check_output(['git','diff','--binary']))
