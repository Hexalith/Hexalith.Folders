using Hexalith.EventStore.DomainService.Content;
using Hexalith.Folders.Server.Content;
using Hexalith.EventStore.Client.Projections;
using Hexalith.EventStore.Client.Registration;
using Hexalith.EventStore.Client.Handlers;
using Hexalith.EventStore.DomainService;
using Hexalith.Folders;
using Hexalith.Folders.Aggregates.Folder;
using Hexalith.Folders.Aggregates.Organization;
using Hexalith.Folders.Authorization;
using Hexalith.Folders.Projections.SemanticIndexing;
using Hexalith.Folders.Projections.OperationalStatus;
using Hexalith.Folders.Projections.TenantAccess;
using Hexalith.Folders.Queries.ContextSearch;
using Hexalith.Folders.Queries.FileContext;
using Hexalith.Folders.Server.Authentication;
using Hexalith.Folders.Server.Authorization;
using Hexalith.Folders.Server.ContextSearch;

using Hexalith.Memories.Client.Rest;

using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;

namespace Hexalith.Folders.Server;

public static class FoldersServerServiceCollectionExtensions
{
    public static IServiceCollection AddFoldersDomainServices(this IServiceCollection services)
    {
        ArgumentNullException.ThrowIfNull(services);

        services.AddEventStore(typeof(FoldersModule).Assembly);
        // These full CLR names are the persisted EventStore 6.6 storage identifiers.
        services.AddKnownEventPayload<FolderCreated>();
        services.AddKnownEventPayload<FolderAccessGranted>();
        services.AddKnownEventPayload<FolderAccessRevoked>();
        services.AddKnownEventPayload<FolderArchived>();
        services.AddKnownEventPayload<RepositoryBindingRequested>();
        services.AddKnownEventPayload<ExistingRepositoryBindingRequested>();
        services.AddKnownEventPayload<RepositoryBound>();
        services.AddKnownEventPayload<RepositoryBindingFailed>();
        services.AddKnownEventPayload<ProviderOutcomeUnknown>();
        services.AddKnownEventPayload<BranchRefPolicyConfigured>();
        services.AddKnownEventPayload<WorkspacePreparationRequested>();
        services.AddKnownEventPayload<FolderWorkspaceLifecycleEventRecorded>();
        services.AddKnownEventPayload<WorkspaceLockAcquired>();
        services.AddKnownEventPayload<WorkspaceLockReleased>();
        services.AddKnownEventPayload<WorkspaceFileMutationAccepted>();
        services.AddKnownEventPayload<WorkspaceContentErasureAuthorized>();
        services.AddKnownEventPayload<WorkspaceCommitSucceeded>();
        services.AddKnownEventPayload<WorkspaceCommitFailed>();
        services.AddKnownEventPayload<WorkspaceCommitOutcomeUnknown>();
        services.AddKnownEventPayload<OrganizationAclBaselineInitialized>();
        services.AddKnownEventPayload<OrganizationAclPrincipalGranted>();
        services.AddKnownEventPayload<OrganizationAclPrincipalRevoked>();
        services.AddKnownEventPayload<ProviderBindingConfigured>();
        services.AddEventStoreGatewayClient();
        services.TryAddSingleton<FolderEventReplay>();
        services.TryAddSingleton(static sp => new OperationalStatusProjectionWriter(
            sp.GetRequiredService<SharedProjectionEpochCoordinator>(), sp.GetService<IUtcClock>()));
        services.AddHttpClient<IOrganizationStreamSequenceReader, DaprOrganizationStreamSequenceReader>();
        services.TryAddSingleton<DomainProjectionCatalogRegistry>();
        services.AddOptions<Hexalith.EventStore.Client.Projections.ProjectionDispatchOptions>()
            .BindConfiguration("EventStore:ProjectionDispatch");
        services.AddOptions<DomainProjectionIdentityOptions>().BindConfiguration("EventStore:DomainService")
            .PostConfigure(static options =>
            {
                if (string.IsNullOrWhiteSpace(options.AppId)) options.AppId = "folders";
            });
        services.TryAddEnumerable(ServiceDescriptor.Singleton<IAsyncDomainProjectionHandler, OperationalStatusProjectionHandler>());
        services.TryAddEnumerable(ServiceDescriptor.Singleton<IDomainProjectionHandler, FolderDomainProjectionHandler>());
        services.AddFoldersObservability();
        services.AddHttpContextAccessor();
        services.TryAddEnumerable(ServiceDescriptor.Singleton<IDomainQueryHandler, Queries.FolderOwnerReadQueryHandler>());
        services.TryAddSingleton<Queries.FolderFileOwnerReadQueryHandler>();
        services.TryAddEnumerable(ServiceDescriptor.Singleton<IDomainQueryHandler, Queries.FolderFileOwnerReadQueryHandler>());
        services.TryAddEnumerable(ServiceDescriptor.Singleton<IDomainQueryHandler, Queries.FolderFileReferenceReadQueryHandler>());
        services.AddOptions<TenantContextOptions>().BindConfiguration(TenantContextOptions.SectionName);
        services.TryAddSingleton<ITenantContextAccessor, HttpContextTenantContextAccessor>();
        services.TryAddSingleton<IEventStoreClaimTransformEvidenceAccessor, HttpContextEventStoreClaimTransformEvidenceAccessor>();
        services.TryAddSingleton<IPd10AuthorizationAuditSink, LoggingPd10AuthorizationAuditSink>();
        services.TryAddSingleton<IFolderCommandActionTokenMapper, FolderCommandActionTokenMapper>();
        services.TryAddScoped<ILayeredFolderAuthorizationResultAccessor, ScopedLayeredFolderAuthorizationResultAccessor>();
        services.TryAddScoped<IFolderArchiveAclEvidenceProvider, LayeredAuthBackedFolderArchiveAclEvidenceProvider>();
        services.TryAddScoped<IFolderArchivePolicyEvidenceProvider, BaselineFolderArchivePolicyEvidenceProvider>();
        services.TryAddScoped<IRepositoryCreationReadinessValidator, ProviderReadinessRepositoryCreationValidator>();
        services.TryAddScoped<IRepositoryBindingReadinessValidator, ProviderReadinessRepositoryBindingValidator>();
        services.TryAddScoped<IBranchRefPolicyReadinessValidator, ProviderReadinessBranchRefPolicyValidator>();
        services.TryAddScoped<IWorkspacePreparationReadinessValidator, ProviderReadinessWorkspacePreparationValidator>();
        services.TryAddScoped<IWorkspaceCommitReadinessValidator, ProviderReadinessWorkspaceCommitValidator>();
        services.TryAddSingleton(TimeProvider.System);
        services.TryAddScoped<FolderArchiveTenantGate>();
        services.TryAddScoped<FolderAccessTenantGate>();
        services.TryAddScoped<FolderCreationService>();
        services.TryAddScoped<FolderAccessMutationService>();
        services.TryAddScoped<ConfigureProviderBindingService>();

        // In-memory organization provider-binding write store default, consistent with the other
        // in-memory provider/read-model defaults registered for the server composition. Production
        // hosts override this with an EventStore-backed implementation.
        services.TryAddSingleton<IOrganizationProviderBindingRepository, InMemoryOrganizationProviderBindingRepository>();
        services.TryAddScoped<RepositoryBackedFolderCreationService>();
        services.TryAddScoped<RepositoryBindingService>();
        services.TryAddScoped<BranchRefPolicyConfigurationService>();
        services.TryAddScoped<WorkspacePreparationService>();
        services.TryAddScoped<WorkspaceLockAcquisitionService>();
        services.TryAddScoped<WorkspaceLockReleaseService>();
        services.AddAuthoritativeContent<WorkspaceContentAuthority>(options => options.MaximumBodyBytes = 1048576);
        services.TryAddScoped<IWorkspaceFilePolicySource, ConfigurationWorkspaceFilePolicySource>();
        services.TryAddScoped<WorkspaceContentStateReader>();
        services.TryAddScoped<WorkspaceContentRejectionReader>();
        services.TryAddScoped<WorkspaceContentBatch>();
        services.TryAddScoped<WorkspaceContentMutationAdapter>();
        services.TryAddScoped<IWorkspacePathPolicyEvidenceProvider, WorkspaceContentPathEvidenceProvider>();
        services.TryAddScoped<IWorkspaceFileContentStore>(provider => provider.GetRequiredService<WorkspaceContentMutationAdapter>());
        services.TryAddScoped<IWorkspaceFileDeleteOperationStore>(provider => provider.GetRequiredService<WorkspaceContentMutationAdapter>());
        services.TryAddScoped<WorkspaceFileMutationService>();
        services.TryAddScoped<IWorkspaceCommitExecutor, UnavailableWorkspaceCommitExecutor>();
        services.TryAddScoped<WorkspaceCommitService>();
        services.TryAddScoped<IWorkspaceFileSensitivityClassifier, WorkspaceFileSensitivityClassifier>();
        // The standalone core module intentionally provides an unavailable singleton. A server
        // must replace that default and its singleton handler so the SDK authority stays scoped.
        foreach (ServiceDescriptor descriptor in services.Where(descriptor =>
            descriptor.ServiceType == typeof(IWorkspaceFileContextSource)
                && descriptor.ImplementationType == typeof(UnavailableWorkspaceFileContextSource)
            || descriptor.ServiceType == typeof(WorkspaceFileContextQueryHandler)
                && descriptor.ImplementationType == typeof(WorkspaceFileContextQueryHandler)
                && descriptor.Lifetime == ServiceLifetime.Singleton).ToArray())
            services.Remove(descriptor);
        services.TryAddScoped<IWorkspaceFileContextSource, AuthoritativeWorkspaceFileContextSource>();
        services.TryAddScoped<WorkspaceFileContextQueryHandler>();
        services.TryAddEnumerable(ServiceDescriptor.Scoped<IDomainProcessor, FolderDomainProcessor>());
        // Enroll the existing bespoke processor in the SDK's domain capability lookup.
        services.TryAddKeyedScoped<IDomainProcessor>(FoldersServerModule.DomainName, static (provider, _) =>
            provider.GetServices<IDomainProcessor>().OfType<FolderDomainProcessor>().Single());
        services.TryAddScoped<FoldersDomainServiceRequestHandler>();
        services.TryAddEnumerable(ServiceDescriptor.Singleton<IHostedService, FoldersAuthSchemeValidator>());

        return services;
    }

    // Stable Dapr app-id contract for the Memories search-index server (project-context #71).
    private const string MemoriesDaprAppId = "memories";

    /// <summary>
    /// Registers the Story 10.5 authorized context-search facade (Option B). Adds the typed Memories search client
    /// and routes its egress through THIS app's Dapr sidecar service-invocation API, so the production deny-by-default
    /// <c>folders -&gt; memories</c> <c>GET /api/search</c> invoke allow-rule + mTLS are the operative network-layer
    /// control (consistent with architecture I-3/S-4). Binds the token/endpoint from configuration and wires the live
    /// <see cref="MemoriesFolderSearchSource"/> as the <see cref="IFolderSearchSource"/>. The live gateway is
    /// registered before the core defaults so the core <c>TryAdd</c> keeps it; it degrades safely when the sidecar or
    /// Memories is unreachable. After the core queries register their fail-safe <c>Unavailable</c> <c>TryAdd</c>
    /// default, this facade replaces the bridge read model with the EventStore-backed store (read-only on Server;
    /// Workers keep the same type as writer).
    /// </summary>
    public static IServiceCollection AddFoldersContextSearchFacade(this IServiceCollection services)
    {
        ArgumentNullException.ThrowIfNull(services);

        services.AddMemoriesClient();
        services.AddOptions<MemoriesClientOptions>().Configure<IConfiguration>(static (options, configuration) =>
        {
            // Compose the base address as this sidecar's service-invocation endpoint; MemoriesClient issues
            // `GET api/search` relative to it, yielding `.../v1.0/invoke/memories/method/api/search` — a genuine
            // Dapr invoke governed by the deny-by-default allow-rule + mTLS. Mirrors Hexalith.Memories.Server's
            // eventstore-invoke idiom. An explicit absolute `Memories:BaseAddress` still wins as a direct-URL
            // override (hermetic tests / non-Dapr hosting).
            if (Uri.TryCreate(configuration["Memories:BaseAddress"], UriKind.Absolute, out Uri? endpoint))
            {
                options.Endpoint = endpoint;
            }
            else
            {
                string daprHttpEndpoint = configuration["DAPR_HTTP_ENDPOINT"]
                    ?? $"http://localhost:{configuration["DAPR_HTTP_PORT"] ?? "3500"}";
                options.Endpoint = new Uri(
                    $"{daprHttpEndpoint.TrimEnd('/')}/v1.0/invoke/{MemoriesDaprAppId}/method/");
            }

            string? apiToken = configuration["HEXALITH_MEMORIES_API_TOKEN"];
            if (!string.IsNullOrWhiteSpace(apiToken))
            {
                options.ApiToken = apiToken;
            }
        });

        // Register the live gateway before the core defaults so the core TryAddScoped keeps it. Scoped gateway over a
        // transient typed MemoriesClient — no captive dependency.
        services.AddScoped<IFolderSearchSource, MemoriesFolderSearchSource>();
        services.AddFoldersContextSearchQueries();

        // Override after AddFoldersContextSearchQueries (TryAddScoped Unavailable). Mirror Workers: RemoveAll then
        // singleton. Server is read-only — no ISemanticIndexingBridgeWriter registration.
        services.AddEventStoreReadModelStore();
        services.RemoveAll<ISemanticIndexingBridgeReadModel>();
        services.TryAddSingleton<EventStoreSemanticIndexingBridgeStore>();
        services.TryAddSingleton<ISemanticIndexingBridgeReadModel>(static sp => sp.GetRequiredService<EventStoreSemanticIndexingBridgeStore>());

        return services;
    }
}
