"""Prove final-review replay checks stay active with optimized Python."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parent


class ReplayTests(unittest.TestCase):
    def invoke(self, root, optimized=False):
        arguments = [sys.executable, *(('-O',) if optimized else ()), 'replay.py']
        return subprocess.run(arguments, cwd=root, text=True, capture_output=True,
                              env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'), timeout=30)

    def test_retained_evidence_passes_normally_and_optimized(self):
        for optimized in (False, True):
            with self.subTest(optimized=optimized):
                result = self.invoke(ROOT, optimized)
                self.assertEqual(0, result.returncode, result.stderr)
                self.assertIn('consistency only; HOLD; 0 staging checks executed', result.stdout)

    def test_corrupted_evidence_is_refused_under_optimized_python(self):
        with tempfile.TemporaryDirectory(prefix='story117-corrupt-replay-') as temporary:
            root = Path(temporary) / 'evidence'
            shutil.copytree(ROOT, root)
            path = root / 'current-packet/configuration.proposed.json'
            path.write_bytes(path.read_bytes() + b'\ncorrupted retained evidence\n')
            result = self.invoke(root, True)
            self.assertEqual(1, result.returncode)
            self.assertIn('FAIL:', result.stderr)
            self.assertNotIn('PASS:', result.stdout)

    def test_unsafe_outcome_is_refused_even_after_rebinding_corrupted_member(self):
        with tempfile.TemporaryDirectory(prefix='story117-outcome-replay-') as temporary:
            root = Path(temporary) / 'evidence'
            shutil.copytree(ROOT, root)
            path = root / 'current-packet/configuration.proposed.json'
            config = json.loads(path.read_bytes())
            config['productionControl']['routeMode'] = 'V2Only'
            body = json.dumps(config).encode()
            path.write_bytes(body)
            import hashlib
            manifest_path = root / 'members.json'
            manifest = json.loads(manifest_path.read_bytes())
            manifest['current-packet/configuration.proposed.json'] = {
                'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}
            manifest_path.write_text(json.dumps(manifest))
            result = self.invoke(root, True)
            self.assertEqual(1, result.returncode)
            self.assertIn('FAIL:', result.stderr)
            self.assertNotIn('PASS:', result.stdout)


if __name__ == '__main__':
    unittest.main(verbosity=2)
