"""Check retained final-review evidence explicitly, including under python -O."""
import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import sys


class EvidenceError(ValueError):
    """A retained input failed integrity or outcome validation."""


def require(condition, message):
    if not condition:
        raise EvidenceError(message)


def digest(body):
    return hashlib.sha256(body).hexdigest()


def replay(root):
    manifest = json.loads((root / "members.json").read_bytes())
    require(isinstance(manifest, dict) and 0 < len(manifest) <= 128, "invalid member manifest")
    for name, row in manifest.items():
        relative = PurePosixPath(name)
        require(not relative.is_absolute() and ".." not in relative.parts, "invalid member name")
        path = root / name
        require(path.resolve() == path and path.is_file() and not path.is_symlink(), "invalid evidence member")
        require(type(row.get("bytes")) is int and 0 <= row["bytes"] <= 8_388_608,
                "invalid member bound")
        require(path.stat().st_size == row["bytes"] and digest(path.read_bytes()) == row["sha256"],
                "evidence member integrity mismatch")
    comparison = json.loads((root / "catalog-comparisons.json").read_bytes())
    require(set(comparison["gitBlobs"]) == {"direct", "platform-gitlink", "accepted-tool"}, "catalog observations differ")
    blobs = {}
    for name, row in comparison["gitBlobs"].items():
        body = (root / row["member"]).read_bytes()
        require(len(body) == row["bytes"] and digest(body) == row["gitNormalizedSha256"],
                "catalog blob integrity mismatch")
        blobs[name] = body
    require(blobs["direct"] == blobs["platform-gitlink"], "current catalog comparison changed")
    require(blobs["accepted-tool"] != blobs["direct"], "accepted-tool comparison changed")
    checkout = (root / "inspected-sources/references/Hexalith.Builds/Props/Directory.Packages.props").read_bytes()
    require(digest(checkout) == comparison["checkout"]["rawSha256"], "catalog checkout identity changed")
    require(checkout.replace(b"\r\n", b"\n") == blobs["direct"], "catalog checkout normalization changed")
    packet = root / "current-packet"
    spec = importlib.util.spec_from_file_location("final_review_verify", packet / "verify.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    try:
        module.validate_packet(packet, root / "inspected-sources")
    except module.PacketError:
        raise EvidenceError("current packet consistency refused") from None
    config = json.loads((packet / "configuration.proposed.json").read_bytes())
    control = config["productionControl"]
    require(control == {"routeMode": "V1Only", "T0": None, "activationAuthority": None,
                        "deploymentAuthorized": False, "publicationAuthorized": False,
                        "trackerTransitionAuthorized": False}, "unsafe operational outcome")
    checks = json.loads((packet / "staging-checks.json").read_bytes())["checks"]
    require(len(checks) == 14 and all(row["status"] == "unexecuted" and row["result"] is None
                                    and row["observedEvidence"] == [] for row in checks),
            "fabricated staging outcome")
    observation = config["catalogCoherenceObservation"]
    require(observation["currentCatalogGitNormalizedSha256"] == digest(blobs["direct"])
            and observation["acceptedToolCatalogGitNormalizedSha256"] == digest(blobs["accepted-tool"]),
            "proposal catalog comparison differs")
    print("PASS: retained member integrity and catalog comparisons; current packet consistency only; HOLD; 0 staging checks executed.")


def main():
    try:
        replay(Path(__file__).resolve().parent)
    except (EvidenceError, OSError, ValueError, TypeError, KeyError):
        print("FAIL: final-review retained evidence validation.", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
