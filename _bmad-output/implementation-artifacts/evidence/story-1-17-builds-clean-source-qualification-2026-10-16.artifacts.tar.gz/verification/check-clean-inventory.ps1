Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$buildsRoot = Join-Path $PSScriptRoot '../../references/Hexalith.Builds'
. (Join-Path $buildsRoot 'Tools/G4PackageQualification.functions.ps1')
$null = Assert-ReleaseEligibleInventory -InventoryPath (Join-Path $buildsRoot 'artifacts/story117-clean-committed-20261016/g4-tool-package-inventory.json') -Version '4.31.2'
[Console]::Out.WriteLine('The actual pre-tag technical inventory check passes for the clean diagnostic. Publication is not authorized; these diagnostic bytes must not be published under the existing 4.31.2 identity.')
