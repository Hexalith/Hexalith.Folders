Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$buildsRoot = Join-Path $PSScriptRoot '../../references/Hexalith.Builds'
. (Join-Path $buildsRoot 'Tools/G4PackageQualification.functions.ps1')
$inventory = Assert-ReleaseEligibleInventory -InventoryPath (Join-Path $buildsRoot 'artifacts/story117-clean-final-20261016/g4-tool-package-inventory.json') -Version '4.31.2'
$head = (& git -C $buildsRoot rev-parse HEAD).Trim()
if ($inventory.qualification.sourceTree.revision -cne $head -or -not $inventory.qualification.sourceTree.clean) { throw 'The current inventory does not bind the actual clean source head.' }
[Console]::Out.WriteLine("Current clean-source technical pre-tag inventory check passed at $head. Diagnostic-only; publication is not authorized.")
