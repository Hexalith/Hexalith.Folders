#!/usr/bin/env python3
from datetime import datetime, timezone
import gzip
import base64
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

case=Path(__file__).resolve().parent
workspace=case.parents[1]
builds=workspace/'references/Hexalith.Builds'
output=workspace/'_bmad-output/implementation-artifacts/evidence'
prefix='story-1-17-builds-clean-source-qualification-2026-10-16'
package=builds/'artifacts/story117-clean-final-20261016'
sha=lambda body:hashlib.sha256(body).hexdigest()
file_hash=lambda path:sha(path.read_bytes())
read=lambda path:json.loads(path.read_bytes())
write=lambda path,value:path.write_text(json.dumps(value,indent=2)+'\n')
source=read(case/'current-source-before.json')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=builds,text=True).strip()==source['head']
assert subprocess.check_output(['git','status','--porcelain'],cwd=builds,text=True)==''
ci_runs=read(case/'exact-head-ci-runs.log')
runs=[r for r in ci_runs['workflow_runs'] if r['head_sha']==source['head'] and r['head_branch']=='main' and r['event']=='push' and r['status']=='completed' and r['conclusion']=='success']
assert runs,'No successful exact-head push CI'
ci=max(runs,key=lambda r:r['id'])
assert read(case/'release-source-guard.command.json')['exitCode']==0
inventory=read(package/'g4-tool-package-inventory.json')
q=inventory['qualification']
assert q['sourceTree']=={'clean':True,'revision':source['head']}
assert q['releaseEligible'] is True and q['fixtures']['mode']=='repository-tracked'
command=read(case/'clean-g4-final.command.json');assert command['exitCode']==0
before=read(case/'before.json')
for name,expected in before['protectedWorkspaceFilesSha256'].items():assert file_hash(workspace/name)==expected,name

members={}
for path in package.rglob('*'):
    if path.is_file():members['diagnostic/'+path.relative_to(package).as_posix()]=path.read_bytes()
for path in case.iterdir():
    if path.is_file() and path.suffix in ['.json','.log','.message','.py','.txt','.ps1']:
        members['verification/'+path.name]=path.read_bytes()
for name in ['evidence/story-1-17-builds-package-qualification-2026-10-16.json','story-1-17-current-candidate-technical-readiness-2026-09-24.md','deferred-work.md']:
    path=workspace/'_bmad-output/implementation-artifacts'/name
    members['historical/'+path.name]=path.read_bytes()
for name,expected in before['protectedWorkspaceFilesSha256'].items():
    body=(workspace/name).read_bytes();assert sha(body)==expected,name
    members['protected/'+name]=body
historical_handoff=read(workspace/'_bmad-output/implementation-artifacts/evidence/story-1-17-builds-package-qualification-2026-10-16.json')
for name,expected in historical_handoff['updated_document_sha256'].items():
    body=(workspace/name).read_bytes()
    if name=='.gitattributes':
        marker=b'\n# Byte-bound committed Builds qualification receipt and portable artifacts.'
        body=body[:body.index(marker)]
    assert sha(body)==expected,name
    members['historical/workspace/'+name]=body
bundle_path=output/(prefix+'.artifacts.tar.gz')
with bundle_path.open('wb') as target:
    with gzip.GzipFile(fileobj=target,mode='wb',filename='',mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as archive:
            for name,body in sorted(members.items()):
                item=tarfile.TarInfo(name);item.size=len(body);item.mode=0o644;item.mtime=0
                archive.addfile(item,io.BytesIO(body))
bundle={'path':bundle_path.relative_to(workspace).as_posix(),'sha256':file_hash(bundle_path),'sizeBytes':bundle_path.stat().st_size,
        'membersSha256':{name:sha(body) for name,body in sorted(members.items())}}
manifest_path=output/(prefix+'.artifacts.manifest.json');write(manifest_path,bundle)
summaries=re.findall(r'Test run summary: Passed!\s+total: (\d+)\s+failed: (\d+)\s+succeeded: (\d+)\s+skipped: (\d+)',(case/'clean-g4-final.log').read_text())
assert len(summaries)==3,summaries
counts={name:dict(zip(['total','failed','passed','skipped'],map(int,row),strict=True)) for name,row in zip(['Evidence','Module','Integration'],summaries,strict=True)}
packages=[]
for row in inventory['packages']:
    for role in ['nupkg','snupkg']:
        item=row[role]
        packages.append({'file':item['file'],'sha256':item['sha256'].lower(),'sizeBytes':item['sizeBytes']})
proof=read(package/'qualification-evidence/packaged-seed-subscriptions.json')
ci_record={key:ci[key] for key in ['id','head_sha','head_branch','event','status','conclusion','html_url','run_attempt','created_at','updated_at']}
verifier=workspace/'eng/story117-builds-clean-source/verify.py'
readme=verifier.with_name('README.md')
record={'schema':'hexalith.story117.builds-clean-source-qualification.v1','recordedAtUtc':datetime.now(timezone.utc).isoformat(),
        'authorization':{'firstInstallPreparation':True,'readOnlyRemoteQueries':True,'gitReconciliation':True,'stagingCommitPush':True,'publication':False,'deployment':False,'productionActivation':False,'platformAcceptance':False},
        'source':{'buildsCommit':source['head'],'buildsTree':source['tree'],'reconciledUpstream':source['upstream'],'clean':True,
                  'catalogSha256':file_hash(builds/'Props/Directory.Packages.props'),'auditSha256':file_hash(builds/'Tools/package-version-audit.json'),
                  'note':'Upstream Dapr/security/startup work retained. Concurrent dependency update 03e3711039346ac6c76f8b2c900dcaca6cacb40f preserved without local catalog-selection edits. Synthetic acceptance pins and audit metadata follow that authority.'},
        'diagnosticOnly':True,'diagnosticVersion':'4.31.2','actualNextReleaseVersion':None,
        'completeQualification':command,'sourceTests':counts,'packages':packages,
        'inventorySha256':file_hash(package/'g4-tool-package-inventory.json'),'packagedSeedSha256':proof['seed']['sha256'].lower(),
        'qualificationEvidenceArtifacts':len(inventory['qualificationEvidence']),'qualification':q,
        'exactHeadPushCi':ci_record,'releaseSourceGuard':read(case/'release-source-guard.command.json'),'inventoryEligibilityGuard':read(case/'final-inventory-gate.command.json'),'retainedArtifactBundle':bundle,
        'verificationFilesSha256':{p.relative_to(workspace).as_posix():file_hash(p) for p in [verifier,readme,manifest_path]},
        'protectedWorkspaceFilesSha256':before['protectedWorkspaceFilesSha256'],
        'auditPreservation':read(case/'current-audit-preservation.json'),'preservation':read(case/'preservation.json'),
        'pushObservation':read(case/'push-observation-current.json'),
        'supersededTimedOutCi':{'source':'63dda8fc14882aba383888afd7e6505afab1f345','localQualificationPassed':True,'ciRun':38916036985,'ciConclusion':'cancelled','reason':'30-minute job maximum exceeded during package qualification; upstream 5aceb5ab0683b5e8c494e82f865e138685180f36 raises only that limit to 45 minutes; final local proof repeated at new SHA'},
        'supersededCleanRun':{'source':'bbd55d0cf5a281b58d2bbef3ef61dbaa9a54700b','catalogEventStoreVersion':'3.122.0','localQualificationPassed':True,'pushCi':'cancelled by concurrent upstream push 03e3711039346ac6c76f8b2c900dcaca6cacb40f; not reused for current inputs'},
        'observations':{'buildsMain':read(case/'builds-main-final.log'),'platformMain':read(case/'platform-main-end.log'),
                        'platformBuildsPin':read(case/'platform-builds-pin-end.log'),'publishedBuildsRelease':read(case/'latest-release-end.log'),
                        'eventStoreRelease':read(case/'eventstore-release-current.log'),
                        'eventStoreDeclarationSha256':sha(base64.b64decode(read(case/'eventstore-declaration-current.log')['content'])),
                        'registry':read(case/'registry-current-observations.json'),'imageAttestationVerified':False},
        'previousDiagnostic':{'path':'references/Hexalith.Builds/evidence/g4/story117-package-seed-20261016/qualification.json',
                              'sha256':file_hash(builds/'evidence/g4/story117-package-seed-20261016/qualification.json'),
                              'releaseEligible':False,'status':'historical dirty-source preparation; unchanged receipt and archives'},
        'decision':{'entry':'HOLD','fullLocalTechnicalQualificationPassed':True,'technicalInventoryReleaseEligible':True,'releaseAdmission':False,'stagingQualification':False,'storyClosure':False,
                    'productionMode':'V1Only','t0Utc':None,'storyTracker':'backlog','stagingChecksExecuted':0,'stagingChecksRemaining':14},
        'remainingBlocker':'Separate publication authorization, semantic-release selecting and requalifying the actual next version, and real Platform acceptance with exact tool pin/range, coherent gitlink and released owner declaration/attestation/intake prerequisites. Deployment and activation remain separately gated.',
        'nextCommands':{'verify':'python3 eng/story117-builds-clean-source/verify.py',
                        'publicationAfterSeparateAuthorization':'gh workflow run build-release.yml --repo Hexalith/Hexalith.Builds --ref main'},
        'limits':['Existing opt-in/checkout skips are not passing live or staging evidence.','Diagnostic 4.31.2 bytes must never replace or be published as the existing released 4.31.2.','Technical clean-source qualification and successful push CI are not publication or Platform acceptance.']}
receipt=output/(prefix+'.json');write(receipt,record)
print(json.dumps({'receipt':str(receipt),'sha256':file_hash(receipt),'bundleSha256':bundle['sha256'],'inventorySha256':record['inventorySha256'],'packages':packages,'sourceTests':counts},indent=2))
