#!/usr/bin/env python3
"""Exercise the current receipt verifier against altered integrity/CI/decision fields."""
import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile

workspace = Path(__file__).resolve().parents[2]
receipt = workspace / '_bmad-output/implementation-artifacts/evidence/story-1-17-builds-clean-source-qualification-2026-10-16.json'
original = json.loads(receipt.read_bytes())
verifier = workspace / 'eng/story117-builds-clean-source/verify.py'
cases = [
    ('archive-hash', ['retainedArtifactBundle', 'sha256'], '0' * 64, 'bundle hash'),
    ('ci-revision', ['exactHeadPushCi', 'head_sha'], '0' * 40, 'Evidence verification failed'),
    ('release-admission', ['decision', 'releaseAdmission'], True, 'releaseAdmission'),
]
with tempfile.TemporaryDirectory(prefix='story117-evidence-controls-') as directory:
    for name, fields, value, expected in cases:
        record = copy.deepcopy(original)
        target = record
        for field in fields[:-1]:
            target = target[field]
        target[fields[-1]] = value
        path = Path(directory) / (name + '.json')
        path.write_text(json.dumps(record))
        result = subprocess.run([sys.executable, str(verifier), '--workspace', str(workspace), '--receipt', str(path)], capture_output=True, text=True)
        assert result.returncode == 1, (name, result.returncode, result.stdout, result.stderr)
        assert expected in result.stderr, (name, result.stderr)
        print(f'{name}: expected refusal, exit 1')
print('All three altered-receipt controls refused as expected.')
