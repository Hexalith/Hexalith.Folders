import hashlib,json,os,subprocess,sys
from pathlib import Path
folder=Path(__file__).resolve().parent
workspace=Path(sys.argv[1]).resolve()
manifest=json.loads((folder/'members.json').read_bytes())
for name,row in manifest.items():
    candidate=folder/name
    assert candidate.is_file() and not candidate.is_symlink(),name
    body=candidate.read_bytes()
    assert len(body)==row['bytes'] and hashlib.sha256(body).hexdigest()==row['sha256'],name
os.chdir(workspace)
for command in (
    ['python3',str(folder/'audit-current.py'),str(folder/'conformance-first.yaml')],
    ['python3',str(folder/'audit-current.py'),str(folder/'conformance-second.yaml')],
    ['python3',str(folder/'preserve-current.py')],
):
    subprocess.run(command,check=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
print('PASS: portable member hashes and immutable-baseline candidate/preservation replay.')
