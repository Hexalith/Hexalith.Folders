import json,subprocess,sys
from pathlib import Path
probe=Path('src/Hexalith.Folders.Server/UnexpectedStory117ReadinessProbe.cs')
assert not probe.exists()
try:
    probe.write_bytes(b'// Disposable inventory-refusal probe; never compiled.\n')
    result=subprocess.run([sys.executable,str(Path(__file__).with_name('preserve-current.py'))],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (Path(__file__).parent/'unexpected-source-refusal.raw.log').write_bytes(result.stdout)
    assert result.returncode!=0 and b'path inventory changed' in result.stdout and str(probe).encode() in result.stdout
    print(json.dumps({'status':'PASS','unexpectedPath':str(probe),'preservationExitCode':result.returncode,'rejection':'path inventory changed','probeWasCompiled':False}))
finally:
    probe.unlink(missing_ok=True)
assert not probe.exists()
print('PASS: disposable source probe removed; original source bytes unchanged.')
