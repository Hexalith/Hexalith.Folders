import hashlib,json,subprocess
from pathlib import Path
folder=Path(__file__).parent
base=json.loads((folder/'baseline.json').read_bytes())
e=json.loads(Path('_bmad-output/implementation-artifacts/evidence/story-1-17-post-12-1-readiness-2026-10-18.json').read_bytes())
revision=e['implementationBaseline']; assert revision==base['repositories']['Folders']['revision']
def oid(body): return hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()
rows=[]
for row in e['beforeAfterSha256']:
 path=row['path']; raw=Path(path).read_bytes(); normalized=raw.replace(b'\r\n',b'\n')
 command=['git','hash-object','--path='+path,path]
 result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
 observed=result.stdout.decode().strip(); assert observed==oid(normalized),path
 before=subprocess.check_output(['git','show',revision+':'+path])
 before_oid=subprocess.check_output(['git','rev-parse',revision+':'+path],text=True).strip()
 assert before_oid==oid(before),path
 rows.append({'path':path,'capturedWorktreeBeforeSha256':base['files'][path],'capturedWorktreeAfterSha256':hashlib.sha256(raw).hexdigest(),'gitNormalizedBeforeSha256':hashlib.sha256(before).hexdigest(),'gitNormalizedAfterSha256':hashlib.sha256(normalized).hexdigest(),'beforeGitBlobObjectId':before_oid,'afterGitBlobObjectId':observed,'normalization':'CRLF-to-LF only; verified against read-only Git clean-filter output','readOnlyGitCommand':command,'gitCommandExitCode':result.returncode,'gitCommandStdout':result.stdout.decode(),'gitCommandStderr':result.stderr.decode()})
(folder/'normalized-identities.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'status':'PASS','implementationBaseline':revision,'identities':rows},indent=2))
