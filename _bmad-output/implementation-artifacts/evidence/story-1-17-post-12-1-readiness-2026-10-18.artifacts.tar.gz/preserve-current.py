import hashlib,json,subprocess
from pathlib import Path
folder=Path(__file__).parent
base=json.loads((folder/'baseline.json').read_bytes())
receipt=json.loads(Path('_bmad-output/implementation-artifacts/evidence/story-1-17-post-12-1-readiness-2026-10-18.json').read_bytes())
revision=receipt['implementationBaseline']; assert revision==base['repositories']['Folders']['revision'] and len(revision)==40
allowed={
 'eng/story117-platform-qualification-current/configuration.proposed.json',
 'eng/story117-platform-qualification-current/staging-checks.json',
 'eng/story117-platform-qualification-current/verify.py',
 'eng/story117-platform-qualification-current/test_verify.py',
 'eng/story117-platform-qualification-current/README.md',
 '_bmad-output/planning-artifacts/generated-v2-conformance-set-2026-09-17.yaml',
 '_bmad-output/planning-artifacts/planning-story-manifest.yaml',
 '_bmad-output/implementation-artifacts/story-1-17-current-candidate-technical-readiness-2026-09-24.md',
}
def sha(body): return hashlib.sha256(body).hexdigest()
def mapping_sha(value): return sha(json.dumps(value,sort_keys=True,separators=(',',':')).encode())
approved_new={
 '_bmad-output/implementation-artifacts/spec-1-17-reconcile-post-12-1-readiness.md',
 '_bmad-output/implementation-artifacts/evidence/story-1-17-post-12-1-readiness-2026-10-18.json',
 '_bmad-output/implementation-artifacts/evidence/story-1-17-post-12-1-readiness-2026-10-18.artifacts.tar.gz',
 '_bmad-output/implementation-artifacts/evidence/story-1-17-post-12-1-readiness-2026-10-18.artifacts.manifest.json',
}
gitlink_names={line.split('\t',1)[1] for line in base['rootGitlinks'].splitlines()}
initial_names=set(base['files'])|gitlink_names
final_names=set(subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z']).decode().rstrip('\0').split('\0'))
assert final_names==initial_names|approved_new, 'path inventory changed: '+repr(sorted(final_names ^ (initial_names|approved_new)))
for relative in set(base['files'])|approved_new:
 candidate=Path(relative)
 assert candidate.is_file() and not candidate.is_symlink(), 'regular unredirected file required: '+relative

after={p:sha(Path(p).read_bytes()) for p in base['files']}
for binding in receipt['beforeAfterSha256']:
 assert binding['hashRepresentation'].startswith('captured-worktree'), binding['path']
 assert after[binding['path']]==binding['afterSha256'], 'current reviewed bytes changed: '+binding['path']

changed={p for p in after if after[p]!=base['files'][p]}
assert changed==allowed,sorted(changed ^ allowed)
unchanged_before={p:h for p,h in base['files'].items() if p not in allowed}
unchanged_after={p:after[p] for p in unchanged_before}
assert unchanged_before==unchanged_after
readiness='_bmad-output/implementation-artifacts/story-1-17-current-candidate-technical-readiness-2026-09-24.md'
original_prefix=Path(readiness).read_bytes().rsplit(b'\r\n\r\n## Addendum 2026-10-18: post-12.1 local readiness reconciled;',1)[0]
assert sha(original_prefix)==base['files'][readiness]
assert original_prefix==(folder/'captured-readiness-baseline.md').read_bytes()
spec=Path('_bmad-output/implementation-artifacts/spec-1-17-reconcile-post-12-1-readiness.md').read_text()
frozen=spec[spec.index('<frozen-after-approval'):spec.index('</frozen-after-approval>')+len('</frozen-after-approval>')]
assert sha(frozen.encode())==base['specFrozenSha256']
assert subprocess.check_output(['git','ls-tree',revision,'references/'],text=True)==base['rootGitlinks']
assert subprocess.check_output(['git','diff',revision,'--raw','--','references/'],text=True)==''
assert subprocess.check_output(['git','-C','references/Hexalith.Platform','ls-tree',base['repositories']['Platform']['revision'],'references/Hexalith.Builds'],text=True)==base['platformBuildsGitlink']
for name,path in [('Folders','.'),('Projects','references/Hexalith.Projects'),('Platform','references/Hexalith.Platform'),('EventStore','references/Hexalith.EventStore'),('Builds','references/Hexalith.Builds')]:
 if name!='Folders':
  assert subprocess.check_output(['git','-C',path,'rev-parse','HEAD'],text=True).strip()==base['repositories'][name]['revision']
  assert subprocess.check_output(['git','-C',path,'status','--porcelain'],text=True)==base['repositories'][name]['status']==''
dependency_revisions={}
for line in base['rootGitlinks'].splitlines():
 identity, relative=line.split('\t',1); dependency_revision=identity.rsplit(' ',1)[1]
 assert subprocess.check_output(['git','-C',relative,'rev-parse','HEAD'],text=True).strip()==dependency_revision, relative
 assert subprocess.check_output(['git','-C',relative,'status','--porcelain'],text=True)=='', relative
 dependency_revisions[relative]=dependency_revision

receipt_path='_bmad-output/implementation-artifacts/evidence/story-1-17-builds-publication-2026-10-16.json'
protected=json.loads(Path(receipt_path).read_bytes())['protectedWorkspaceFilesSha256']
current_run_before={p:base['files'].get(p,h) for p,h in protected.items()}
current_run_after={p:sha(Path(p).read_bytes()) for p in protected}
task_changes={p:{'beforeSha256':current_run_before[p],'afterSha256':h} for p,h in current_run_after.items() if h!=current_run_before[p]}
assert set(task_changes)=={p for p in allowed if p.startswith('_bmad-output/planning-artifacts/')}
prior_drift={p:{'receiptSha256':h,'taskBaselineSha256':current_run_before[p]} for p,h in protected.items() if h!=current_run_before[p]}
assert set(prior_drift)=={'_bmad-output/implementation-artifacts/sprint-status.yaml'}
critical={p:h for p,h in unchanged_before.items() if p.startswith('_bmad-output/implementation-artifacts/evidence/') or p in (
 '_bmad-output/implementation-artifacts/sprint-status.yaml',
 '_bmad-output/implementation-artifacts/spec-1-17-complete-pd10-v2-migration-and-closure.md',
 '_bmad-output/implementation-artifacts/spec-1-17-publish-the-pd10-v2-authorization-contract-spine.md',
 'src/Hexalith.Folders.Contracts/openapi/hexalith.folders.v1.yaml','.gitmodules')}
tracker=Path('_bmad-output/implementation-artifacts/sprint-status.yaml').read_text()
assert '1-17-publish-the-pd10-v2-authorization-contract-spine: backlog' in tracker
c=json.loads(Path('eng/story117-platform-qualification-current/configuration.proposed.json').read_bytes()); s=json.loads(Path('eng/story117-platform-qualification-current/staging-checks.json').read_bytes())
oldc=json.loads(subprocess.check_output(['git','show',revision+':eng/story117-platform-qualification-current/configuration.proposed.json'])); olds=json.loads(subprocess.check_output(['git','show',revision+':eng/story117-platform-qualification-current/staging-checks.json']))
for key in ('productionControl','installationProposal','acceptedEnvelope','releaseIdentity','publishedBuildsObservation','dependencies','secretReferences'):
 assert c[key]==oldc[key],key
assert c['qualification']=='HOLD' and s['qualification']=='HOLD'
assert len(s['checks'])==14
for old,new in zip(olds['checks'],s['checks']):
 for key in ('id','order','owner','maxDurationSeconds','status','result','observedEvidence','startedAt','completedAt'): assert old[key]==new[key],key
result={'status':'PASS','implementationBaseline':revision,'pathInventory':{'baselineTrackedAndGitlinkCount':len(initial_names),'observedInitialNameCount':len(initial_names|{line[3:] for line in base['repositories']['Folders']['status'].splitlines() if line.startswith('?? ')}),'finalCount':len(final_names),'approvedNewPaths':sorted(approved_new),'trackedAndUntrackedNamesChecked':True},'trackedBaselineFileCount':len(base['files']),'authorizedChangedTrackedFileCount':len(changed),'unchangedTrackedFileCount':len(unchanged_before),'beforeUnchangedMapSha256':mapping_sha(unchanged_before),'afterUnchangedMapSha256':mapping_sha(unchanged_after),'criticalBeforeAndAfterSha256':critical,'rootGitlinksUnchanged':True,'explicitDependencyRevisions':dependency_revisions,'platformBuildsGitlinkUnchanged':True,'referenceRepositoryHeadsAndWorkingTreesUnchanged':True,'frozenApprovedSpecBlockSha256':base['specFrozenSha256'],'originalReadinessBytesPreservedAsPrefix':True,'originalMigrationIntentBaselineAndSevenDayLimitPreserved':True,'productionControlInstallationEnvelopeReleasesSecretsAndDependenciesUnchanged':True,'stagingCheckLifecycleOwnersOrderAndDurationsUnchanged':True,'trackerStatus':'backlog','trackerTransition':False,'historicalPublicationProtectedPaths':{'count':len(protected),'taskBaselineUnchangedCount':len(protected)-len(task_changes),'historicalReceiptEqualCount':sum(current_run_after[p]==h for p,h in protected.items()),'preexistingMismatch':prior_drift,'authorizedCurrentEvidenceChanges':task_changes,'historicalReceiptSha256':sha(Path(receipt_path).read_bytes())}}
(folder/'preservation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='criticalBeforeAndAfterSha256'},indent=2))
