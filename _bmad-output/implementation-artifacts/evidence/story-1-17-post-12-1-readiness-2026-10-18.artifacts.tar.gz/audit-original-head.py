import hashlib,json,re,subprocess,sys
from pathlib import Path

def digest(body):
    return hashlib.sha256(body).hexdigest()

def inventory(body):
    text=body.decode('utf-8')
    matches=re.findall(r'^  - path: (.+)\n    kind: file\n    bytes: (\d+)\n    sha256: ([0-9a-f]{64})$',text,re.M)
    assert len(matches)==int(re.search(r'^artifact_count: (\d+)$',text,re.M)[1])
    return [(json.loads(path),int(size),sha) for path,size,sha in matches]

path=Path(sys.argv[1]); body=path.read_bytes(); rows=inventory(body)
canonical=Path('_bmad-output/planning-artifacts/generated-v2-conformance-set-2026-09-17.yaml')
old_body=subprocess.check_output(['git','show','HEAD:'+canonical.as_posix()]); old_rows=inventory(old_body)
allowlist=Path('scripts/pd10-v2-story-owned-paths.txt').read_text().splitlines()
assert [r[0] for r in rows]==[r[0] for r in old_rows]==allowlist==sorted(set(allowlist))
assert len(rows)==229
for relative,size,sha in rows:
    source=Path(relative); assert source.is_file() and not source.is_symlink(),relative
    actual=source.read_bytes(); assert len(actual)==size and digest(actual)==sha,relative
assert digest(body)==digest(canonical.read_bytes())
material=''.join(relative+'\0'+sha+'\n' for relative,_,sha in rows).encode()
set_digest=digest(material); assert re.search(rb'^candidate_set_sha256: ([0-9a-f]{64})$',body,re.M)[1].decode()==set_digest
# Every non-inventory lifecycle/baseline/v1/approval field is independently preserved.
def header_without_digest(value):
    return re.sub(rb'^candidate_set_sha256: [0-9a-f]{64}\n',b'',value.split(b'artifacts:\n',1)[0],flags=re.M)
assert header_without_digest(body)==header_without_digest(old_body)
v1='src/Hexalith.Folders.Contracts/openapi/hexalith.folders.v1.yaml'
assert re.search(rb'^historical_v1_sha256: ([0-9a-f]{64})$',body,re.M)[1].decode()==digest(Path(v1).read_bytes())
manifest_path='_bmad-output/planning-artifacts/planning-story-manifest.yaml'
manifest=Path(manifest_path).read_bytes(); before=subprocess.check_output(['git','show','HEAD:'+manifest_path])
assert manifest==before.replace(('\n- path: '+canonical.as_posix()+'\n  sha256: '+digest(old_body)+'\n').encode(),('\n- path: '+canonical.as_posix()+'\n  sha256: '+digest(body)+'\n').encode(),1)
provenance=manifest.split(b'\nprovenance:\n',1)[1].split(b'\npost_a8_finalization:',1)[0].decode()
bindings=re.findall(r'^- path: (.+)\n  sha256: ([0-9a-f]{64})$',provenance,re.M)
assert len(bindings)==20
for relative,sha in bindings:
    assert digest(Path(relative).read_bytes())==sha,relative
changes=[{'path':old[0],'beforeBytes':old[1],'afterBytes':new[1],'beforeSha256':old[2],'afterSha256':new[2]} for old,new in zip(old_rows,rows) if old!=new]
assert len(changes)==3
print(json.dumps({'status':'PASS','artifactCount':len(rows),'candidateSetSha256':set_digest,'conformanceSha256':digest(body),'provenanceBindingsMatched':len(bindings),'inventoryScopePreserved':True,'lifecycleAndHistoricalBindingsPreserved':True,'manifestOnlyCurrentProvenanceChanged':True,'changedCandidateRows':changes},indent=2))
