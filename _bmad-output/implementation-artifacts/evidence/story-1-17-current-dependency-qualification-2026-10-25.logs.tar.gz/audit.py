"""Independently verify retained Story 1.17 source/control and current inventory bytes."""
from pathlib import Path
import hashlib,json,tarfile,subprocess,datetime,yaml
import sys
root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path.cwd(); scratch=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prior=json.loads((root/'_bmad-output/implementation-artifacts/evidence/story-1-17-context-observation-review-final-2026-10-25.json').read_text())
archive=prior['archive']; assert sha(root/archive['path'])==archive['sha256']
with tarfile.open(root/archive['path']) as bundle:
 for name,digest in archive['members'].items(): assert hashlib.sha256(bundle.extractfile(name).read()).hexdigest()==digest,name
preservation=json.loads((scratch/'prior-preservation.json').read_text())
for p,h in preservation['protected_hashes'].items(): assert sha(root/p)==h,p
planning=yaml.safe_load((root/'_bmad-output/planning-artifacts/planning-story-manifest.yaml').read_text())['provenance']; assert len(planning)==20
for row in planning: assert sha(root/row['path'])==row['sha256'],row['path']
manifest=root/'_bmad-output/implementation-artifacts/evidence/story-12-2-v2-source-requalification-pending.yaml'; data=yaml.safe_load(manifest.read_text()); rows=data['artifacts']
assert len(rows)==data['artifact_count']==1425
for row in rows:
 p=root/row['path']; assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],row['path']
assert sha(manifest)==sha(scratch/'candidate-one.yaml')==sha(scratch/'candidate-two.yaml')
assert hashlib.sha256(''.join(f'{r["path"]}\0{r["sha256"]}\n' for r in rows).encode()).hexdigest()==data['candidate_set_sha256']
for name, original in json.loads((scratch/'initial-document-prefixes.json').read_text()).items():
 current=(root/'_bmad-output/implementation-artifacts'/name).read_bytes()[:original['bytes']]
 assert hashlib.sha256(current).hexdigest()==original['sha256'],name
index=Path(subprocess.check_output(['git','rev-parse','--git-path','index'],cwd=root).decode().strip()); index=index if index.is_absolute() else root/index
index_bytes_unchanged=sha(index)==(scratch/'initial-index.sha256').read_text()
staged_content_unchanged=subprocess.run(['git','diff','--cached','--exit-code','--quiet'],cwd=root).returncode==0; assert staged_content_unchanged
before=json.loads((scratch/'binary-identities-before.json').read_text()); binaries={p:{'sha256':sha(root/p),'bytes':(root/p).stat().st_size} for p in before['files']}; assert binaries==before['files']
memories=root/'references/Hexalith.Memories'; changes=subprocess.check_output(['git','diff','--name-only'],cwd=memories).decode().splitlines()
assert set(changes)=={'src/Hexalith.Memories.Server/Hexalith.Memories.Server.csproj','src/Hexalith.Memories.EventStore/Hexalith.Memories.EventStore.csproj'},changes
result={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_rows':len(rows),'candidate_raw_sha256':sha(manifest),'candidate_set_sha256':data['candidate_set_sha256'],'protected_inputs':len(preservation['protected_hashes']),'planning_bindings':len(planning),'prior_archive_members':len(archive['members']),'original_spec_and_readiness_prefix_preserved':True,'index_bytes_unchanged':index_bytes_unchanged,'staged_content_unchanged':staged_content_unchanged,'test_binary_identities_unchanged_during_release_checks':True,'test_binary_files':binaries,'memories_working_tree_files':{p:sha(memories/p) for p in changes},'memories_base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=memories).decode().strip(),'folders_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()}
(scratch/'preservation-final.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps({k:v for k,v in result.items() if k not in ['test_binary_files','memories_working_tree_files']},indent=2))
