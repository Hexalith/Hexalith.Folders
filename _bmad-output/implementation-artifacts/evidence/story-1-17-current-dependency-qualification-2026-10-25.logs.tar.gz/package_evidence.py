from pathlib import Path
import json,hashlib,subprocess,tarfile,datetime
root=Path('/home/administrator/projects/hexalith/folders'); scratch=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
subprocess.run(['python3',str(scratch/'audit.py'),str(root)],check=True)
(scratch/'folders-working-tree.diff').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=root))
checks=[]
for p in scratch.glob('*.json'):
 data=json.loads(p.read_text())
 if isinstance(data,dict) and all(k in data for k in ['id','command','started_utc','finished_utc','exit','log']):
  assert sha(scratch/data['log'])==data['sha256'],data['id']
  if 'xml' in data: assert sha(scratch/data['xml'])==data['xml_sha256'],data['id']
  checks.append(data)
checks.sort(key=lambda c:c['started_utc'])
(scratch/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
include={p.name for p in scratch.glob('*.log')}|{p.name for p in scratch.glob('*.xml')}|{p.name for p in scratch.glob('*.json') if p.name!='initial-tracked-hashes.json'}|{'candidate-one.yaml','candidate-two.yaml','audit.py','run.py','package_evidence.py','initial-index.sha256','memories-working-tree.diff','folders-working-tree.diff'}
directory=root/'_bmad-output/implementation-artifacts/evidence'; archive_relative=Path('_bmad-output/implementation-artifacts/evidence/story-1-17-current-dependency-qualification-2026-10-25.logs.tar.gz'); archive=root/archive_relative
with tarfile.open(archive,'w:gz') as bundle:
 for name in sorted(include): bundle.add(scratch/name,arcname=name,recursive=False)
members={name:sha(scratch/name) for name in sorted(include)}
prior=directory/'story-1-17-context-observation-review-final-2026-10-25.json'
initial=json.loads((scratch/'initial-audit.json').read_text()); candidate=json.loads((scratch/'candidate-audit.json').read_text()); preservation=json.loads((scratch/'preservation-final.json').read_text()); graph=json.loads((scratch/'memories-graph-audit.json').read_text()); delta=json.loads((scratch/'memories-delta.json').read_text()); identities=json.loads((scratch/'memories-runtime-identities.json').read_text()); packages=json.loads((scratch/'projects-package-identity.json').read_text()); states=json.loads((scratch/'aspire-final-state-before-diagnostic.log').read_text())
parity=json.loads((scratch/'parity-report.json').read_text()); assert parity['status']=='passed' and len(parity['categories'])==12
record={
'record_id':'story-1-17-current-dependency-qualification-2026-10-25',
'recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
'scope':'Local Story 1.17 qualification, including the permitted Memories source-reference prerequisite. Broader rollout/closure remains incomplete.',
'source':{'commit':preservation['folders_head'],'initial_observed_commit':subprocess.check_output(['git','rev-parse','c048d8c4'],cwd=root).decode().strip(),'concurrent_head_advance':'befe1039 was observed before the recorded source/package checks; no Git mutation was performed by this implementation agent.','original_baseline':'37d348945b35620da6ba4e524a09bee202712460','root_gitlinks':initial['root_gitlinks'],'memories_working_tree':delta},
'prior_receipt':{'path':str(prior.relative_to(root)),'sha256':sha(prior)},
'checks':checks,
'memories':{'evaluated_graphs':graph,'constants':{'Debug_source':'TRACE;HEXALITH_EVENTSTORE_MULTI_DOMAIN_WORKLOAD;DEBUG','Release_package':'TRACE;RELEASE'},'runtime_identities':identities,'explanation':'The original Debug source-mode flag enabled source-only APIs while the runtime still selected Client/DomainService 3.127.0 packages. The repaired source branch selects root projects; the preserved Release branch uses existing packages and does not enable the source-only constant.','build_scope':'Both Server.Tests project builds compile the actual Server runtime and EventStore wrapper; focused execution is only MemoriesGatewayCompositionTests (Debug 8/8, Release 6/6), not the entire Memories test suite.'},
'candidate':candidate,
'projects_released_pair':packages,
'verification_summary':{'folders_default_audited_release_build':'passed; zero warnings/errors','projects_default_audited_release_build':'passed; zero warnings/errors; existing AppHost runtime prebuilds remain Debug resources, separate from Release consumer-library qualification','source_production':{'passed':20,'total':20},'release_server_callbacks':{'passed':81,'total':81},'authorization_routing':{'passed':71,'total':71},'focused_contracts':{'passed':63,'total':63},'projects_adapters_registration':{'passed':85,'total':85},'contract_parity':{'passed_categories':12,'total_categories':12},'governance':[{'passed':23,'total':23},{'passed':7,'total':7},{'passed':3,'total':3}]},
'startup':{'serialized_explicit_source_build':'passed; zero warnings/errors','normal_start':'exit2; occupied local port22385; unrelated AppHosts left untouched','earlier_partial_readiness':'Before repair, Folders/UI/workers/EventStore/Tenants/security were healthy, but the Memories executable was absent.','repaired_memories':'Running/Healthy in subsequent isolated attempts; original missing executable and CS0246 superseded.','interrupted_attempt':'aspire-fixed-folders-readiness was stopped before its pending wait completed and exited18; not treated as a product failure or full readiness evidence.','final_attempt':{'start_exit':0,'folders_wait_seconds':50,'folders_wait_exit':17,'state':states,'security_logs':'No logs found.','doctor':{'passed':6,'warnings':5,'failed':0},'exact_target_stop_exit':0,'describe_confirms_stopped':True},'qualification':'Full topology readiness remains unverified. Historical default-profile CS1704/MSB4166 are not fresh observations from these commands.'},
'preservation':preservation,
'index_note':'Raw index bytes differ from the initial observation; staged content still equals unchanged HEAD. Status/diff can refresh index metadata. No staging or index-restoration command was run.',
'operational_control':{'route_mode':'V1Only','T0':None,'activation_authority':None,'tracker':'backlog','spec_status':'in-progress','original_tasks_preserved':True,'production_exposed':False,'publication_deployment_observation_recovery_retirement_closure_performed':False},
'remaining':['Full local topology readiness after the bounded security/storage Unknown state and Folders timeout.','Source-identity qualification packet remains HOLD on changed FoldersServerHostComposition.cs binding.','Exact current-candidate publication and immutable hosted Folders/Projects/Platform artifacts.','Attempt-bound target/consumer and retained-data disposition; hosted identity/delegation, staging, measured observation/recovery.','Unverified production namespace-read latency concern already retained in deferred-work.md.','Applicable migration retirement gates and authorized closure/tracker decision.'],
'sanitization':json.loads((scratch/'sanitization.json').read_text()),
'archive':{'path':str(archive_relative),'sha256':sha(archive),'members':members}}
path=directory/'story-1-17-current-dependency-qualification-2026-10-25.json';path.write_text(json.dumps(record,indent=2)+'\n')
with tarfile.open(archive) as bundle:
 assert set(bundle.getnames())==set(members)
 for name,h in members.items(): assert hashlib.sha256(bundle.extractfile(name).read()).hexdigest()==h,name
print(json.dumps({'receipt':str(path),'receipt_sha256':sha(path),'archive':str(archive),'archive_sha256':sha(archive),'checks':len(checks),'archive_members':len(members)},indent=2))
