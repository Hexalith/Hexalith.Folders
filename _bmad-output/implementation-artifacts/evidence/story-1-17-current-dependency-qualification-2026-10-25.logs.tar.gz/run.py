import subprocess,sys,json,hashlib,re,datetime
from pathlib import Path
scratch=Path(__file__).parent
identifier=sys.argv[1]; command=sys.argv[2:]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
p=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
output=p.stdout.decode(errors='replace'); output=re.sub(r'\x1b\[[0-9;]*m','',output)
output=re.sub(r'([?&](?:t|token|access_token|api_key)=)[^&#\s]+',r'\1[REDACTED]',output,flags=re.I)
if 'describe' in command:
 try:
  data=json.loads(output)
  output=json.dumps({'resources':[{k:r[k] for k in ['name','displayName','resourceType','state','healthStatus','waitingFor'] if k in r} for r in data['resources']]},indent=2)+'\n'
 except (ValueError,KeyError):
  pass
log=scratch/(identifier+'.log'); log.write_text(output)
record={'id':identifier,'command':command,'cwd':str(Path.cwd()),'started_utc':started,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode,'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
if '-xml' in command:
 import xml.etree.ElementTree as ET
 xml=Path(command[command.index('-xml')+1])
 if xml.exists():
  node=ET.parse(xml).getroot().find('assembly')
  record['counts']={key:int(node.attrib.get(key,0)) for key in ['total','passed','failed','skipped','errors']}
  record['xml']=xml.name; record['xml_sha256']=hashlib.sha256(xml.read_bytes()).hexdigest()
(scratch/(identifier+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record)); print(output[-3500:])
sys.exit(p.returncode)
