from story117_current_capture import *
cli='/home/administrator/.nuget/packages/hexalith.builds.module.cli/4.35.2/tools/net10.0/any/Hexalith.Builds.Module.Cli.dll'
results={}
for name in ['Folders','Projects','EventStore','Tenants','Memories']:
 root=W if name=='Folders' else W/'references'/('Hexalith.'+name);results[name]={}
 for mode in ['declaration','adoption']:
  args=['dotnet',cli,'validate','--manifest','module/hexalith.module-manifest.v2.json']+(['--adoption'] if mode=='adoption' else [])+['--output','json']
  results[name][mode]=run('intake-'+name.lower()+'-'+mode,args,root)
  print(name,mode,results[name][mode]['exitCode'],flush=True)
write('intake.json',results)
