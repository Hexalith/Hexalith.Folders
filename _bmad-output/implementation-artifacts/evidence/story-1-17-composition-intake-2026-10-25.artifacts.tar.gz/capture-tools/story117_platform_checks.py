from story117_current_capture import *
import sys,xml.etree.ElementTree as ET
config=sys.argv[1]; platform=W/'references/Hexalith.Platform';base=platform/'tests/Hexalith.Platform.Composition.Tests/bin'/config/'net10.0';mirror=C/'mirrors'/config;mirror.mkdir(exist_ok=True)
for n in ['apphost.cs','eng/helm-qualification/chart/reference-graph.json']:
 t=mirror/n;t.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(platform/n,t)
exports=json.loads((C/'exports.json').read_text())
# Manifest test-entry existence is validated, never executed by these graph checks.
e=exports['Memories'];rel='tools/verify-access-telemetry-lifecycle.py';b=git(pathlib.Path(e['repository']),'show',e['platformPin']+':'+rel);t=C/'exports/Hexalith.Memories'/rel;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(b)
write('provenance/memories-entry.json',{'owner':e['owner'],'revision':e['platformPin'],'path':rel,'blob':git(pathlib.Path(e['repository']),'rev-parse',e['platformPin']+':'+rel).decode().strip(),'sha256':sha(b),'executed':False})
shutil.copytree(C/'exports',mirror/'references',dirs_exist_ok=True)
shutil.copytree(base,mirror/'bin',dirs_exist_ok=True)
records={}
for f in base.rglob('*'):
 if f.is_file():records[str(f.relative_to(base))]={'sha256':sha(f.read_bytes()),'bytes':f.stat().st_size}
write('binaries/'+config+'-runtime.json',records)
for name in ['Hexalith.Builds.Tooling','Hexalith.Platform.Composition','Hexalith.Platform.Composition.Tests','Hexalith.Platform.Custody']:
 for suffix in ['.dll','.pdb']:
  t=C/'binaries'/config/(name+suffix);t.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(base/(name+suffix),t)
results={};method='Hexalith.Platform.Composition.Tests.PlatformHostedPublishingTests.HostedGraphDoesNotReadTheLocalProfileAndMatchesTheMaintainedChartInput'
for label,assembly,cwd in [('ordinary',base/'Hexalith.Platform.Composition.Tests.dll',platform),('supplied',mirror/'bin/Hexalith.Platform.Composition.Tests.dll',mirror)]:
 args=['dotnet',str(assembly),'-method',method,'-xml',str(C/(config.lower()+'-'+label+'-graph.xml'))];results[label]=run('platform-'+config.lower()+'-'+label+'-graph',args,cwd)
args=['dotnet',str(base/'Hexalith.Platform.Composition.Tests.dll'),'-class','Hexalith.Platform.Composition.Tests.AgentsAcceptedDeploymentContextTests','-class','Hexalith.Platform.Composition.Tests.PlatformOwnerServicesTests','-method','Hexalith.Platform.Composition.Tests.PlatformHostedPublishingTests.HostedEntryRefusesRunModeBeforeGeneratingLocalResourcesOrSecrets','-xml',str(C/(config.lower()+'-safe-tests.xml'))];results['safe']=run('platform-'+config.lower()+'-safe-tests',args,platform)
for n,d in records.items():
 if sha((base/n).read_bytes())!=d['sha256'] or sha((mirror/'bin'/n).read_bytes())!=d['sha256']:raise RuntimeError('Runtime drift '+n)
results['runtimeUnchanged']=True;results['sourceToolingMatchesLoaded']=all(sha((base/('Hexalith.Builds.Tooling'+s)).read_bytes())==sha((W/'references/Hexalith.Builds/src/libraries/Hexalith.Builds.Tooling/bin'/config/'net10.0'/('Hexalith.Builds.Tooling'+s)).read_bytes()) for s in ['.dll','.pdb'])
write('platform-'+config.lower()+'-checks.json',results);print(json.dumps(results,indent=2))
