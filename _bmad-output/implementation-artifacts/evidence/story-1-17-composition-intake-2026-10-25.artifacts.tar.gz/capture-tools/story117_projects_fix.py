from story117_current_capture import *
import xml.etree.ElementTree as ET
root=W/'references/Hexalith.Projects';p=root/'src/Hexalith.Projects.Client/Hexalith.Projects.Client.csproj';before=p.read_bytes();(C/'sources/projects-client.before.csproj').write_bytes(before)
results={}
for stage in ['before','after']:
 if stage=='after':
  if p.read_bytes()!=before:raise RuntimeError('Concurrent Projects edit')
  if before.count(b'HexalithProjectsRepositoryRoot')!=3:raise RuntimeError('Unexpected replacement scope')
  p.write_bytes(before.replace(b'HexalithProjectsRepositoryRoot',b'ProjectsRepositoryDirectory'));(C/'sources/projects-client.after.csproj').write_bytes(p.read_bytes())
 prop='HexalithProjectsRepositoryRoot' if stage=='before' else 'ProjectsRepositoryDirectory'
 command=ET.fromstring(p.read_bytes()).find("Target[@Name='GenerateHexalithProjectsIdempotencyHelpers']/Exec").attrib['Command']
 targets=ET.Element('Project');t=ET.SubElement(targets,'Target',Name='CaptureProjectsGeneratorEquivalence');g=ET.SubElement(t,'PropertyGroup');ET.SubElement(g,'CapturedGeneratorCommand').text=command
 path=C/'sources'/('projects-generator-'+stage+'.targets');ET.ElementTree(targets).write(path,encoding='utf-8',xml_declaration=True)
 results[stage]={}
 for config,mode in [('Debug','true'),('Release','false')]:
  args=['dotnet','msbuild',str(p),'-nologo','-t:CaptureProjectsGeneratorEquivalence','-p:Configuration='+config,'-p:UseHexalithProjectReferences='+mode,'-p:CustomAfterMicrosoftCommonTargets='+str(path),'-getProperty:'+prop+',CapturedGeneratorCommand,HexalithProjectsHelperGeneratorProject,HexalithProjectsContractSpine,HexalithProjectsGeneratedHelpers,HexalithProjectsDotnetHostPath']
  r=run('projects-properties-'+stage+'-'+config.lower(),args,root)
  if r['exitCode']!=0:raise RuntimeError(r)
  d=json.loads((C/r['log']).read_text())['Properties'];results[stage][config]={'command':r,'properties':d}
for config in ['Debug','Release']:
 b=results['before'][config]['properties'];a=results['after'][config]['properties'];b['ProjectsRepositoryDirectory']=b.pop('HexalithProjectsRepositoryRoot')
 if b!=a:raise RuntimeError('Property/argument mismatch '+config)
write('projects-property-equivalence.json',{'results':results,'beforeSha256':sha(before),'afterSha256':sha(p.read_bytes()),'onlyChange':'Rename local reserved HexalithProjectsRepositoryRoot to ProjectsRepositoryDirectory in definition and generator use.','allEvaluatedValuesAndGeneratorCommandsEquivalent':True})
print('Projects Debug/Release properties and generator commands equivalent')
