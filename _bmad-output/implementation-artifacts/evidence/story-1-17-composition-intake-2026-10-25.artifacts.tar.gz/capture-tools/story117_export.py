from story117_current_capture import *
platform=W/'references/Hexalith.Platform';parties=pathlib.Path('/home/administrator/projects/hexalith/parties');exports={};proof=[]
for name in ['EventStore','Tenants','Memories','Parties']:
 owner=parties if name=='Parties' else W/'references'/('Hexalith.'+name)
 pin=git(platform,'ls-tree','HEAD','references/Hexalith.'+name).decode().split()[2]
 rel='module/hexalith.module-manifest.v2.json';b=git(owner,'show',pin+':'+rel)
 target=C/'exports'/('Hexalith.'+name)/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
 current=owner/rel;exports[name]={'owner':'Hexalith.'+name+' module maintainer','repository':str(owner),'ownerHead':git(owner,'rev-parse','HEAD').decode().strip(),'platformRevision':git(platform,'rev-parse','HEAD').decode().strip(),'platformPin':pin,'manifestBlob':git(owner,'rev-parse',pin+':'+rel).decode().strip(),'sha256':sha(b),'bytes':len(b),'member':str(target.relative_to(C)),'currentOwnerBytesMatch':current.exists() and sha(current.read_bytes())==sha(b),'exportCommand':['git','show',pin+':'+rel]}
for rev in ['1ef274ea0471643d83f924147e85ac8326cf6a47','9c116910f9d712b82ae27ceb1946605d76c8a451','45c033ced0cbdf3edfec12bba427361e2abe6b95','35d891d202a87fd4f494f2cadd26c277df44b84a']:
 b=git(parties,'show',rev+':module/hexalith.module-manifest.v2.json');proof.append({'revision':rev,'blob':git(parties,'rev-parse',rev+':module/hexalith.module-manifest.v2.json').decode().strip(),'sha256':sha(b),'bytes':len(b),'ancestorOfCurrentPlatformPin':subprocess.run(['git','merge-base','--is-ancestor',rev,exports['Parties']['platformPin']],cwd=parties).returncode==0})
for n in ['approved-integration.json','upstream-integration.json','review-follow-up.json']:
 shutil.copyfile(platform/'_bmad-output/implementation-artifacts/evidence/1-12'/n,C/'provenance'/n)
write('exports.json',exports);write('provenance/parties.json',{'revisions':proof,'scope':'Exact declaration bytes and recorded owner integration only; no current adoption, tuple acceptance or hosted evidence inferred.'})
for n in ['apphost.cs','eng/helm-qualification/chart/reference-graph.json','src/Hexalith.Platform.Composition/PlatformHostedPublishing.cs','src/Hexalith.Platform.Composition/CompositionDeclarationClosure.cs','tests/Hexalith.Platform.Composition.Tests/PlatformHostedPublishingTests.cs','.config/dotnet-tools.json','hexalith-platform.json']:
 target=C/'sources/Platform'/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(platform/n,target)
print(json.dumps(exports,indent=2))
