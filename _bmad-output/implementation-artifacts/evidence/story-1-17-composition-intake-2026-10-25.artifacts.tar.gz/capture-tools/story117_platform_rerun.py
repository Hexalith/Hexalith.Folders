from story117_current_capture import *
import sys
config=sys.argv[1];platform=W/'references/Hexalith.Platform';mirror=C/'mirrors'/config;base=platform/'tests/Hexalith.Platform.Composition.Tests/bin'/config/'net10.0';results={}
for owner in (C/'exports').iterdir():
 (owner/'.git').mkdir(exist_ok=True)
for owner in (mirror/'references').iterdir():
 (owner/'.git').mkdir(exist_ok=True)
results['fixtureRootMarkers']='Empty .git directories in disposable exports only, used by unchanged ManifestPathValidator root detection; no Git repository initialized or accepted mapping supplied.'
method='Hexalith.Platform.Composition.Tests.PlatformHostedPublishingTests.HostedGraphDoesNotReadTheLocalProfileAndMatchesTheMaintainedChartInput'
results['supplied']=run('platform-'+config.lower()+'-qualified-export-graph',['dotnet',str(mirror/'bin/Hexalith.Platform.Composition.Tests.dll'),'-method',method,'-xml',str(C/(config.lower()+'-qualified-export-graph.xml'))],mirror)
for cls in ['AgentsAcceptedDeploymentContextTests','PlatformOwnerServicesTests']:
 results[cls]=run('platform-'+config.lower()+'-'+cls,['dotnet',str(base/'Hexalith.Platform.Composition.Tests.dll'),'-class','Hexalith.Platform.Composition.Tests.'+cls,'-xml',str(C/(config.lower()+'-'+cls+'.xml'))],platform)
results['refusal']=run('platform-'+config.lower()+'-refusal',['dotnet',str(base/'Hexalith.Platform.Composition.Tests.dll'),'-method','Hexalith.Platform.Composition.Tests.PlatformHostedPublishingTests.HostedEntryRefusesRunModeBeforeGeneratingLocalResourcesOrSecrets','-xml',str(C/(config.lower()+'-refusal.xml'))],platform)
records=json.loads((C/'binaries'/f'{config}-runtime.json').read_text())
for n,d in records.items():
 if sha((base/n).read_bytes())!=d['sha256'] or sha((mirror/'bin'/n).read_bytes())!=d['sha256']:raise RuntimeError('Runtime drift '+n)
results['runtimeUnchanged']=True;write('platform-'+config.lower()+'-qualified-checks.json',results)
print({k:v.get('exitCode') for k,v in results.items() if isinstance(v,dict)})
