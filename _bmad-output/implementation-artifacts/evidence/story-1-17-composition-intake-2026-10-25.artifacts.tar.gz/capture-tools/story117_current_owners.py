from story117_current_capture import *
exports=json.loads((C/'exports.json').read_text());current={};dst=C/'exports-current-owner';dst.mkdir(exist_ok=True)
for name,e in exports.items():
 owner=pathlib.Path(e['repository']);rel='module/hexalith.module-manifest.v2.json';b=(owner/rel).read_bytes();t=dst/('Hexalith.'+name)/rel;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(b);(t.parent.parent/'.git').mkdir(exist_ok=True);current[name]={'owner':e['owner'],'revision':git(owner,'rev-parse','HEAD').decode().strip(),'path':str(owner/rel),'sha256':sha(b),'member':str(t.relative_to(C))}
 if name=='Memories':
  entry='tools/verify-access-telemetry-lifecycle.py';t=dst/'Hexalith.Memories'/entry;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes((owner/entry).read_bytes());current[name]['entrySha256']=sha(t.read_bytes())
results={}
for config in ['Debug','Release']:
 mirror=C/'mirrors'/config;shutil.copytree(dst,mirror/'references',dirs_exist_ok=True)
 results[config]=run('platform-'+config.lower()+'-current-owner-export-graph',['dotnet',str(mirror/'bin/Hexalith.Platform.Composition.Tests.dll'),'-method','Hexalith.Platform.Composition.Tests.PlatformHostedPublishingTests.HostedGraphDoesNotReadTheLocalProfileAndMatchesTheMaintainedChartInput','-xml',str(C/(config.lower()+'-current-owner-graph.xml'))],mirror)
 shutil.copytree(C/'exports',mirror/'references',dirs_exist_ok=True)
cli='/home/administrator/.nuget/packages/hexalith.builds.module.cli/4.35.2/tools/net10.0/any/Hexalith.Builds.Module.Cli.dll';args=['dotnet',cli,'validate']
for e in current.values():args+=['--manifest',str(C/e['member'])]
args+=['--output','json'];results['released-cli']=run('four-current-owner-released-cli',args,W/'references/Hexalith.Platform')
write('current-owner-export-checks.json',{'exports':current,'checks':results,'scope':'Direct root-declared EventStore/Tenants/Memories current bytes plus current exact existing Parties owner checkout; supplied-input graph only. Ordinary workspace remains missing mapped owner paths.'});print({k:r['exitCode'] for k,r in results.items()})
