from story117_current_capture import *
import zipfile,xml.etree.ElementTree as ET
platform=W/'references/Hexalith.Platform';builds=W/'references/Hexalith.Builds';catalogs={}
for label,rev in [('direct',git(builds,'rev-parse','HEAD').decode().strip()),('platform-gitlink',git(platform,'ls-tree','HEAD','references/Hexalith.Builds').decode().split()[2]),('accepted-tool-source','4248b8c70cb35ba79fdd7e4dd63049d4c73211a0')]:
 b=git(builds,'show',rev+':Props/Hexalith.Packages.props') if False else git(builds,'show',rev+':Props/Directory.Packages.props');p=C/'provenance'/('catalog-'+label+'.props');p.write_bytes(b);catalogs[label]={'revision':rev,'gitCommand':['git','show',rev+':Props/Directory.Packages.props'],'sha256':sha(b),'member':str(p.relative_to(C))}
catalogs['comparison']={'directEqualsPlatform':catalogs['direct']['sha256']==catalogs['platform-gitlink']['sha256'],'directEqualsAcceptedTool':catalogs['direct']['sha256']==catalogs['accepted-tool-source']['sha256'],'currentTupleAccepted':False};write('catalogs.json',catalogs)
pkg=pathlib.Path('/home/administrator/.nuget/packages/hexalith.builds.module.cli/4.35.2');archive=pkg/'hexalith.builds.module.cli.4.35.2.nupkg';tool={};members={}
with zipfile.ZipFile(archive) as z:
 for name in ['tools/net10.0/any/Hexalith.Builds.Module.Cli.dll','tools/net10.0/any/Hexalith.Builds.Tooling.dll','Hexalith.Builds.Module.Cli.nuspec']:
  b=z.read(name);t=C/'provenance/released-cli'/pathlib.Path(name).name;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(b);members[name]={'sha256':sha(b),'installedSha256':sha((pkg/name).read_bytes()) if (pkg/name).exists() else None,'member':str(t.relative_to(C))}
tool={'version':'4.35.2','source':'4248b8c70cb35ba79fdd7e4dd63049d4c73211a0','archiveSha256':sha(archive.read_bytes()),'expectedArchiveSha256':'637bebd547f45b5f2012c2f43af79b9b01772f1e81af02809babe62f4aa7cf1d','matchesPriorAcceptedArchive':sha(archive.read_bytes())=='637bebd547f45b5f2012c2f43af79b9b01772f1e81af02809babe62f4aa7cf1d','members':members,'acceptanceScope':'Previously accepted released package identity only; current source Tooling/catalog/composition tuple remains unaccepted.'};write('released-tool-identity.json',tool)
inspector=P/'capture-tools/inspector-bin/Inspector.dll';pdbs=sorted((C/'binaries').glob('*/*.pdb'));r=run('current-portable-pdb-documents',['dotnet',str(inspector),*[str(p) for p in pdbs]])
if r['exitCode']!=0:raise RuntimeError(r)
docs=json.loads((C/r['log']).read_text());audit=[];mismatch=[]
for row in docs:
 for doc in row['documents']:
  p=pathlib.Path(doc['name']);b=p.read_bytes() if p.is_file() else None;h=sha(b) if b is not None else None
  entry={'pdb':str(pathlib.Path(row['pdb']).relative_to(C)),'path':str(p),'compilerSha256':doc['hash'],'currentSha256':h,'matches':h==doc['hash']}
  if b is not None and p.is_relative_to(W):
   t=C/'sources/compiled'/p.relative_to(W);t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(b);entry['member']=str(t.relative_to(C))
  if not entry['matches']:mismatch.append(entry)
  audit.append(entry)
write('current-compiled-source-audit.json',{'inspectorSha256':sha(inspector.read_bytes()),'documents':audit,'mismatches':mismatch});print('Catalogs',catalogs['comparison'],'tool archive',tool['matchesPriorAcceptedArchive'],'PDB docs',len(audit),'mismatches',len(mismatch))
