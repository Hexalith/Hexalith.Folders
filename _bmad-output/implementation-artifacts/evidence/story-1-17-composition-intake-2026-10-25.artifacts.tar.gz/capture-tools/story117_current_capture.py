import pathlib,json,hashlib,subprocess,time,datetime,shutil,os
W=pathlib.Path('/home/administrator/projects/hexalith/folders'); C=pathlib.Path('/tmp/story117-composition-20261025-z4ue63x2/current'); P=C.parent/'prior'; C.mkdir(exist_ok=True)
for d in ['logs','exports','provenance','binaries','sources','mirrors']: (C/d).mkdir(exist_ok=True)
def sha(b): return hashlib.sha256(b).hexdigest()
def write(n,d):
 p=C/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n')
def git(root,*args): return subprocess.check_output(['git',*args],cwd=root)
def run(name,args,cwd=W):
 t=time.time(); p=subprocess.run(args,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT); f=C/'logs'/f'{name}.txt';f.write_bytes(p.stdout)
 r={'command':args,'cwd':str(cwd),'exitCode':p.returncode,'startedUtc':datetime.datetime.fromtimestamp(t,datetime.UTC).isoformat(),'seconds':round(time.time()-t,3),'log':str(f.relative_to(C)),'logSha256':sha(p.stdout)};write('logs/'+name+'.command.json',r);return r
repos=['.']+[x.split()[1] for x in git(W,'config','-f','.gitmodules','--get-regexp','path').decode().splitlines()]
def snapshot():
 out={}
 for n in repos:
  root=W/n;stage=git(root,'ls-files','--stage');files={}
  for l in stage.decode().splitlines():
   meta,path=l.split('\t',1)
   if meta.startswith('160000 '): continue
   f=root/path;files[path]=sha(f.read_bytes()) if f.is_file() else None
  out[n]={'head':git(root,'rev-parse','HEAD').decode().strip(),'indexSha256':sha(stage),'status':git(root,'status','--short','--untracked-files=all').decode(),'files':files,'rootGitlink':git(W,'ls-tree','HEAD','--',n).decode().strip() if n!='.' else None}
 return out
if __name__=='__main__':
 write('baseline.json',snapshot());shutil.copyfile(C.parent/'baseline.json',C/'provenance/investigation-baseline.json')
 checks={}
 for n,expect in [('story-1-17-release-readiness-2026-10-25.review-final.artifacts.tar.gz','9c9425f0b93e9e6b400f2c49150e42bcc7ba98f199971cf7115ec35de19d48c2'),('story-1-17-release-readiness-2026-10-25.review-final.members.json','366f36659ea571feb3c78c400acbf1b2cca62a89aff3a2e8b59a7297b7f333aa')]:
  f=W/'_bmad-output/implementation-artifacts/evidence'/n;h=sha(f.read_bytes());checks[n]={'sha256':h,'matches':h==expect}
  if h!=expect:raise RuntimeError(n)
 write('provenance/prior-seals.json',checks)
 bindings=json.loads((P/'source-bindings.json').read_text());audit={}
 for k,v in bindings.items():
  if k.startswith('<workspace>/'): f=W/k.removeprefix('<workspace>/')
  elif k.startswith('<nuget>/'): f=pathlib.Path('/home/administrator/.nuget/packages')/k.removeprefix('<nuget>/')
  elif k.startswith('<capsule>/'): f=P/k.removeprefix('<capsule>/')
  else: audit[k]={'prior':v,'status':'unresolved-token'};continue
  h=sha(f.read_bytes()) if f.is_file() else None;audit[k]={'prior':v,'currentSha256':h,'status':'unchanged' if h==v['sha256'] else 'changed' if h else 'missing'}
 write('source-reuse-audit.json',audit)
 print('captured',len(repos),'repos;',len(audit),'prior bindings',dict((s,sum(v['status']==s for v in audit.values())) for s in set(x['status'] for x in audit.values())))
