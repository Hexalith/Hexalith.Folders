from story117_current_capture import *
import collections
old=json.loads((P/'source-bindings.json').read_text());audit={};dotnet=pathlib.Path(shutil.which('dotnet')).resolve().parent
member_manifest=json.loads((W/'_bmad-output/implementation-artifacts/evidence/story-1-17-release-readiness-2026-10-25.review-final.members.json').read_text());member_drift=[]
for name,v in member_manifest['files'].items():
 f=P/name
 if not f.is_file() or sha(f.read_bytes())!=v['sha256']:member_drift.append(name)
if member_drift:raise RuntimeError(member_drift)
for k,v in old.items():
 row={'expectedSha256':v['sha256'],'bytes':v['bytes']};f=None
 if 'member' in v:
  row['retainedMember']=v['member'];row['retainedMemberSha256']=sha((P/v['member']).read_bytes());row['retainedMemberMatches']=row['retainedMemberSha256']==v['sha256']
 if k.startswith('<workspace>/'):f=W/k.removeprefix('<workspace>/');row['comparison']='current-workspace'
 elif k.startswith('<nuget>/'):f=pathlib.Path('/home/administrator/.nuget/packages')/k.removeprefix('<nuget>/');row['comparison']='current-cache'
 elif k.startswith('<dotnet>/'):f=dotnet/k.removeprefix('<dotnet>/');row['comparison']='current-sdk'
 elif k.startswith('<capsule>/') and 'member' in v:f=P/v['member'];row['comparison']='retained-capsule-only'
 else:row['comparison']='unretained-temporary-input'
 h=sha(f.read_bytes()) if f is not None and f.is_file() else None;row['observedSha256']=h;row['status']='unchanged' if h==v['sha256'] else 'changed' if h else 'unavailable';audit[k]=row
write('source-reuse-audit.json',audit)
ci=json.loads((P/'compiled-inputs.json').read_text());profiles=[]
for i,profile in enumerate(json.loads((P/'indices/profiles.json').read_text())):
 record=ci['projects'][int(profile['recordPointer'].rsplit('/',1)[1])];keys={record['PROJECT']}
 for values in record['paths'].values():keys.update(values)
 if profile.get('expandedImportRecord'):
  recordkey=profile['expandedImportRecord'].rsplit('/',1)[1];keys.update(ci['expandedImports'].get(recordkey,{}).get('imports',[]))
 failures=[{'path':k,'status':audit[k]['status'] if k in audit else 'not-bound'} for k in sorted(keys) if k not in audit or audit[k]['status']!='unchanged']
 profiles.append({'profile':profile['profile'],'checkedBindings':len(keys),'byteReuseEligible':not failures,'failures':failures,'scope':'Retained profile input bytes only. No current execution or transitive source/release/hosted acceptance inferred.'})
summary={'bindings':len(audit),'retainedMembersVerified':len(member_manifest['files']),'statuses':dict(collections.Counter(v['status'] for v in audit.values())),'byScope':{s:dict(collections.Counter(v['status'] for v in audit.values() if v['comparison']==s)) for s in sorted(set(v['comparison'] for v in audit.values()))},'profiles':len(profiles),'byteReuseEligibleProfiles':sum(x['byteReuseEligible'] for x in profiles),'policy':'Only unchanged byte bindings/profile facets are reusable. All previous executable outcomes remain labelled historical; current Platform results are fresh. Projects rename has independently proven property/argument equivalence but changed project-file bytes are not marked unchanged.'}
write('source-reuse-profiles.json',profiles);write('source-reuse-summary.json',summary);print(summary)
