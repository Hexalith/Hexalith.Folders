"""Focused negative controls for the offline evidence verifier; never rerun builds."""
import errno,hashlib,json,os,pathlib,shutil,subprocess,sys,tempfile,unittest
import xml.etree.ElementTree as ET
from unittest import mock
BASE=pathlib.Path(__file__).resolve().parent

def link_or_copy(source,destination):
    try:return os.link(source,destination)
    except OSError as error:
        if error.errno!=errno.EXDEV:raise
        return shutil.copy2(source,destination)

def write_detached(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():path.unlink()
    path.write_bytes(data)

def change_json(action):
    def mutate(data):
        value=json.loads(data);action(value);return (json.dumps(value,indent=2)+'\n').encode()
    return mutate

def change_xml(action):
    def mutate(data):
        value=ET.fromstring(data);action(value);return ET.tostring(value,encoding='utf-8',xml_declaration=True)
    return mutate

class ReplayMutationTests(unittest.TestCase):
    def run_mutation(self,member,mutate,diagnostic,reseal=True,rebind_log=False):
        source=BASE/member;before=source.read_bytes() if source.is_file() else None
        with tempfile.TemporaryDirectory(prefix='story117-replay-mutation-') as tmp:
            target=pathlib.Path(tmp)/'capsule';shutil.copytree(BASE,target,copy_function=link_or_copy)
            p=target/member;data=mutate(p.read_bytes() if p.exists() else b'');write_detached(p,data)
            updates={member:data}
            if rebind_log:
                command_member=member.removesuffix('.txt')+'.command.json';command=json.loads((target/command_member).read_text());command['logSha256']=hashlib.sha256(data).hexdigest()
                updates[command_member]=json.dumps(command).encode();commands=json.loads((target/'commands.json').read_text())
                for row in commands:
                    if row['log']==member:row['logSha256']=command['logSha256']
                updates['commands.json']=json.dumps(commands).encode()
                for name,payload in updates.items():write_detached(target/name,payload)
            if reseal:
                m=target/'members.json';d=json.loads(m.read_text())
                for name,payload in updates.items():d['files'][name]={'sha256':hashlib.sha256(payload).hexdigest(),'bytes':len(payload)}
                write_detached(m,json.dumps(d).encode())
            result=subprocess.run([sys.executable,'-O',str(target/'replay.py')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            self.assertNotEqual(result.returncode,0,result.stdout.decode());self.assertIn(('FAIL: '+diagnostic).encode(),result.stdout)
        self.assertEqual(source.read_bytes() if source.is_file() else None,before,'Mutation changed source evidence')

    def test_catalog_corruption_hits_member_integrity_guard(self):
        self.run_mutation('provenance/catalog-direct.props',lambda b:b+b'corruption','Member mismatch: provenance/catalog-direct.props',False)

    def test_zero_test_false_pass_refused(self):
        self.run_mutation('debug-qualified-export-graph.xml',change_xml(lambda d:d.find('assembly').set('total','0')),'Wrong/nonexecuted test outcome:')

    def test_unrelated_canonical_test_refused(self):
        self.run_mutation('debug-qualified-export-graph.xml',change_xml(lambda d:d.find('.//test').set('method','Unrelated')),'Test identity mismatch:')

    def test_wrong_additional_test_identity_refused(self):
        self.run_mutation('debug-PlatformOwnerServicesTests.xml',change_xml(lambda d:d.find('.//test').set('type','UnrelatedTests')),'Test identity mismatch:')

    def test_individual_failure_cannot_hide_in_pass_totals(self):
        self.run_mutation('debug-AgentsAcceptedDeploymentContextTests.xml',change_xml(lambda d:d.find('.//test').set('result','Fail')),'Individual test result mismatch:')

    def test_arbitrary_workspace_failure_refused(self):
        def replace(root):root.find('.//failure/message').text='System.IO.InvalidDataException : unrelated timeout'
        self.run_mutation('debug-ordinary-graph.xml',change_xml(replace),'Ordinary workspace failure is not missing Parties declaration')

    def test_empty_parties_provenance_refused(self):
        self.run_mutation('provenance/parties.json',change_json(lambda d:d.update(revisions=[])),'Parties revision coverage mismatch')

    def test_duplicate_parties_revision_refused(self):
        self.run_mutation('provenance/parties.json',change_json(lambda d:d['revisions'].__setitem__(1,d['revisions'][0])),'Parties revision coverage mismatch')

    def test_empty_compiler_documents_refused(self):
        self.run_mutation('current-compiled-source-audit.json',change_json(lambda d:d.update(documents=[])),'Compiler document coverage mismatch')

    def test_duplicate_compiler_document_refused(self):
        self.run_mutation('current-compiled-source-audit.json',change_json(lambda d:d['documents'].__setitem__(1,d['documents'][0])),'Compiler document coverage mismatch')

    def test_missing_materialized_binding_refused(self):
        self.run_mutation('current-compiled-source-audit.json',change_json(lambda d:d['documents'][0].pop('member')),'Materialized compiler document coverage mismatch')

    def test_retained_pdb_audit_coverage_required(self):
        self.run_mutation('logs/current-portable-pdb-documents.txt',change_json(lambda d:d.clear()),'Retained PDB document coverage mismatch',rebind_log=True)

    def test_current_owner_revision_substitution_refused(self):
        self.run_mutation('current-owner-export-checks.json',change_json(lambda d:d['exports']['Memories'].update(revision='0'*40)),'Current owner export revision/path mismatch:')

    def test_current_owner_hash_substitution_refused(self):
        self.run_mutation('current-owner-export-checks.json',change_json(lambda d:d['exports']['Memories'].update(sha256='0'*64)),'Current owner export binding mismatch:')

    def test_current_owner_receipt_substitution_refused(self):
        self.run_mutation('current-owner-export-checks.json',change_json(lambda d:d['checks']['Debug'].update(exitCode=1)),'Current owner graph receipt mismatch')

    def test_released_tool_handoff_substitution_refused(self):
        self.run_mutation('handoff.json',change_json(lambda d:d['releasedTool'].update(source='0'*40)),'Handoff released tool identity mismatch')

    def test_source_tooling_handoff_substitution_refused(self):
        self.run_mutation('handoff.json',change_json(lambda d:d['currentSourceBuiltTooling']['Debug'].update(loadedDllSha256='0'*64)),'Handoff loaded Tooling identity mismatch')

    def test_preservation_index_summary_cannot_hide_drift(self):
        self.run_mutation('final-state.json',change_json(lambda d:d['references/Hexalith.Projects'].update(indexSha256='0'*64)),'Repository revision/index changed:')

    def test_preservation_summary_cannot_hide_changed_file(self):
        self.run_mutation('final-state.json',change_json(lambda d:d['.']['files'].update({'README.md':'0'*64})),'Unauthorized tracked change:')

    def test_prior_handoff_snapshot_substitution_refused(self):
        self.run_mutation('provenance/prior-publication-handoff.json',lambda b:b+b' ','Prior handoff changed')

    def test_reuse_summary_must_match_detailed_rows(self):
        self.run_mutation('source-reuse-summary.json',change_json(lambda d:d['statuses'].update(unchanged=0)),'Reuse summary differs from detailed audit')

    def test_reuse_eligibility_must_match_detailed_rows(self):
        self.run_mutation('source-reuse-profiles.json',change_json(lambda d:d[0].update(byteReuseEligible=False)),'Reuse profile eligibility mismatch:')

    def test_reuse_binding_status_cannot_be_invented(self):
        self.run_mutation('source-reuse-audit.json',change_json(lambda d:next(iter(d.values())).update(status='unavailable')),'Reuse binding status mismatch:')

    def test_intake_requirement_counts_derived_from_diagnostics(self):
        self.run_mutation('intake-classification.json',change_json(lambda d:d['folders']['countsByRequirement'].update(declaration=0)),'Intake category summary mismatch:')

    def test_intake_source_categories_derived_from_diagnostics(self):
        self.run_mutation('intake-classification.json',change_json(lambda d:d['folders'].update(categories={})),'Intake category summary mismatch:')

    def test_nested_members_file_is_not_exempt(self):
        self.run_mutation('extra/members.json',lambda b:b'{}','Unexpected or missing file members',False)

    def test_nested_members_in_cache_directory_is_not_exempt(self):
        self.run_mutation('extra/__pycache__/members.json',lambda b:b'{}','Unexpected or missing file members',False)

    def test_current_tuple_acceptance_refused(self):
        self.run_mutation('handoff.json',change_json(lambda d:d['releasedTool'].update(currentTupleAccepted=True)),'Current tuple acceptance fabricated')

    def test_activation_authority_refused(self):
        self.run_mutation('handoff.json',change_json(lambda d:d['operationalControl'].update(activationAuthority='unauthorized')),'Operational authority changed')

    def test_cross_filesystem_copy_fallback_preserves_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            source=pathlib.Path(tmp)/'source';target=pathlib.Path(tmp)/'target';source.write_bytes(b'evidence')
            with mock.patch.object(os,'link',side_effect=OSError(errno.EXDEV,'different filesystem')):
                link_or_copy(source,target)
            self.assertEqual(target.read_bytes(),b'evidence');target.write_bytes(b'changed');self.assertEqual(source.read_bytes(),b'evidence')

    def test_copy_fallback_does_not_hide_other_errors(self):
        with mock.patch.object(os,'link',side_effect=OSError(errno.EACCES,'denied')):
            with self.assertRaises(PermissionError):link_or_copy('source','target')

if __name__=='__main__':unittest.main(verbosity=2)
