"""Offline integrity/claim replay. All checks remain active with python -O."""
import argparse,collections,hashlib,json,pathlib,subprocess,sys,xml.etree.ElementTree as ET
BASE=pathlib.Path(__file__).resolve().parent

def require(ok,message):
    if not ok: raise RuntimeError(message)
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def read(name): return json.loads((BASE/name).read_text())
NAMESPACE='Hexalith.Platform.Composition.Tests.'
GRAPH_CLASS=NAMESPACE+'PlatformHostedPublishingTests'
GRAPH_METHOD='HostedGraphDoesNotReadTheLocalProfileAndMatchesTheMaintainedChartInput'
GRAPH=GRAPH_CLASS+'.'+GRAPH_METHOD
OWNERS=('EventStore','Tenants','Memories','Parties')

def expected_tests(label):
    if label.endswith(('ordinary-graph.xml','qualified-export-graph.xml','current-owner-graph.xml')):
        return [(GRAPH_CLASS,GRAPH_METHOD,GRAPH)]
    if label.endswith('refusal.xml'):
        method='HostedEntryRefusesRunModeBeforeGeneratingLocalResourcesOrSecrets'
        return [(GRAPH_CLASS,method,GRAPH_CLASS+'.'+method)]
    if label.endswith('AgentsAcceptedDeploymentContextTests.xml'):
        cls=NAMESPACE+'AgentsAcceptedDeploymentContextTests'
        methods=['RealDateMustAgreeAcrossAcceptedRegisterPacketAndExactProfileBytes','ParsingReferencesAloneDoesNotGrantProductionCompositionAuthority']
        return [(cls,m,cls+'.'+m) for m in methods]+[(cls,'InvalidCalendarDateCannotBeComposed',cls+'.InvalidCalendarDateCannotBeComposed(date: "'+date+'")') for date in ['2026-02-30','2026-1-03','2026-11-03T00:00:00']]
    if label.endswith('PlatformOwnerServicesTests.xml'):
        cls=NAMESPACE+'PlatformOwnerServicesTests'
        return [(cls,m,cls+'.'+m) for m in ['EnrollmentKeepsClientsSecretsTenantsAndExactScopesSeparate','EnrollmentRejectsExistingOrRepeatedClientIdentities']]
    raise RuntimeError('Unknown test evidence: '+label)

def test(name,total,passed,failed,label=None):
    label=label or str(name)
    root=ET.parse(BASE/name).getroot();assemblies=root.findall('assembly')
    require(len(assemblies)==1,'Wrong test assembly coverage: '+label)
    a=assemblies[0]
    require(pathlib.Path(a.attrib['name']).name=='Hexalith.Platform.Composition.Tests.dll','Wrong test assembly: '+label)
    require(tuple(int(a.attrib[k]) for k in ['total','passed','failed','skipped','errors','not-run'])==(total,passed,failed,0,0,0),'Wrong/nonexecuted test outcome: '+label)
    cases=a.findall('.//test');expected=expected_tests(label)
    require(len(cases)==total==len(expected),'Test case count mismatch: '+label)
    identities=[(t.attrib['type'],t.attrib['method'],t.attrib['name'].replace(chr(92),'')) for t in cases]
    require(collections.Counter(identities)==collections.Counter(expected),'Test identity mismatch: '+label)
    outcome='Fail' if failed else 'Pass'
    require(all(t.attrib['result']==outcome for t in cases),'Individual test result mismatch: '+label)
    if failed:
        failure=cases[0].find('failure');message=cases[0].findtext('failure/message') or ''
        require(failure is not None and failure.attrib.get('exception-type')=='System.IO.InvalidDataException' and message.endswith('references/Hexalith.Parties/module/hexalith.module-manifest.v2.json: manifest: Supply an existing readable manifest file.'),'Ordinary workspace failure is not missing Parties declaration')
    else:
        require(all(t.find('failure') is None and t.find('reason') is None for t in cases),'Passing test contains failure/skip evidence: '+label)

def receipt(row,exit_code):
    require(row==read(row['log'].removesuffix('.txt')+'.command.json') and row['exitCode']==exit_code,'Execution receipt mismatch: '+row['log'])
    require(sha(BASE/row['log'])==row['logSha256'],'Execution log mismatch: '+row['log'])

def check_test_receipt(row,xml,selector,identity,exit_code=0):
    receipt(row,exit_code)
    require(row['command'][0]=='dotnet' and pathlib.Path(row['command'][1]).name=='Hexalith.Platform.Composition.Tests.dll' and row['command'][2:]==[selector,identity,'-xml',str(pathlib.Path(row['command'][-1]).parent/xml)],'Test execution identity mismatch: '+xml)
    require(pathlib.Path(row['command'][-1]).name==xml,'Test result receipt mismatch: '+xml)

def verify_exports(handoff,baseline):
    pinned=read('exports.json');current=read('current-owner-export-checks.json')
    require(set(pinned)==set(current['exports'])==set(OWNERS),'Owner export coverage mismatch')
    for owner in OWNERS:
        row=current['exports'][owner];old=pinned[owner];member='exports-current-owner/Hexalith.'+owner+'/module/hexalith.module-manifest.v2.json'
        revision=old['ownerHead'] if owner=='Parties' else baseline['references/Hexalith.'+owner]['head']
        require(row['revision']==revision and row['owner']==old['owner'] and row['path']==old['repository']+'/module/hexalith.module-manifest.v2.json','Current owner export revision/path mismatch: '+owner)
        require(row['member']==member and sha(BASE/member)==row['sha256']==old['currentOwnerSha256'],'Current owner export binding mismatch: '+owner)
        if owner!='Parties':require(row['sha256']==baseline['references/Hexalith.'+owner]['files']['module/hexalith.module-manifest.v2.json'],'Current export differs from owner snapshot: '+owner)
        pb=(BASE/old['member']).read_bytes();cb=(BASE/member).read_bytes()
        require(old['currentOwnerBytesMatch']==(pb==cb) and old['currentOwnerEqualAfterCrLfNormalization']==(pb.replace(b'\r\n',b'\n')==cb.replace(b'\r\n',b'\n')) and old['currentOwnerJsonEquivalent']==(json.loads(pb)==json.loads(cb)),'Export comparison mismatch: '+owner)
    entry='tools/verify-access-telemetry-lifecycle.py'
    require(current['exports']['Memories']['entrySha256']==sha(BASE/'exports-current-owner/Hexalith.Memories'/entry)==baseline['references/Hexalith.Memories']['files'][entry],'Current Memories entry binding mismatch')
    require(set(current['checks'])=={'Debug','Release','released-cli'},'Current owner execution coverage mismatch')
    for config in ['Debug','Release']:
        row=current['checks'][config]
        require(row==read('logs/platform-'+config.lower()+'-current-owner-export-graph.command.json'),'Current owner graph receipt mismatch')
        check_test_receipt(row,config.lower()+'-current-owner-graph.xml','-method',GRAPH)
    row=current['checks']['released-cli'];receipt(row,0)
    require(row==read('logs/four-current-owner-released-cli.command.json'),'Current owner CLI receipt mismatch')
    args=row['command'];root=pathlib.Path(current['checks']['Debug']['command'][1]).parents[3]
    expected=['dotnet',args[1],'validate']
    for owner in OWNERS:expected+=['--manifest',str(root/current['exports'][owner]['member'])]
    expected+=['--output','json']
    require(args==expected,'Current owner CLI manifest arguments mismatch')
    require('/hexalith.builds.module.cli/4.35.2/tools/net10.0/any/Hexalith.Builds.Module.Cli.dll' in args[1],'Current owner CLI identity mismatch')
    require(read(row['log'])=={'status':'validated','outcome':{'exitCode':'Success','phase':'None','category':'None','ruleId':None},'diagnostics':[]},'Current owner CLI validation mismatch')

def verify_compiler_documents():
    audit=read('current-compiled-source-audit.json');raw=read('logs/current-portable-pdb-documents.txt')
    expected={};pdbs=set()
    for row in raw:
        pdb='/'.join(pathlib.Path(row['pdb']).parts[-3:]);require(pdb not in pdbs,'Duplicate retained PDB audit');pdbs.add(pdb)
        require((BASE/pdb).is_file(),'Missing retained PDB')
        for doc in row['documents']:
            key=(pdb,doc['name']);require(key not in expected,'Duplicate retained compiler document')
            require(doc['algorithm']=='8829d00f-11b8-4213-878b-770e8597ac16','Unexpected compiler checksum algorithm');expected[key]=doc['hash']
    require(len(pdbs)==8 and len(expected)==870,'Retained PDB document coverage mismatch')
    documents=audit['documents'];keys=[(r['pdb'],r['path']) for r in documents]
    require(len(keys)==len(set(keys))==870 and set(keys)==set(expected),'Compiler document coverage mismatch')
    materialized=[r for r in documents if 'member' in r];generated=[r for r in documents if 'member' not in r]
    require(len(materialized)==864 and len(generated)==6 and not audit['mismatches'],'Materialized compiler document coverage mismatch')
    workspace=pathlib.Path(read('current-owner-export-checks.json')['exports']['EventStore']['path']).parents[3]
    for row in documents:
        require(row['compilerSha256']==expected[(row['pdb'],row['path'])],'Compiler checksum differs from retained PDB audit')
        if 'member' in row:
            path=pathlib.Path(row.get('mappedPath',row['path']))
            expected_member='sources/compiled/nuget/'+str(path).split('/.nuget/packages/',1)[1] if '/.nuget/packages/' in str(path) else 'sources/compiled/'+str(path.relative_to(workspace))
            require(row['member']==expected_member,'Compiler source member path mismatch')
            require(row['matches'] is True and row['currentSha256']==row['compilerSha256']==sha(BASE/row['member']),'Compiler document mismatch')
        else:require(row['matches'] is False and row['currentSha256'] is None,'Generated document limitation mismatch')
    require(audit['generatedDocumentsNotMaterialized']==generated,'Generated compiler document coverage mismatch')

def verify_preservation():
    before=read('baseline.json');after=read('final-state.json');report=read('preservation.json')
    require(set(before)==set(after)==set(report['repositories']) and len(before)==12,'Preservation repository coverage mismatch')
    allowed={'.':{'.gitattributes'},'references/Hexalith.Projects':{'src/Hexalith.Projects.Client/Hexalith.Projects.Client.csproj'}}
    for repo,b in before.items():
        a=after[repo];changed=sorted(k for k in set(b['files'])|set(a['files']) if b['files'].get(k)!=a['files'].get(k))
        require(b['head']==a['head'] and b['indexSha256']==a['indexSha256'],'Repository revision/index changed: '+repo)
        require(set(b['files'])==set(a['files']) and set(changed)<=allowed.get(repo,set()),'Unauthorized tracked change: '+repo)
        expected={'headBefore':b['head'],'headAfter':a['head'],'headUnchanged':True,'indexBefore':b['indexSha256'],'indexAfter':a['indexSha256'],'indexUnchanged':True,'changedTrackedFiles':changed,'allOtherTrackedFilesUnchanged':True}
        require(report['repositories'][repo]==expected,'Preservation summary differs from snapshots: '+repo)
    prior='_bmad-output/implementation-artifacts/story-1-17-publication-handoff-2026-10-25.json'
    require(before['.']['files'][prior]==after['.']['files'][prior]==sha(BASE/'provenance/prior-publication-handoff.json'),'Prior handoff changed')
    require(not report['unexpected'] and report['priorHandoffUnchanged'],'Preservation summary mismatch')

def verify_reuse(handoff):
    audit=read('source-reuse-audit.json');profiles=read('source-reuse-profiles.json');summary=read('source-reuse-summary.json')
    require(len(audit)==10049 and len(profiles)==231,'Reuse coverage missing')
    scopes={'current-workspace','current-cache','current-sdk','retained-capsule-only','unretained-temporary-input'}
    for name,row in audit.items():
        status='unchanged' if row['observedSha256']==row['expectedSha256'] else 'changed' if row['observedSha256'] else 'unavailable'
        require(row['status']==status and row['comparison'] in scopes,'Reuse binding status mismatch: '+name)
        if 'retainedMember' in row:require(row['retainedMemberMatches']==(row['retainedMemberSha256']==row['expectedSha256']),'Retained binding comparison mismatch')
    names=[r['profile'] for r in profiles];require(len(names)==len(set(names)),'Duplicate reuse profile')
    for row in profiles:
        keys=row['checkedBindingKeys'];require(len(keys)==len(set(keys))==row['checkedBindings'] and keys==sorted(keys),'Reuse profile binding coverage mismatch')
        failures=[{'path':k,'status':audit[k]['status'] if k in audit else 'not-bound'} for k in keys if k not in audit or audit[k]['status']!='unchanged']
        require(row['failures']==failures and row['byteReuseEligible']==(not failures),'Reuse profile eligibility mismatch: '+row['profile'])
    expected={'bindings':len(audit),'retainedMembersVerified':len(read('provenance/story-1-17-release-readiness-2026-10-25.review-final.members.json')['files']),'statuses':dict(collections.Counter(r['status'] for r in audit.values())),'byScope':{scope:dict(collections.Counter(r['status'] for r in audit.values() if r['comparison']==scope)) for scope in sorted(scopes)},'profiles':len(profiles),'byteReuseEligibleProfiles':sum(r['byteReuseEligible'] for r in profiles)}
    require(all(summary[k]==v for k,v in expected.items()),'Reuse summary differs from detailed audit')
    require(handoff['sourceReuseSummary']==summary,'Handoff reuse summary differs from detailed audit')

def verify_intake_categories(handoff):
    classification=read('intake-classification.json');intake=read('intake.json')
    require(set(classification)==set(handoff['moduleIntake'])=={'folders','projects','eventstore','tenants','memories'},'Intake owner coverage mismatch')
    for owner,commands in intake.items():
        row=classification[owner.lower()];diagnostics=read(commands['adoption']['log'])['diagnostics'];categories={}
        for diagnostic in diagnostics:
            source=diagnostic['source'];kind='tracked-tests' if source.startswith(('tests/','test/')) else 'tracked-historical-evidence' if source.startswith(('_bmad-output/','eng/story117-')) else 'current-source-build-or-enrollment'
            categories.setdefault(diagnostic['field'],{}).setdefault(kind,[]).append(diagnostic)
        counts=dict(collections.Counter(d['field'] for d in diagnostics))
        require(row['categories']==categories and row['countsByRequirement']==counts and row['diagnosticCount']==len(diagnostics),'Intake category summary mismatch: '+owner)
        claim={k:row[k] for k in ['declarationExitCode','adoptionExitCode','diagnosticCount','countsByRequirement','owner','status']}
        require(handoff['moduleIntake'][owner.lower()]==claim,'Handoff intake categories differ from diagnostics: '+owner)
        receipt(commands['declaration'],row['declarationExitCode']);receipt(commands['adoption'],row['adoptionExitCode'])

def verify_tool(handoff):
    tool=read('released-tool-identity.json');prior=read('provenance/prior-publication-handoff.json')['packageIdentities']['tool'];claim=handoff['releasedTool']
    expected={'version':prior['version'],'source':prior['sourceRevision'],'archiveSha256':prior['archiveSha256']}
    require(all(claim[k]==tool[k]==v for k,v in expected.items()),'Handoff released tool identity mismatch')
    require(tool['expectedArchiveSha256']==expected['archiveSha256'] and claim['cachedArchiveMatchesAccepted'] is True and claim['currentTupleAccepted'] is False,'Released tool acceptance mismatch')
    nuspec=ET.parse(BASE/'provenance/released-cli/Hexalith.Builds.Module.Cli.nuspec').getroot();ns={'n':nuspec.tag.split('}')[0][1:]}
    require(nuspec.findtext('n:metadata/n:version',namespaces=ns)==tool['version'] and nuspec.find('n:metadata/n:repository',ns).attrib['commit']==tool['source'],'Released tool nuspec identity mismatch')
    require((BASE/'logs/released-cli-version.txt').read_text().strip()==tool['version']+'+'+tool['source'],'Actual tool version differs from identity')
    for config,row in handoff['currentSourceBuiltTooling'].items():
        require(config in ['Debug','Release'] and row['binding']=='binaries/'+config+'-runtime.json','Source Tooling binding mismatch')
    require(set(handoff['currentSourceBuiltTooling'])=={'Debug','Release'},'Source Tooling profile coverage mismatch')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--workspace',type=pathlib.Path);parser.add_argument('--execute-graphs',action='store_true');args=parser.parse_args()
    manifest=read('members.json')
    require(len(manifest['files'])>100,'Incomplete evidence manifest')
    for name,row in manifest['files'].items():
        p=BASE/name
        require(p.resolve().is_relative_to(BASE) and p.is_file() and not p.is_symlink(),'Unsafe/missing member: '+name)
        require(p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],'Member mismatch: '+name)
    actual={str(p.relative_to(BASE)) for p in BASE.rglob('*') if p.is_file() and p!=BASE/'members.json'}
    require(actual==set(manifest['files']),'Unexpected or missing file members')
    for name in manifest['requiredFixtureDirectories']:
        require((BASE/name).is_dir(),'Missing disposable root marker: '+name)
    handoff=read('handoff.json');control=handoff['operationalControl']
    require(handoff['status'].startswith('HOLD') and handoff['releasedTool']['currentTupleAccepted'] is False,'Current tuple acceptance fabricated')
    require(handoff['catalogs']==read('catalogs.json'),'Handoff catalog claims differ from evidence')
    require(handoff['sourceTuple']=={name:{'revision':row['head'],'indexSha256':row['indexSha256']} for name,row in read('baseline.json').items()},'Handoff source tuple differs from captured baseline')
    require(handoff['localQualification']['additionalTests']['Debug']==8 and handoff['localQualification']['additionalTests']['Release']==8,'Handoff test count mismatch')
    require(control=={'routeMode':'V1Only','T0':None,'activationAuthority':None,'publicationAuthorized':False,'deploymentAuthorized':False,'trackerTransitionAuthorized':False,'stagingChecksExecuted':0},'Operational authority changed')
    require(handoff['parentStatus']=='in-progress' and handoff['trackerStatus']=='backlog' and handoff['stagingChecks']=={'total':14,'executed':0},'Parent/staging authority changed')
    for profile in ['debug','release']:
        test(profile+'-ordinary-graph.xml',1,0,1)
        for variant in ['qualified-export-graph','current-owner-graph']: test(profile+'-'+variant+'.xml',1,1,0)
        for label,total in [('AgentsAcceptedDeploymentContextTests',5),('PlatformOwnerServicesTests',2),('refusal',1)]: test(profile+'-'+label+'.xml',total,total,0)
        checks=read('platform-'+profile+'-checks.json');qualified=read('platform-'+profile+'-qualified-checks.json')
        require(checks['runtimeUnchanged'] and checks['sourceToolingMatchesLoaded'] and qualified['runtimeUnchanged'],'Source/loaded runtime changed')
        runtime=read('binaries/'+profile.capitalize()+'-runtime.json')
        for name,row in runtime.items():require(sha(BASE/'mirrors'/profile.capitalize()/'bin'/name)==row['sha256'],'Runtime inventory mismatch')
        claimed=handoff['currentSourceBuiltTooling'][profile.capitalize()]
        require(claimed['sourceRevision']==handoff['sourceTuple']['references/Hexalith.Builds']['revision'] and claimed['matchesDirectSourceOutput'],'Wrong source Tooling tuple')
        require(claimed['loadedDllSha256']==runtime['Hexalith.Builds.Tooling.dll']['sha256'] and claimed['loadedPdbSha256']==runtime['Hexalith.Builds.Tooling.pdb']['sha256'],'Handoff loaded Tooling identity mismatch')
        require(read('logs/platform-build-'+profile+'.command.json')['exitCode']==0,'Required build failed')
        require(qualified['supplied']['exitCode']==0 and checks['ordinary']['exitCode']==1,'Graph command outcomes do not match claims')
        for suffix in ['.dll','.pdb']:
            require(sha(BASE/'binaries'/profile.capitalize()/('Hexalith.Builds.Tooling'+suffix))==runtime['Hexalith.Builds.Tooling'+suffix]['sha256'],'Loaded Tooling identity mismatch')
    exports=read('exports.json');parties=read('provenance/parties.json')['revisions']
    expected_revisions={'1ef274ea0471643d83f924147e85ac8326cf6a47','9c116910f9d712b82ae27ceb1946605d76c8a451','45c033ced0cbdf3edfec12bba427361e2abe6b95','35d891d202a87fd4f494f2cadd26c277df44b84a'}
    require(len(parties)==4 and {r['revision'] for r in parties}==expected_revisions,'Parties revision coverage mismatch')
    require(all(x['blob']=='c96bb9746220da7e11c309f8a2897816b72449a9' and x['sha256']=='0fd4457a1801fa13053ef8821eb16a0cfcc6a5edac94b6ce89e8f220e8a30511' and x['bytes']==12797 and x['ancestorOfCurrentPlatformPin'] for x in parties),'Parties provenance mismatch')
    require(exports['Parties']['platformPin']==exports['Parties']['ownerHead']=='986a369ec26f6c5194593eb7bce12955eda54149' and exports['Parties']['manifestBlob']=='c96bb9746220da7e11c309f8a2897816b72449a9','Current Parties revision/blob mismatch')
    for name,row in exports.items():
        require(sha(BASE/row['member'])==row['sha256'],'Export identity mismatch')
        for config in ['Debug','Release']:
            require(sha(BASE/'mirrors'/config/'references'/('Hexalith.'+name)/'module/hexalith.module-manifest.v2.json')==row['sha256'],'Mirror owner mismatch')
    for log in ['four-owner-released-cli-qualified-export','four-current-owner-released-cli']:
        require(read('logs/'+log+'.command.json')['exitCode']==0 and read('logs/'+log+'.txt')['status']=='validated','Released tool validation failed')
    for owner,expected in [('Folders',1),('Projects',1),('EventStore',0),('Tenants',0),('Memories',0)]:
        r=read('intake.json')[owner];require(r['declaration']['exitCode']==expected and r['adoption']['exitCode']==1,'Intake outcome changed')
        require(read(r['adoption']['log'])['status']=='failed','False adoption acceptance')
        claim=handoff['moduleIntake'][owner.lower()]
        require(claim['declarationExitCode']==expected and claim['adoptionExitCode']==1 and claim['status']=='HOLD','Handoff intake claim mismatch')
        require(claim['diagnosticCount']==len(read(r['adoption']['log'])['diagnostics']),'Handoff diagnostic count mismatch')
    projects=read('projects-property-equivalence.json')
    before=(BASE/'sources/projects-client.before.csproj').read_bytes();after=(BASE/'sources/projects-client.after.csproj').read_bytes()
    require(before.replace(b'HexalithProjectsRepositoryRoot',b'ProjectsRepositoryDirectory')==after,'Unexpected Projects edit')
    for profile in ['Debug','Release']:
        b=projects['results']['before'][profile]['properties'];a=projects['results']['after'][profile]['properties'];require(a==b,'Generator/property behavior changed')
        raw_before=read(projects['results']['before'][profile]['command']['log'])['Properties'];raw_after=read(projects['results']['after'][profile]['command']['log'])['Properties']
        raw_before['ProjectsRepositoryDirectory']=raw_before.pop('HexalithProjectsRepositoryRoot')
        require(raw_before==raw_after==a,'Property equivalence differs from actual MSBuild output')
    require(not read('intake-classification.json')['projects']['propertyRepair']['afterDiagnostics'],'Projects diagnostic not repaired')
    require(read('catalogs.json')['comparison']=={'directEqualsPlatform':True,'directEqualsAcceptedTool':False,'currentTupleAccepted':False},'Catalog acceptance scope changed')
    tool=read('released-tool-identity.json');require(tool['matchesPriorAcceptedArchive'] and tool['archiveSha256']==tool['expectedArchiveSha256'],'Released tool archive mismatch')
    for row in tool['members'].values():
        require(sha(BASE/row['member'])==row['sha256'],'Released tool payload mismatch')
        if row['installedSha256'] is not None:require(row['installedSha256']==row['sha256'],'Installed tool differs from archive')
    source=read('current-compiled-source-audit.json');require(not source['mismatches'] and len(source['generatedDocumentsNotMaterialized'])==6,'Compiled source drift')
    for row in source['documents']:
        if row.get('member'):require(sha(BASE/row['member'])==row['compilerSha256'],'Compiler document mismatch')
    preservation=read('preservation.json');require(not preservation['unexpected'] and preservation['priorHandoffUnchanged'],'Preservation failed')
    for row in preservation['repositories'].values():require(row['headUnchanged'] and row['indexUnchanged'] and row['allOtherTrackedFilesUnchanged'],'Repository mutation')
    require(read('source-reuse-summary.json')['bindings']==10049,'Source audit incomplete')
    require(len(read('source-reuse-audit.json'))==10049 and len(read('source-reuse-profiles.json'))==231,'Reuse coverage missing')
    for row in read('commands.json'):
        require(sha(BASE/row['log'])==row['logSha256'],'Command log binding mismatch')
        require(row==read(row['log'].removesuffix('.txt')+'.command.json'),'Command index differs from execution receipt')
    verify_exports(handoff,read('baseline.json'))
    verify_compiler_documents()
    verify_preservation()
    verify_reuse(handoff)
    verify_intake_categories(handoff)
    verify_tool(handoff)
    for config in ['debug','release']:
        base=read('platform-'+config+'-checks.json');qualified=read('platform-'+config+'-qualified-checks.json')
        check_test_receipt(base['ordinary'],config+'-ordinary-graph.xml','-method',GRAPH,1)
        check_test_receipt(qualified['supplied'],config+'-qualified-export-graph.xml','-method',GRAPH)
        for cls in ['AgentsAcceptedDeploymentContextTests','PlatformOwnerServicesTests']:
            check_test_receipt(qualified[cls],config+'-'+cls+'.xml','-class',NAMESPACE+cls)
        check_test_receipt(qualified['refusal'],config+'-refusal.xml','-method',GRAPH_CLASS+'.HostedEntryRefusesRunModeBeforeGeneratingLocalResourcesOrSecrets')
    if args.workspace:
        workspace=args.workspace.resolve()
        for repo,state in read('final-state.json').items():
            root=workspace/repo
            require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()==state['head'],'Current revision drift: '+repo)
            require(hashlib.sha256(subprocess.check_output(['git','ls-files','--stage'],cwd=root)).hexdigest()==state['indexSha256'],'Current index drift: '+repo)
            for name,digest in state['files'].items():
                path=root/name
                require((sha(path) if path.is_file() else None)==digest,'Current tracked source drift: '+str(path))
    if args.execute_graphs:
        import tempfile
        with tempfile.TemporaryDirectory(prefix='story117-replay-results-') as tmp:
            for config in ['Debug','Release']:
                root=BASE/'mirrors'/config
                result=subprocess.run(['dotnet',str(root/'bin/Hexalith.Platform.Composition.Tests.dll'),'-method','Hexalith.Platform.Composition.Tests.PlatformHostedPublishingTests.HostedGraphDoesNotReadTheLocalProfileAndMatchesTheMaintainedChartInput','-xml',str(pathlib.Path(tmp)/(config+'.xml'))],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
                require(result.returncode==0,result.stdout.decode(errors='replace'))
                test(pathlib.Path(tmp)/(config+'.xml'),1,1,0,label=config.lower()+'-qualified-export-graph.xml')
    print('PASS: sealed current composition/intake evidence, nonzero checks, exact identities and preserved controls; publication and hosted acceptance remain HOLD.')
if __name__=='__main__':
    try:main()
    except Exception as error:print('FAIL: '+str(error),file=sys.stderr);sys.exit(1)
