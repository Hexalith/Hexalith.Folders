import collections,hashlib,json,pathlib,shutil
W=pathlib.Path('/tmp/story117-owner-intake-20261025-4w9dr812');R=pathlib.Path('/home/administrator/projects/hexalith/folders');C=W/'current';P=W/'prior';A=R/'_bmad-output/implementation-artifacts'
def read(p):return json.loads(p.read_text())
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
audit={};roots={'current-workspace':R,'current-cache':pathlib.Path('/home/administrator/.nuget/packages'),'current-sdk':pathlib.Path(shutil.which('dotnet')).resolve().parent}
for key,row in read(P/'source-reuse-audit.json').items():
 current=dict(row);scope=row['comparison']
 if scope in roots:
  p=roots[scope]/key.split('>/',1)[1];h=sha(p) if p.is_file() else None
  current.update(observedSha256=h,status='unchanged' if h==row['expectedSha256'] else ('changed' if h else 'unavailable'),comparisonPath=str(p))
 else:current['observation']='Retained prior sealed observation; original scope retained, no current workspace eligibility implied.'
 audit[key]=current
profiles=[]
for row in read(P/'source-reuse-profiles.json'):
 keys=row['checkedBindingKeys'];fail=[{'path':k,'status':audit[k]['status'] if k in audit else 'not-bound'} for k in keys if k not in audit or audit[k]['status']!='unchanged']
 profiles.append({**row,'checkedBindings':len(keys),'byteReuseEligible':not fail,'failures':fail})
summary={'bindings':len(audit),'statuses':dict(collections.Counter(x['status'] for x in audit.values())),'byScope':{s:dict(collections.Counter(x['status'] for x in audit.values() if x['comparison']==s)) for s in sorted(set(x['comparison'] for x in audit.values()))},'profiles':len(profiles),'byteReuseEligibleProfiles':sum(x['byteReuseEligible'] for x in profiles),'priorAuditSha256':sha(P/'source-reuse-audit.json'),'priorProfilesSha256':sha(P/'source-reuse-profiles.json'),'policy':'Current workspace/cache/SDK bindings freshly rehashed; retained-only and unavailable scopes preserve earlier sealed observations. Eligibility is bounded to listed input bytes. No command rerun, current whole-tuple qualification, release or hosted acceptance inferred.'}
for f,d in [('source-reuse-audit.json',audit),('source-reuse-profiles.json',profiles),('source-reuse-summary.json',summary)]:save(C/f,d)
for f in ['source-reuse-audit.json','source-reuse-profiles.json','source-reuse-summary.json']:shutil.copy2(P/f,C/'prior-bound'/f)
b=read(C/'bounded-reuse.json');b['sourcePackageConformanceFacets']=summary;save(C/'bounded-reuse.json',b)
hp=A/'story-1-17-owner-intake-handoff-2026-10-25.json';h=read(hp);h['localQualification']['reuse']=b
md=A/'story-1-17-owner-intake-decisions-2026-10-25.md';s=md.read_text();s=s.replace('Earlier graph/build/replay outcomes retain',f'The broader source/package/conformance audit rechecks {summary["bindings"]:,} bindings across {summary["profiles"]} profiles; {summary["byteReuseEligibleProfiles"]} profiles remain eligible for bounded byte reuse. `source-reuse-audit.json` and `source-reuse-profiles.json` retain every key and failure. Earlier graph/build/replay outcomes retain');md.write_text(s);shutil.copy2(md,C/'decisions.md');h['readableDecisions']['sha256']=sha(md);h['readableDecisions']['bytes']=md.stat().st_size;save(hp,h);shutil.copy2(hp,C/'handoff.json');shutil.copy2(__file__,C/'refresh_reuse.py');print(json.dumps(summary,indent=2))
