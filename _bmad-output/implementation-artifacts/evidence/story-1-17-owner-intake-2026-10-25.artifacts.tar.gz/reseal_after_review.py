"""Reseal only amended evidence verifier and its focused test outcomes."""
import datetime,gzip,hashlib,json,pathlib,re,shutil,tarfile
W=pathlib.Path('/tmp/story117-owner-intake-20261025-4w9dr812');C=W/'current';R=pathlib.Path('/home/administrator/projects/hexalith/folders');E=R/'_bmad-output/implementation-artifacts/evidence';N='story-1-17-owner-intake-2026-10-25'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
rp=E/(N+'.json');vp=E/(N+'.verification.json');receipt=read(rp);oldverify=read(vp)
review=C/'review';review.mkdir(exist_ok=True)
shutil.copy2(rp,review/'pre-review-receipt.json');shutil.copy2(vp,review/'pre-review-verification.json');shutil.copy2(W/'review-reproductions.json',review/'reproductions.json')
for mode in ['normal','optimized']:
 log=W/('review-'+mode+'-tests.log');text=log.read_text()
 if not re.search(r'Ran 42 tests in [0-9.]+s',text) or not text.rstrip().endswith('OK'):raise RuntimeError('test outcome missing '+mode)
 shutil.copy2(log,C/('logs/'+mode+'-tests.txt'))
readme=C/'README.md';text=readme.read_text().replace('two positive controls and twenty focused negative evidence controls','42 focused tests, including complete disposable receipt replay and prior-file mutation controls')
text+='\nReview fixes bind command ownership, diagnostic routing and sources, unique compiler provenance/current input bytes, handoff tool/owner projections, completion and hosted controls, and receipt/verification claims. The six non-materialized generated documents remain excluded from source-match claims. Only the amended verifier test file was run in normal/optimized modes after these fixes. Full final-capsule replay is pending independent parent verification. Earlier replay results are retained under `review/` with their original archive identity.\n';readme.write_text(text)
shutil.copy2(__file__,C/'reseal_after_review.py')
save(review/'remediation.json',{'scope':'Evidence binding fixes only; real audit/probe outcomes, previous immutable capsule, captured source transitions and operational controls preserved.','changed':['replay.py','test_replay.py','compiled-current-inputs.json','prior-bound/current-compiled-source-audit.json','compiled-materialized-inputs/','README.md','review/','new capsule seal/receipt/verification'],'focusedTests':42,'fullFinalReplay':'Pending parent; not performed by implementation agent','preservedPreReviewArchiveSha256':receipt['archive']['sha256']})
files={str(p.relative_to(C)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(C.rglob('*')) if p.is_file() and p!=C/'members.json'}
save(C/'members.json',{'files':files});shutil.copy2(C/'members.json',E/(N+'.members.json'))
archive=E/(N+'.artifacts.tar.gz')
with archive.open('wb') as output:
 with gzip.GzipFile(fileobj=output,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tf:
   for name in sorted(set(files)|{'members.json'}):
    p=C/name;info=tf.gettarinfo(str(p),arcname=name);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
    with p.open('rb') as content:tf.addfile(info,content)
receipt['recordedAtUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
for key,path in [('archive',archive),('memberManifest',E/(N+'.members.json'))]:receipt[key].update(sha256=sha(path),bytes=path.stat().st_size)
verification={'recordId':'STORY-1-17-OWNER-INTAKE-VERIFICATION-2026-10-25','archiveSha256':sha(archive),'memberManifestSha256':sha(C/'members.json'),'handoffSha256':sha(C/'handoff.json'),'postReviewFullReplay':{'status':'Pending independent parent replay','executed':False},'retainedPreReviewReplay':{'member':'review/pre-review-verification.json','sha256':sha(review/'pre-review-verification.json'),'archiveSha256':oldverify['archiveSha256'],'scope':'Historical pre-review replay only; never relabeled as final archive replay.'},'focusedTests':{'total':42,'negativeControls':40,'counting':'Negative test methods, including subtest matrices and the complete replay mutation; two other methods are positive controls.'},'limits':'Only amended test_replay.py executed after review fixes, normal and optimized. No application build, prior suite, declaration/adoption audit or ordinary run repeated; final full replay delegated to parent.'}
for mode,flags in [('normal',[]),('optimized',['-O'])]:verification['focusedTests'][mode]={'command':['python3','-B',*flags,str(C/'test_replay.py')],'exitCode':0,'logMember':'logs/'+mode+'-tests.txt','logSha256':sha(C/('logs/'+mode+'-tests.txt'))}
save(vp,verification);receipt['verification'].update(sha256=sha(vp),bytes=vp.stat().st_size);save(rp,receipt)
print(json.dumps({'archiveSha256':sha(archive),'archiveBytes':archive.stat().st_size,'members':len(files),'receipt':str(rp),'focusedTests':'42 normal + 42 optimized passed','fullReplay':'pending parent'},indent=2))
