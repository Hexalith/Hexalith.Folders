import hashlib,importlib.util,json,pathlib,shutil,subprocess,datetime
W=pathlib.Path('/tmp/story117-owner-intake-20261025-4w9dr812');C=W/'current';R=pathlib.Path('/home/administrator/projects/hexalith/folders')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
s=importlib.util.spec_from_file_location('snapshot',W/'capture_snapshot.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
after=m.capture();save(C/'after.json',after);before=json.loads((C/'before.json').read_text());pres={}
for rel,b in before['repositories'].items():
 a=after['repositories'][rel];changed=[p for p,h in b['files'].items() if a['files'].get(p)!=h];added=[p for p in a['files'] if p not in b['files']]
 if b['revision']!=a['revision'] or b['indexEntriesSha256']!=a['indexEntriesSha256'] or b['gitlinks']!=a['gitlinks'] or b['nestedGitMarkers']!=a['nestedGitMarkers'] or changed!=(['.gitattributes'] if rel=='.' else []) or added:raise RuntimeError((rel,changed,added))
 pres[rel]={'revisionUnchanged':True,'indexEntriesUnchanged':True,'gitlinksUnchanged':True,'nestedMarkersUnchanged':True,'changedTrackedFiles':changed,'addedTrackedFiles':added,'trackedFilesCompared':len(b['files'])}
prior=json.loads((C/'prior-seal-validation.json').read_text())['boundFiles']
for b in prior:
 if sha(R/b['path'])!=b['sha256']:raise RuntimeError('prior bound drift')
sourceChecks=[]
for b in json.loads((C/'investigation-source-recheck.json').read_text()):
 p=R/b['path'];observed=sha(p) if p.is_file() else None
 if observed!=b['expectedSha256']:raise RuntimeError('investigation source drift '+str(p))
 sourceChecks.append({'path':b['path'],'sha256':observed})
for n,mod in json.loads((C/'fresh-intake.json').read_text()).items():
 for row in mod['diagnostics']:
  b=row['sourceBinding'];p=R/b['path'] if b['path'] else None
  if (sha(p) if p and p.is_file() else None)!=b['sha256']:raise RuntimeError('diagnostic source drift')
for b in json.loads((C/'compiled-source-recheck.json').read_text()):
 p=pathlib.Path(b['path'])
 if (sha(p) if p.is_file() else None)!=b['observedSha256']:raise RuntimeError('compiled source drift')
save(C/'preservation.json',{'repositories':pres,'priorReceiptBoundFilesCompared':prior,'investigationBindingsCompared':len(sourceChecks),'compiledBindingsCompared':864,'parentAndTracker':'Covered by complete root tracked-file comparison; zero changes.','originalUntrackedSpecUnchanged':sha(R/'_bmad-output/implementation-artifacts/spec-1-17-ordinary-workspace-owner-intake.md')==sha(C/'original/_bmad-output/implementation-artifacts/spec-1-17-ordinary-workspace-owner-intake.md')})
cmds=json.loads((C/'commands.json').read_text())
for name,rel in [('folders','.'),('platform','references/Hexalith.Platform'),('projects','references/Hexalith.Projects')]:
 args=['git','diff','--check'];p=subprocess.run(args,cwd=R/rel,capture_output=True);paths={}
 for channel,data in [('stdout',p.stdout),('stderr',p.stderr)]:
  out=C/f'logs/after-diff-check-{name}.{channel}.txt';out.write_bytes(data);paths[channel]={'path':str(out.relative_to(C)),'sha256':sha(out),'bytes':len(data)}
 row={'id':'after-diff-check-'+name,'command':args,'cwd':str(R/rel),'exitCode':p.returncode,**paths};cmds.append(row)
 previous=next(x for x in cmds if x['id']=='before-diff-check-'+name)
 if p.returncode!=previous['exitCode'] or paths['stdout']['sha256']!=previous['stdout']['sha256'] or paths['stderr']['sha256']!=previous['stderr']['sha256']:raise RuntimeError('diff check changed')
save(C/'commands.json',cmds)
# Bind metadata sufficient to compare exact prior controls, including historical proposals.
save(C/'completion-source-stability.json',{'checkedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'snapshot':'after.json','sourceBindingsStable':True,'repositories':len(pres),'investigationBindings':len(sourceChecks),'compiledBindings':864,'auditDiagnosticBindings':sum(len(x['diagnostics']) for x in json.loads((C/'fresh-intake.json').read_text()).values()),'priorReceiptBoundFiles':len(prior)})
shutil.copy2(__file__,C/'finalize_capture.py');print('preservation derived; only .gitattributes changed; prior bindings intact')
