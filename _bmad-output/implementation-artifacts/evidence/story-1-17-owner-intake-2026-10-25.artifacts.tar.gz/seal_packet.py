import datetime,gzip,hashlib,importlib.util,json,pathlib,shutil,subprocess,tarfile,tempfile
W=pathlib.Path('/tmp/story117-owner-intake-20261025-4w9dr812');C=W/'current';R=pathlib.Path('/home/administrator/projects/hexalith/folders');A=R/'_bmad-output/implementation-artifacts';E=A/'evidence';N='story-1-17-owner-intake-2026-10-25'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def entry(p,base):return {'path':str(p.relative_to(base)),'sha256':sha(p),'bytes':p.stat().st_size}
# Final rehash of every current source/package/SDK binding plus repository snapshot.
checked=0
for key,row in read(C/'source-reuse-audit.json').items():
 if 'comparisonPath' in row:
  p=pathlib.Path(row['comparisonPath']);h=sha(p) if p.is_file() else None
  if h!=row['observedSha256']:raise RuntimeError('final reuse input drift '+key)
  checked+=1
s=importlib.util.spec_from_file_location('snapshot',W/'capture_snapshot.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);final=m.capture();previous=read(C/'after.json')
for rel,repo in previous['repositories'].items():
 for k in ['revision','indexEntriesSha256','gitlinks','nestedGitMarkers','files']:
  if repo[k]!=final['repositories'][rel][k]:raise RuntimeError('completion source drift '+rel+' '+k)
save(C/'after.json',final);completion=read(C/'completion-source-stability.json');completion.update(checkedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),currentSourcePackageSdkBindingsRechecked=checked);save(C/'completion-source-stability.json',completion)
for b in read(C/'prior-seal-validation.json')['boundFiles']:
 if sha(R/b['path'])!=b['sha256']:raise RuntimeError('completion prior drift')
# Focused tests are rerun because seal-boundary verification changed.
for flags,label in [([], 'normal'),(['-O'], 'optimized')]:
 args=['python3','-B',*flags,str(C/'test_replay.py')];p=subprocess.run(args,cwd=C,capture_output=True,timeout=60);(C/('logs/'+label+'-tests.txt')).write_bytes(p.stdout+p.stderr)
 if p.returncode:raise RuntimeError((args,p.stdout,p.stderr))
shutil.copy2(__file__,C/'seal_packet.py')
files={str(p.relative_to(C)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(C.rglob('*')) if p.is_file() and p!=C/'members.json'}
save(C/'members.json',{'files':files});shutil.copy2(C/'members.json',E/(N+'.members.json'))
archive=E/(N+'.artifacts.tar.gz')
with archive.open('wb') as output:
 with gzip.GzipFile(fileobj=output,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tf:
   for name in sorted(set(files)|{'members.json'}):
    p=C/name;info=tf.gettarinfo(str(p),arcname=name);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
    with p.open('rb') as content:tf.addfile(info,content)
receipt={'recordId':'STORY-1-17-OWNER-INTAKE-2026-10-25','recordedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'Sealed local packet; ordinary/adoption/current tuple/release/hosted acceptance HOLD','archive':entry(archive,E),'memberManifest':entry(E/(N+'.members.json'),E),'handoff':{'path':'../story-1-17-owner-intake-handoff-2026-10-25.json','sha256':sha(C/'handoff.json')},'decisions':{'path':'../story-1-17-owner-intake-decisions-2026-10-25.json','sha256':sha(C/'decisions.json')},'readableDecisions':{'path':'../story-1-17-owner-intake-decisions-2026-10-25.md','sha256':sha(C/'decisions.md')},'priorReceipt':read(C/'handoff.json')['previousReceipt'],'outcomes':{'ordinaryExitCode':3,'ordinaryRuleId':'HXW001','declarationPasses':3,'declarationsMissing':2,'adoptionFailures':5,'adoptionDiagnostics':267,'ownerDecisions':11,'hostingCandidates':14,'applicationBuilds':0},'reuse':read(C/'source-reuse-summary.json'),'compiledBindings':{'total':864,'unchanged':836,'changed':28},'operationalControl':read(C/'handoff.json')['operationalControl'],'stagingChecks':{'total':14,'executed':0},'preservation':{'repositories':12,'trackedChanges':['.gitattributes additive preservation patterns'],'parentAndTrackerBytesUnchanged':True,'priorReceiptBoundFilesUnchanged':True},'completionSourceStability':completion,'replay':'Extract archive into a fresh directory; python3 -B replay.py --receipt /absolute/path/to/this/receipt.json (also python3 -B -O).'}
rp=E/(N+'.json');save(rp,receipt)
# Verify a fresh extraction, including external receipt and previous receipt-bound artifacts.
extract=pathlib.Path(tempfile.mkdtemp(prefix='story117-owner-intake-replay-'))
with tarfile.open(archive) as tf:tf.extractall(extract,filter='data')
checks=[]
for flags in [[],['-O']]:
 args=['python3','-B',*flags,str(extract/'replay.py'),'--receipt',str(rp)];p=subprocess.run(args,cwd=extract,capture_output=True,text=True,timeout=60);checks.append({'command':args,'cwd':str(extract),'exitCode':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
 if p.returncode:raise RuntimeError(checks[-1])
verification={'recordId':'STORY-1-17-OWNER-INTAKE-VERIFICATION-2026-10-25','archiveSha256':sha(archive),'memberManifestSha256':sha(C/'members.json'),'handoffSha256':sha(C/'handoff.json'),'checks':checks,'focusedTests':{'total':22,'negativeControls':20,'normal':{'command':['python3','-B',str(C/'test_replay.py')],'exitCode':0,'logMember':'logs/normal-tests.txt','logSha256':sha(C/'logs/normal-tests.txt')},'optimized':{'command':['python3','-B','-O',str(C/'test_replay.py')],'exitCode':0,'logMember':'logs/optimized-tests.txt','logSha256':sha(C/'logs/optimized-tests.txt')}},'limits':'Only new seal/claim checks; no prior verifier/test/graph suite rerun and no application build.'}
vp=E/(N+'.verification.json');save(vp,verification);receipt['verification']=entry(vp,E);save(rp,receipt)
print(json.dumps({'receipt':str(rp),'archiveSha256':sha(archive),'archiveBytes':archive.stat().st_size,'members':len(files),'extraction':str(extract),'normalReplay':checks[0]['exitCode'],'optimizedReplay':checks[1]['exitCode']},indent=2))
