# Story 1.17 ordinary workspace and owner intake evidence

This additive capsule records one ordinary missing-Parties refusal and ten fresh read-only declaration/adoption audits using the actual cached CLI 4.35.2. It contains no application build or runtime qualification. All owner enrollment, current tuple, publication and hosted acceptance remain HOLD.

Read `handoff.json`, `decisions.md` and `decisions.json`. Exact commands and unmodified output streams are in `commands.json` and `logs/`. All 267 adoption diagnostics retain their source hashes, classifications and owner decision links in `fresh-intake.json`. `ordinary-preflight.json` binds all eleven initialized direct checkouts to their root pins and records absent nested markers and manifest before the sole ordinary probe. The refusal is exit 3/HXW001; HXW011 and HXW009 warnings remain visible.

`before.json`, `after-audits.json`, `after.json` and `preservation.json` derive preservation from tracked bytes, canonical index entries, revisions and nested markers for all twelve repositories. The original untracked input spec is also retained. Only additive `.gitattributes` byte-preservation patterns changed tracked bytes. The Platform diff-check exit 2 is pre-existing; its before/after diagnostics are identical. Folders and Projects diff checks exit 0.

`revision-transitions.json` records earlier external revisions separately. `compiled-source-recheck.json` retains 864 bindings (836 unchanged, 28 changed). `source-reuse-audit.json` and `source-reuse-profiles.json` retain all 10,049 original source/package/conformance binding keys and 231 profiles. Current workspace, package cache and SDK files were rehashed; retained-capsule-only and unavailable inputs keep their original scope. Only 108 profiles are eligible for bounded input-byte reuse. Prior executable commands/results remain historical in the receipt-bound previous capsule; there is no current full-tuple PASS.

The prior 89 MB composition archive is referenced by hash, not copied. `prior-seal-validation.json` binds every prior receipt file and records validation of all 2,107 archive/extracted members. Its original verifier/test/graph results are reused, not rerun. `prior-bound/` contains small original receipt/handoff/reuse records with original hashes and tuples.

After extracting this archive into a fresh directory, run (substitute absolute paths):

```sh
python3 -B /tmp/extracted/replay.py --receipt /repo/_bmad-output/implementation-artifacts/evidence/story-1-17-owner-intake-2026-10-25.json
python3 -B -O /tmp/extracted/replay.py --receipt /repo/_bmad-output/implementation-artifacts/evidence/story-1-17-owner-intake-2026-10-25.json
```

The verifier checks the seal and derives the claim bindings without executing applications. `test_replay.py` contains 42 focused tests, including complete disposable receipt replay and prior-file mutation controls; it is safe under normal and optimized Python. Replay with `--receipt` also verifies the original prior receipt-bound files in the repository.

Capture scripts are retained for inspection, not for automatic execution: `capture_intake.py`, `generate_packet.py`, `refresh_reuse.py`, `finalize_capture.py`, and `seal_packet.py`. The initial capture expected exit 1 for the ordinary refusal; the real exit was 3, so capture stopped after preserving the exact output. The expectation was corrected to 3 and capture resumed at the audits; the ordinary command was not rerun. Later presentation refinements separated unsigned local diagnostic identities from signed releases and shortened readable provenance; JSON source bindings remain complete.

V1Only, unset T0, null activation authority, unchanged parent/tracker and fourteen unexecuted staging checks remain in force.

Review fixes bind command ownership, diagnostic routing and sources, unique compiler provenance/current input bytes, handoff tool/owner projections, completion and hosted controls, and receipt/verification claims. The six non-materialized generated documents remain excluded from source-match claims. Only the amended verifier test file was run in normal/optimized modes after these fixes. Full final-capsule replay is pending independent parent verification. Earlier replay results are retained under `review/` with their original archive identity.
