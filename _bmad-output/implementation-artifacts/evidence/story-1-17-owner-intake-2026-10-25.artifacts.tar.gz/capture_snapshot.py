import pathlib,subprocess,json,hashlib,datetime,sys
ROOT=pathlib.Path('/home/administrator/projects/hexalith/folders')
def git(p,*args):return subprocess.check_output(['git','-C',str(p),*args])
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def capture():
 paths=['.']+[x.split(' ',1)[1] for x in git(ROOT,'config','--file','.gitmodules','--get-regexp','^submodule\\..*\\.path$').decode().splitlines()]
 out={'capturedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repositories':{}}
 for rel in paths:
  p=ROOT/rel; files={}
  for f in git(p,'ls-files','-z').decode().split('\0'):
   if f and (p/f).is_file():files[f]=digest(p/f)
  entries=git(p,'ls-files','--stage'); links=[x for x in entries.decode().splitlines() if x.startswith('160000')]
  out['repositories'][rel]={'revision':git(p,'rev-parse','HEAD').decode().strip(),'branch':git(p,'branch','--show-current').decode().strip(),'status':git(p,'status','--short').decode(),'remotes':git(p,'remote','-v').decode(),'history':git(p,'log','-3','--format=%H %s').decode(),'gitlinks':links,'indexEntriesSha256':hashlib.sha256(entries).hexdigest(),'files':files,'nestedGitMarkers':{x.split('\t',1)[1]:(p/x.split('\t',1)[1]/'.git').exists() for x in links} if rel!='.' else {}}
 return out
if __name__=='__main__':
 out=capture();pathlib.Path(sys.argv[1]).write_text(json.dumps(out,indent=2)+'\n')
 for k,v in out['repositories'].items():print(k,v['revision'])
