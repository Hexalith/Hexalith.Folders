"""Read-only seal and semantic replay. Does not execute applications or old suites."""
import argparse, collections, copy, hashlib, json, pathlib, re, sys, tarfile
ROOT=pathlib.Path(__file__).resolve().parent
N='story-1-17-owner-intake-2026-10-25'
PN='story-1-17-composition-intake-2026-10-25'
WORKSPACE='/home/administrator/projects/hexalith/folders'
EXPECTED_TOOL_ARCHIVE='637bebd547f45b5f2012c2f43af79b9b01772f1e81af02809babe62f4aa7cf1d'
def require(ok,message):
    if not ok: raise ValueError(message)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def documents(root):
    names=['before.json','after-audits.json','after.json','ordinary-preflight.json','commands.json','fresh-intake.json','decisions.json','handoff.json','preservation.json','bounded-reuse.json','compiled-source-recheck.json','compiled-current-inputs.json','source-reuse-audit.json','source-reuse-profiles.json','source-reuse-summary.json','tool-identity.json','prior-seal-validation.json','investigation-source-recheck.json','owner-intake-investigation.json','ordinary-mapping-investigation.json','revision-transitions.json','completion-source-stability.json']
    d={n:read(root/n) for n in names}
    for c in d['commands.json']:
        if c['id']=='ordinary-missing-parties' or c['id'].endswith(('-adoption','-declaration')):d[c['stdout']['path']]=read(root/c['stdout']['path'])
    for n in ['current-compiled-source-audit.json','source-reuse-audit.json','source-reuse-profiles.json','source-reuse-summary.json',PN+'.json','story-1-17-composition-intake-handoff-2026-10-25.json']:d['prior-bound/'+n]=read(root/'prior-bound'/n)
    return d

def validate_claims(d):
    before=d['before.json']['repositories'];after=d['after.json']['repositories'];auditafter=d['after-audits.json']['repositories'];pre=d['ordinary-preflight.json'];pres=d['preservation.json'];hand=d['handoff.json'];dec=d['decisions.json'];old=d['prior-bound/story-1-17-composition-intake-handoff-2026-10-25.json'];intake=d['fresh-intake.json']
    require(len(before)==12 and set(before)==set(after)==set(auditafter),'repository coverage')
    for rel,b in before.items():
        a=after[rel];mid=auditafter[rel]
        for field in ['revision','indexEntriesSha256','gitlinks','nestedGitMarkers']:require(b[field]==a[field]==mid[field],f'{rel} {field} preservation')
        require(b['files']==mid['files'],'audit changed tracked bytes')
        changed=[p for p,h in b['files'].items() if a['files'].get(p)!=h]
        require(changed==(['.gitattributes'] if rel=='.' else []),'tracked preservation delta')
        require(set(b['files'])==set(a['files']),'tracked file set changed')
        require(pres['repositories'][rel]['changedTrackedFiles']==changed,'preservation claim mismatch')
        require(pres['repositories'][rel]['trackedFilesCompared']==len(b['files']),'preservation count')
    require(pres['originalUntrackedSpecUnchanged'],'input spec changed')
    require(pre['passed'] and pre['targetAbsent'] and not pre['nestedMarkers'],'ordinary preflight failed')
    pins={s.split('\t',1)[1]:s.split()[1] for s in before['.']['gitlinks']}
    require(len(pre['direct'])==11 and {r['path'] for r in pre['direct']}==set(pins),'preflight direct coverage')
    require(pre['rootRevision']==before['.']['revision'],'preflight root')
    for r in pre['direct']:
        require(r['gitMarkerExists'] and not r['nestedMarkers'],'direct checkout or nested marker')
        require(r['head']==r['indexPin']==r['headPin']==pins[r['path']]==before[r['path']]['revision'],'preflight pin mismatch')
        require(r['indexEntry']=='160000 '+r['head']+' 0\t'+r['path'],'preflight index entry')
    commands=d['commands.json'];cmd={r['id']:r for r in commands};require(len(cmd)==len(commands),'duplicate command')
    cli=['dotnet','/home/administrator/.nuget/packages/hexalith.builds.module.cli/4.35.2/tools/net10.0/any/Hexalith.Builds.Module.Cli.dll']
    ordinary=cmd['ordinary-missing-parties'];out=d[ordinary['stdout']['path']]
    require(ordinary['command']==cli+['run','--manifest','references/Hexalith.Parties/module/hexalith.module-manifest.v2.json','--mode','source','--output','json'],'ordinary command altered')
    require(ordinary['cwd']==WORKSPACE+'/references/Hexalith.Platform' and ordinary['timeoutSeconds']==45 and not ordinary['timedOut'],'ordinary execution bounds')
    require(ordinary['exitCode']==3 and out['status']=='failed' and out['outcome']['ruleId']=='HXW001','ordinary refusal outcome')
    require([r['ruleId'] for r in out['diagnostics']]==['HXW001','HXW011','HXW011','HXW009'],'ordinary diagnostics incomplete')
    require('unavailable after checkout' in out['diagnostics'][0]['message'],'missing manifest refusal')
    require(dec['ordinaryDiagnostics']==out['diagnostics'] and dec['ordinaryCommand']==ordinary,'ordinary decision binding')
    require(set(intake)=={'Folders','Projects','EventStore','Tenants','Memories'},'five-module audit coverage')
    ids={r['id'] for r in dec['decisions']};require(len(ids)==11 and len(dec['decisions'])==11,'decision coverage')
    count=0
    for name,v in intake.items():
        label=name.lower();decl=cmd[label+'-declaration'];adopt=cmd[label+'-adoption'];raw=d[adopt['stdout']['path']];rawdecl=d[decl['stdout']['path']]
        repo=d['owner-intake-investigation.json']['modules'][name]['repository']
        for c,is_adoption in [(decl,False),(adopt,True)]:
            require(c['command']==cli+['validate','--manifest','module/hexalith.module-manifest.v2.json']+(['--adoption'] if is_adoption else [])+['--output','json'],'audit command')
            require(not c['timedOut'] and c['timeoutSeconds']==60,'audit timeout')
            require(c['cwd']==str(pathlib.Path(WORKSPACE)/repo),'audit owning repository cwd')
        require(decl['exitCode']==v['declarationExitCode']==(1 if name in ('Folders','Projects') else 0),'declaration outcome')
        require(adopt['exitCode']==v['adoptionExitCode']==1 and raw['status']=='failed','adoption outcome')
        rows=v['diagnostics'];require([r['diagnostic'] for r in rows]==raw['diagnostics'],'diagnostic dropped or rewritten')
        require(v['declarationDiagnostics']==rawdecl['diagnostics'],'declaration diagnostics changed')
        require(v['requirements']==raw['adoption'] and v['scope']==raw['adoptionScope'],'audit requirements/scope changed')
        require(v['diagnosticCount']==len(rows) and v['countsByRequirement']==dict(collections.Counter(x['field'] for x in raw['diagnostics'])),'diagnostic totals')
        for i,row in enumerate(rows):
            source=row['diagnostic'].get('source');scope='historical-evidence' if source and ('evidence/' in source or source.startswith('_bmad-output/')) else ('test-or-test-helper' if source and (source.startswith(('tests/','test/')) or '/tests/' in source) else 'current-source-build-or-enrollment')
            require(row['classification']==scope and row['ordinal']==i and row['module']==name,'row classification')
            routes={'declaration':[label+'-declaration-registration'] if name in ('Folders','Projects') else ['minimum-dependency-policy-conflict'],'gitlinks':['ordinary-platform-workspace-map','ordinary-source-selection-and-complete-diagnostics'],'tool-pin':['accepted-tool-and-current-tuple'],'hosting-inventory':[label+'-hosting-accountability'],'dependency-selectors':['ordinary-source-selection-and-complete-diagnostics'],'dapr-subscriptions':[label+'-hosting-accountability','ordinary-source-selection-and-complete-diagnostics']}
            expected_routes=routes.get(row['diagnostic'].get('field'))
            require(expected_routes and row['decisionIds']==expected_routes and set(expected_routes)<=ids and row['disposition'].startswith('HOLD'),'row decision routing')
            b=row['sourceBinding'];prefix='' if repo=='.' else repo.rstrip('/')+'/'
            require(b['path']==(prefix+source if source else None),'diagnostic source path')
            expected_hash=before[repo]['files'].get(source) if source else None
            require(b['sha256']==expected_hash,'diagnostic source hash')
            require(b['exists']==bool(source and source in before[repo]['files']),'diagnostic existence')
        history=d['owner-intake-investigation.json']['modules'][name]['historicalAdoption']['diagnostics']
        require(v['addedSincePrior']==[x for x in raw['diagnostics'] if x not in history] and v['removedSincePrior']==[x for x in history if x not in raw['diagnostics']],'diagnostic delta')
        count+=len(rows)
    require(count==267 and dec['freshAudits']==intake,'complete intake packet')
    require(sum(len(v) for v in dec['hostingCandidates'].values())==dec['hostingCandidateCount']==14,'hosting inventory candidate coverage')
    for name,rows in dec['hostingCandidates'].items():
        require(rows==d['owner-intake-investigation.json']['modules'][name]['hostingCandidates'],'hosting candidate changed')
        for r in rows:require(r['accountableOwner'] is None and r['retirementDecision'] is None and not r['consumerInventoryComplete'],'fabricated hosting accountability')
    for entry in dec['decisions']:
        require(entry['acceptance'] is None and entry['supplyingOwner'] and entry['dependentChecks'],'owner decision improperly accepted')
        require(entry.get('targetArtifacts',entry.get('exactArtifacts')),'missing concrete artifact request')
    originals=[d['ordinary-mapping-investigation.json']['decisionPacket']]+d['owner-intake-investigation.json']['decisionPackets']
    for expected,actual in zip(originals,dec['decisions']):
        for k,v in expected.items():require(actual[k]==v,'owner decision provenance changed')
    for control in ['operationalControl','stagingChecks','parentStatus','trackerStatus']:require(hand[control]==old[control],'operational control changed')
    require(dec['operationalControl']==old['operationalControl'] and not dec['retirementAuthorized'] and not dec['runtimeDependenciesAdded'] and not dec['accountabilityInferred'],'decision authority overclaim')
    require(hand['hostedAcceptance']['status']=='HOLD; not attempted' and hand['hostedAcceptance']['stagingChecks']==hand['stagingChecks']=={'total':14,'executed':0},'hosted acceptance overclaim')
    expected_requests=[{'id':e['id'],'supplyingOwner':e['supplyingOwner'],'status':'HOLD','requiredArtifacts':e.get('targetArtifacts',e.get('exactArtifacts',[])),'dependentChecks':e['dependentChecks']} for e in dec['decisions']]
    require(hand['unresolvedOwnerDecisions']==expected_requests,'handoff owner-request projection')
    require(hand['localQualification']['applicationBuildsExecuted']==0 and not hand['releasedIdentities']['currentTupleAccepted'],'qualification overclaim')
    require(hand['sourceTuple']==dec['sourceTuple']=={r:{'revision':v['revision'],'indexEntriesSha256':v['indexEntriesSha256'],'gitlinks':v['gitlinks']} for r,v in before.items()},'source tuple mismatch')
    for name,packages in old['retainedPackageIdentities'].items():
        require(hand['releasedIdentities']['packages'][name]==[p for p in packages if 'diagnostic' not in p['qualification']],'signed release identity changed')
        require(hand['localQualification']['unsignedDiagnosticPackages'][name]==[p for p in packages if 'diagnostic' in p['qualification']],'diagnostic package identity changed')
    tool=d['tool-identity.json'];require(tool['archiveSha256']==EXPECTED_TOOL_ARCHIVE and tool['version']=='4.35.2' and tool['source']=='4248b8c70cb35ba79fdd7e4dd63049d4c73211a0','accepted tool identity')
    require({k:hand['releasedIdentities']['tool'][k] for k in ['version','source','archiveSha256','scope']}=={k:tool[k] for k in ['version','source','archiveSha256','scope']},'handoff tool identity')
    require(hand['releasedIdentities']['tool']['identityEvidence']['installedFilesCompared']==len(tool['members']),'tool member count')
    reuse=d['compiled-source-recheck.json'];summary=d['bounded-reuse.json'];require(len(reuse)==864,'compiled binding coverage')
    prior_compile=d['prior-bound/current-compiled-source-audit.json'];prior_docs=prior_compile['documents']
    require(all(not r['path'].startswith('/_/') or r['pdb']=='binaries/Release/Hexalith.Builds.Tooling.pdb' for r in prior_docs),'unsupported compiler source mapping')
    prior_map={(r['pdb'],WORKSPACE+'/references/Hexalith.Builds/'+r['path'][3:] if r['path'].startswith('/_/') else r['path']):r for r in prior_docs if r['currentSha256'] is not None}
    input_capture=d['compiled-current-inputs.json'];current_map={(r['priorPdb'],r['path']):r for r in input_capture['inputs']}
    reuse_map={(r['priorPdb'],r['path']):r for r in reuse}
    require(len(prior_docs)==len({(r['pdb'],r['path']) for r in prior_docs})==870,'prior compiled identity uniqueness')
    require(len(reuse_map)==len(reuse)==len(current_map)==len(input_capture['inputs'])==len(prior_map)==864 and set(reuse_map)==set(prior_map)==set(current_map),'compiled identity coverage/uniqueness')
    require(input_capture['unmaterializedGeneratedDocuments']==[r for r in prior_docs if r['currentSha256'] is None] and len(input_capture['unmaterializedGeneratedDocuments'])==6 and input_capture['scope']==prior_compile['scope'],'generated-source limitations')
    for key,row in reuse_map.items():
        captured=current_map[key]
        require(row['expectedSha256']==prior_map[key]['compilerSha256'],'compiled prior provenance')
        require(row['observedSha256']==captured['observedSha256'],'compiled current input binding')
        if 'repository' in captured:
            require(captured['snapshot']=='before.json' and row['observedSha256']==before[captured['repository']]['files'][captured['relativePath']]==after[captured['repository']]['files'][captured['relativePath']],'compiled tracked snapshot binding')
        else:require(captured.get('member') and captured['scope']=='materialized generated/cache bytes only; no revision or whole-tuple qualification','compiled materialized input scope')
        require(row['matches']==(row['expectedSha256']==row['observedSha256']),'compiled comparison')
    require(summary['unchanged']==sum(r['matches'] for r in reuse)==836 and summary['changedOrMissing']==28 and not summary['currentFullTupleQualified'],'compiled eligibility')
    full=d['source-reuse-audit.json'];oldfull=d['prior-bound/source-reuse-audit.json'];profiles=d['source-reuse-profiles.json'];oldprofiles=d['prior-bound/source-reuse-profiles.json'];s=d['source-reuse-summary.json']
    require(len(full)==10049 and set(full)==set(oldfull) and len(profiles)==231,'source/package/conformance reuse coverage')
    for key,row in full.items():
        prev=oldfull[key];require(row['expectedSha256']==prev['expectedSha256'] and row['comparison']==prev['comparison'],'reuse original input changed')
        require(row['status']==('unchanged' if row['observedSha256']==row['expectedSha256'] else ('changed' if row['observedSha256'] else 'unavailable')),'reuse comparison status')
        if row['comparison'] in ['retained-capsule-only','unretained-temporary-input']:require(row['observedSha256']==prev['observedSha256'],'retained scope promoted')
        if row['comparison']=='current-workspace':
            path=key.removeprefix('<workspace>/');repo='.';local=path
            for candidate in after:
                if candidate!='.' and path.startswith(candidate+'/'):repo=candidate;local=path[len(candidate)+1:];break
            if local in after[repo]['files']:require(row['observedSha256']==after[repo]['files'][local],'reuse workspace snapshot binding')
    for p,oldp in zip(profiles,oldprofiles):
        require(p['profile']==oldp['profile'] and p['checkedBindingKeys']==oldp['checkedBindingKeys'],'profile bindings changed')
        keys=p['checkedBindingKeys'];fail=[{'path':k,'status':full[k]['status'] if k in full else 'not-bound'} for k in keys if k not in full or full[k]['status']!='unchanged']
        require(p['checkedBindings']==len(keys) and p['failures']==fail and p['byteReuseEligible']==(not fail),'profile eligibility')
    require(s['statuses']==dict(collections.Counter(x['status'] for x in full.values())) and s['byteReuseEligibleProfiles']==sum(p['byteReuseEligible'] for p in profiles),'reuse summary')
    require(summary['sourcePackageConformanceFacets']==s and hand['localQualification']['reuse']==summary,'handoff reuse binding')
    transitions=d['revision-transitions.json'];require(len(transitions)==12,'transition coverage')
    for t in transitions:require(t['executionRevision']==before[t['repository']]['revision'] and t['executionIndexSha256']==before[t['repository']]['indexEntriesSha256'] and t['stableSinceExternalUpdate'],'external transition mismatch')
    require(d['prior-seal-validation.json']['verifiedFileMembers']==2107,'prior seal coverage')
    prior_receipt=d['prior-bound/'+PN+'.json'];prior_base=pathlib.PurePosixPath('_bmad-output/implementation-artifacts/evidence')
    required_prior_paths={str(prior_base/(PN+'.json')),str(prior_base/(PN+'.parent-verification.json'))}
    for field in ['archive','memberManifest','handoff','verification']:
        path=pathlib.Path(WORKSPACE)/prior_base/prior_receipt[field]['path'];required_prior_paths.add(str(path.resolve().relative_to(WORKSPACE)))
    prior_bound=d['prior-seal-validation.json']['boundFiles']
    require(len(prior_bound)==len(required_prior_paths)==6 and {b['path'] for b in prior_bound}==required_prior_paths,'complete previous receipt-bound coverage')
    require(all(b['sha256']==before['.']['files'][b['path']] for b in prior_bound),'previous receipt-bound snapshot identity')
    stability=d['completion-source-stability.json']
    expected_stability={'snapshot':'after.json','sourceBindingsStable':True,'repositories':len(before),'investigationBindings':len(d['investigation-source-recheck.json']),'compiledBindings':len(reuse),'auditDiagnosticBindings':count,'priorReceiptBoundFiles':len(d['prior-seal-validation.json']['boundFiles']),'currentSourcePackageSdkBindingsRechecked':sum('comparisonPath' in row for row in full.values())}
    require({k:stability.get(k) for k in expected_stability}==expected_stability and isinstance(stability.get('checkedAtUtc'),str) and stability['checkedAtUtc']>=d['after.json']['capturedAtUtc'],'completion source stability binding')
    require(pres['priorReceiptBoundFilesCompared']==d['prior-seal-validation.json']['boundFiles'] and pres['investigationBindingsCompared']==expected_stability['investigationBindings'] and pres['compiledBindingsCompared']==len(reuse),'preservation source coverage')
    for name in ['folders','projects','platform']:
        a=cmd['before-diff-check-'+name];b=cmd['after-diff-check-'+name]
        require(a['exitCode']==b['exitCode']==(2 if name=='platform' else 0),'diff check status')
        for channel in ['stdout','stderr']:require(a[channel]['sha256']==b[channel]['sha256'],'diff check diagnostics changed')

def receipt_claims(d):
    cmd={c['id']:c for c in d['commands.json']};intake=d['fresh-intake.json'];hand=d['handoff.json'];dec=d['decisions.json'];before=d['before.json']['repositories'];after=d['after.json']['repositories']
    return {'outcomes':{'ordinaryExitCode':cmd['ordinary-missing-parties']['exitCode'],'ordinaryRuleId':d[cmd['ordinary-missing-parties']['stdout']['path']]['outcome']['ruleId'],'declarationPasses':sum(x['declarationExitCode']==0 for x in intake.values()),'declarationsMissing':sum(x['declarationExitCode']!=0 for x in intake.values()),'adoptionFailures':sum(x['adoptionExitCode']!=0 for x in intake.values()),'adoptionDiagnostics':sum(len(x['diagnostics']) for x in intake.values()),'ownerDecisions':len(dec['decisions']),'hostingCandidates':sum(len(x) for x in dec['hostingCandidates'].values()),'applicationBuilds':hand['localQualification']['applicationBuildsExecuted']},'operationalControl':hand['operationalControl'],'stagingChecks':hand['stagingChecks'],'preservation':{'repositories':len(before),'trackedChanges':['.gitattributes additive preservation patterns'],'parentAndTrackerBytesUnchanged':all(h==after[r]['files'].get(p) for r,v in before.items() for p,h in v['files'].items() if not (r=='.' and p=='.gitattributes')),'priorReceiptBoundFilesUnchanged':True},'reuse':d['source-reuse-summary.json'],'compiledBindings':{'total':len(d['compiled-source-recheck.json']),'unchanged':sum(x['matches'] for x in d['compiled-source-recheck.json']),'changed':sum(not x['matches'] for x in d['compiled-source-recheck.json'])},'completionSourceStability':d['completion-source-stability.json'],'priorReceipt':hand['previousReceipt']}
def validate_receipt_claims(receipt,d):
    for key,value in receipt_claims(d).items():require(receipt.get(key)==value,'receipt claim '+key)
def validate_verification(v,receipt,root):
    for vk,rk in [('archiveSha256','archive'),('memberManifestSha256','memberManifest'),('handoffSha256','handoff')]:require(v.get(vk)==receipt[rk]['sha256'],'verification identity '+vk)
    tests=v['focusedTests'];require(isinstance(tests['total'],int) and 0<tests['negativeControls']<tests['total'],'verification test counts')
    for mode in ['normal','optimized']:
        test=tests[mode];require(test['exitCode']==0 and test['logMember']=='logs/'+mode+'-tests.txt','verification test result')
        logfile=regular_member(root,test['logMember']);require(sha(logfile)==test['logSha256'],'verification retained test-log binding')
        content=logfile.read_text();require(re.search(r'Ran '+str(tests['total'])+r' tests in [0-9.]+s',content) is not None and content.rstrip().endswith('OK'),'verification retained test outcome')
        command=test['command'];require(command[:2]==['python3','-B'] and ('-O' in command)==(mode=='optimized') and command[-1].endswith('/test_replay.py'),'verification test command')

def safe_name(name):
    path=pathlib.PurePosixPath(name)
    require(bool(name) and not path.is_absolute() and '..' not in path.parts and '.' not in path.parts and str(path)==name and '\\' not in name,'unsafe member path')
    return path
def regular_member(root,name):
    path=safe_name(name);p=root/path
    require(p.is_file() and not p.is_symlink(),'member is not a regular non-symlink file')
    require(p.resolve().is_relative_to(root.resolve()),'member escapes capsule')
    require(not any(parent.is_symlink() for parent in p.parents if parent!=root and parent.is_relative_to(root)),'member has symlink parent')
    return p
def file_members(root):
    paths=list(root.rglob('*'))
    require(not any(p.is_symlink() for p in paths),'capsule contains symlink')
    return {str(p.relative_to(root)) for p in paths if p.is_file() and p!=root/'members.json'}
def archive_members(tf):
    members=tf.getmembers();names=[m.name for m in members]
    require(len(names)==len(set(names)),'duplicate archive member')
    for m in members:safe_name(m.name);require(m.isfile(),'non-regular archive member')
    return members

def verify(root,receipt_path=None):
    regular_member(root,'members.json')
    manifest=read(root/'members.json')['files']
    actual=file_members(root)
    require(actual==set(manifest),'capsule member set')
    for name,b in manifest.items():
        p=regular_member(root,name);require(sha(p)==b['sha256'] and p.stat().st_size==b['bytes'],'member hash: '+name)
    d=documents(root);validate_claims(d)
    prior_members=read(root/'prior-bound'/(PN+'.members.json'))['files']
    for name in ['current-compiled-source-audit.json','source-reuse-audit.json','source-reuse-profiles.json','source-reuse-summary.json']:
        require(sha(root/'prior-bound'/name)==prior_members[name]['sha256'],'prior reuse manifest binding')
    for b in d['prior-seal-validation.json']['boundFiles']:
        if not b['path'].endswith('.tar.gz'):require(sha(root/'prior-bound'/pathlib.Path(b['path']).name)==b['sha256'],'prior retained file binding')
    require((root/'gitattributes.after').read_bytes().startswith((root/'original/.gitattributes').read_bytes()),'attributes not additive')
    require(sha(root/'gitattributes.after')==d['after.json']['repositories']['.']['files']['.gitattributes'],'attributes snapshot binding')
    for command in d['commands.json']:
        for stream in ['stdout','stderr']:
            b=command[stream];require(sha(root/b['path'])==b['sha256'],'command stream binding')
    for row in d['investigation-source-recheck.json']:
        require(row['expectedSha256']==row['observedSha256'],'investigation source drift')
        if row['snapshot']:require(sha(root/row['snapshot'])==row['snapshotSha256']==row['expectedSha256'],'investigation retained binding')
    for name in ['ordinaryInvestigation','ownerInvestigation']:
        b=d['decisions.json']['sourceEvidence'][name];require(sha(root/b['member'])==b['sha256'],'decision source evidence binding')
    require(d['decisions.json']['sourceEvidence']['recheckedSources']==d['investigation-source-recheck.json'],'decision recheck coverage')
    for member,key in [('decisions.json','decisions'),('decisions.md','readableDecisions')]:require(sha(root/member)==d['handoff.json'][key]['sha256'],'handoff decision binding')
    for row in d['compiled-current-inputs.json']['inputs']:
        if 'member' in row:require(sha(regular_member(root,row['member']))==row['observedSha256'],'compiled materialized byte binding')
    require(sha(root/'tool-identity.json')==d['handoff.json']['releasedIdentities']['tool']['identityEvidence']['sha256'],'tool evidence reference')
    if receipt_path:
        receipt_path=receipt_path.resolve();receipt=read(receipt_path);base=receipt_path.parent;repo=base.parents[2]
        for key in ['archive','memberManifest','handoff','decisions','readableDecisions','verification']:
            b=receipt[key];p=base/b['path'];require(sha(p)==b['sha256'],'external receipt '+key)
            if 'bytes' in b:require(p.stat().st_size==b['bytes'],'external receipt size '+key)
            if key=='verification':require('bytes' in b,'verification size absent')
        require(sha(root/'members.json')==receipt['memberManifest']['sha256'],'archive manifest reference')
        require(sha(root/'handoff.json')==receipt['handoff']['sha256'],'external handoff copy')
        require(sha(root/'decisions.json')==receipt['decisions']['sha256'],'external decisions copy')
        with tarfile.open(base/receipt['archive']['path']) as tf:
            members=archive_members(tf);names={m.name for m in members};require(names==set(manifest)|{'members.json'},'archive member set')
            for m in members:
                require(m.isfile(),'archive non-file entry')
                require(hashlib.sha256(tf.extractfile(m).read()).hexdigest()==sha(root/m.name),'archive/extracted member mismatch')
        validate_receipt_claims(receipt,d)
        validate_verification(read(base/receipt['verification']['path']),receipt,root)
        for b in d['prior-seal-validation.json']['boundFiles']:require((repo/b['path']).is_file() and sha(repo/b['path'])==b['sha256'],'previous receipt-bound file drift')
    return {'members':len(manifest),'adoptionDiagnostics':267,'decisions':11,'hostingCandidates':14,'profiles':231,'currentFullTupleQualified':False}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--receipt',type=pathlib.Path);args=parser.parse_args()
    try:print(json.dumps({'status':'PASS','checks':verify(ROOT,args.receipt),'limit':'Evidence/claim replay only; ordinary adoption, current tuple, release and hosted acceptance remain HOLD.'}))
    except (ValueError,KeyError,OSError,TypeError) as e:print('FAIL: '+str(e),file=sys.stderr);sys.exit(1)
