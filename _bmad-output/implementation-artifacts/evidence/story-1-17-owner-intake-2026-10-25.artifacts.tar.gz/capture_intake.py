import datetime, hashlib, importlib.util, json, os, pathlib, shutil, subprocess, sys, time, zipfile
W=pathlib.Path('/tmp/story117-owner-intake-20261025-4w9dr812'); R=pathlib.Path('/home/administrator/projects/hexalith/folders'); C=W/'current'; C.mkdir(exist_ok=True)
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save(p,d): p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n')
def git(p,*args):return subprocess.check_output(['git','-C',str(p),*args]).decode().strip()
spec=importlib.util.spec_from_file_location('snap',W/'capture_snapshot.py');snap=importlib.util.module_from_spec(spec);spec.loader.exec_module(snap)
before=snap.capture();save(C/'before.json',before)
for f in ['baseline.json','current-baseline.json','latest-source-comparison.json','compiled-source-reuse.json','prior-source-comparison.json','capture_snapshot.py','ordinary-mapping-investigation.json','owner-intake-investigation.json']:
 shutil.copy2(W/f,C/f)
for name in ['ordinary-mapping-sources','intake-owner-sources']:shutil.copytree(W/name,C/name,dirs_exist_ok=True)
for f in ['.gitattributes','_bmad-output/implementation-artifacts/spec-1-17-ordinary-workspace-owner-intake.md']:
 p=C/'original'/f;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/f,p)
bindings=[]
for f,key in [('ordinary-mapping-investigation.json','retainedPath'),('owner-intake-investigation.json','snapshot')]:
 d=json.loads((C/f).read_text())
 for row in d['sources']:
  p=R/row['path']; observed=sha(p) if p.is_file() else None
  retained=C/row.get(key,''); exists=row.get('exists', True)
  check={'investigation':f,'path':row['path'],'expectedSha256':row.get('sha256'),'observedSha256':observed,'snapshot':row.get(key),'snapshotSha256':sha(retained) if retained.is_file() else None}
  if observed!=row.get('sha256') or (row.get(key) and check['snapshotSha256']!=row.get('sha256')): raise RuntimeError(check)
  bindings.append(check)
save(C/'investigation-source-recheck.json',bindings)
cache=pathlib.Path('/home/administrator/.nuget/packages/hexalith.builds.module.cli/4.35.2'); archive=cache/'hexalith.builds.module.cli.4.35.2.nupkg'; accepted='637bebd547f45b5f2012c2f43af79b9b01772f1e81af02809babe62f4aa7cf1d'
if sha(archive)!=accepted: raise RuntimeError('tool archive drift')
identity={'version':'4.35.2','source':'4248b8c70cb35ba79fdd7e4dd63049d4c73211a0','archivePath':str(archive),'archiveSha256':sha(archive),'members':{},'scope':'Accepted released identity only; current source/catalog/composition tuple unaccepted.'}
with zipfile.ZipFile(archive) as z:
 for name in z.namelist():
  if not name.startswith('tools/net10.0/any/') or name.endswith('/'):continue
  b=z.read(name); installed=cache/name
  if not installed.is_file() or sha(installed)!=hashlib.sha256(b).hexdigest(): raise RuntimeError('installed tool differs '+name)
  identity['members'][name]={'sha256':sha(installed),'bytes':len(b)}
save(C/'tool-identity.json',identity)
commands=[]
def run(name,args,cwd,timeout=60):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
 try:
  p=subprocess.run(args,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout); code=p.returncode; out=p.stdout; err=p.stderr; timed=False
 except subprocess.TimeoutExpired as e: code=None;out=e.stdout or b'';err=e.stderr or b'';timed=True
 paths={}
 for channel,b in [('stdout',out),('stderr',err)]:
  rel=f'logs/{name}.{channel}.txt'; dest=C/rel;dest.parent.mkdir(exist_ok=True);dest.write_bytes(b);paths[channel]={'path':rel,'sha256':sha(dest),'bytes':len(b)}
 row={'id':name,'command':args,'cwd':str(cwd),'startedAtUtc':start,'seconds':round(time.monotonic()-t,3),'timeoutSeconds':timeout,'timedOut':timed,'exitCode':code,**paths};commands.append(row);save(C/'commands.json',commands);return row
for name,p in [('folders',R),('platform',R/'references/Hexalith.Platform'),('projects',R/'references/Hexalith.Projects')]:run('before-diff-check-'+name,['git','diff','--check'],p)
# Every root path must already be initialized and equal both HEAD and index pins.
root_entries={x.split('\t',1)[1]:x.split()[1] for x in before['repositories']['.']['gitlinks']}
paths=[x.split(' ',1)[1] for x in git(R,'config','--file','.gitmodules','--get-regexp',r'^submodule\..*\.path$').splitlines()]
pre={'capturedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rootRevision':git(R,'rev-parse','HEAD'),'direct':[],'targetManifest':'references/Hexalith.Platform/references/Hexalith.Parties/module/hexalith.module-manifest.v2.json','nestedMarkers':[]}
for rel in paths:
 p=R/rel
 nested=[]
 for base,dirs,files in os.walk(p,followlinks=False):
  if pathlib.Path(base)==p:dirs[:]=[d for d in dirs if d!='.git'];continue
  if '.git' in dirs or '.git' in files:nested.append(str((pathlib.Path(base)/'.git').relative_to(R)))
  dirs[:]=[d for d in dirs if d!='.git']
 head=git(p,'rev-parse','HEAD');entry=git(R,'ls-files','--stage','--',rel);headPin=git(R,'ls-tree','HEAD','--',rel).split()[2]
 pre['direct'].append({'path':rel,'gitMarkerExists':(p/'.git').exists(),'head':head,'indexEntry':entry,'indexPin':root_entries.get(rel),'headPin':headPin,'nestedMarkers':nested});pre['nestedMarkers']+=nested
pre['targetAbsent']=not os.path.lexists(R/pre['targetManifest'])
pre['passed']=pre['targetAbsent'] and not pre['nestedMarkers'] and len(paths)==11 and all(x['gitMarkerExists'] and x['head']==x['indexPin']==x['headPin'] and x['indexEntry'].startswith('160000 '+x['head']+' 0\t') for x in pre['direct']) and pre['rootRevision']==before['repositories']['.']['revision']
save(C/'ordinary-preflight.json',pre)
if not pre['passed']:raise RuntimeError('ordinary preflight refused; no ordinary run executed')
cli=['dotnet',str(cache/'tools/net10.0/any/Hexalith.Builds.Module.Cli.dll')]
row=run('ordinary-missing-parties',cli+['run','--manifest','references/Hexalith.Parties/module/hexalith.module-manifest.v2.json','--mode','source','--output','json'],R/'references/Hexalith.Platform',45)
if row['timedOut'] or row['exitCode']!=3: raise RuntimeError('unexpected ordinary result '+str(row))
print('ordinary',row['exitCode'],(C/row['stdout']['path']).read_text(),flush=True)
for name,rel in [('Folders','.'),('Projects','references/Hexalith.Projects'),('EventStore','references/Hexalith.EventStore'),('Tenants','references/Hexalith.Tenants'),('Memories','references/Hexalith.Memories')]:
 for adoption in [False,True]:
  label=name.lower()+('-adoption' if adoption else '-declaration');row=run(label,cli+['validate','--manifest','module/hexalith.module-manifest.v2.json']+(['--adoption'] if adoption else [])+['--output','json'],R/rel,60)
  d=json.loads((C/row['stdout']['path']).read_text()); print(label,row['exitCode'],list(d),len(d.get('diagnostics',[])),flush=True)
  if row['timedOut']: raise RuntimeError('audit timeout')
save(C/'after-audits.json',snap.capture())
shutil.copy2(__file__,C/'capture_intake.py')
print('capture complete',flush=True)
