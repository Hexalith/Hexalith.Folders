"""Focused negative evidence controls; no application execution."""
import copy,unittest,tempfile,pathlib,tarfile,io,json,shutil,hashlib
import replay
class ClaimBindingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.original=replay.documents(replay.ROOT)
    def reject(self,change):
        d=copy.deepcopy(self.original);change(d)
        with self.assertRaises(ValueError):replay.validate_claims(d)
    def test_valid_claims(self):replay.validate_claims(self.original)
    def test_adoption_wrong_owning_cwd(self):self.reject(lambda d:next(c for c in d['commands.json'] if c['id']=='folders-adoption').update(cwd='/tmp/wrong-repository'))
    def test_declaration_wrong_owning_cwd(self):self.reject(lambda d:next(c for c in d['commands.json'] if c['id']=='projects-declaration').update(cwd='/tmp/wrong-repository'))
    def test_empty_diagnostic_decisions(self):self.reject(lambda d:d['fresh-intake.json']['Folders']['diagnostics'][3].update(decisionIds=[]))
    def test_unrelated_diagnostic_decisions(self):self.reject(lambda d:d['fresh-intake.json']['Folders']['diagnostics'][3].update(decisionIds=['minimum-dependency-policy-conflict']))
    def test_source_binding_omitted(self):self.reject(lambda d:d['fresh-intake.json']['Folders']['diagnostics'][3]['sourceBinding'].update(path=None,sha256=None,exists=False))
    def test_fabricated_equal_compiler_hashes(self):self.reject(lambda d:d['compiled-source-recheck.json'][0].update(expectedSha256='0'*64,observedSha256='0'*64,matches=True))
    def test_duplicated_compiled_identity(self):self.reject(lambda d:d['compiled-source-recheck.json'].__setitem__(1,d['compiled-source-recheck.json'][0].copy()))
    def test_compiled_observation_diverges_from_capture(self):self.reject(lambda d:d['compiled-source-recheck.json'][0].update(observedSha256='0'*64,matches=False))
    def test_generated_limit_promoted(self):self.reject(lambda d:d['compiled-current-inputs.json'].update(unmaterializedGeneratedDocuments=[]))
    def test_handoff_tool_mismatch(self):self.reject(lambda d:d['handoff.json']['releasedIdentities']['tool'].update(version='999.0.0'))
    def test_owner_requests_removed(self):self.reject(lambda d:d['handoff.json'].update(unresolvedOwnerDecisions=[]))
    def test_stability_false(self):self.reject(lambda d:d['completion-source-stability.json'].update(sourceBindingsStable=False))
    def test_stability_wrong_count(self):self.reject(lambda d:d['completion-source-stability.json'].update(compiledBindings=0))
    def test_stability_wrong_snapshot(self):self.reject(lambda d:d['completion-source-stability.json'].update(snapshot='before.json'))
    def test_hosted_acceptance_promoted(self):self.reject(lambda d:d['handoff.json']['hostedAcceptance'].update(status='Accepted',stagingChecks={'total':14,'executed':14}))
    def test_receipt_claim_forgery(self):
        valid=replay.receipt_claims(self.original)
        for section,key,value in [('operationalControl','publicationAuthorized',True),('outcomes','ordinaryExitCode',0),('outcomes','applicationBuilds',99),('stagingChecks','executed',14),('preservation','parentAndTrackerBytesUnchanged',False),('compiledBindings','changed',0),('reuse','bindings',0),('completionSourceStability','sourceBindingsStable',False)]:
            with self.subTest(section=section,key=key):
                receipt=copy.deepcopy(valid);receipt[section][key]=value
                with self.assertRaisesRegex(ValueError,'receipt claim '+section):replay.validate_receipt_claims(receipt,self.original)
    def test_missing_direct_checkout(self):self.reject(lambda d:d['ordinary-preflight.json']['direct'][0].update(gitMarkerExists=False))
    def test_changed_checkout_pin(self):self.reject(lambda d:d['ordinary-preflight.json']['direct'][0].update(head='0'*40))
    def test_present_target_manifest(self):self.reject(lambda d:d['ordinary-preflight.json'].update(targetAbsent=False))
    def test_nested_marker(self):self.reject(lambda d:d['ordinary-preflight.json']['direct'][0].update(nestedMarkers=['unexpected/.git']))
    def test_dropped_identity_warning(self):self.reject(lambda d:d['logs/ordinary-missing-parties.stdout.txt']['diagnostics'].pop())
    def test_wrong_cli_exit(self):self.reject(lambda d:next(c for c in d['commands.json'] if c['id']=='ordinary-missing-parties').update(exitCode=0))
    def test_dropped_historical_diagnostic(self):self.reject(lambda d:d['fresh-intake.json']['Folders']['diagnostics'].pop())
    def test_wrong_diagnostic_source_hash(self):self.reject(lambda d:d['fresh-intake.json']['Folders']['diagnostics'][3]['sourceBinding'].update(sha256='0'*64))
    def test_invented_hosting_owner(self):self.reject(lambda d:d['decisions.json']['hostingCandidates']['Folders'][0].update(accountableOwner='unapproved'))
    def test_invented_acceptance(self):self.reject(lambda d:d['decisions.json']['decisions'][0].update(acceptance='accepted'))
    def test_tracker_control_changed(self):self.reject(lambda d:d['handoff.json']['operationalControl'].update(activationAuthority='invented'))
    def test_tracked_source_changed(self):self.reject(lambda d:d['after.json']['repositories']['.']['files'].update({'Directory.Build.props':'0'*64}))
    def test_prior_binding_expected_hash_rewritten(self):self.reject(lambda d:next(iter(d['source-reuse-audit.json'].values())).update(expectedSha256='0'*64))
    def test_ineligible_profile_claimed_reusable(self):self.reject(lambda d:next(p for p in d['source-reuse-profiles.json'] if not p['byteReuseEligible']).update(byteReuseEligible=True))
    def test_diagnostic_package_promoted_to_release(self):self.reject(lambda d:d['handoff.json']['releasedIdentities']['packages']['Hexalith.Folders.Client'].append(d['handoff.json']['localQualification']['unsignedDiagnosticPackages']['Hexalith.Folders.Client'][0]))
    def test_current_tuple_overclaimed(self):self.reject(lambda d:d['bounded-reuse.json'].update(currentFullTupleQualified=True))
class SealBoundaryTests(unittest.TestCase):
    def test_nested_manifest_and_bytecode_paths_are_covered(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp)
            for name in ['members.json','nested/members.json','__pycache__/retained.pyc']:
                p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b'x')
            self.assertEqual(replay.file_members(root),{'nested/members.json','__pycache__/retained.pyc'})
    def test_escaping_member_path_rejected(self):
        with self.assertRaises(ValueError):replay.safe_name('../outside')
    def test_symlink_member_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp);(root/'link').symlink_to('/etc/passwd')
            with self.assertRaises(ValueError):replay.file_members(root)
    def test_duplicate_archive_member_rejected(self):
        buf=io.BytesIO()
        with tarfile.open(fileobj=buf,mode='w') as tf:
            for _ in range(2):tf.addfile(tarfile.TarInfo('same'))
        buf.seek(0)
        with tarfile.open(fileobj=buf) as tf:
            with self.assertRaises(ValueError):replay.archive_members(tf)
    def test_archive_symlink_rejected(self):
        buf=io.BytesIO()
        with tarfile.open(fileobj=buf,mode='w') as tf:
            entry=tarfile.TarInfo('link');entry.type=tarfile.SYMTYPE;entry.linkname='outside';tf.addfile(entry)
        buf.seek(0)
        with tarfile.open(fileobj=buf) as tf:
            with self.assertRaises(ValueError):replay.archive_members(tf)
class CompleteReceiptReplayTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory(prefix='story117-owner-intake-test-');cls.addClassCleanup(cls.temp.cleanup)
        cls.base=pathlib.Path(cls.temp.name);cls.root=cls.base/'capsule';cls.repo=cls.base/'repo';cls.evidence=cls.repo/'_bmad-output/implementation-artifacts/evidence';cls.evidence.mkdir(parents=True)
        shutil.copytree(replay.ROOT,cls.root)
        # Complete disposable capsule; never mutate a hardlink to workspace evidence.
        files={str(p.relative_to(cls.root)):{'sha256':replay.sha(p),'bytes':p.stat().st_size} for p in cls.root.rglob('*') if p.is_file() and p!=cls.root/'members.json'}
        (cls.root/'members.json').write_text(json.dumps({'files':files})+'\n')
        cls.data=replay.documents(cls.root)
        for b in cls.data['prior-seal-validation.json']['boundFiles']:
            target=cls.repo/b['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(pathlib.Path(replay.WORKSPACE)/b['path'],target)
        source=pathlib.Path(replay.WORKSPACE)/'_bmad-output/implementation-artifacts/evidence'/ (replay.N+'.json');cls.receipt=replay.read(source)
        for key,member in [('memberManifest','members.json'),('handoff','handoff.json'),('decisions','decisions.json'),('readableDecisions','decisions.md')]:
            target=cls.evidence/cls.receipt[key]['path'];shutil.copy2(cls.root/member,target);cls.receipt[key].update(sha256=replay.sha(target),bytes=target.stat().st_size)
        archive=cls.evidence/cls.receipt['archive']['path']
        with tarfile.open(archive,'w') as tf:
            for name in sorted(set(files)|{'members.json'}):tf.add(cls.root/name,arcname=name,recursive=False)
        cls.receipt['archive'].update(sha256=replay.sha(archive),bytes=archive.stat().st_size)
        cls.receipt.update(replay.receipt_claims(cls.data))
        verification=replay.read(source.parent/cls.receipt['verification']['path'])
        for vk,rk in [('archiveSha256','archive'),('memberManifestSha256','memberManifest'),('handoffSha256','handoff')]:verification[vk]=cls.receipt[rk]['sha256']
        # Bind actual logs already in this disposable snapshot, independent of the suite running now.
        import re
        total=int(re.search(r'Ran (\d+) tests', (cls.root/'logs/normal-tests.txt').read_text()).group(1));verification['focusedTests']['total']=total;verification['focusedTests']['negativeControls']=total-2
        for mode in ['normal','optimized']:
            verification['focusedTests'][mode]['logSha256']=replay.sha(cls.root/('logs/'+mode+'-tests.txt'))
        cls.verification_path=cls.evidence/cls.receipt['verification']['path'];cls.verification_path.write_text(json.dumps(verification)+'\n');cls.receipt['verification'].update(sha256=replay.sha(cls.verification_path),bytes=cls.verification_path.stat().st_size)
        cls.receipt_path=cls.evidence/(replay.N+'.json');cls.receipt_path.write_text(json.dumps(cls.receipt)+'\n')
    def test_complete_replay_and_prior_receipt_bound_drift(self):
        replay.verify(self.root,self.receipt_path)
        # Mutate only a disposable copy. The precise external preservation guard must reject it.
        target=self.repo/self.data['prior-seal-validation.json']['boundFiles'][-1]['path'];original=target.read_bytes()
        try:
            target.write_bytes(original+b'altered')
            with self.assertRaisesRegex(ValueError,'^previous receipt-bound file drift$'):replay.verify(self.root,self.receipt_path)
        finally:target.write_bytes(original)
    def test_verification_digest_is_bound(self):
        original=self.verification_path.read_bytes()
        try:
            self.verification_path.write_bytes(original+b' ')
            with self.assertRaisesRegex(ValueError,'external receipt verification'):replay.verify(self.root,self.receipt_path)
        finally:self.verification_path.write_bytes(original)
    def test_verification_size_is_bound(self):
        original=self.receipt_path.read_bytes()
        try:
            changed=copy.deepcopy(self.receipt);changed['verification']['bytes']+=1;self.receipt_path.write_text(json.dumps(changed)+'\n')
            with self.assertRaisesRegex(ValueError,'external receipt size verification'):replay.verify(self.root,self.receipt_path)
        finally:self.receipt_path.write_bytes(original)
    def test_verification_content_is_bound(self):
        v=replay.read(self.verification_path)
        for change,message in [(lambda x:x.update(archiveSha256='0'*64),'verification identity archiveSha256'),(lambda x:x['focusedTests']['normal'].update(logSha256='0'*64),'verification retained test-log binding'),(lambda x:x['focusedTests'].update(total=999),'verification retained test outcome')]:
            with self.subTest(message=message):
                altered=copy.deepcopy(v);change(altered)
                with self.assertRaisesRegex(ValueError,message):replay.validate_verification(altered,self.receipt,self.root)
if __name__=='__main__':unittest.main()
