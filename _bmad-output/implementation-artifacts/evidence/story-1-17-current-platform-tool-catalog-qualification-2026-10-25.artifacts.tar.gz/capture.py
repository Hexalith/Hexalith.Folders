import datetime, hashlib, json, pathlib, subprocess, sys

ROOT = pathlib.Path('/home/administrator/projects/hexalith/folders')
OUT = pathlib.Path(sys.argv[1])
commands = []
def sha(data): return hashlib.sha256(data).hexdigest()
def run(cwd, *argv):
    p = subprocess.run(argv, cwd=cwd, capture_output=True)
    commands.append(dict(cwd=str(cwd), argv=list(argv), exitCode=p.returncode,
                         stdout=p.stdout.decode(errors='replace'), stderr=p.stderr.decode(errors='replace'),
                         stdoutSha256=sha(p.stdout), stderrSha256=sha(p.stderr)))
    if p.returncode: raise RuntimeError(commands[-1])
    return p.stdout

paths = run(ROOT, 'git', 'config', '--file', '.gitmodules', '--get-regexp', r'^submodule\..*\.path$').decode().splitlines()
repos = ['.'] + [p.split(' ', 1)[1] for p in paths]
data = dict(recordedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(), repositories={})
for rel in repos:
    cwd = ROOT / rel
    r = dict(revision=run(cwd,'git','rev-parse','HEAD').decode().strip(),
             branch=run(cwd,'git','status','--short','--branch').decode(),
             status=run(cwd,'git','status','--porcelain=v1','--untracked-files=all').decode(),
             remotes=run(cwd,'git','remote','-v').decode(),
             recentHistory=run(cwd,'git','log','-5','--format=%H %s').decode())
    index = run(cwd,'git','ls-files','--stage')
    r['indexEntriesSha256'] = sha(index)
    r['gitlinks'] = [s for s in index.decode().splitlines() if s.startswith('160000 ')]
    r['trackedFiles'] = {}
    for entry in index.decode().splitlines():
        meta, path = entry.split('\t', 1)
        if meta.startswith('160000 '): continue
        p = cwd/path
        r['trackedFiles'][path] = dict(sha256=sha(p.read_bytes()), bytes=p.stat().st_size) if p.is_file() else None
    r['untrackedFiles'] = {}
    for path in run(cwd,'git','ls-files','--others','--exclude-standard','-z').decode().split('\0'):
        p=cwd/path
        if path and p.is_file(): r['untrackedFiles'][path]=dict(sha256=sha(p.read_bytes()),bytes=p.stat().st_size)
    r['nestedGitMarkers'] = [str(p.relative_to(cwd)) for p in (cwd/'references').glob('*/.git')] if rel!='.' else []
    data['repositories'][rel]=r
data['rootCachedDiff'] = run(ROOT,'git','diff','--cached','--binary','--full-index').decode()
data['rootCachedDiffSha256'] = sha(data['rootCachedDiff'].encode())
data['rootUnstagedDiff'] = run(ROOT,'git','diff','--binary','--full-index').decode()
data['commands']=commands
data['driver'] = dict(path=str(pathlib.Path(__file__)),sha256=sha(pathlib.Path(__file__).read_bytes()),source=pathlib.Path(__file__).read_text())
OUT.write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(dict(output=str(OUT),sha256=sha(OUT.read_bytes()),repositories={k:{x:v[x] for x in ['revision','indexEntriesSha256','status','nestedGitMarkers']} for k,v in data['repositories'].items()},rootCachedDiffSha256=data['rootCachedDiffSha256']),indent=2))
