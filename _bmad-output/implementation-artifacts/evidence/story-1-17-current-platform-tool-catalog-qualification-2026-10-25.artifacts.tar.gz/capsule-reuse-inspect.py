import pathlib,hashlib,json,tarfile,datetime
ROOT=pathlib.Path('/home/administrator/projects/hexalith/folders')
BASE=ROOT/'_bmad-output/implementation-artifacts'
E=BASE/'evidence'
OUT=pathlib.Path('/tmp/story117-capsule-reuse-evidence.json')
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return {'path':str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else str(p),'sha256':sha(b),'bytes':len(b)}
out={'recordedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Read-only receipt/member integrity and current file byte comparisons; all executable results reused, no replay/build/test/audit/runtime invocation.','command':['python3','-B','/tmp/story117-capsule-reuse-inspect.py'],'capsules':{},'mappingEvidence':{}}
for kind in ['owner-intake','composition-intake']:
 prefix=f'story-1-17-{kind}-2026-10-25'
 rp=E/(prefix+'.json');r=json.loads(rp.read_bytes());m=json.loads((E/r['memberManifest']['path']).read_bytes());par=json.loads((E/(prefix+'.parent-verification.json')).read_bytes());ver=json.loads((E/(prefix+'.verification.json')).read_bytes());row={'receipt':bind(rp),'receiptData':r,'hashBindings':[],'memberCount':len(m['files']),'reusedParentVerification':{'binding':bind(E/(prefix+'.parent-verification.json')),'checks':par['checks']},'reusedVerification':{'binding':bind(E/(prefix+'.verification.json')),'data':ver}}
 for k,v in r.items():
  if isinstance(v,dict) and 'path' in v and 'sha256' in v:
   p=ROOT/v['path'] if v['path'].startswith('_bmad-output/') else E/v['path'];actual=bind(p);actual.update({'expectedSha256':v['sha256'],'matches':actual['sha256']==v['sha256'],'relation':k});row['hashBindings'].append(actual);assert actual['matches'],str(p)
 assert par['receiptSha256']==row['receipt']['sha256']
 row['parentReceiptBindingMatches']=True
 with tarfile.open(E/r['archive']['path']) as tar:
  byname={v.name:v for v in tar.getmembers() if v.isfile()}
  checked=[]
  for name,binding in m['files'].items():
   data=tar.extractfile(byname[name]).read();assert sha(data)==binding['sha256'] and len(data)==binding['bytes'],name;checked.append(name)
  row['allMemberHashesMatch']=True;row['checkedFileMemberCount']=len(checked)
  commands=json.load(tar.extractfile('commands.json'));row['historicalCommands']=commands
  row['selectedMemberData']={}
  selected=['ordinary-preflight.json'] if kind=='owner-intake' else ['provenance/approved-integration.json','provenance/upstream-integration.json','provenance/parties.json']
  for name in selected:
   data=tar.extractfile(name).read();row['selectedMemberData'][name]={'sha256':sha(data),'data':json.loads(data)}
  if kind=='composition-intake':
   row['currentDeclarationByteComparison']=[]
   for module in ['EventStore','Tenants','Memories','Parties']:
    p=ROOT/f'references/Hexalith.{module}/module/hexalith.module-manifest.v2.json'
    for lane in ['exports','exports-current-owner']:
     name=f'{lane}/Hexalith.{module}/module/hexalith.module-manifest.v2.json';b=tar.extractfile(name).read();now=bind(p)
     row['currentDeclarationByteComparison'].append({'module':module,'retainedMember':name,'retainedSha256':sha(b),'current':now,'unchanged':now['sha256']==sha(b)})
 out['capsules'][kind]=row
for kind in ['application','proposal']:
 p=E/f'story-1-17-ordinary-workspace-mapping-{kind}-2026-10-25.json';d=json.loads(p.read_bytes());row={'binding':bind(p),'status':d['status'],'operationalControl':d['operationalControl'],'stagingChecks':d['stagingChecks']}
 if kind=='application':
  row['approval']=d['approval'];row['sourceSelectionEvidence']=d['sourceSelectionEvidence'];row['retainedHolds']=d['retainedHolds'];row['verificationSummary']={k:v for k,v in d['verification'].items() if k not in ['sourceTuple','preservation']};row['historicalCommands']=d['applicationCommands']+d['verificationCommands']
  pre=d['preflight'];row['approvalInputBindings']=[]
  for key in ['approvedProposal','approvedPatch','proposalEvidence']:
   binding=pre[key];actual=bind(ROOT/binding['path']);actual['expectedSha256']=binding['sha256'];actual['matches']=actual['sha256']==binding['sha256'];row['approvalInputBindings'].append(actual);assert actual['matches']
  actual=bind(ROOT/d['approval']['note']);actual['expectedSha256']=d['approval']['noteSha256'];actual['matches']=actual['sha256']==actual['expectedSha256'];row['approvalInputBindings'].append(actual);assert actual['matches']
 else:
  row['reusedVerification']=d['reusedVerification'];row['reusedCapsuleEvidence']=d['reusedCapsuleEvidence'];row['reuseLimit']=d['reuseLimit']
 out['mappingEvidence'][kind]=row
out['driver']=bind(pathlib.Path(__file__))
OUT.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'output':str(OUT),'sha256':sha(OUT.read_bytes()),'capsules':{k:{'memberCount':v['memberCount'],'allMemberHashesMatch':v['allMemberHashesMatch'],'allReceiptBindingsMatch':all(b['matches'] for b in v['hashBindings'])} for k,v in out['capsules'].items()},'declarations':out['capsules']['composition-intake']['currentDeclarationByteComparison']},indent=2))
