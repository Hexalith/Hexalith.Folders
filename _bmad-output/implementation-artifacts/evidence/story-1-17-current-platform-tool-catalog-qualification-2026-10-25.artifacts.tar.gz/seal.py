import datetime, gzip, hashlib, io, json, pathlib, subprocess, tarfile

ROOT=pathlib.Path('/home/administrator/projects/hexalith/folders')
TMP=pathlib.Path('/tmp/story117-current-tuple-7Rw5kh')
ART=ROOT/'_bmad-output/implementation-artifacts'
BASE='story-1-17-current-platform-tool-catalog-qualification-2026-10-25'
def sha(b): return hashlib.sha256(b).hexdigest()
def binding(p):
    return {'path':str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}

pre=json.loads((TMP/'preflight.json').read_text())
commands=[]
def run(cwd,*argv):
    r=subprocess.run(argv,cwd=cwd,capture_output=True)
    commands.append({'cwd':str(cwd),'argv':list(argv),'exitCode':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode(),'stdoutSha256':sha(r.stdout),'stderrSha256':sha(r.stderr)})
    assert r.returncode==0,commands[-1]
    return r.stdout

preservation=[]
for rel,old in pre['repositories'].items():
    cwd=ROOT/rel
    rev=run(cwd,'git','rev-parse','HEAD').decode().strip()
    idx=sha(run(cwd,'git','ls-files','--stage'))
    changed=[]
    for path,b in {**old['trackedFiles'],**old['untrackedFiles']}.items():
        p=cwd/path
        now=binding(p) if p.is_file() else None
        if (now and now['sha256']) != (b and b['sha256']): changed.append(path)
    markers=[str(p.relative_to(cwd)) for p in (cwd/'references').glob('*/.git')] if rel!='.' else []
    untracked=run(cwd,'git','ls-files','--others','--exclude-standard','-z').decode().split('\0')
    newpaths=[p for p in untracked if p and p not in old['untrackedFiles']]
    allowed={
      '_bmad-output/implementation-artifacts/'+BASE+'.md',
      '_bmad-output/implementation-artifacts/story-1-17-current-platform-tool-catalog-qualification-plan-2026-10-25.json',
      '_bmad-output/implementation-artifacts/spec-1-17-current-platform-tool-catalog-qualification.md',
      *['_bmad-output/implementation-artifacts/evidence/'+BASE+s for s in ['.json','.members.json','.artifacts.tar.gz']],
    } if rel=='.' else set()
    assert not (set(newpaths)-allowed),newpaths
    row={'repository':rel,'revision':rev,'revisionPreserved':rev==old['revision'],'indexEntriesSha256':idx,'indexPreserved':idx==old['indexEntriesSha256'],'comparedFiles':len(old['trackedFiles'])+len(old['untrackedFiles']),'changedPreviouslyExistingFiles':changed,'nestedGitMarkers':markers,'nestedMarkersPreserved':markers==old['nestedGitMarkers']}
    preservation.append(row)
    assert row['revisionPreserved'] and row['indexPreserved'] and not changed and row['nestedMarkersPreserved'],row

nested=json.loads((TMP/'nested-ownership-scan.json').read_text())
assert len(nested['repositories'])==12
assert all(not r['nestedGitMarkers'] and not r['skippedDirectorySymlinks'] for r in nested['repositories'].values())

application=json.loads((ART/'evidence/story-1-17-ordinary-workspace-mapping-application-2026-10-25.json').read_text())
assert sha((ROOT/'.gitmodules').read_bytes())==application['verification']['gitmodulesAfterSha256']
for b in application['verification']['sourceBindings']:
    assert sha((ROOT/b['path']).read_bytes())==b['sha256']
assert sha((ROOT/application['approval']['note']).read_bytes())==application['approval']['noteSha256']
for key in ['approvedProposal','approvedPatch','proposalEvidence']:
    b=application['preflight'][key];assert sha((ROOT/b['path']).read_bytes())==b['sha256']
assert pre['repositories']['references/Hexalith.Parties']['revision']==application['verification']['partiesHead']
run(ROOT,'git','log','--format=%H %P %s','09707e19ab7024b88b34d89651e15a45bc895eeb..HEAD')
run(ROOT,'git','diff','--check')
run(ROOT,'git','diff','--cached','--check')
status=run(ROOT,'git','status','--short','--branch').decode()
cached=run(ROOT,'git','diff','--cached','--name-only').decode()
assert not cached

planpath=ART/'story-1-17-current-platform-tool-catalog-qualification-plan-2026-10-25.json'
plan=json.loads(planpath.read_text())
assert plan['ordinaryAttempt']['commandProducedMapping'] is None and plan['ordinaryAttempt']['ContentHash'] is None
assert plan['ownerDecision'] is None and not plan['candidateTool']['accepted']
assert plan['workspacePatch'] is None and plan['affectedRepositoryPaths']==[]
assert all(not s['executed'] for s in plan['steps'])
assert plan['operationalControl']==application['operationalControl']
authored=[ART/(BASE+'.md'),planpath,ART/'spec-1-17-current-platform-tool-catalog-qualification.md']
for p in authored:
    data=p.read_text()
    assert data.endswith('\n')
    assert all(line==line.rstrip() for line in data.splitlines()),p
validation={'recordedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':['python3','-B',str(pathlib.Path(__file__))],'cwd':str(ROOT),'preservation':preservation,'approvedPartiesAndHistoricalProposalBindingsUnchanged':True,'rootStatus':status,'rootStagedPaths':[],'planInvariantsPassed':True,'newArtifactsJsonAndWhitespacePassed':True,'commands':commands,'limits':'Fresh hash/state checks only; no prior verifier, build, graph, audit, runtime, or candidate CLI rerun.'}
(TMP/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')

members={
 'preflight.json':TMP/'preflight.json',
 'external-transition.json':TMP/'external-transition.json',
 'capture.py':TMP/'capture.py',
 'seal.py':pathlib.Path(__file__),
 'validation.json':TMP/'validation.json',
 'cli-tuple-evidence.json':pathlib.Path('/tmp/story117-cli-tuple-evidence.json'),
 'platform-delta-evidence.json':pathlib.Path('/tmp/story117-platform-delta-evidence.json'),
 'capsule-reuse-evidence.json':pathlib.Path('/tmp/story117-capsule-reuse-evidence.json'),
 'capsule-reuse-inspect.py':pathlib.Path('/tmp/story117-capsule-reuse-inspect.py'),
 'accepted-api-inspection.json':TMP/'accepted-api-inspection.json',
 'candidate-api-inspection.json':TMP/'candidate-api-inspection.json',
 'package-mode-and-validator-source.json':TMP/'package-mode-and-validator-source.json',
 'nested-ownership-scan.json':TMP/'nested-ownership-scan.json',
 'candidate-release-inventory.json':pathlib.Path('/tmp/story117-v438-package-inventory.json'),
}
for p in authored: members['proposal/'+p.name]=p
if (TMP/'review.json').exists(): members['review.json']=TMP/'review.json'
manifest={'format':'sha256-file-members-v1','members':[{'path':n,'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for n,p in sorted(members.items())]}
manifestpath=ART/'evidence'/(BASE+'.members.json')
manifestpath.write_text(json.dumps(manifest,indent=2)+'\n')
archive=ART/'evidence'/(BASE+'.artifacts.tar.gz')
with archive.open('wb') as output:
    with gzip.GzipFile(fileobj=output,mode='wb',mtime=0,filename='') as gz:
        with tarfile.open(fileobj=gz,mode='w') as tar:
            for n,p in sorted(members.items()):
                b=p.read_bytes();info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;info.mtime=0
                tar.addfile(info,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tar:
    assert sorted(tar.getnames())==sorted(members)
    for item in manifest['members']:
        b=tar.extractfile(item['path']).read();assert sha(b)==item['sha256'] and len(b)==item['bytes']

prior=[]
for pattern in ['story-1-17-owner-intake-2026-10-25*','story-1-17-composition-intake-2026-10-25*','story-1-17-ordinary-workspace-mapping-application-2026-10-25.json','story-1-17-ordinary-workspace-mapping-proposal-2026-10-25.json']:
    prior.extend(binding(p) for p in sorted((ART/'evidence').glob(pattern)) if p.is_file())
prior.extend(binding(ART/n) for n in ['story-1-17-ordinary-workspace-mapping-approval-2026-10-25.md','story-1-17-ordinary-workspace-mapping-proposal-2026-10-25.md','story-1-17-ordinary-workspace-mapping-proposal-2026-10-25.patch','story-1-17-owner-intake-handoff-2026-10-25.json','story-1-17-composition-intake-handoff-2026-10-25.json'])
receipt={
 'recordId':'STORY-1-17-CURRENT-PLATFORM-TOOL-CATALOG-QUALIFICATION-2026-10-25','recordedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'status':'Accepted CLI 4.35.2/current Platform statically incompatible; isolated CLI 4.38.0 qualification proposed; acceptance HOLD',
 'rootRevision':pre['repositories']['.']['revision'],
 'initialObservation':{'source':'Initial tool output in this conversation; historical observation, not reconstructed as a new command run','rootRevision':'09707e19ab7024b88b34d89651e15a45bc895eeb','stagedPaths':['.gitmodules','references/Hexalith.Parties'],'unstagedTrackedPaths':['_bmad-output/implementation-artifacts/evidence/story-1-17-ordinary-workspace-mapping-proposal-2026-10-25.json','_bmad-output/implementation-artifacts/spec-1-17-ordinary-workspace-mapping-proposal.md','_bmad-output/implementation-artifacts/story-1-17-ordinary-workspace-mapping-proposal-2026-10-25.md','references/Hexalith.Platform'],'untrackedPaths':['_bmad-output/implementation-artifacts/evidence/story-1-17-ordinary-workspace-mapping-application-2026-10-25.json','_bmad-output/implementation-artifacts/story-1-17-ordinary-workspace-mapping-approval-2026-10-25.md']},
 'externalTransition':{'commits':['6566b154ac940f4274780665818396e689036298','b5ae26e4ce2df1bc4a275f1272bf3d147eef2a2b'],'taskIssuedGitMutation':False,'approvalInferred':False,'currentStagedPaths':[],'originalApprovedPartiesBytesAndCheckoutPreserved':True},
 'sourceTuple':plan['baseline'],
 'tool':{'acceptedVersion':'4.35.2','acceptedSource':plan['acceptedTool']['source'],'acceptedPackageSha256':plan['acceptedTool']['archive']['sha256'],'candidateVersion':'4.38.0','candidateSource':plan['candidateTool']['source'],'candidatePackageSha256':plan['candidateTool']['archive']['sha256'],'candidatePackageSignatureExitCode':0,'candidateCliExecuted':False,'candidateInstalled':False,'candidateAccepted':False},
 'conclusions':{'additionalRepositoryPinChangeJustified':False,'tool4_35_2MissingRequiredPlatformApis':True,'tool4_38_0ContainsIdentifiedApis':True,'candidateModelBuildExecuted':False,'runtimeCompatibilityProven':False,'currentTupleAccepted':False,'packageModeAccepted':False,'hostedAccepted':False,'commandProducedMapping':None,'ContentHash':None},
 'artifactArchive':binding(archive),'memberManifest':binding(manifestpath),'artifactMembersVerified':len(members),'authoredArtifacts':[binding(p) for p in authored],
 'priorReceiptBindings':prior,
 'reusedEvidence':{'ownerIntakeMembersVerified':331,'compositionIntakeMembersVerified':2107,'ownerIntakeVerifierTests':42,'compositionVerifierTests':31,'verifiersRerun':False,'fourCurrentOwnerDeclarationsByteIdentical':True,'releasedJointValidationExitCode':0,'releasedJointValidationLogSha256':'724d6ace8bd53e2658aa456dc61b065be48a3fe24e71ebb7c93b76c056cd0d53','buildsGraphTestsAdoptionAuditsRerun':False,'limits':'All executable outcomes are historical and retain their recorded source/tool/fixture scopes; hash integrity is not current runtime qualification.'},
 'validation':{'allPreexistingTrackedBytesPreservedSinceCapturedPostExternalBaseline':True,'allRepositoryRevisionsAndIndicesPreservedSinceCapturedPostExternalBaseline':True,'newUntrackedPathsLimitedToSixAuthoredArtifacts':True,'ignoredOutputBytePreservationClaimed':False,'noNestedSubmodulesInitialized':True,'descendantScan':'nested-ownership-scan.json; all12direct checkouts; no markers or directory symlinks','approvedPartiesAndHistoricalProposalBindingsUnchanged':True,'newArtifactJsonAndWhitespacePassed':True,'archiveManifestVerified':True,'command':['python3','-B',str(pathlib.Path(__file__))]},
 'ownerDecision':None,'proposedPatch':None,'proposedPatchReason':'Isolated candidate compile/reference inspection needs no workspace/gitlink/tool-manifest replacement. Any later permanent dependency/source change requires a separate exact patch.',
 'operationalControl':application['operationalControl'],'parentStatus':'in-progress','trackerStatus':'backlog','stagingChecks':{'executed':0,'total':14},
 'limitations':['No compiler run or compiler error claimed; missing APIs established by actual package metadata plus immutable source.','Candidate archive inspected/signature-verified in /tmp only; its CLI was not invoked.','No ordinary mapping, run/debug, AppHost, Dapr service probe or hosted operation executed.','No dependency-policy, ownership, registration, hosting or retirement decision inferred.','No acceptance from external commits or historical passed fixtures.']}
receiptpath=ART/'evidence'/(BASE+'.json');receiptpath.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'receipt':binding(receiptpath),'archive':binding(archive),'verifiedMembers':len(members),'preservedRepositories':len(preservation),'preservedFiles':sum(r['comparedFiles'] for r in preservation),'stagedPaths':[]},indent=2))
