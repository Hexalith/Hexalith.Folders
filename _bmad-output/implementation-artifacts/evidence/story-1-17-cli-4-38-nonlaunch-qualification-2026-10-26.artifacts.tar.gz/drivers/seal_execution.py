import datetime, gzip, hashlib, io, json, pathlib, subprocess, tarfile

ROOT=pathlib.Path('/home/administrator/projects/hexalith/folders')
Q=pathlib.Path(__file__).parent
ART=ROOT/'_bmad-output/implementation-artifacts'
BASE='story-1-17-cli-4-38-nonlaunch-qualification-2026-10-26'
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text())
def binding(p):return {'path':str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
def write(p,d):p.write_text(json.dumps(d,indent=2)+'\n')

pre=read(Q/'preflight.json');pres=read(Q/'preservation.json');result=read(Q/'qualification-result.json');limits=read(Q/'evidence-limitations.json')
assert pres['outsidePrivateDirectoryPreserved'] and pres['gitMarkersPreserved']
assert not pres['added'] and not pres['removed'] and not pres['changed']
assert all(x['revisionPreserved'] and x['indexPreserved'] and not x['status'] for x in pres['repositories'].values())
assert read(Q/'property-gate.json')['passed'] and read(Q/'assets-gate.json')['passed']
assert result['compile']=={'exitCode':0,'warnings':1,'errors':0,'warningId':'MSB3277'}
assert all(x['identityMatches'] for x in result['requiredDirectReferenceChecks'].values())
assert result['ordinaryMapping'] is None and result['ContentHash'] is None

proposal=ART/'evidence/story-1-17-current-platform-tool-catalog-qualification-2026-10-25.json'
old=read(proposal)
for b in old['authoredArtifacts']+[old['artifactArchive'],old['memberManifest']]+old['priorReceiptBindings']:
    assert sha((ROOT/b['path']).read_bytes())==b['sha256'],b['path']

report=ART/(BASE+'.md')
approval=ART/'story-1-17-cli-4-38-nonlaunch-qualification-approval-2026-10-26.md'
for p in [report,approval]:
    text=p.read_text();assert text.endswith('\n') and all(x.rstrip()==x for x in text.splitlines())

commands=[]
for p in sorted((Q/'logs').glob('*.command.json')):
    d=read(p)
    for stream in ['stdout','stderr']:
        b=d[stream];f=Q/b['path'];assert sha(f.read_bytes())==b['sha256'] and f.stat().st_size==b['bytes']
    commands.append({'record':str(p.relative_to(Q)),'argv':d['argv'],'cwd':d['cwd'],'exitCode':d['exitCode'],'stdoutSha256':d['stdout']['sha256'],'stderrSha256':d['stderr']['sha256']})
assert read(Q/'logs/model-build.command.json')['exitCode']==0
assert sum(c['record']=='logs/model-build.command.json' for c in commands)==1
assert not any('Hexalith.Builds.Module.Cli.dll' in ' '.join(c['argv']) for c in commands)

checks=[]
for rel,expected in pre['repositories'].items():
    cwd=ROOT/rel
    out=subprocess.run(['git','rev-parse','HEAD'],cwd=cwd,capture_output=True,check=True)
    idx=subprocess.run(['git','ls-files','--stage'],cwd=cwd,capture_output=True,check=True)
    status=subprocess.run(['git','status','--porcelain=v1','--untracked-files=all'],cwd=cwd,capture_output=True,check=True)
    assert out.stdout.decode().strip()==expected['revision'] and sha(idx.stdout)==expected['indexEntriesSha256'],rel
    if rel!='.':assert not status.stdout,rel
    checks.append({'repository':rel,'revision':out.stdout.decode().strip(),'indexEntriesSha256':sha(idx.stdout),'status':status.stdout.decode()})
for argv in [['git','diff','--check'],['git','diff','--cached','--check'],['git','diff','--cached','--name-only']]:
    p=subprocess.run(argv,cwd=ROOT,capture_output=True,check=True);assert not p.stdout and not p.stderr
    checks.append({'argv':argv,'cwd':str(ROOT),'exitCode':0,'stdoutSha256':sha(p.stdout),'stderrSha256':sha(p.stderr)})
write(Q/'final-validation.json',{'recordedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':['python3','-B',str(pathlib.Path(__file__))],'checks':checks,'priorReceiptBindingsPreserved':True,'commandStreamBindingsVerified':len(commands),'singleApprovedBuild':True,'noPublicCliInvoked':True,'authoredWhitespacePassed':True,'limits':'Final Git checks record revisions, index entries and working-tree status; the repository inventory comparison preceded authored evidence. The receipt binds the new documents.'})

members={}
for p in sorted(Q.glob('*.json')):members[p.name]=p
for p in sorted(Q.glob('*.py')):members['drivers/'+p.name]=p
for p in sorted(Q.glob('*driver.std*')):members[p.name]=p
for p in sorted((Q/'logs').iterdir()):
    if p.is_file():members['logs/'+p.name]=p
for p in sorted((Q/'build/platform-model').rglob('project.assets.json')):members[str(p.relative_to(Q))]=p
for p in sorted((Q/'hosts/platform-model').rglob('*')):
    if p.is_file():members[str(p.relative_to(Q))]=p
for name in ['Hexalith.Builds.Module.AppHost.dll','Hexalith.Builds.Module.AppHost.deps.json','Hexalith.Builds.Module.AppHost.runtimeconfig.json','Aspire.Hosting.dll','Hexalith.EventStore.Aspire.dll','StackExchange.Redis.dll']:
    p=Q/'tool-4.38.0/tools/net10.0/any/g4-host'/name
    if p.exists():members['candidate-host/'+name]=p
p=Q/'tool-4.38.0/Hexalith.Builds.Module.Cli.nuspec';members['candidate/Hexalith.Builds.Module.Cli.nuspec']=p
p=Q/'cache/nuget/packages/stackexchange.redis/2.13.17/lib/net10.0/StackExchange.Redis.dll';members['model-restore/StackExchange.Redis.dll']=p
members['catalog/Directory.Packages.props']=Q/'pinned-tree/Props/Directory.Packages.props'
members['approval/'+approval.name]=approval;members['report/'+report.name]=report
plan=ART/'story-1-17-current-platform-tool-catalog-qualification-plan-2026-10-25.json'
members['approved-plan.json']=plan

manifest={'format':'sha256-file-members-v1','members':[{'path':n,'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for n,p in sorted(members.items())]}
mf=ART/'evidence'/(BASE+'.members.json');write(mf,manifest)
archive=ART/'evidence'/(BASE+'.artifacts.tar.gz')
with archive.open('wb') as out:
    with gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as gz:
        with tarfile.open(fileobj=gz,mode='w') as t:
            for n,p in sorted(members.items()):
                b=p.read_bytes();i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as t:
    assert sorted(t.getnames())==sorted(members)
    for b in manifest['members']:
        data=t.extractfile(b['path']).read();assert sha(data)==b['sha256'] and len(data)==b['bytes']

build=read(Q/'build-result.json')
receipt={
 'recordId':'STORY-1-17-CLI-4-38-NONLAUNCH-QUALIFICATION-2026-10-26',
 'recordedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'status':'Authorized non-launch build and metadata checks executed with partial procedural conformance: compilation and Tooling/Aspire references pass; immediate SDK identity gate incomplete; EventStore/Redis runtime compatibility unresolved; acceptance HOLD',
 'approval':{'decisionMaker':'Jerome','reply':'yes','date':'2026-10-26','note':binding(approval),'plan':binding(plan),'scope':pre['approval']['scope']},
 'proposalReceipt':binding(proposal),'sourceTuple':pre['repositories'],'externalTransition':pre['externalTransition'],
 'candidate':{'version':'4.38.0','source':read(plan)['candidateTool']['source'],'packageSha256':read(plan)['candidateTool']['archive']['sha256'],'signatureExitCode':0,'selectedAsAcceptedTool':False,'installed':False,'publicCliInvoked':False},
 'sdk':read(Q/'sdk.json'),'build':build,'qualification':result,
 'propertyGate':read(Q/'property-gate.json'),'assetsGate':read(Q/'assets-gate.json'),
 'preservation':{'scope':limits['repositoryInventoryScope'],'inventoriedRepositoryPaths':len(read(Q/'filesystem-before.json')['entries']),'regularFileBytesHashed':read(Q/'filesystem-before.json')['fileBytesHashed'],'afterComparisonRaw':pres,'rawLabelInterpretation':limits['rawPreservationLabelInterpretation'],'sourceFilesComparedWithProposal':pre['previousSourceFilesCompared'],'noNestedInitializationPerformed':True,'wholeHostPreservationProven':False,'finalValidationMember':'final-validation.json'},
 'artifactArchive':binding(archive),'memberManifest':binding(mf),'membersVerified':len(members),'executionReport':binding(report),
 'exactCommandRecords':commands,
 'historicalEvidenceReused':{'priorProposalAndReceiptBindingsUnchanged':True,'noHistoricalVerifierRerun':True,'noGraphTestRerun':True,'noAdoptionAuditRerun':True,'onlyNewModelBuildAttempts':1},
 'collectorLimitRaw':pre['collectorCorrection'],'collectorLimitCorrection':limits['missingInitialFailureRecord'],
 'evidenceLimitations':limits,
 'sdkPostExecutionReconciliation':read(Q/'sdk-post-execution-reconciliation.json'),
 'reportedSdkCertificateSideEffect':read(Q/'certificate-store-observation.json'),
 'postReviewProcessGroupObservation':read(Q/'owned-process-group-observation.json'),
 'ordinaryMapping':None,'ContentHash':None,'operationalControl':read(plan)['operationalControl'],'parentStatus':'in-progress','trackerStatus':'backlog','stagingChecks':{'executed':0,'total':14},
 'runtimeLaunched':False,'currentTupleAccepted':False,'packageAccepted':False,'hostedAccepted':False,'dependenciesChanged':False,'staged':False,'committed':False,'pushed':False,'published':False,'deployed':False,
 'proposedPatch':None,'patchDisposition':'No required source or dependency repair established by this compile/metadata lane. Do not turn version differences or MSB3277 into an invented pin fix. A later required repair must have an exact independent proposal.',
 'nextPrerequisites':['Retain the incomplete immediate SDK identity gate as a qualification limitation; a later authorized execution must enforce that gate and explicitly address SDK first-use side effects. No automatic rebuild is authorized here.','Resolve EventStore3.128 model versus3.127 packaged-host compatibility with separately scoped loader/host evidence.','Resolve actual Redis binding/API behavior; retain model2.13.17 versus host3.4.5 and the unset transitive-pinning observation.','Actual ordinary public CLI model/graph/mapping and runtime prerequisite gates remain separate, with no launch authority in this approval.','Owner declarations/registration/adoption/hosting and EventStore/Tenants/Memories policy holds remain separate.'],
 'review':read(Q/'review.json') if (Q/'review.json').exists() else {'status':'pending evidence review'}
}
p=ART/'evidence'/(BASE+'.json');write(p,receipt)
print(json.dumps({'receipt':binding(p),'archive':binding(archive),'membersVerified':len(members),'commands':len(commands),'status':receipt['status']},indent=2))
