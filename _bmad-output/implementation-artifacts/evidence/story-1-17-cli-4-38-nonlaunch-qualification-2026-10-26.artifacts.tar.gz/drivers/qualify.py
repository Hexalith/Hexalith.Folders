import datetime, hashlib, json, os, pathlib, shutil, stat, subprocess, sys, tarfile, time, zipfile

ROOT=pathlib.Path('/home/administrator/projects/hexalith/folders')
Q=pathlib.Path(__file__).parent
ART=ROOT/'_bmad-output/implementation-artifacts'
PLAN_PATH=ART/'story-1-17-current-platform-tool-catalog-qualification-plan-2026-10-25.json'
RECEIPT_PATH=ART/'evidence/story-1-17-current-platform-tool-catalog-qualification-2026-10-25.json'
PLAN=json.loads(PLAN_PATH.read_text())
ENV=os.environ.copy()
def subst(s): return s.replace('<qualification-dir>',str(Q))
for k,v in PLAN['environment'].items(): ENV[k]=subst(v)
for k in ['NUGET_PACKAGES','NUGET_HTTP_CACHE_PATH','NUGET_PLUGINS_CACHE_PATH','DOTNET_CLI_HOME','XDG_CACHE_HOME','TMPDIR']:
    pathlib.Path(ENV[k]).mkdir(parents=True,exist_ok=True)
(Q/'logs').mkdir(exist_ok=True)

def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(data): return hashlib.sha256(data).hexdigest()
def filehash(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        while b:=f.read(1024*1024):h.update(b)
    return h.hexdigest()
def write(name,data):
    p=Q/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,indent=2)+'\n')
def command(name,argv,cwd=ROOT,check=True):
    original=name;attempt=1
    while (Q/'logs'/(name+'.command.json')).exists():
        name=original+'-recheck-'+str(attempt);attempt+=1
    argv=[subst(s) for s in argv]
    start=now();t=time.monotonic()
    stdout=Q/'logs'/(name+'.stdout');stderr=Q/'logs'/(name+'.stderr')
    with stdout.open('wb') as out,stderr.open('wb') as err:
        p=subprocess.Popen(argv,cwd=cwd,env=ENV,stdout=out,stderr=err,start_new_session=True)
        pid=p.pid;code=p.wait()
    record={'argv':argv,'cwd':str(cwd),'environmentOverrides':{k:ENV[k] for k in PLAN['environment']},'startedAtUtc':start,'finishedAtUtc':now(),'durationSeconds':time.monotonic()-t,'processId':pid,'processGroupId':pid,'exitCode':code,'stdout':{'path':str(stdout.relative_to(Q)),'sha256':filehash(stdout),'bytes':stdout.stat().st_size},'stderr':{'path':str(stderr.relative_to(Q)),'sha256':filehash(stderr),'bytes':stderr.stat().st_size}}
    write('logs/'+name+'.command.json',record)
    print(json.dumps({'command':name,'exitCode':code,'durationSeconds':record['durationSeconds']}),flush=True)
    if check and code:raise RuntimeError('STOP: '+name+' exit '+str(code))
    return record,stdout.read_bytes(),stderr.read_bytes()
def git(name,rel,*args):return command(name,['git',*args],ROOT/rel)[1]

def inventory(name):
    data={'root':str(ROOT),'recordedAtUtc':now(),'excluded':'All .git internals/markers (independently captured via Git); no symlink traversal','entries':{},'gitMarkers':[]}
    total=0
    for current,dirs,files in os.walk(ROOT,followlinks=False):
        base=pathlib.Path(current)
        for n in list(dirs)+files:
            p=base/n;rel=str(p.relative_to(ROOT))
            if n=='.git':
                data['gitMarkers'].append(rel)
                if n in dirs:dirs.remove(n)
                continue
            st=p.lstat();row={'mode':stat.S_IMODE(st.st_mode)}
            if stat.S_ISLNK(st.st_mode):
                row.update(type='symlink',target=os.readlink(p))
                if n in dirs:dirs.remove(n)
            elif stat.S_ISDIR(st.st_mode):row['type']='directory'
            elif stat.S_ISREG(st.st_mode):
                digest=filehash(p);after=p.stat()
                if after.st_size!=st.st_size or after.st_mtime_ns!=st.st_mtime_ns:raise RuntimeError('Concurrent file change during capture: '+rel)
                row.update(type='file',sha256=digest,bytes=st.st_size);total+=st.st_size
            else:row.update(type='special',size=st.st_size)
            data['entries'][rel]=row
    data['fileBytesHashed']=total;data['completedAtUtc']=now();write(name,data)
    print(json.dumps({'inventory':name,'paths':len(data['entries']),'bytesHashed':total}),flush=True)
    return data

def preflight():
    receipt=json.loads(RECEIPT_PATH.read_text())
    for b in receipt['authoredArtifacts']+[receipt['artifactArchive'],receipt['memberManifest']]:
        assert filehash(ROOT/b['path'])==b['sha256'],b['path']
    with tarfile.open(ROOT/receipt['artifactArchive']['path'],'r:gz') as tar:
        old=json.loads(tar.extractfile('preflight.json').read())
    state={'recordedAtUtc':now(),'approval':{'decisionMaker':'Jerome','reply':'yes','date':'2026-10-26','scope':PLAN['decision'],'planSha256':filehash(PLAN_PATH),'proposalReceiptSha256':filehash(RECEIPT_PATH)},'repositories':{}}
    for i,(rel,expected) in enumerate(PLAN['baseline']['repositories'].items()):
        rev=git(f'pre-{i}-revision',rel,'rev-parse','HEAD').decode().strip()
        status=git(f'pre-{i}-status',rel,'status','--porcelain=v1','--untracked-files=all').decode()
        git(f'pre-{i}-branch',rel,'status','--short','--branch')
        git(f'pre-{i}-remotes',rel,'remote','-v');git(f'pre-{i}-history',rel,'log','-5','--format=%H %s')
        index=git(f'pre-{i}-index',rel,'ls-files','--stage');links=[s for s in index.decode().splitlines() if s.startswith('160000 ')]
        assert not status,(rel,status)
        assert links==expected['gitlinks'],rel
        if rel!='.': assert rev==expected['revision'] and sha(index)==expected['indexEntriesSha256'],rel
        state['repositories'][rel]={'revision':rev,'indexEntriesSha256':sha(index),'gitlinks':links,'status':status,'physicalPath':str((ROOT/rel).resolve())}
        assert (ROOT/rel).resolve().is_relative_to(ROOT)
    delta=git('pre-root-transition','.','diff','--name-status',PLAN['baseline']['root'],'HEAD').decode().splitlines()
    expectedAdded={b['path'] for b in receipt['authoredArtifacts']+[receipt['artifactArchive'],receipt['memberManifest']]}|{str(RECEIPT_PATH.relative_to(ROOT))}
    assert set(delta)=={'A\t'+p for p in expectedAdded},delta
    state['externalTransition']={'from':PLAN['baseline']['root'],'to':state['repositories']['.']['revision'],'addedPaths':sorted(expectedAdded),'sourceOrDependencyChange':False,'approvalInferredFromCommit':False}
    before=json.loads((Q/'filesystem-before.json').read_text()) if (Q/'filesystem-before.json').exists() else inventory('filesystem-before.json')
    changed=[];count=0
    for rel,repo in old['repositories'].items():
        for p,b in {**repo['trackedFiles'],**repo['untrackedFiles']}.items():
            name=p if rel=='.' else rel+'/'+p
            current=before['entries'].get(name)
            if current and current['type']=='symlink':
                target=(ROOT/name).resolve()
                assert target.is_relative_to(ROOT),name
                # The prior receipt's Path.read_bytes() hashed the symlink target.
                current=before['entries'].get(str(target.relative_to(ROOT)))
            if (current and current.get('sha256'))!=(b and b['sha256']):changed.append(name)
            count+=1
    assert not changed,changed
    allowedMarkers={'.git'}|{p+'/.git' for p in state['repositories'] if p!='.'}
    actualMarkers=set(before['gitMarkers'])
    assert allowedMarkers.issubset(actualMarkers)
    extraMarkers=actualMarkers-allowedMarkers
    assert not any(marker.startswith(rel+'/') for marker in extraMarkers for rel in state['repositories'] if rel!='.'),before['gitMarkers']
    state['otherRootGitMarkersOutsideDirectReferences']=sorted(extraMarkers)
    state['previousSourceFilesCompared']=count;state['previousSourceBytesPreserved']=True
    state['nestedMarkersAbsent']=True;state['rootIndexReconciledForProposalCommit']=True
    state['collectorCorrection']='Initial comparison treated a tracked documentation symlink as a missing content hash. Compare its captured target bytes using the prior receipt semantics; link/index and target bytes match. A second collector assertion overreached the direct-reference nested-submodule scope and rejected an existing standalone historical fixture under root artifacts; its superproject query is empty. Corrected coverage still rejects every extra marker under a direct reference. Failed driver attempts retained; no source drift or source change.'
    write('preflight.json',state)
    print('Preflight passed; original source tuple and approved bytes retained.',flush=True)

def prepare():
    assert (Q/'preflight.json').exists()
    platform=ROOT/'references/Hexalith.Platform'
    for i,args in enumerate(PLAN['steps'][0]['sdkCommands']):
        _,out,_=command('sdk-'+str(i),args,platform)
        if i==1:
            version=out.decode().strip();parts=version.split('.')
            assert len(parts)==3 and parts[:2]==['10','0'] and 402<=int(parts[2])<500,version
    dotnet=pathlib.Path(shutil.which('dotnet')).resolve()
    write('sdk.json',{'dotnetPath':str(dotnet),'sha256':filehash(dotnet),'globalJson':{'path':str(platform/'global.json'),'sha256':filehash(platform/'global.json'),'data':json.loads((platform/'global.json').read_text())},'inheritedRelevantEnvironment':{k:os.environ[k] for k in ['DOTNET_ROOT','DOTNET_ROOT_X64','MSBuildSDKsPath','MSBuildExtensionsPath','MSBUILD_EXE_PATH'] if k in os.environ}})
    command('feeds',['dotnet','nuget','list','source','--format','detailed'],platform)
    package=Q/'download/hexalith.builds.module.cli.4.38.0.nupkg';package.parent.mkdir(exist_ok=True)
    cached=pathlib.Path(PLAN['steps'][1]['archiveAcquisition']['useIfPresent'])
    expected=PLAN['candidateTool']['archive']
    if cached.exists():
        assert filehash(cached)==expected['sha256'] and cached.stat().st_size==expected['bytes']
        shutil.copyfile(cached,package)
        write('package-acquisition.json',{'method':'Copy existing observed archive after exact hash/size check','source':str(cached),'destination':str(package),'sha256':filehash(package),'bytes':package.stat().st_size})
    else:command('download-candidate',PLAN['steps'][1]['archiveAcquisition']['downloadArgv'])
    assert filehash(package)==expected['sha256'] and package.stat().st_size==expected['bytes']
    command('candidate-signature',PLAN['steps'][1]['archiveAcquisition']['verificationArgv'],platform)
    target=Q/'tool-4.38.0';target.mkdir()
    members=[]
    with zipfile.ZipFile(package) as z:
        for item in z.infolist():
            path=pathlib.PurePosixPath(item.filename)
            assert not path.is_absolute() and '..' not in path.parts and '\\' not in item.filename
            assert not stat.S_ISLNK(item.external_attr>>16)
            dst=target.joinpath(*path.parts)
            assert dst.resolve().is_relative_to(target)
            if item.is_dir():dst.mkdir(parents=True,exist_ok=True);continue
            dst.parent.mkdir(parents=True,exist_ok=True);blob=z.read(item);dst.write_bytes(blob)
            members.append({'path':item.filename,'bytes':len(blob),'sha256':sha(blob)})
    byname={m['path']:m for m in members}
    for name,b in PLAN['candidateTool']['members'].items():assert byname[name]['sha256']==b['sha256'] and byname[name]['bytes']==b['bytes'],name
    write('extracted-package-members.json',members)
    s=PLAN['steps'][2];_,catalog,_=command('catalog-export',s['argv'],pathlib.Path(s['cwd']))
    assert sha(catalog)==PLAN['baseline']['selectedCatalogSha256']
    import xml.etree.ElementTree as ET
    assert not any(x.tag.rsplit('}',1)[-1]=='Import' for x in ET.fromstring(catalog).iter())
    dst=pathlib.Path(subst(s['stdoutDestination']));dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(catalog)
    write('preparation.json',{'completedAtUtc':now(),'signaturePassed':True,'extractedMembers':len(members),'catalogHash':sha(catalog),'noCatalogImports':True,'candidateCliInvoked':False})

def evaluate():
    assert (Q/'preparation.json').exists()
    s=PLAN['steps'][3];_,out,_=command('property-evaluation',s['propertyEvidenceArgv'],pathlib.Path(s['cwd']))
    d=json.loads(out);p=d['Properties']
    for k,v in s['requiredResolvedProperties'].items():assert p[k]==v,(k,p[k],v)
    for k,v in {'BuildsToolingAssemblyPath':str(Q/'tool-4.38.0/tools/net10.0/any/Hexalith.Builds.Tooling.dll'),'DirectoryPackagesPropsPath':str(Q/'pinned-tree/Props/Directory.Packages.props')}.items():assert p[k]==v,(k,p[k],v)
    for item in d['Items']['ProjectReference']:
        path=pathlib.Path(item['FullPath']);assert path.is_file() and path.resolve().is_relative_to(ROOT),str(path)
        assert 'Hexalith.Builds.Tooling.csproj' not in str(path)
    write('property-gate.json',{'passed':True,'properties':p,'projectReferences':[x['FullPath'] for x in d['Items']['ProjectReference']],'packageReferences':[x['Identity'] for x in d['Items']['PackageReference']],'catalogPackageCount':len(d['Items']['PackageVersion'])})

def build():
    assert json.loads((Q/'property-gate.json').read_text())['passed']
    # Reconfirm inputs immediately before the only authorized build attempt.
    state=json.loads((Q/'preflight.json').read_text())
    for i,(rel,old) in enumerate(state['repositories'].items()):
        assert git(f'build-{i}-revision',rel,'rev-parse','HEAD').decode().strip()==old['revision']
        assert sha(git(f'build-{i}-index',rel,'ls-files','--stage'))==old['indexEntriesSha256']
    command('sdk-before-build',['dotnet','--version'],ROOT/'references/Hexalith.Platform')
    s=PLAN['steps'][3];r,_,_=command('model-build',s['argv'],pathlib.Path(s['cwd']),check=False)
    write('build-result.json',r)
    if r['exitCode']!=0:print('STOP: build failed; no dependent reference check or repair.',flush=True);return
    assert (Q/'hosts/platform-model/Hexalith.Platform.Composition.dll').is_file()

def after():
    before=json.loads((Q/'filesystem-before.json').read_text());current=inventory('filesystem-after.json')
    a=before['entries'];b=current['entries'];added=sorted(b.keys()-a.keys());removed=sorted(a.keys()-b.keys());changed=sorted(k for k in a.keys()&b.keys() if a[k]!=b[k])
    result={'recordedAtUtc':now(),'added':added,'removed':removed,'changed':changed,'gitMarkersPreserved':before['gitMarkers']==current['gitMarkers'],'outsidePrivateDirectoryPreserved':not added and not removed and not changed,'repositories':{}}
    state=json.loads((Q/'preflight.json').read_text())
    for i,(rel,old) in enumerate(state['repositories'].items()):
        rev=git(f'after-{i}-revision',rel,'rev-parse','HEAD').decode().strip();idx=sha(git(f'after-{i}-index',rel,'ls-files','--stage'));status=git(f'after-{i}-status',rel,'status','--porcelain=v1','--untracked-files=all').decode()
        result['repositories'][rel]={'revision':rev,'indexEntriesSha256':idx,'revisionPreserved':rev==old['revision'],'indexPreserved':idx==old['indexEntriesSha256'],'status':status}
    write('preservation.json',result)
    print(json.dumps({k:v for k,v in result.items() if k!='repositories'}),flush=True)

def metadata():
    assert json.loads((Q/'build-result.json').read_text())['exitCode']==0
    assets=json.loads((Q/'resolved-assets.json').read_text())
    for row in assets:
        assert all(not p.startswith('Hexalith.') for p in row['packageLibraries']),row['project']
        assert all(pathlib.Path(p).resolve().is_relative_to(Q/'cache/nuget/packages') for p in row['packageFolders'])
        for framework in row['projectReferences'].values():
            for ref in framework.get('projectReferences',{}).values():
                assert pathlib.Path(ref['projectPath']).resolve().is_relative_to(ROOT),ref
    write('assets-gate.json',{'passed':True,'projectAssetFiles':len(assets),'unexpectedHexalithPackageFallback':False,'privatePackageCacheOnly':True})
    model=Q/'hosts/platform-model';host=Q/'tool-4.38.0/tools/net10.0/any/g4-host'
    requests=[('model',model/'Hexalith.Platform.Composition.dll'),('apphost',host/'Hexalith.Builds.Module.AppHost.dll')]
    names=['Hexalith.Builds.Tooling.dll','Aspire.Hosting.dll','Hexalith.EventStore.Aspire.dll','Hexalith.EventStore.ServiceDefaults.dll']
    inventory=[]
    for scope,root in [('model',model),('host',host)]:
        for name in names:
            p=root/name;row={'scope':scope,'path':str(p),'present':p.is_file()}
            if p.is_file():
                row.update(sha256=filehash(p),bytes=p.stat().st_size)
                requests.append((scope+'-'+name.removesuffix('.dll'),p))
            inventory.append(row)
    write('metadata-inventory.json',inventory)
    for label,path in requests:
        command('metadata-'+label,['dnx','dotnet-inspect@0.26.0','-y','--','library',str(path),'--json'],ROOT/'references/Hexalith.Platform')

if __name__=='__main__':
    action=sys.argv[1]
    try:globals()[action]()
    except Exception as e:
        write('failure-'+action+'-'+str(time.time_ns())+'.json',{'recordedAtUtc':now(),'action':action,'error':str(e),'type':type(e).__name__})
        raise
