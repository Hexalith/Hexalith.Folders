"""Post-execution evidence corrections; no SDK, CLI, model or host execution."""
import datetime
import json
import pathlib
import shutil

import qualify as q

stores = []
for path in [
    pathlib.Path('/home/administrator/.dotnet/corefx/cryptography/x509stores/my'),
    q.Q / 'dotnet-home/.dotnet/corefx/cryptography/x509stores/my',
]:
    row = {'path': str(path), 'exists': path.exists(), 'entries': []}
    if path.exists():
        for entry in sorted(path.iterdir()):
            st = entry.lstat()
            row['entries'].append({
                'name': entry.name, 'bytes': st.st_size, 'mode': oct(st.st_mode),
                'uid': st.st_uid, 'gid': st.st_gid,
                'mtimeUtc': datetime.datetime.fromtimestamp(st.st_mtime, datetime.timezone.utc).isoformat(),
                'ctimeUtc': datetime.datetime.fromtimestamp(st.st_ctime, datetime.timezone.utc).isoformat(),
                'symlink': entry.is_symlink(),
            })
    stores.append(row)
q.write('certificate-store-observation.json', {
    'recordedAtUtc': q.now(),
    'command': ['python3', '-B', str(pathlib.Path(__file__))],
    'method': 'Directory listing and lstat only; certificate contents were not read; no store changes or cleanup performed.',
    'reportedBySdk': 'Installed an ASP.NET Core HTTPS development certificate.',
    'reportedIn': 'logs/sdk-3.stderr', 'stores': stores,
    'beforeStoreInventoryAvailable': False,
    'conclusion': 'The inspected real-user store has one entry with mtime/ctime predating this run. The SDK message does not independently prove a new certificate was created. No before-store inventory exists, so whole-host preservation is unproven.',
})

initial = json.loads((q.Q / 'sdk.json').read_text())
dotnet = pathlib.Path(shutil.which('dotnet')).resolve()
global_json = pathlib.Path(initial['globalJson']['path'])
version = (q.Q / 'logs/sdk-before-build.stdout').read_text().strip()
q.write('sdk-post-execution-reconciliation.json', {
    'recordedAtUtc': q.now(),
    'command': ['python3', '-B', str(pathlib.Path(__file__))],
    'dotnetPath': str(dotnet), 'sha256': q.filehash(dotnet),
    'initialExecutableHashMatchesNow': q.filehash(dotnet) == initial['sha256'],
    'globalJsonSha256': q.filehash(global_json),
    'initialGlobalJsonHashMatchesNow': q.filehash(global_json) == initial['globalJson']['sha256'],
    'retainedBeforeBuildVersion': version,
    'retainedBeforeBuildVersionMatchesInitialSelection': version == '10.0.402',
    'limit': 'Post-execution reconciliation only. The driver recorded but did not assert the immediate pre-build SDK version, and did not rehash executable/global.json then. This does not retroactively satisfy that planned gate. No rebuild authorized or performed.',
})

record, raw, _ = q.command('review-process-observation', ['ps', '-eo', 'pid,ppid,pgid,stat,comm'])
group = json.loads((q.Q / 'build-result.json').read_text())['processGroupId']
matches = []
for line in raw.decode().splitlines()[1:]:
    fields = line.split(None, 4)
    if len(fields) == 5 and int(fields[2]) == group:
        matches.append(line)
q.write('owned-process-group-observation.json', {
    'observedAtUtc': record['finishedAtUtc'], 'commandRecord': 'logs/review-process-observation.command.json',
    'method': 'Filter retained ps pid,ppid,pgid,stat,comm table by the recorded build processGroupId.',
    'processGroupId': group, 'matchingRows': matches,
    'limit': 'Current process-group observation only; no guarantee about escaped/adopted processes. The earlier qualification-result.json survivors array has no retained observation provenance and is not independently auditable.',
})
assert not matches
print('Post-execution metadata and process observation saved; no build or candidate entry point invoked.')
