import datetime,hashlib,json,subprocess,tarfile,xml.etree.ElementTree as ET,yaml
from pathlib import Path
p=Path(__file__).parent;root=Path.cwd();sha=lambda b:hashlib.sha256(b).hexdigest()
prior_path=Path('_bmad-output/implementation-artifacts/evidence/story-1-17-context-observation-recheck-2026-10-25.json')
prior=json.loads(prior_path.read_text())
ids=['review-production-source-build','review-production-source-tests','release-build','server-final','authorization-final','candidate-generation-one','candidate-generation-two','contracts-final','parity-final','governance-final']
checks=[json.loads((p/(i+'.json')).read_text()) for i in ids]
for c in checks:
 assert c['exit']==0,c['id']
 assert sha((p/c['log']).read_bytes())==c['sha256']
 if 'xml' in c:
  data=(p/c['xml']).read_bytes();assert sha(data)==c['xml_sha256']
  actual={k:sum(int(a.get(k,'0')) for a in ET.fromstring(data).iter('assembly')) for k in ['total','passed','failed','skipped','errors']};assert actual==c['counts']
xml=ET.parse(p/'server-final.xml').getroot()
regressions=[t for t in xml.iter('test') if any(n in t.get('name','') for n in ['NamespaceClassificationRechecksAuthority','PendingSecondClassification'])]
assert len(regressions)==8 and all(t.get('result')=='Pass' for t in regressions)
assert json.loads((p/'binary-identities-after.json').read_text())['unchanged_during_checks']
protected={}
for name,row in prior['preservation']['protected_inputs'].items():
 h=sha(Path(name).read_bytes());assert h==row['before']==row['after'],name;protected[name]=h
for row in prior['preservation']['planning_bindings']:assert sha(Path(row['path']).read_bytes())==row['sha256']
manifest=Path('_bmad-output/implementation-artifacts/evidence/story-12-2-v2-source-requalification-pending.yaml');candidate=yaml.safe_load(manifest.read_bytes())
for a in candidate['artifacts']:
 b=Path(a['path']).read_bytes();assert len(b)==a['bytes'] and sha(b)==a['sha256'],a['path']
assert (p/'candidate-one.yaml').read_bytes()==(p/'candidate-two.yaml').read_bytes()==manifest.read_bytes()
assert not subprocess.check_output(['git','diff','--cached','--name-only'])
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==prior['source']['folders_commit']
subprocess.run(['git','diff','--check'],check=True)
spec=Path('_bmad-output/implementation-artifacts/spec-1-17-complete-pd10-v2-migration-and-closure.md')
ready=Path('_bmad-output/implementation-artifacts/story-1-17-current-candidate-technical-readiness-2026-09-24.md')
for f in [spec,ready]:assert f.read_bytes().startswith(subprocess.check_output(['git','show','HEAD:'+str(f)]))
raw=sha(manifest.read_bytes());sethash=candidate['candidate_set_sha256']
followup='\n\n## 2026-10-25 final local review verification\n\nThe [final review receipt](evidence/story-1-17-context-observation-review-final-2026-10-25.json) records the reviewed code and test bytes, .NET SDK/runtime, assembly/dependency hashes before and after execution, and portable logs. The two later-entry cases use actual asynchronous suspension; all eight new namespace race cases pass, including full folder and content-store snapshot equality. The current production source still has only the one additional post-classifier authority fence.\n\nFinal Debug/source production tests pass 20/20 after review. The full audited Release CI build has zero warnings/errors; affected Release Server/callback tests pass 81/81, authorization/routing 71/71, Contracts 63/63, parity 12/12 and governance 23/23 + 7/7 + 3/3. The earlier Debug 79/79 and Release 79/79 are retained pre-review evidence, not the final post-review suite counts. After final Release authorization completed, two inventory generations again matched across all 1425 paths at raw SHA-256 `{raw}` and ordered-set SHA-256 `{sethash}`. All 193 protected input hashes and 20 planning bindings still match.\n\nThe three review test concerns were patched; gate chronology and full revision references are clarified. One production-latency concern remains explicitly unverified and is recorded in `deferred-work.md`; no measured performance regression is claimed. Aspire startup remains unverified after the retained MSB4166 failure, and the default-profile CS1704 is historical evidence. Exact current-candidate release, hosted source/artifact qualification, target/data disposition, staging, observation, recovery and authorized closure remain incomplete. Preserve the parent `in-progress` status, original baseline/frozen scope/task checkboxes, `V1Only`, unset T0, null activation authority and tracker `backlog`. No Git mutation, dependency change or rollout was performed.\n'
followup=followup.format(raw=raw,sethash=sethash)
with spec.open('a') as f:f.write(followup)
with ready.open('a') as f:f.write(followup.replace('## 2026-10-25 final local review verification','## Addendum 2026-10-25: final local review verification'))
subprocess.run(['git','diff','--check'],check=True)
for name,h in protected.items():assert sha(Path(name).read_bytes())==h
(p/'review-triage.md').write_text(spec.read_text()[spec.read_text().rindex('## Review Triage Log'):])
(p/'final-tracked.diff').write_bytes(subprocess.check_output(['git','diff','HEAD']))
(p/'preservation-final.json').write_text(json.dumps({'protected_hashes':protected,'planning_bindings':prior['preservation']['planning_bindings'],'index_unchanged':True,'original_spec_and_readiness_prefix_preserved':True},indent=2)+'\n')
archive=Path('_bmad-output/implementation-artifacts/evidence/story-1-17-context-observation-review-final-2026-10-25.logs.tar.gz')
files=sorted(x for x in p.iterdir() if x.is_file())
with tarfile.open(archive,'w:gz') as tf:
 for f in files:tf.add(f,arcname=f.name)
record={'record_id':'story-1-17-context-observation-review-final-2026-10-25','recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Final reviewed local qualification only; broader Story 1.17 rollout is incomplete.','source':{'commit':prior['source']['folders_commit'],'original_baseline':prior['source']['original_parent_baseline'],'root_gitlinks':prior['source']['root_gitlinks'],'changed_input_hashes':{f:sha(Path(f).read_bytes()) for f in prior['source']['changed_input_hashes']}},'prior_receipt':{'path':str(prior_path),'sha256':sha(prior_path.read_bytes())},'checks':checks,'toolchain':{'sdk':'10.0.402','host_runtime':'10.0.13','details':'dotnet-info.txt'},'binary_identity_observations':{'before':json.loads((p/'binary-identities-before.json').read_text()),'after':json.loads((p/'binary-identities-after.json').read_text()),'debug_note':'Debug source suite completed before the parent identity snapshot; Release identities were captured before execution and verified afterward.'},'regressions':{'new_namespace_cases':8,'all_pass':True,'suspended_later_entry_cases':2,'full_persisted_state_asserted':True},'candidate':json.loads((p/'candidate-audit.json').read_text()),'preservation':{'protected_inputs':len(protected),'planning_bindings':20,'original_spec_and_readiness_prefix_preserved':True,'original_frontmatter_frozen_intent_and_task_values_preserved':True,'index_unchanged':True,'details':'preservation-final.json'},'review':{'layers':['blind hunter','edge-case hunter','verification gap'],'triage':'review-triage.md','patches':'Later-entry pending classifier and complete persisted-state regressions.','deferred':'Production namespace latency assessment: medium impact, unverified.'},'remaining_startup_failure':prior['remaining_failures'],'operational_control':prior['operational_control'],'archive':{'path':str(archive),'sha256':sha(archive.read_bytes()),'members':{f.name:sha(f.read_bytes()) for f in files}}}
output=archive.with_name(archive.name.replace('.logs.tar.gz','.json'));output.write_text(json.dumps(record,indent=2)+'\n')
with tarfile.open(archive) as tf:
 for m in tf.getmembers():assert sha(tf.extractfile(m).read())==record['archive']['members'][m.name]
print(json.dumps({'receipt':str(output),'archive_members':len(files),'candidate_hash':raw,'checks':{c['id']:c.get('counts',c['exit']) for c in checks},'protected_count':len(protected)},indent=2))
