import json,hashlib,subprocess,sys,datetime,shutil,yaml
from pathlib import Path
p=Path(__file__).parent
root=Path.cwd()
old=json.loads(Path('_bmad-output/implementation-artifacts/evidence/story-1-17-context-observation-recheck-2026-10-25.json').read_text())
old_scratch='/tmp/story117-committed-recheck-20261025-cwy_5yzx'
checks={c['id']:c for c in old['checks']}
sha=lambda b:hashlib.sha256(b).hexdigest()
assemblies={}
for config,project in [('Debug','Hexalith.Folders.Server.Tests'),('Release','Hexalith.Folders.Server.Tests'),('Release','Hexalith.Folders.IntegrationTests'),('Release','Hexalith.Folders.Contracts.Tests')]:
 for suffix in ['.dll','.deps.json','.runtimeconfig.json']:
  f=root/'tests'/project/'bin'/config/'net10.0'/(project+suffix)
  assemblies[str(f.relative_to(root))]={'sha256':sha(f.read_bytes()),'bytes':f.stat().st_size}
(p/'binary-identities-before.json').write_text(json.dumps({'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':assemblies},indent=2)+'\n')
for name in ['server-final','authorization-final','candidate-generation-one','candidate-generation-two','contracts-final','parity-final','governance-final']:
 cmd=[v.replace(old_scratch,str(p)) for v in checks[name]['command']]
 result=subprocess.run([sys.executable,str(p/'run.py'),name,*cmd])
 if result.returncode: sys.exit(result.returncode)
 if name=='candidate-generation-two':
  first=(p/'candidate-one.yaml').read_bytes(); second=(p/'candidate-two.yaml').read_bytes(); assert first==second
  dest=Path('_bmad-output/implementation-artifacts/evidence/story-12-2-v2-source-requalification-pending.yaml')
  current=yaml.safe_load(dest.read_bytes()); new=yaml.safe_load(first)
  controls=lambda d:{k:v for k,v in d.items() if k not in ['artifacts','candidate_set_sha256','artifact_count']}
  assert controls(current)==controls(new)
  for a in new['artifacts']:
   b=Path(a['path']).read_bytes(); assert len(b)==a['bytes'] and sha(b)==a['sha256'],a['path']
  dest.write_bytes(first)
  (p/'candidate-audit.json').write_text(json.dumps({'artifact_count':len(new['artifacts']),'raw_sha256':sha(first),'set_sha256':new['candidate_set_sha256'],'all_sizes_and_hashes_match':True,'pending_authority_fields_preserved':True},indent=2)+'\n')
  print('Verified and wrote pending manifest',sha(first),flush=True)
after={f:{'sha256':sha(Path(f).read_bytes()),'bytes':Path(f).stat().st_size} for f in assemblies}
assert after==assemblies
(p/'binary-identities-after.json').write_text(json.dumps({'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':after,'unchanged_during_checks':True},indent=2)+'\n')
