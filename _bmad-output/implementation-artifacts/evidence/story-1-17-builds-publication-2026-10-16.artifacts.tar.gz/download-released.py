#!/usr/bin/env python3
"""Download only an observed release and retain its signed NuGet package identity."""
import base64
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import urllib.request
import xml.etree.ElementTree as ET
import zipfile

if not __debug__:
 raise SystemExit('Integrity verification requires Python assertions; optimization is refused.')

case=Path(__file__).resolve().parent
before=json.loads((case/'before.json').read_bytes())
candidate=json.loads((case/'candidate-source.json').read_bytes())
release=json.loads((case/'release.json').read_bytes())
tag=json.loads((case/'tag-ref.json').read_bytes())
version=release['tag_name'].removeprefix('v')
assert re.fullmatch(r'\d+\.\d+\.\d+',version),version
assert release['tag_name']!='v4.31.2' and release['published_at']>='2026-10-16T15:33:07Z'
assert tag['object']['type']=='commit' and tag['object']['sha']==candidate['revision'],tag
inventory_path=case/'release/g4-tool-package-inventory.json'
inv=json.loads(inventory_path.read_bytes())
assert inv['version']==version and inv['configuration']=='Release'
assert len(inv['packages'])==2 and {x['id'] for x in inv['packages']}=={'Hexalith.Builds.Evidence.Cli','Hexalith.Builds.Module.Cli'}
q=inv['qualification']
assert q['sourceTree']=={'clean':True,'revision':candidate['revision']}
assert q['releaseEligible'] is True and not q['ineligibilityReasons']
for lane in ['sourceValidation','controls']:assert q[lane]=={'mode':'executed','result':'passed'}
assert q['packageBuild']=={'mode':'official','result':'passed'} and q['fixtures']['mode']=='repository-tracked'
assets=[x for x in release['assets'] if x['name']=='g4-tool-package-inventory.json'];assert len(assets)==1
sha=lambda b:hashlib.sha256(b).hexdigest()
assert assets[0]['digest']=='sha256:'+sha(inventory_path.read_bytes())
output=case/'downloads';output.mkdir(exist_ok=False)
rows=[]
for row in inv['packages']:
 identity=row['id'];assert identity in ['Hexalith.Builds.Evidence.Cli','Hexalith.Builds.Module.Cli']
 lower=identity.lower();url='https://api.nuget.org/v3-flatcontainer/'+lower+'/'+version+'/'+lower+'.'+version+'.nupkg'
 started=datetime.now(timezone.utc).isoformat()
 with urllib.request.urlopen(url,timeout=60) as response:body=response.read();headers=dict(response.headers)
 path=output/(lower+'.'+version+'.nupkg');path.write_bytes(body)
 with zipfile.ZipFile(path) as archive:
  names=archive.namelist();assert len(names)==len(set(names))
  assert names.count('.signature.p7s')==1
  specs=[n for n in names if n.endswith('.nuspec')];assert len(specs)==1
  spec=ET.fromstring(archive.read(specs[0]))
  metadata=next(x for x in spec if x.tag.rsplit('}',1)[-1]=='metadata')
  fields={x.tag.rsplit('}',1)[-1]:x for x in metadata}
  assert fields['id'].text==identity and fields['version'].text==version
  assert fields['repository'].attrib['commit']==candidate['revision']
  assert fields['repository'].attrib['url'].rstrip('/').removesuffix('.git').lower()=='https://github.com/hexalith/hexalith.builds'
  types=[e.attrib['name'] for e in fields['packageTypes']];assert types==['DotnetTool'],types
  entries={n:sha(archive.read(n)) for n in sorted(names) if n!='.signature.p7s'}
 proof={'id':identity,'version':version,'url':url,'file':path.relative_to(case).as_posix(),'signedSha256':sha(body),'signedSizeBytes':len(body),'qualifiedUnsignedSha256':row['nupkg']['sha256'].lower(),'qualifiedSymbolsSha256':row['snupkg']['sha256'].lower(),'repositoryCommit':candidate['revision'],'signaturePresent':True,'payloadEntriesSha256':entries,'sha512Base64':base64.b64encode(hashlib.sha512(body).digest()).decode(),'startedAtUtc':started,'finishedAtUtc':datetime.now(timezone.utc).isoformat()}
 rows.append(proof);print(identity+' signed SHA-256 '+proof['signedSha256'],flush=True)
(case/'signed-packages.json').write_text(json.dumps({'version':version,'sourceRevision':candidate['revision'],'releaseInventorySha256':sha(inventory_path.read_bytes()),'packages':rows},indent=2)+'\n')
