#!/usr/bin/env python3
"""Reject altered publication artifacts even when their outer hashes are recomputed."""
import copy
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
import zipfile
import xml.etree.ElementTree as ET

if not __debug__:
 raise SystemExit('Integrity verification requires Python assertions; optimization is refused.')
case=Path(__file__).resolve().parent
workspace=case.parents[1]
receipt=workspace/'_bmad-output/implementation-artifacts/evidence/story-1-17-builds-publication-2026-10-16.json'
original=json.loads(receipt.read_bytes())
verifier=workspace/'eng/story117-builds-publication/verify.py'
sha=lambda body:hashlib.sha256(body).hexdigest()
with tarfile.open(workspace/original['retainedArtifactBundle']['path'],'r:gz') as archive:
 bodies={m.name:archive.extractfile(m).read() for m in archive.getmembers() if m.isfile()}
def encode(value):return (json.dumps(value,indent=2)+'\n').encode()
def mutate(name,record,members):
 if name=='duplicate-signed-tool':
  signed=json.loads(members['signed-packages.json']);signed['packages']=[signed['packages'][0],signed['packages'][0]]
  members['signed-packages.json']=encode(signed);record['signedPackages']=signed
 elif name=='duplicate-signature-target':
  rows=record['verificationCommands'];indices=[i for i,r in enumerate(rows) if r['command'][:3]==['dotnet','nuget','verify']];rows[indices[1]]=copy.deepcopy(rows[indices[0]])
 elif name in ['duplicate-control','noncanonical-stdout','changed-expectation']:
  controls=json.loads(members['installed-controls.json']);rows=[r for r in controls['controls'] if 'fixture' in r]
  if name=='duplicate-control':controls['controls']=[r for r in controls['controls'] if 'fixture' not in r]+[copy.deepcopy(rows[0]) for _ in range(37)]
  elif name=='noncanonical-stdout':
   row=rows[0];key=row['stdout']['file'];members[key]=b'\xef\xbb\xbf'+members[key];row['stdout']['sha256']=sha(members[key]);row['stdout']['sizeBytes']=len(members[key])
  else:
   row=rows[0];key=row['fixture'].removeprefix('test/').removesuffix('.json')+'.expected.json';expected=json.loads(members[key]);expected['ruleIds']=[];members[key]=encode(expected);row['expectation']=expected;row['expectationSha256']=sha(members[key])
  members['installed-controls.json']=encode(controls)
 elif name=='stale-source-ci':
  run=json.loads(members['exact-head-ci.log']);run['head_sha']=json.loads(members['before.json'])['localBuildsHead'];members['exact-head-ci.log']=encode(run)
 elif name=='stale-diagnostic-source':
  inventory=json.loads(members['source-qualification/g4-tool-package-inventory.json']);item=inventory['packages'][0]['nupkg'];key='source-qualification/'+item['file']
  stale=json.loads(members['before.json'])['localBuildsHead'];buffer=io.BytesIO()
  with zipfile.ZipFile(io.BytesIO(members[key])) as original_archive, zipfile.ZipFile(buffer,'w') as altered:
   for entry in original_archive.infolist():
    body=original_archive.read(entry.filename)
    if entry.filename.endswith('.nuspec'):
     spec=ET.fromstring(body)
     for node in spec.iter():
      if node.tag.rsplit('}',1)[-1]=='repository':node.set('commit',stale)
     body=ET.tostring(spec,encoding='utf-8',xml_declaration=True)
    altered.writestr(entry,body)
  members[key]=buffer.getvalue();item['sha256']=sha(members[key]).upper();item['sizeBytes']=len(members[key])
  inventory_key='source-qualification/g4-tool-package-inventory.json';members[inventory_key]=encode(inventory)
  candidate=json.loads(members['candidate-source.json']);candidate['inventorySha256']=sha(members[inventory_key]);members['candidate-source.json']=encode(candidate);record['freshSourceQualification']=candidate
 elif name=='changed-diagnostic-archive':
  inv=json.loads(members['source-qualification/g4-tool-package-inventory.json']);key='source-qualification/'+inv['packages'][0]['nupkg']['file'];members[key]=members[key]+b'altered'
 elif name=='missing-protected-files':record['protectedWorkspaceFilesSha256']={}
 elif name=='wrong-workflow':
  run=json.loads(members['release-run.log']);run['repository']['full_name']='Example/Unrelated';run['path']='.github/workflows/unrelated.yml';members['release-run.log']=encode(run)
 else:raise ValueError(name)
cases=['duplicate-signed-tool','duplicate-signature-target','duplicate-control','changed-expectation','missing-protected-files','wrong-workflow','noncanonical-stdout','stale-source-ci','changed-diagnostic-archive','stale-diagnostic-source']
baseline=subprocess.run([sys.executable,str(verifier),'--workspace',str(workspace),'--receipt',str(receipt)],capture_output=True,text=True)
assert baseline.returncode==0,(baseline.returncode,baseline.stdout,baseline.stderr)
results=[]
with tempfile.TemporaryDirectory(prefix='story117-publication-controls-') as directory:
 target=Path(directory)
 for name in cases:
  record=copy.deepcopy(original);members=dict(bodies);mutate(name,record,members)
  bundle=target/'altered.tar.gz'
  with bundle.open('wb') as raw:
   with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as compressed:
    with tarfile.open(fileobj=compressed,mode='w') as archive:
     for key,body in sorted(members.items()):
      item=tarfile.TarInfo(key);item.size=len(body);archive.addfile(item,io.BytesIO(body))
  record['retainedArtifactBundle'].update({'path':str(bundle),'sha256':sha(bundle.read_bytes()),'sizeBytes':bundle.stat().st_size,'membersSha256':{k:sha(b) for k,b in sorted(members.items())}})
  path=target/'altered.json';path.write_bytes(encode(record))
  command=[sys.executable,str(verifier),'--workspace',str(workspace),'--receipt',str(path)]
  result=subprocess.run(command,capture_output=True,text=True)
  assert result.returncode==1 and 'Publication evidence verification failed:' in result.stderr,(name,result.returncode,result.stdout,result.stderr)
  results.append({'case':name,'exitCode':result.returncode,'expectedExitCode':1,'matched':True,'stderr':result.stderr})
  print(name+': expected refusal after recomputing outer hashes',flush=True)
result=subprocess.run([sys.executable,'-O',str(verifier)],capture_output=True,text=True)
assert result.returncode==1 and 'optimization is refused' in result.stderr
results.append({'case':'optimized-python','exitCode':result.returncode,'expectedExitCode':1,'matched':True,'stderr':result.stderr})
(case/'verifier-controls.json').write_text(json.dumps({'baseline':{'exitCode':baseline.returncode,'stdout':baseline.stdout,'stderr':baseline.stderr},'syntheticTamperInputs':True,'allRefusedAsExpected':True,'controls':results},indent=2)+'\n')
print('All eleven altered-execution/artifact controls refused as expected.')
