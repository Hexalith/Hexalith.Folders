#!/usr/bin/env python3
from datetime import datetime,timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

if not __debug__:
 raise SystemExit('Integrity verification requires Python assertions; optimization is refused.')

case=Path(__file__).resolve().parent
workspace=case.parents[1]
builds=workspace/'references/Hexalith.Builds'
output=workspace/'_bmad-output/implementation-artifacts/evidence'
prefix='story-1-17-builds-publication-2026-10-16'
read=lambda p:json.loads(p.read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
write=lambda p,r:p.write_text(json.dumps(r,indent=2)+'\n')
candidate=read(case/'candidate-source.json')
before=read(case/'before.json');run=read(case/'release-run.log');release=read(case/'release.json')
assert run['status']=='completed' and run['conclusion']=='success' and run['head_sha']==candidate['revision']
assert release['tag_name']!='v4.31.2' and not release['draft'] and not release['prerelease']
version=release['tag_name'].removeprefix('v')
signed=read(case/'signed-packages.json');assert signed['version']==version
inventory=read(case/'release/g4-tool-package-inventory.json')
controls=read(case/'installed-controls.json');assert controls['allMatched'] and controls['acceptanceControlCount']==37
commands=[read(case/(name+'.command.json')) for name in ['signature-evidence','signature-module','installed-controls','published-seed']]
for command in commands:
 assert command['exitCode']==0,command
 assert sha((case/command['log']).read_bytes())==command['sha256']
for name,h in before['protectedWorkspaceFilesSha256'].items():assert sha((workspace/name).read_bytes())==h,name
for name,h in read(case/'platform-inputs-preservation.json')['filesSha256'].items():assert sha((workspace/name).read_bytes())==h,name
assert subprocess.check_output(['git','status','--porcelain'],cwd=builds,text=True)==''
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=builds,text=True).strip()==candidate['revision']
log=(case/'release-workflow.log').read_text()
for row in signed['packages']:
 marker=f"Verified remote '{row['id']}' '{version}' SHA-256 {row['signedSha256']} (qualified local SHA-256 {row['qualifiedUnsignedSha256']})."
 assert marker.lower() in log.lower(),row['id']
members={}
for p in case.rglob('*'):
 if not p.is_file() or '__pycache__' in p.parts:continue
 relative=p.relative_to(case)
 if relative.parts[:2]==('failed-installed-attempt-one','consumer'):continue
 if relative.parts[0]=='consumer':
  if relative.parts[:3]==('consumer','test','fixtures'):members['fixtures/'+Path(*relative.parts[3:]).as_posix()]=p.read_bytes()
  continue
 if p.suffix in ['.json','.log','.txt','.py','.ps1','.nupkg','.snupkg'] or relative.parts[0]=='release':members[relative.as_posix()]=p.read_bytes()
for name in ['story-1-17-current-candidate-technical-readiness-2026-09-24.md','deferred-work.md']:
 p=workspace/'_bmad-output/implementation-artifacts'/name;members['historical/'+name]=p.read_bytes()
prior=workspace/'_bmad-output/implementation-artifacts/evidence/story-1-17-builds-clean-source-qualification-2026-10-16.json'
assert sha(prior.read_bytes())==before['priorQualificationReceiptSha256'];members['historical/'+prior.name]=prior.read_bytes()
archive_path=output/(prefix+'.artifacts.tar.gz')
assert not archive_path.exists()
with archive_path.open('wb') as target:
 with gzip.GzipFile(fileobj=target,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as archive:
   for name,body in sorted(members.items()):
    entry=tarfile.TarInfo(name);entry.mode=0o644;entry.size=len(body);entry.mtime=0;archive.addfile(entry,io.BytesIO(body))
bundle={'path':archive_path.relative_to(workspace).as_posix(),'sha256':sha(archive_path.read_bytes()),'sizeBytes':archive_path.stat().st_size,'membersSha256':{n:sha(b) for n,b in sorted(members.items())}}
manifest=output/(prefix+'.artifacts.manifest.json');write(manifest,bundle)
record={'schema':'hexalith.story117.builds-publication.v1','recordedAtUtc':datetime.now(timezone.utc).isoformat(),'authorization':before['authorization'],
 'workflowRunId':run['id'],'workflowUrl':run['html_url'],'newDispatchPerformedByThisAgent':read(case/'dispatch-observation.json')['newDispatchPerformedByThisAgent'],
 'dispatchObservation':read(case/'dispatch-observation.json'),
 'freshSourceQualification':candidate,
 'priorFailedAttempt':{'runId':before['existingReleaseRun'],'runAttempt':1,'latestObservedRetry':{'attempt':read(case/'prior-attempt-final.log')['run_attempt'],'conclusion':read(case/'prior-attempt-final.log')['conclusion']},'sourceRevision':before['localBuildsHead'],'candidateVersion':'4.32.0','published':False,'failure':'HXR028 stdin-listener blocked-after-stop in inherited-open-stdin deadline unit test; fixed by controlled test input and freshly qualified source.'},
 'releaseDispatch':{'actor':run['actor']['login'],'createdAt':run['created_at'],'event':run['event'],'environmentReviewHistory':read(case/'release-environment-reviews.log')},
 'version':version,'sourceRevision':run['head_sha'],'releaseUrl':release['html_url'],'publishedAt':release['published_at'],
 'inventorySha256':sha((case/'release/g4-tool-package-inventory.json').read_bytes()),'qualification':inventory['qualification'],
 'signedPackages':signed,'verificationCommands':commands,'syntheticAcceptanceControls':37,'realAcceptanceEvidenceCreated':False,
 'retainedArtifactBundle':bundle,'protectedWorkspaceFilesSha256':before['protectedWorkspaceFilesSha256'],
 'preservation':{'capturedPlatformFilesUnchanged':4888,'protectedWorkspaceFilesUnchanged':42,'priorDiagnosticReceiptUnchanged':True,'priorDirtyDiagnosticReleaseEligible':False},
 'verificationFilesSha256':{p.relative_to(workspace).as_posix():sha(p.read_bytes()) for p in [workspace/'eng/story117-builds-publication/verify.py',workspace/'eng/story117-builds-publication/README.md',manifest]},
 'foldersCiObservation':read(case/'folders-ci-observation.json'),
 'priorCleanSourceQualification':{'path':prior.relative_to(workspace).as_posix(),'sha256':sha(prior.read_bytes()),'status':'Historical authorized Git/source qualification before publication authorization; unchanged.'},
 'decision':{'entry':'HOLD','buildsPublicationVerified':True,'platformAcceptance':False,'stagingQualification':False,'storyClosure':False,'productionMode':'V1Only','t0Utc':None,'storyTracker':'backlog','stagingChecksExecuted':0,'stagingChecksRemaining':14},
 'remainingBlocker':'Real Platform acceptance with the exact released tool pin/range and coherent Builds gitlink, released owner declarations/attestations and intake prerequisites; staging/deployment and production activation remain separately authorized.',
 'nextCommands':{'verify':'python3 eng/story117-builds-publication/verify.py','inspectRelease':f'gh release view {release["tag_name"]} --repo Hexalith/Hexalith.Builds'},
 'limits':['Synthetic validator records and sample approvals remain synthetic, never a real Platform acceptance decision.','Signed NuGet outer hashes differ from qualified unsigned hashes; the successful publisher proves exact payload equivalence and these downloads match its observed signed hashes.','Qualified symbol archive hashes are retained from the release inventory; no independent signed symbol-package download is claimed.','No diagnostic 4.31.2 archive was uploaded or relabeled.','No publication changes the 14 unexecuted staging checks or Story 1.17 state.']}
receipt=output/(prefix+'.json');assert not receipt.exists();write(receipt,record)
lines=[f"Builds {version} at {run['head_sha']}",'SHA-256  artifact']
for row in signed['packages']:
 lines.append(row['signedSha256']+'  published signed '+row['file'])
for label,inv in [('published qualification',inventory),('local diagnostic only',read(case/'source-qualification/g4-tool-package-inventory.json'))]:
 for package in inv['packages']:
  for role in ['nupkg','snupkg']:
   artifact=package[role];lines.append(artifact['sha256'].lower()+'  '+label+' '+artifact['file'])
lines += [record['inventorySha256']+'  released g4-tool-package-inventory.json',bundle['sha256']+'  '+archive_path.name,sha(receipt.read_bytes())+'  '+receipt.name]
(output/(prefix+'.hashes.txt')).write_text('\n'.join(lines)+'\n')
print(json.dumps({'version':version,'sourceRevision':run['head_sha'],'receiptSha256':sha(receipt.read_bytes()),'bundleSha256':bundle['sha256'],'inventorySha256':record['inventorySha256'],'signedPackages':[{k:r[k] for k in ['id','signedSha256','qualifiedUnsignedSha256','qualifiedSymbolsSha256']} for r in signed['packages']]},indent=2))
