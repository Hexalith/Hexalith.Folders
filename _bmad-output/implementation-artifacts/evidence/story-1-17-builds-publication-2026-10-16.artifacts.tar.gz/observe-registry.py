#!/usr/bin/env python3
import base64
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess
from urllib.request import Request,urlopen
from urllib.error import HTTPError
case=Path(__file__).resolve().parent
registry='registry.hexalith.com'
config=json.loads((Path.home()/'.docker/config.json').read_bytes())
auth=config.get('auths',{}).get(registry,{}).get('auth')
if not auth:
 helper=config.get('credHelpers',{}).get(registry,config.get('credsStore'))
 result=subprocess.run(['docker-credential-'+helper,'get'],input=(registry+'\n').encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
 credential=json.loads(result.stdout)
 auth=base64.b64encode((credential['Username']+':'+credential['Secret']).encode()).decode()
rows=[]
def request(name,path):
 started=datetime.now(timezone.utc).isoformat();url='https://'+registry+path
 headers={'Authorization':'Basic '+auth,'Accept':'application/vnd.oci.image.index.v1+json, application/vnd.oci.image.manifest.v1+json, application/vnd.docker.distribution.manifest.v2+json'}
 try:
  with urlopen(Request(url,headers=headers),timeout=30) as response:body=response.read();status=response.status;digest=response.headers.get('Docker-Content-Digest')
 except HTTPError as error:body=error.read();status=error.code;digest=None
 (case/(name+'.json')).write_bytes(body)
 row={'method':'GET','url':url,'httpStatus':status,'digest':digest,'body':name+'.json','sha256':hashlib.sha256(body).hexdigest(),'startedAtUtc':started,'finishedAtUtc':datetime.now(timezone.utc).isoformat(),'credentialSource':'existing Docker credential configuration/helper; no credentials retained'}
 rows.append(row);return row
manifest=request('registry-eventstore-current-manifest','/v2/eventstore/manifests/3.123.0')
if manifest['httpStatus']==200:
 digest=manifest['digest'] or 'sha256:'+manifest['sha256']
 request('registry-eventstore-current-referrers','/v2/eventstore/referrers/'+digest)
(case/'registry-current-observations.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps([{'httpStatus':row['httpStatus'],'digest':row['digest'],'body':row['body']} for row in rows]))
