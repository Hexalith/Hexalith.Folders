#!/usr/bin/env python3
"""Retain a completed fresh qualification and its actual clean source/CI identity."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

if not __debug__:
    raise SystemExit('Integrity verification requires Python assertions; optimization is refused.')

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--qualification-directory', required=True, type=Path)
p.add_argument('--qualification-command', required=True)
p.add_argument('--ci-run-id', required=True, type=int)
a = p.parse_args()
case = Path(__file__).resolve().parent
workspace = case.parents[1]
builds = workspace / 'references/Hexalith.Builds'
read = lambda path: json.loads(path.read_bytes())
sha = lambda body: hashlib.sha256(body).hexdigest()
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=builds, text=True).strip()
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=builds, text=True) == ''
ci = read(case / 'exact-head-ci.log')
assert ci['repository']['full_name'] == 'Hexalith/Hexalith.Builds'
assert ci['id'] == a.ci_run_id and ci['head_sha'] == revision
assert ci['path'] == '.github/workflows/ci.yml' and ci['event'] == 'push'
assert ci['head_branch'] == 'main' and ci['status'] == 'completed' and ci['conclusion'] == 'success'
command = read(case / a.qualification_command)
assert command['exitCode'] == 0 and '-RequireControls' in command['command']
assert '-SkipSourceValidation' not in command['command']
log = (case / command['log']).read_bytes()
assert sha(log) == command['sha256']
source = a.qualification_directory.resolve()
inventory = read(source / 'g4-tool-package-inventory.json')
q = inventory['qualification']
assert q['sourceTree'] == {'clean': True, 'revision': revision}
assert q['releaseEligible'] is True and q['ineligibilityReasons'] == []
assert q['packageBuild'] == {'mode': 'official', 'result': 'passed'}
for lane in ['sourceValidation', 'controls']:
    assert q[lane] == {'mode': 'executed', 'result': 'passed'}
assert q['fixtures']['mode'] == 'repository-tracked'
assert len(inventory['qualificationEvidence']) == 55
target = case / 'source-qualification'
target.mkdir(exist_ok=False)
files = [*inventory['qualificationEvidence']]
for package in inventory['packages']:
    files += [package['nupkg'], package['snupkg']]
for row in files:
    body = (source / row['file']).read_bytes()
    assert sha(body) == row['sha256'].lower() and len(body) == row['sizeBytes']
    destination = target / row['file']
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(body)
shutil.copyfile(source / 'g4-tool-package-inventory.json', target / 'g4-tool-package-inventory.json')
counts = [dict(zip(['total', 'failed', 'passed', 'skipped'], map(int, row), strict=True))
          for row in re.findall(r'total: (\d+)\s+failed: (\d+)\s+succeeded: (\d+)\s+skipped: (\d+)', log.decode())]
record = {
    'recordedAtUtc': datetime.now(timezone.utc).isoformat(),
    'revision': revision,
    'tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=builds, text=True).strip(),
    'clean': True,
    'ciRunId': ci['id'],
    'ciUrl': ci['html_url'],
    'inventorySha256': sha((target / 'g4-tool-package-inventory.json').read_bytes()),
    'qualificationCommandFile': a.qualification_command,
    'sourceTestProjects': counts,
    'sourceTestTotals': {key: sum(row[key] for row in counts) for key in ['total', 'failed', 'passed', 'skipped']},
    'diagnosticVersion': inventory['version'],
    'diagnosticOnly': True,
    'note': 'Fresh complete qualification on the combined source, including concurrent upstream startup handling. No prior-source pass substitutes for changed inputs; diagnostic 4.31.2 bytes must not be published.'
}
path = case / 'candidate-source.json'
assert not path.exists()
path.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
