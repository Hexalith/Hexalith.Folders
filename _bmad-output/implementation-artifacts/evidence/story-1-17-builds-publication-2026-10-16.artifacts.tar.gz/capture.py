#!/usr/bin/env python3
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
p=argparse.ArgumentParser()
p.add_argument('--name',required=True)
p.add_argument('--cwd',required=True,type=Path)
p.add_argument('command',nargs=argparse.REMAINDER)
a=p.parse_args();cmd=a.command[1:] if a.command[0]=='--' else a.command
case=Path(__file__).resolve().parent;started=datetime.now(timezone.utc).isoformat();log=case/(a.name+'.log')
with log.open('xb') as out: r=subprocess.run(cmd,cwd=a.cwd,stdout=out,stderr=subprocess.STDOUT)
record={'command':cmd,'cwd':str(a.cwd.resolve()),'startedAtUtc':started,'finishedAtUtc':datetime.now(timezone.utc).isoformat(),'exitCode':r.returncode,'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
(case/(a.name+'.command.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record));raise SystemExit(r.returncode)
