#!/usr/bin/env python3
"""Run metadata-only synthetic acceptance controls against downloaded release bytes."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
from xml.sax.saxutils import escape

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--version',required=True)
p.add_argument('--revision',required=True)
a=p.parse_args()
if not __debug__:
 raise SystemExit('Integrity verification requires Python assertions; optimization is refused.')

case=Path(__file__).resolve().parent
workspace=case.parents[1]
builds=workspace/'references/Hexalith.Builds'
inventory=json.loads((case/'release/g4-tool-package-inventory.json').read_bytes())
assert inventory['version']==a.version and inventory['qualification']['sourceTree']=={'clean':True,'revision':a.revision}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=builds,text=True).strip()==a.revision
assert subprocess.check_output(['git','status','--porcelain'],cwd=builds,text=True)==''
consumer=case/'consumer'
consumer.mkdir(exist_ok=False)
# Match the official package gate: bind repository-relative fixture paths to this synthetic consumer.
initialization=subprocess.run(['git','-C',str(consumer),'init','--quiet'],capture_output=True,check=True)
assert initialization.returncode==0
streams=case/'controls';streams.mkdir(exist_ok=False)
shutil.copytree(builds/'test/fixtures',consumer/'test/fixtures')
for item in inventory['qualification']['fixtures']['files']:
 path=consumer/'test/fixtures'/item['file']
 assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256'].lower(),item['file']
 assert path.stat().st_size==item['sizeBytes'],item['file']
prior_path=workspace/'_bmad-output/implementation-artifacts/evidence/story-1-17-builds-clean-source-qualification-2026-10-16.json'
assert hashlib.sha256(prior_path.read_bytes()).hexdigest()=='80604829ed24bc571732384ea654004b2d234228de11531c260d7c9e16a398db'
prior=json.loads(prior_path.read_bytes())
canonical_path=case/'synthetic-expectations-preservation.json'
assert hashlib.sha256(canonical_path.read_bytes()).hexdigest()==prior['retainedArtifactBundle']['membersSha256']['verification/synthetic-expectations-preservation.json']
canonical=json.loads(canonical_path.read_bytes())['unchangedExpectationsSha256']
for name,expected_hash in canonical.items():
 assert hashlib.sha256((consumer/'test/fixtures/evidence/acceptance'/name).read_bytes()).hexdigest()==expected_hash,name

(consumer/'.config').mkdir()
ids={'hexalith.builds.module.cli':'hexalith-module','hexalith.builds.evidence.cli':'hexalith-evidence'}
(consumer/'.config/dotnet-tools.json').write_text(json.dumps({'version':1,'isRoot':True,'tools':{i:{'version':a.version,'commands':[cmd]} for i,cmd in ids.items()}},indent=2)+'\n')
(consumer/'NuGet.Config').write_text('<?xml version="1.0" encoding="utf-8"?>\n<configuration><packageSources><clear/><add key="frozen-signed-downloads" value="'+escape(str(case/'downloads'))+'"/></packageSources></configuration>\n')
env=os.environ.copy();env.update({'NUGET_PACKAGES':str(consumer/'packages'),'DOTNET_CLI_HOME':str(consumer/'cli-home'),'DOTNET_NOLOGO':'1','DOTNET_CLI_TELEMETRY_OPTOUT':'1','DOTNET_PROCESSOR_COUNT':'2'})
rows=[]
sha=lambda b:hashlib.sha256(b).hexdigest()
def run(key,args):
 started=datetime.now(timezone.utc).isoformat()
 result=subprocess.run(['dotnet',*args],cwd=consumer,env=env,capture_output=True,timeout=300)
 files={}
 for kind,body in [('stdout',result.stdout),('stderr',result.stderr)]:
  path=streams/(key+'.'+kind+'.txt');path.write_bytes(body)
  files[kind]={'file':path.relative_to(case).as_posix(),'sha256':sha(body),'sizeBytes':len(body)}
 row={'key':key,'command':['dotnet',*args],'exitCode':result.returncode,'startedAtUtc':started,'finishedAtUtc':datetime.now(timezone.utc).isoformat(),**files}
 rows.append(row)
 (case/'installed-controls.json').write_text(json.dumps({'synthetic':True,'acceptanceEvidence':False,'version':a.version,'sourceRevision':a.revision,'controls':rows},indent=2)+'\n')
 return result,row
r,_=run('restore',['tool','restore','--configfile','NuGet.Config','--no-http-cache']);assert r.returncode==0,r.stderr.decode()
for i,cmd in ids.items():
 cached=consumer/'packages'/i/a.version/(i+'.'+a.version+'.nupkg')
 original=case/'downloads'/(i+'.'+a.version+'.nupkg')
 assert sha(cached.read_bytes())==sha(original.read_bytes()),i
 r,row=run(cmd+'-version',['tool','run',cmd,'--','--version']);assert r.returncode==0 and r.stdout.decode().strip()==a.version+'+'+a.revision,(cmd,r.stdout,r.stderr)
 row['matchedExpectation']=True
 r,row=run(cmd+'-help',['tool','run',cmd,'--','--help']);assert r.returncode==0 and not r.stderr and b'Usage:' in r.stdout,(cmd,r.stdout,r.stderr)
 row['matchedExpectation']=True
root=consumer/'test/fixtures/evidence/acceptance'
fixtures=sorted((root/'positive').glob('*.json'))+sorted((root/'negative').glob('*.json'))
fixtures=[f for f in fixtures if not f.name.endswith('.expected.json')]
assert len(fixtures)==37,len(fixtures)
assert {f.relative_to(root).as_posix() for f in fixtures}=={n.removesuffix('.expected.json')+'.json' for n in canonical}
for fixture in fixtures:
 expected_path=fixture.with_suffix('.expected.json');expected=json.loads(expected_path.read_bytes())
 key=fixture.parent.name+'-'+fixture.stem
 r,row=run(key,['tool','run','hexalith-evidence','--','validate',fixture.relative_to(consumer).as_posix(),'--output','json'])
 row.update({'fixture':fixture.relative_to(consumer).as_posix(),'fixtureSha256':sha(fixture.read_bytes()),'expectation':expected,'expectationSha256':sha(expected_path.read_bytes())})
 assert r.returncode==expected['exitCode'],(key,r.returncode,r.stdout,r.stderr)
 assert not r.stderr and not r.stdout.startswith(b'\xef\xbb\xbf') and b'\r' not in r.stdout and r.stdout.endswith(b'\n') and not r.stdout.endswith(b'\n\n'),key
 result=json.loads(r.stdout.decode('utf-8'))
 assert type(result['status']) is str and result['status']==expected['status'],key
 for name,value in [('exitCode',expected['outcomeExitCode']),('phase',expected['phase']),('category',expected['category']),('ruleId',expected['outcomeRuleId'])]:
  assert type(result['outcome'][name]) is type(value) and result['outcome'][name]==value,(key,name,result['outcome'])
 assert [d['ruleId'] for d in result['diagnostics']]==expected['ruleIds'],key
 row['matchedExpectation']=True
 print(key+': exact expectation passed')
(case/'installed-controls.json').write_text(json.dumps({'synthetic':True,'acceptanceEvidence':False,'version':a.version,'sourceRevision':a.revision,'controls':rows,'acceptanceControlCount':37,'allMatched':True,'downloadedArchiveCacheHashesMatch':True,'fixturePreparation':{'command':['git','-C',str(consumer),'init','--quiet'],'exitCode':initialization.returncode,'synthetic':True,'commitsCreated':False}},indent=2)+'\n')
print('Both downloaded tools match version/source; all 37 synthetic acceptance controls pass exactly. No acceptance decision or live run.')
