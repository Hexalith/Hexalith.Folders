// <copyright file="ReadinessEvidenceValidator.cs" company="ITANEO">
// Copyright (c) ITANEO (https://www.itaneo.com). All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.
// </copyright>

namespace Hexalith.Builds.Tooling.Evidence;

using System.Security.Cryptography;
using System.Text;

using Hexalith.Builds.Tooling.Diagnostics;
using Hexalith.Builds.Tooling.Filesystem;
using Hexalith.Builds.Tooling.Manifest;
using Hexalith.Builds.Tooling.RunEvidence;

using YamlDotNet.Core;
using YamlDotNet.RepresentationModel;
using YamlDotNet.Serialization;

/// <summary>
/// Loads and fail-closed validates <c>hexalith.readiness-evidence.v1</c> YAML documents.
/// </summary>
internal static class ReadinessEvidenceValidator
{
    private const string _schema = "hexalith.readiness-evidence.v1";
    private const string _moduleRunEvidenceSchema = "hexalith.module-run-evidence.v1";

    private static readonly HashSet<string> _rootFields = new(StringComparer.Ordinal)
    {
        "schema",
        "project",
        "generated",
        "generated_by",
        "source_of_truth",
        "markdown_view",
        "sources",
        "validation",
        "status_legend",
        "containment",
        "defaults",
        "rows",
    };

    private static readonly HashSet<string> _defaultFields = new(StringComparer.Ordinal)
    {
        "repository",
        "owner",
        "environment",
        "pinned_revision",
        "status",
        "release_disposition",
    };

    private static readonly HashSet<string> _validationFields = new(StringComparer.Ordinal)
    {
        "command",
        "tool_status",
        "rejects",
        "required_coverage",
    };

    private static readonly HashSet<string> _coverageFields = new(StringComparer.Ordinal)
    {
        "fr",
        "nfr",
        "finding",
        "release",
    };

    private static readonly HashSet<string> _containmentFields = new(StringComparer.Ordinal)
    {
        "overall_readiness",
        "freeze",
        "release_block",
        "open_triggers",
    };

    private static readonly HashSet<string> _rowFields = new(StringComparer.Ordinal)
    {
        "key",
        "category",
        "ids",
        "description",
        "architecture_decisions",
        "user_journeys",
        "primary_story",
        "supporting_stories",
        "entry_gates",
        "fixture",
        "verification_command",
        "evidence_artifact",
        "estimate",
        "status",
        "blocker",
        "notes",
        "owner",
        "priority",
        "binding",
        "linked_findings",
        "repository",
        "environment",
        "pinned_revision",
        "release_disposition",
        "artifact_schema",
        "artifact_sha256",
        "outcome",
        "skip_reason",
        "critical",
    };

    private static readonly HashSet<string> _supportedStatuses = new(StringComparer.Ordinal)
    {
        "pending",
        "blocked",
        "blocked-external",
        "not-verified",
        "failed",
        "passed",
        "skipped",
    };

    private static readonly HashSet<string> _supportedCategories = new(StringComparer.Ordinal)
    {
        "fr",
        "nfr",
        "finding",
        "release",
    };

    private static readonly string[] _requiredEffectiveScalars =
    [
        "repository",
        "owner",
        "environment",
        "pinned_revision",
        "release_disposition",
        "category",
        "description",
        "primary_story",
        "fixture",
        "verification_command",
        "evidence_artifact",
        "estimate",
        "status",
    ];

    /// <summary>
    /// Validates a readiness-evidence YAML file without retaining its raw contents.
    /// </summary>
    /// <param name="evidencePath">The YAML readiness-evidence path.</param>
    /// <param name="cancellationToken">The cancellation token.</param>
    /// <returns>A deterministic command result.</returns>
    public static async Task<ToolCommandResult> ValidateAsync(
        string evidencePath,
        CancellationToken cancellationToken)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(evidencePath);

        List<ToolDiagnostic> diagnostics = [];
        ReadinessEvidenceDocument? document = await TryLoadDocumentAsync(evidencePath, diagnostics, cancellationToken).ConfigureAwait(false);
        if (document is null)
        {
            return CreateFailure(diagnostics, ToolFailureCategory.EvidenceSchema);
        }

        ValidateSchema(document, diagnostics);
        if (diagnostics.Count > 0)
        {
            return CreateFailure(diagnostics, ToolFailureCategory.EvidenceSchema);
        }

        await ValidatePolicyAsync(document, diagnostics, cancellationToken).ConfigureAwait(false);
        return diagnostics.Count == 0
            ? new ToolCommandResult("passed", ToolOutcome.Passed(), [])
            : CreateFailure(diagnostics, ToolFailureCategory.EvidencePolicy);
    }

    private static void AddDiagnostic(
        List<ToolDiagnostic> diagnostics,
        ReadinessEvidenceDocument document,
        string ruleId,
        ToolFailureCategory category,
        string field,
        YamlNode? node = null,
        string? row = null)
    {
        diagnostics.Add(new ToolDiagnostic(
            ruleId,
            ToolPhase.Evidence,
            category,
            MessageFor(ruleId),
            field,
            HintFor(ruleId),
            document.Source,
            node is null ? null : ToLocation(node),
            row));
    }

    private static bool ContainsPlaceholder(string value) =>
        value.Contains("{{", StringComparison.Ordinal)
        || value.Contains("}}", StringComparison.Ordinal)
        || value.Contains("${", StringComparison.Ordinal)
        || value.Contains('%', StringComparison.Ordinal)
        || string.Equals(value, "TBD", StringComparison.OrdinalIgnoreCase)
        || string.Equals(value, "TODO", StringComparison.OrdinalIgnoreCase)
        || string.Equals(value, "CHANGEME", StringComparison.OrdinalIgnoreCase);

    /// <summary>
    /// Recognizes explicit boolean-false spellings. Any value that is not an explicit false is
    /// treated as critical so YAML spellings such as <c>yes</c>/<c>on</c>/<c>1</c> cannot
    /// silently downgrade a critical row to non-critical.
    /// </summary>
    /// <param name="value">The criticality override value.</param>
    /// <returns><see langword="true"/> when the value is an explicit boolean false.</returns>
    private static bool IsFalseBoolean(string value) =>
        string.Equals(value, "false", StringComparison.OrdinalIgnoreCase)
        || string.Equals(value, "no", StringComparison.OrdinalIgnoreCase)
        || string.Equals(value, "off", StringComparison.OrdinalIgnoreCase)
        || string.Equals(value, "n", StringComparison.OrdinalIgnoreCase)
        || string.Equals(value, "0", StringComparison.Ordinal);

    private static ToolCommandResult CreateFailure(
        IEnumerable<ToolDiagnostic> diagnostics,
        ToolFailureCategory category)
    {
        IReadOnlyList<ToolDiagnostic> orderedDiagnostics = [.. diagnostics
            .OrderBy(diagnostic => diagnostic.Source, StringComparer.Ordinal)
            .ThenBy(diagnostic => diagnostic.Row, StringComparer.Ordinal)
            .ThenBy(diagnostic => diagnostic.RuleId, StringComparer.Ordinal)
            .ThenBy(diagnostic => diagnostic.Field, StringComparer.Ordinal)
            .ThenBy(diagnostic => diagnostic.Location, StringComparer.Ordinal)
            .ThenBy(diagnostic => diagnostic.Hint, StringComparer.Ordinal),
        ];
        ToolDiagnostic firstDiagnostic = orderedDiagnostics.Count == 0
            ? new ToolDiagnostic(
                "HXE999",
                ToolPhase.Evidence,
                category,
                "The readiness evidence could not be validated.",
                "evidence")
            : orderedDiagnostics[0];
        ToolOutcome outcome = ToolOutcome.Passed().Fail(
            ToolPhase.Evidence,
            category,
            firstDiagnostic.RuleId,
            ToolExitCode.EvidenceSchemaOrPolicy);
        return new ToolCommandResult("failed", outcome, orderedDiagnostics);
    }

    private static string? GetEffectiveScalar(
        YamlMappingNode row,
        YamlMappingNode defaults,
        string field) =>
        GetScalar(row, field) ?? GetScalar(defaults, field);

    private static string? GetScalar(YamlMappingNode mapping, string key) =>
        TryGetNode(mapping, key, out YamlNode? node) && node is YamlScalarNode scalar
            ? scalar.Value
            : null;

    private static bool HasNonEmptySequence(YamlMappingNode row, string field) =>
        TryGetNode(row, field, out YamlNode? node)
        && node is YamlSequenceNode { Children.Count: > 0 };

    private static bool IsCanonicalIdentifier(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)
            || value[0] == '-'
            || value[^1] == '-')
        {
            return false;
        }

        bool previousHyphen = false;
        foreach (char character in value)
        {
            bool isLowercaseLetter = character is >= 'a' and <= 'z';
            bool isDigit = character is >= '0' and <= '9';
            if (!isLowercaseLetter && !isDigit && character != '-')
            {
                return false;
            }

            if (character == '-' && previousHyphen)
            {
                return false;
            }

            previousHyphen = character == '-';
        }

        return true;
    }

    private static bool IsCanonicalRelativePath(string value)
    {
        if (string.IsNullOrWhiteSpace(value)
            || Path.IsPathRooted(value)
            || value.Contains('\\', StringComparison.Ordinal)
            || value.StartsWith('/'))
        {
            return false;
        }

        string[] segments = value.Split('/', StringSplitOptions.None);
        return segments.All(segment => !string.IsNullOrWhiteSpace(segment)
            && !string.Equals(segment, ".", StringComparison.Ordinal)
            && !string.Equals(segment, "..", StringComparison.Ordinal));
    }

    private static string MessageFor(string ruleId) => ruleId switch
    {
        "HXE001" => "The YAML document contains a duplicate mapping key.",
        "HXE002" => "The YAML document is syntactically invalid.",
        "HXE003" => "The YAML document contains an unknown field.",
        "HXE004" => "The readiness-evidence schema is unsupported.",
        "HXE005" => "The YAML document is missing a required schema field.",
        "HXE006" => "The YAML document contains an invalid schema field shape.",
        "HXE007" => "The readiness-evidence path does not resolve to a readable file.",
        "HXE100" => "A required effective row value is missing.",
        "HXE101" => "A row key is missing, invalid, or duplicated.",
        "HXE102" => "A row category is unsupported.",
        "HXE103" => "A row identity or requirement identifier is invalid.",
        "HXE104" => "A required row collection is missing or empty.",
        "HXE108" => "The evidence contains an unresolved placeholder.",
        "HXE109" => "A repository path is not canonical and repository-relative.",
        "HXE123" => "The status vocabulary contains an unsupported status.",
        "HXE124" => "A row status is not declared by the status legend.",
        "HXE130" => "Required readiness coverage is incomplete.",
        "HXE131" => "A required coverage declaration is invalid.",
        "HXE140" => "Passing evidence cannot report an unavailable outcome.",
        "HXE141" => "Critical evidence reports a failed outcome.",
        "HXE142" => "Critical skipped evidence requires an explanation.",
        "HXE143" => "Passing evidence must report a passing outcome.",
        "HXE144" => "Failed evidence must report a failed outcome.",
        "HXE145" => "Executed evidence does not resolve to a readable artifact.",
        "HXE146" => "Executed evidence is missing its schema or SHA-256 metadata.",
        "HXE147" => "The evidence artifact SHA-256 does not match its declared value.",
        "HXE148" => "The evidence artifact schema does not match its declared value.",
        "HXE149" => "Passed readiness must reference a successful module-run artifact.",
        "HXE150" => "The Markdown view does not resolve to a readable file.",
        "HXE151" => "The Markdown view row identities drift from the YAML source of truth.",
        "HXE152" => "Passed readiness must cite an artifact whose canonical command and manifest, profile, filter, and fixture identities match the row and current bytes.",
        "HXE153" => "Passed readiness must cite an artifact with executed passing tests.",
        _ => "The readiness evidence is invalid.",
    };

    private static string HintFor(string ruleId) => ruleId switch
    {
        "HXE001" => "Remove duplicate YAML mapping keys before validation.",
        "HXE002" => "Supply syntactically valid YAML.",
        "HXE003" => "Remove fields not declared by hexalith.readiness-evidence.v1.",
        "HXE004" => "Use hexalith.readiness-evidence.v1.",
        "HXE005" => "Supply every required schema field.",
        "HXE006" => "Use the field type required by the readiness-evidence schema.",
        "HXE007" => "Supply an existing readable YAML file.",
        "HXE100" => "Resolve row defaults or provide the required row value.",
        "HXE101" => "Use unique lowercase kebab-case stable row keys.",
        "HXE102" => "Use fr, nfr, finding, or release as the row category.",
        "HXE103" => "Align the stable row key with its canonical requirement identifier.",
        "HXE104" => "Supply the required non-empty row collection.",
        "HXE108" => "Resolve placeholders before recording readiness evidence.",
        "HXE109" => "Use a canonical repository-relative path without traversal.",
        "HXE123" => "Use a supported status with defined fail-closed semantics.",
        "HXE124" => "Declare the row status in status_legend before using it.",
        "HXE130" => "Add rows covering every required requirement and critical category.",
        "HXE131" => "Use a valid coverage range or required row count.",
        "HXE140" => "Record unavailable work as not-verified, never passed.",
        "HXE141" => "Resolve failed critical evidence before release qualification.",
        "HXE142" => "Provide a specific critical skip explanation or execute the evidence.",
        "HXE143" => "Record a passed outcome only for successful execution.",
        "HXE144" => "Record a failed outcome only for failed execution.",
        "HXE145" => "Retain an actual readable artifact for executed evidence.",
        "HXE146" => "Record the artifact schema and SHA-256 for executed evidence.",
        "HXE147" => "Regenerate the artifact hash after producing the evidence.",
        "HXE148" => "Use an artifact whose schema matches the declared evidence schema.",
        "HXE149" => "Reference a completed run-evidence artifact with a successful outcome.",
        "HXE150" => "Supply the configured Markdown view beside the YAML source.",
        "HXE151" => "Regenerate the Markdown view from the YAML row identities.",
        "HXE152" => "Cite the test-command artifact for this row and declare the same manifest, profile, filter, and profile fixture whose current bytes match its hashes.",
        "HXE153" => "Reference a run-evidence artifact reporting executed passing tests and no failures.",
        _ => "Correct the readiness evidence and run validation again.",
    };

    private static string? ReadRowKey(YamlMappingNode row) =>
        IsCanonicalIdentifier(GetScalar(row, "key")) ? GetScalar(row, "key") : null;

    private static IReadOnlyList<string> ReadSequence(YamlMappingNode mapping, string field) =>
        TryGetNode(mapping, field, out YamlNode? node) && node is YamlSequenceNode sequence ? [.. sequence.Children.OfType<YamlScalarNode>().Select(value => value.Value).Where(value => !string.IsNullOrWhiteSpace(value)).Select(value => value!),] : [];

    private static bool TryGetNode(YamlMappingNode mapping, string key, out YamlNode? value)
    {
        foreach (KeyValuePair<YamlNode, YamlNode> entry in mapping.Children)
        {
            if (entry.Key is YamlScalarNode { Value: string candidate }
                && string.Equals(candidate, key, StringComparison.Ordinal))
            {
                value = entry.Value;
                return true;
            }
        }

        value = null;
        return false;
    }

    private static string ToLocation(YamlNode node) => $"{node.Start.Line + 1}:{node.Start.Column + 1}";

    private static async Task<ReadinessEvidenceDocument?> TryLoadDocumentAsync(
        string evidencePath,
        List<ToolDiagnostic> diagnostics,
        CancellationToken cancellationToken)
    {
        string fullPath;
        try
        {
            fullPath = Path.GetFullPath(evidencePath);
        }
        catch (Exception exception) when (exception is ArgumentException or NotSupportedException or PathTooLongException)
        {
            diagnostics.Add(new ToolDiagnostic(
                "HXE007",
                ToolPhase.Evidence,
                ToolFailureCategory.EvidenceSchema,
                MessageFor("HXE007"),
                "path",
                HintFor("HXE007")));
            return null;
        }

        if (!File.Exists(fullPath))
        {
            diagnostics.Add(new ToolDiagnostic(
                "HXE007",
                ToolPhase.Evidence,
                ToolFailureCategory.EvidenceSchema,
                MessageFor("HXE007"),
                "path",
                HintFor("HXE007")));
            return null;
        }

        string content;
        try
        {
            content = await File.ReadAllTextAsync(fullPath, cancellationToken).ConfigureAwait(false);
        }
        catch (IOException)
        {
            diagnostics.Add(new ToolDiagnostic(
                "HXE007",
                ToolPhase.Evidence,
                ToolFailureCategory.EvidenceSchema,
                MessageFor("HXE007"),
                "path",
                HintFor("HXE007")));
            return null;
        }
        catch (UnauthorizedAccessException)
        {
            diagnostics.Add(new ToolDiagnostic(
                "HXE007",
                ToolPhase.Evidence,
                ToolFailureCategory.EvidenceSchema,
                MessageFor("HXE007"),
                "path",
                HintFor("HXE007")));
            return null;
        }

        string repositoryRoot = FindRepositoryRoot(fullPath);
        string source = ToRepositoryRelativePath(fullPath, repositoryRoot);
        try
        {
            // A plain load tolerates duplicate mapping keys, so any failure here is a
            // genuine syntax error rather than a duplicate key. This classifies HXE002
            // without depending on any third-party exception message text.
            IDeserializer syntaxCheckingDeserializer = new DeserializerBuilder().Build();
            _ = syntaxCheckingDeserializer.Deserialize<object>(content);
        }
        catch (YamlException exception)
        {
            diagnostics.Add(new ToolDiagnostic(
                "HXE002",
                ToolPhase.Evidence,
                ToolFailureCategory.EvidenceSchema,
                MessageFor("HXE002"),
                "yaml",
                HintFor("HXE002"),
                source,
                $"{exception.Start.Line + 1}:{exception.Start.Column + 1}"));
            return null;
        }

        try
        {
            // The document is already known to be syntactically valid, so a rejection from
            // the duplicate-key-checking deserializer is unambiguously a duplicate key.
            IDeserializer duplicateKeyCheckingDeserializer = new DeserializerBuilder()
                .WithDuplicateKeyChecking()
                .Build();
            _ = duplicateKeyCheckingDeserializer.Deserialize<object>(content);
        }
        catch (YamlException exception)
        {
            diagnostics.Add(new ToolDiagnostic(
                "HXE001",
                ToolPhase.Evidence,
                ToolFailureCategory.EvidenceSchema,
                MessageFor("HXE001"),
                "yaml",
                HintFor("HXE001"),
                source,
                $"{exception.Start.Line + 1}:{exception.Start.Column + 1}"));
            return null;
        }

        try
        {
            using StringReader reader = new(content);
            YamlStream stream = [];
            stream.Load(reader);
            if (stream.Documents.Count != 1 || stream.Documents[0].RootNode is not YamlMappingNode root)
            {
                diagnostics.Add(new ToolDiagnostic(
                    "HXE006",
                    ToolPhase.Evidence,
                    ToolFailureCategory.EvidenceSchema,
                    MessageFor("HXE006"),
                    "root",
                    HintFor("HXE006"),
                    source));
                return null;
            }

            return new ReadinessEvidenceDocument(fullPath, repositoryRoot, source, root);
        }
        catch (YamlException exception)
        {
            diagnostics.Add(new ToolDiagnostic(
                "HXE002",
                ToolPhase.Evidence,
                ToolFailureCategory.EvidenceSchema,
                MessageFor("HXE002"),
                "yaml",
                HintFor("HXE002"),
                source,
                $"{exception.Start.Line + 1}:{exception.Start.Column + 1}"));
            return null;
        }
    }

    private static void ValidateMappingFields(
        ReadinessEvidenceDocument document,
        YamlMappingNode mapping,
        IReadOnlySet<string> allowedFields,
        string field,
        List<ToolDiagnostic> diagnostics,
        string? row = null)
    {
        foreach (YamlNode keyNode in mapping.Children.Select(static entry => entry.Key))
        {
            if (keyNode is not YamlScalarNode { Value: string key }
                || !allowedFields.Contains(key))
            {
                AddDiagnostic(
                    diagnostics,
                    document,
                    "HXE003",
                    ToolFailureCategory.EvidenceSchema,
                    field,
                    keyNode,
                    row);
            }
        }
    }

    private static void ValidateNestedMapping(
        ReadinessEvidenceDocument document,
        YamlMappingNode root,
        string field,
        IReadOnlySet<string> allowedFields,
        List<ToolDiagnostic> diagnostics)
    {
        if (!TryGetNode(root, field, out YamlNode? node) || node is not YamlMappingNode mapping)
        {
            AddDiagnostic(diagnostics, document, "HXE005", ToolFailureCategory.EvidenceSchema, field, node);
            return;
        }

        ValidateMappingFields(document, mapping, allowedFields, field, diagnostics);
    }

    private static void ValidatePolicyRow(
        ReadinessEvidenceDocument document,
        YamlMappingNode row,
        YamlMappingNode defaults,
        HashSet<string> declaredStatuses,
        HashSet<string> seenRowKeys,
        List<ToolDiagnostic> diagnostics)
    {
        string? rowKey = ReadRowKey(row);
        if (rowKey is null || !seenRowKeys.Add(rowKey))
        {
            AddDiagnostic(diagnostics, document, "HXE101", ToolFailureCategory.EvidencePolicy, "key", row, rowKey);
        }

        foreach (string field in _requiredEffectiveScalars)
        {
            string? value = GetEffectiveScalar(row, defaults, field);
            if (string.IsNullOrWhiteSpace(value))
            {
                AddDiagnostic(diagnostics, document, "HXE100", ToolFailureCategory.EvidencePolicy, field, row, rowKey);
                continue;
            }

            if (ContainsPlaceholder(value))
            {
                AddDiagnostic(diagnostics, document, "HXE108", ToolFailureCategory.EvidencePolicy, field, row, rowKey);
            }
        }

        if (!HasNonEmptySequence(row, "ids"))
        {
            AddDiagnostic(diagnostics, document, "HXE104", ToolFailureCategory.EvidencePolicy, "ids", row, rowKey);
        }

        if (!TryGetNode(row, "supporting_stories", out YamlNode? supportingStories)
            || supportingStories is not YamlSequenceNode)
        {
            AddDiagnostic(diagnostics, document, "HXE104", ToolFailureCategory.EvidencePolicy, "supporting_stories", row, rowKey);
        }

        if (!HasNonEmptySequence(row, "entry_gates"))
        {
            AddDiagnostic(diagnostics, document, "HXE104", ToolFailureCategory.EvidencePolicy, "entry_gates", row, rowKey);
        }

        string? category = GetScalar(row, "category");
        if (!string.IsNullOrWhiteSpace(category) && !_supportedCategories.Contains(category))
        {
            AddDiagnostic(diagnostics, document, "HXE102", ToolFailureCategory.EvidencePolicy, "category", row, rowKey);
        }

        ValidateRowIdentifiers(document, row, category, rowKey, diagnostics);
        ValidateRowStatus(document, row, defaults, declaredStatuses, rowKey, diagnostics);

        foreach (string pathField in new[] { "fixture", "evidence_artifact" })
        {
            string? path = GetEffectiveScalar(row, defaults, pathField);
            if (!string.IsNullOrWhiteSpace(path) && !IsCanonicalRelativePath(path))
            {
                AddDiagnostic(diagnostics, document, "HXE109", ToolFailureCategory.EvidencePolicy, pathField, row, rowKey);
            }
        }
    }

    private static void ValidateRowIdentifiers(
        ReadinessEvidenceDocument document,
        YamlMappingNode row,
        string? category,
        string? rowKey,
        List<ToolDiagnostic> diagnostics)
    {
        IReadOnlyList<string> identifiers = ReadSequence(row, "ids");
        HashSet<string> uniqueIdentifiers = new(StringComparer.Ordinal);
        if (identifiers.Any(identifier => !uniqueIdentifiers.Add(identifier) || ContainsPlaceholder(identifier)))
        {
            AddDiagnostic(diagnostics, document, "HXE103", ToolFailureCategory.EvidencePolicy, "ids", row, rowKey);
        }

        if (rowKey is null || category is not "fr" and not "nfr")
        {
            return;
        }

        string prefix = category == "fr" ? "fr-" : "nfr-";
        if (!rowKey.StartsWith(prefix, StringComparison.Ordinal)
            || !int.TryParse(rowKey[prefix.Length..], out int number)
            || number <= 0)
        {
            AddDiagnostic(diagnostics, document, "HXE103", ToolFailureCategory.EvidencePolicy, "key", row, rowKey);
            return;
        }

        string requiredIdentifier = category == "fr" ? $"FR-{number}" : $"NFR-{number}";
        if (!identifiers.Contains(requiredIdentifier, StringComparer.Ordinal))
        {
            AddDiagnostic(diagnostics, document, "HXE103", ToolFailureCategory.EvidencePolicy, "ids", row, rowKey);
        }
    }

    private static void ValidateRowStatus(
        ReadinessEvidenceDocument document,
        YamlMappingNode row,
        YamlMappingNode defaults,
        HashSet<string> declaredStatuses,
        string? rowKey,
        List<ToolDiagnostic> diagnostics)
    {
        string? status = GetEffectiveScalar(row, defaults, "status");
        if (string.IsNullOrWhiteSpace(status))
        {
            return;
        }

        if (!declaredStatuses.Contains(status))
        {
            AddDiagnostic(diagnostics, document, "HXE124", ToolFailureCategory.EvidencePolicy, "status", row, rowKey);
        }
        else if (!_supportedStatuses.Contains(status))
        {
            AddDiagnostic(diagnostics, document, "HXE123", ToolFailureCategory.EvidencePolicy, "status", row, rowKey);
        }
    }

    private static void ValidateSchema(ReadinessEvidenceDocument document, List<ToolDiagnostic> diagnostics)
    {
        YamlMappingNode root = document.Root;
        ValidateMappingFields(document, root, _rootFields, "root", diagnostics);

        string? schema = GetScalar(root, "schema");
        if (!string.Equals(schema, _schema, StringComparison.Ordinal))
        {
            AddDiagnostic(diagnostics, document, "HXE004", ToolFailureCategory.EvidenceSchema, "schema", root);
        }

        if (string.IsNullOrWhiteSpace(GetScalar(root, "project")))
        {
            AddDiagnostic(diagnostics, document, "HXE005", ToolFailureCategory.EvidenceSchema, "project", root);
        }

        if (TryGetNode(root, "markdown_view", out YamlNode? markdownViewNode) && markdownViewNode is not YamlScalarNode)
        {
            AddDiagnostic(diagnostics, document, "HXE006", ToolFailureCategory.EvidenceSchema, "markdown_view", markdownViewNode);
        }

        ValidateNestedMapping(document, root, "defaults", _defaultFields, diagnostics);
        ValidateNestedMapping(document, root, "validation", _validationFields, diagnostics);

        if (!TryGetNode(root, "status_legend", out YamlNode? statusLegend)
            || statusLegend is not YamlMappingNode)
        {
            AddDiagnostic(diagnostics, document, "HXE005", ToolFailureCategory.EvidenceSchema, "status_legend", statusLegend);
        }

        if (TryGetNode(root, "containment", out YamlNode? containment)
            && containment is YamlMappingNode containmentMapping)
        {
            ValidateMappingFields(document, containmentMapping, _containmentFields, "containment", diagnostics);
        }
        else if (containment is not null)
        {
            AddDiagnostic(diagnostics, document, "HXE006", ToolFailureCategory.EvidenceSchema, "containment", containment);
        }

        if (TryGetNode(root, "validation", out YamlNode? validationNode)
            && validationNode is YamlMappingNode validation
            && TryGetNode(validation, "required_coverage", out YamlNode? coverageNode))
        {
            if (coverageNode is YamlMappingNode coverage)
            {
                ValidateMappingFields(document, coverage, _coverageFields, "validation.required_coverage", diagnostics);
            }
            else
            {
                AddDiagnostic(diagnostics, document, "HXE006", ToolFailureCategory.EvidenceSchema, "validation.required_coverage", coverageNode);
            }
        }
        else
        {
            AddDiagnostic(diagnostics, document, "HXE005", ToolFailureCategory.EvidenceSchema, "validation.required_coverage", validationNode);
        }

        if (!TryGetNode(root, "rows", out YamlNode? rowsNode) || rowsNode is not YamlSequenceNode rows)
        {
            AddDiagnostic(diagnostics, document, "HXE005", ToolFailureCategory.EvidenceSchema, "rows", rowsNode);
            return;
        }

        foreach (YamlNode rowNode in rows.Children)
        {
            if (rowNode is not YamlMappingNode row)
            {
                AddDiagnostic(diagnostics, document, "HXE006", ToolFailureCategory.EvidenceSchema, "rows", rowNode);
                continue;
            }

            ValidateMappingFields(document, row, _rowFields, "row", diagnostics, ReadRowKey(row));
        }
    }

    private static async Task ValidatePolicyAsync(
        ReadinessEvidenceDocument document,
        List<ToolDiagnostic> diagnostics,
        CancellationToken cancellationToken)
    {
        YamlMappingNode defaults = (YamlMappingNode)document.Root.Children.First(entry => entry.Key is YamlScalarNode { Value: "defaults" }).Value;
        YamlMappingNode validation = (YamlMappingNode)document.Root.Children.First(entry => entry.Key is YamlScalarNode { Value: "validation" }).Value;
        YamlMappingNode statusLegend = (YamlMappingNode)document.Root.Children.First(entry => entry.Key is YamlScalarNode { Value: "status_legend" }).Value;
        YamlSequenceNode rows = (YamlSequenceNode)document.Root.Children.First(entry => entry.Key is YamlScalarNode { Value: "rows" }).Value;
        YamlMappingNode coverage = (YamlMappingNode)validation.Children.First(entry => entry.Key is YamlScalarNode { Value: "required_coverage" }).Value;

        HashSet<string> declaredStatuses = [];
        foreach (KeyValuePair<YamlNode, YamlNode> entry in statusLegend.Children)
        {
            if (entry.Key is YamlScalarNode { Value: string status }
                && entry.Value is YamlScalarNode { Value: not null })
            {
                _ = declaredStatuses.Add(status);
                if (!_supportedStatuses.Contains(status))
                {
                    AddDiagnostic(diagnostics, document, "HXE123", ToolFailureCategory.EvidencePolicy, "status_legend", entry.Key);
                }
            }
            else
            {
                AddDiagnostic(diagnostics, document, "HXE006", ToolFailureCategory.EvidenceSchema, "status_legend", entry.Key);
            }
        }

        HashSet<string> seenRowKeys = new(StringComparer.Ordinal);
        List<YamlMappingNode> rowMappings = [];
        foreach (YamlNode rowNode in rows.Children)
        {
            if (rowNode is not YamlMappingNode row)
            {
                continue;
            }

            rowMappings.Add(row);
            ValidatePolicyRow(document, row, defaults, declaredStatuses, seenRowKeys, diagnostics);
            await ValidateOutcomeAndArtifactAsync(document, row, defaults, diagnostics, cancellationToken).ConfigureAwait(false);
        }

        ValidateCoverage(document, coverage, rowMappings, diagnostics);
        await ValidateMarkdownViewAsync(document, rowMappings, diagnostics, cancellationToken).ConfigureAwait(false);
    }

    private static async Task ValidateMarkdownViewAsync(
        ReadinessEvidenceDocument document,
        IEnumerable<YamlMappingNode> rows,
        List<ToolDiagnostic> diagnostics,
        CancellationToken cancellationToken)
    {
        string? markdownView = GetScalar(document.Root, "markdown_view");
        if (string.IsNullOrWhiteSpace(markdownView))
        {
            return;
        }

        if (!IsCanonicalRelativePath(markdownView))
        {
            AddDiagnostic(diagnostics, document, "HXE109", ToolFailureCategory.EvidencePolicy, "markdown_view", document.Root);
            return;
        }

        string markdownRoot = Path.GetDirectoryName(document.FullPath)!;
        string lexicalMarkdownPath = Path.GetFullPath(Path.Combine(markdownRoot, markdownView));
        if (!File.Exists(lexicalMarkdownPath))
        {
            AddDiagnostic(diagnostics, document, "HXE150", ToolFailureCategory.EvidencePolicy, "markdown_view", document.Root);
            return;
        }

        if (!RepositoryPathResolver.TryResolveExistingFile(markdownRoot, markdownView, out string markdownPath))
        {
            AddDiagnostic(diagnostics, document, "HXE109", ToolFailureCategory.EvidencePolicy, "markdown_view", document.Root);
            return;
        }

        string[] lines;
        try
        {
            lines = await File.ReadAllLinesAsync(markdownPath, cancellationToken).ConfigureAwait(false);
        }
        catch (IOException)
        {
            AddDiagnostic(diagnostics, document, "HXE150", ToolFailureCategory.EvidencePolicy, "markdown_view", document.Root);
            return;
        }
        catch (UnauthorizedAccessException)
        {
            AddDiagnostic(diagnostics, document, "HXE150", ToolFailureCategory.EvidencePolicy, "markdown_view", document.Root);
            return;
        }

        HashSet<string> yamlKeys = rows
            .Select(ReadRowKey)
            .Where(key => key is not null)
            .Select(key => key!)
            .ToHashSet(StringComparer.Ordinal);
        HashSet<string> markdownKeys = new(StringComparer.Ordinal);
        foreach (string line in lines)
        {
            string trimmed = line.Trim();
            if (!trimmed.StartsWith('|') || !trimmed.EndsWith('|'))
            {
                continue;
            }

            string[] cells = trimmed.Split('|', StringSplitOptions.None);
            if (cells.Length < 3)
            {
                continue;
            }

            string firstCell = cells[1].Trim();
            string candidate = firstCell.Length > 1 && firstCell[0] == '`' && firstCell[^1] == '`'
                ? firstCell[1..^1].Trim()
                : firstCell;
            if (IsCanonicalIdentifier(candidate))
            {
                _ = markdownKeys.Add(candidate);
            }
        }

        foreach (string key in yamlKeys.Except(markdownKeys, StringComparer.Ordinal))
        {
            AddDiagnostic(diagnostics, document, "HXE151", ToolFailureCategory.EvidencePolicy, "markdown_view", document.Root, key);
        }

        foreach (string key in markdownKeys.Except(yamlKeys, StringComparer.Ordinal))
        {
            AddDiagnostic(diagnostics, document, "HXE151", ToolFailureCategory.EvidencePolicy, "markdown_view", document.Root, key);
        }
    }

    private static async Task ValidateOutcomeAndArtifactAsync(
        ReadinessEvidenceDocument document,
        YamlMappingNode row,
        YamlMappingNode defaults,
        List<ToolDiagnostic> diagnostics,
        CancellationToken cancellationToken)
    {
        string? rowKey = ReadRowKey(row);
        string? category = GetScalar(row, "category");
        string? status = GetEffectiveScalar(row, defaults, "status");
        string? outcome = GetScalar(row, "outcome");
        string? criticalOverride = GetScalar(row, "critical");
        bool criticalByOverride = !string.IsNullOrWhiteSpace(criticalOverride) && !IsFalseBoolean(criticalOverride);
        bool critical = string.Equals(category, "release", StringComparison.Ordinal) || criticalByOverride;

        if (string.Equals(status, "passed", StringComparison.Ordinal))
        {
            if (string.Equals(outcome, "unavailable", StringComparison.Ordinal))
            {
                AddDiagnostic(diagnostics, document, "HXE140", ToolFailureCategory.EvidencePolicy, "outcome", row, rowKey);
            }
            else if (!string.Equals(outcome, "passed", StringComparison.Ordinal))
            {
                AddDiagnostic(diagnostics, document, "HXE143", ToolFailureCategory.EvidencePolicy, "outcome", row, rowKey);
            }
        }
        else if (string.Equals(status, "failed", StringComparison.Ordinal)
            && !string.Equals(outcome, "failed", StringComparison.Ordinal))
        {
            AddDiagnostic(diagnostics, document, "HXE144", ToolFailureCategory.EvidencePolicy, "outcome", row, rowKey);
        }
        else if (string.Equals(outcome, "passed", StringComparison.Ordinal))
        {
            AddDiagnostic(diagnostics, document, "HXE143", ToolFailureCategory.EvidencePolicy, "outcome", row, rowKey);
        }

        if (critical
            && string.Equals(status, "failed", StringComparison.Ordinal))
        {
            AddDiagnostic(diagnostics, document, "HXE141", ToolFailureCategory.EvidencePolicy, "status", row, rowKey);
        }

        if (critical
            && string.Equals(status, "skipped", StringComparison.Ordinal)
            && string.IsNullOrWhiteSpace(GetScalar(row, "skip_reason")))
        {
            AddDiagnostic(diagnostics, document, "HXE142", ToolFailureCategory.EvidencePolicy, "skip_reason", row, rowKey);
        }

        bool executionClaim = string.Equals(outcome, "passed", StringComparison.Ordinal)
            || string.Equals(outcome, "failed", StringComparison.Ordinal);
        if (!executionClaim
            && !string.Equals(status, "passed", StringComparison.Ordinal)
            && !string.Equals(status, "failed", StringComparison.Ordinal))
        {
            return;
        }

        string? artifact = GetEffectiveScalar(row, defaults, "evidence_artifact");
        if (string.IsNullOrWhiteSpace(artifact) || !IsCanonicalRelativePath(artifact))
        {
            return;
        }

        if (!RepositoryPathResolver.TryResolveExistingFile(document.RepositoryRoot, artifact, out string artifactPath))
        {
            AddDiagnostic(diagnostics, document, "HXE145", ToolFailureCategory.EvidencePolicy, "evidence_artifact", row, rowKey);
            return;
        }

        byte[] artifactBytes;
        try
        {
            artifactBytes = await File.ReadAllBytesAsync(artifactPath, cancellationToken).ConfigureAwait(false);
        }
        catch (IOException)
        {
            AddDiagnostic(diagnostics, document, "HXE145", ToolFailureCategory.EvidencePolicy, "evidence_artifact", row, rowKey);
            return;
        }
        catch (UnauthorizedAccessException)
        {
            AddDiagnostic(diagnostics, document, "HXE145", ToolFailureCategory.EvidencePolicy, "evidence_artifact", row, rowKey);
            return;
        }

        string? artifactSchema = GetScalar(row, "artifact_schema");
        string? artifactHash = GetScalar(row, "artifact_sha256");
        if (string.IsNullOrWhiteSpace(artifactSchema) || string.IsNullOrWhiteSpace(artifactHash))
        {
            AddDiagnostic(diagnostics, document, "HXE146", ToolFailureCategory.EvidencePolicy, "artifact_schema", row, rowKey);
            return;
        }

        string actualHash = Convert.ToHexString(SHA256.HashData(artifactBytes));
        if (!string.Equals(actualHash, artifactHash, StringComparison.OrdinalIgnoreCase))
        {
            AddDiagnostic(diagnostics, document, "HXE147", ToolFailureCategory.EvidencePolicy, "artifact_sha256", row, rowKey);
        }

        ModuleRunEvidenceArtifactSummary? artifactSummary = null;
        bool isValidModuleRunArtifact = string.Equals(artifactSchema, _moduleRunEvidenceSchema, StringComparison.Ordinal)
            && ModuleRunEvidenceArtifactValidator.TryValidate(artifactBytes, out artifactSummary);
        if (!isValidModuleRunArtifact || artifactSummary is null)
        {
            AddDiagnostic(diagnostics, document, "HXE148", ToolFailureCategory.EvidencePolicy, "artifact_schema", row, rowKey);
        }
        else if (string.Equals(status, "passed", StringComparison.Ordinal))
        {
            if (!string.Equals(artifactSummary.FinalStatus, "completed", StringComparison.Ordinal)
                || artifactSummary.ExitCode != (int)ToolExitCode.Success)
            {
                AddDiagnostic(diagnostics, document, "HXE149", ToolFailureCategory.EvidencePolicy, "evidence_artifact", row, rowKey);
            }
            else if (!ArtifactBindsToRow(
                artifactSummary,
                document.RepositoryRoot,
                GetScalar(row, "verification_command"),
                GetEffectiveScalar(row, defaults, "fixture")))
            {
                AddDiagnostic(diagnostics, document, "HXE152", ToolFailureCategory.EvidencePolicy, "evidence_artifact", row, rowKey);
            }
            else if (!artifactSummary.TestsReported
                || artifactSummary.TestsPassed <= 0
                || artifactSummary.TestsFailed != 0)
            {
                AddDiagnostic(diagnostics, document, "HXE153", ToolFailureCategory.EvidencePolicy, "evidence_artifact", row, rowKey);
            }
        }
    }

    /// <summary>
    /// Binds a passing readiness row to the artifact it cites: the artifact must be a
    /// <c>test</c> invocation (never <c>run</c>/<c>down</c>), its module subcommand must match
    /// the row's verification command, profile fixture, and current repository input bytes.
    /// </summary>
    /// <param name="summary">The validated artifact summary.</param>
    /// <param name="repositoryRoot">The readiness document's repository root.</param>
    /// <param name="verificationCommand">The row's declared verification command.</param>
    /// <param name="fixture">The row's declared fixture path.</param>
    /// <returns><see langword="true"/> when the artifact binds to the row.</returns>
    private static bool ArtifactBindsToRow(
        ModuleRunEvidenceArtifactSummary summary,
        string repositoryRoot,
        string? verificationCommand,
        string? fixture)
    {
        string? canonicalArtifactCommand = CreateCanonicalArtifactCommand(summary);
        if (canonicalArtifactCommand is null
            || !string.Equals(summary.Command, canonicalArtifactCommand, StringComparison.Ordinal))
        {
            return false;
        }

        string? rowSubcommand = ExtractModuleSubcommand(verificationCommand);
        if (!string.Equals(rowSubcommand, "test", StringComparison.Ordinal))
        {
            return false;
        }

        string? rowManifestPath = ExtractCommandOption(verificationCommand, "--manifest");
        string? rowProfile = ExtractCommandOption(verificationCommand, "--profile");
        string? rowFilter = ExtractCommandOption(verificationCommand, "--filter");
        if (string.IsNullOrWhiteSpace(rowManifestPath)
            || string.IsNullOrWhiteSpace(summary.ManifestPath)
            || !IsCanonicalRelativePath(rowManifestPath)
            || !string.Equals(rowManifestPath, summary.ManifestPath, StringComparison.Ordinal)
            || string.IsNullOrWhiteSpace(rowProfile)
            || !string.Equals(rowProfile, summary.Profile, StringComparison.Ordinal)
            || string.IsNullOrWhiteSpace(rowFilter)
            || string.IsNullOrWhiteSpace(summary.FilterHash)
            || !string.Equals(HashString(rowFilter), summary.FilterHash, StringComparison.Ordinal)
            || string.IsNullOrWhiteSpace(fixture)
            || string.IsNullOrWhiteSpace(summary.FixturePath)
            || !IsCanonicalRelativePath(fixture)
            || !string.Equals(fixture, summary.FixturePath, StringComparison.Ordinal)
            || !RepositoryFileMatchesHash(repositoryRoot, summary.ManifestPath, summary.ManifestHash)
            || !RepositoryFileMatchesHash(repositoryRoot, summary.FixturePath, summary.FixtureHash))
        {
            return false;
        }

        if (!RepositoryPathResolver.TryResolveExistingFile(repositoryRoot, summary.ManifestPath, out string manifestPath))
        {
            return false;
        }

        ManifestLoadResult manifestResult = ModuleManifestLoader.Load(manifestPath);
        return manifestResult.IsValid
            && manifestResult.Manifest!.Profiles.TryGetValue(rowProfile, out ModuleProfile? profile)
            && string.Equals(profile.Fixture, summary.FixturePath, StringComparison.Ordinal);
    }

    private static string? CreateCanonicalArtifactCommand(ModuleRunEvidenceArtifactSummary summary) =>
        string.IsNullOrWhiteSpace(summary.ManifestPath) || string.IsNullOrWhiteSpace(summary.Profile) || string.IsNullOrWhiteSpace(summary.FilterHash) ? null : $"hexalith-module test --manifest {summary.ManifestPath} --profile {summary.Profile} --filter-sha256 {summary.FilterHash}";

    private static string HashString(string value) =>
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(value)));

    private static bool RepositoryFileMatchesHash(string repositoryRoot, string path, string? expectedHash)
    {
        if (!IsCanonicalRelativePath(path)
            || string.IsNullOrWhiteSpace(expectedHash)
            || !RepositoryPathResolver.TryResolveExistingFile(repositoryRoot, path, out string resolvedPath))
        {
            return false;
        }

        try
        {
            string actualHash = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(resolvedPath)));
            return string.Equals(actualHash, expectedHash, StringComparison.Ordinal);
        }
        catch (IOException)
        {
            return false;
        }
        catch (UnauthorizedAccessException)
        {
            return false;
        }
    }

    private static string? ExtractModuleSubcommand(string? command) =>
        ExtractTokenAfter(command, "hexalith-module");

    private static string? ExtractCommandOption(string? command, string option) =>
        ExtractTokenAfter(command, option);

    private static string? ExtractTokenAfter(string? command, string token)
    {
        if (string.IsNullOrWhiteSpace(command))
        {
            return null;
        }

        string[] tokens = command.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        int index = -1;
        for (int candidateIndex = 0; candidateIndex < tokens.Length; candidateIndex++)
        {
            if (!string.Equals(tokens[candidateIndex], token, StringComparison.Ordinal))
            {
                continue;
            }

            if (index >= 0)
            {
                return null;
            }

            index = candidateIndex;
        }

        if (index < 0 || index + 1 >= tokens.Length)
        {
            return null;
        }

        string value = tokens[index + 1];
        return value.StartsWith("--", StringComparison.Ordinal) ? null : value;
    }

    private static void ValidateCoverage(
        ReadinessEvidenceDocument document,
        YamlMappingNode coverage,
        IEnumerable<YamlMappingNode> rows,
        List<ToolDiagnostic> diagnostics)
    {
        List<YamlMappingNode> rowList = [.. rows];
        ValidateRangeCoverage(document, coverage, rowList, "fr", "FR", diagnostics);
        ValidateRangeCoverage(document, coverage, rowList, "nfr", "NFR", diagnostics);
        ValidateCountCoverage(document, coverage, rowList, "finding", diagnostics);
        ValidateCountCoverage(document, coverage, rowList, "release", diagnostics);
    }

    private static void ValidateCountCoverage(
        ReadinessEvidenceDocument document,
        YamlMappingNode coverage,
        IEnumerable<YamlMappingNode> rows,
        string category,
        List<ToolDiagnostic> diagnostics)
    {
        string? declaration = GetScalar(coverage, category);
        List<YamlMappingNode> categoryRows = [.. rows.Where(row => string.Equals(GetScalar(row, "category"), category, StringComparison.Ordinal))];

        // Priority-aware coverage: a declaration such as "9 P1 + 7 P2" enforces the count
        // of each priority independently using the row `priority` field, so P2 findings can
        // no longer be silently ignored behind the aggregate first-integer count.
        if (string.Equals(category, "finding", StringComparison.Ordinal)
            && TryReadPriorityCounts(declaration, out int expectedP1, out int expectedP2))
        {
            ValidatePriorityCount(document, coverage, categoryRows, category, "P1", expectedP1, diagnostics);
            ValidatePriorityCount(document, coverage, categoryRows, category, "P2", expectedP2, diagnostics);
            return;
        }

        if (!TryReadFirstPositiveInteger(declaration, out int expected))
        {
            AddDiagnostic(diagnostics, document, "HXE131", ToolFailureCategory.EvidencePolicy, $"validation.required_coverage.{category}", coverage);
            return;
        }

        if (categoryRows.Count < expected)
        {
            AddDiagnostic(diagnostics, document, "HXE130", ToolFailureCategory.EvidencePolicy, $"validation.required_coverage.{category}", coverage);
        }
    }

    private static void ValidatePriorityCount(
        ReadinessEvidenceDocument document,
        YamlMappingNode coverage,
        IEnumerable<YamlMappingNode> categoryRows,
        string category,
        string priority,
        int expected,
        List<ToolDiagnostic> diagnostics)
    {
        if (expected <= 0)
        {
            return;
        }

        int actual = categoryRows.Count(row => string.Equals(GetScalar(row, "priority"), priority, StringComparison.OrdinalIgnoreCase));
        if (actual < expected)
        {
            AddDiagnostic(diagnostics, document, "HXE130", ToolFailureCategory.EvidencePolicy, $"validation.required_coverage.{category}", coverage);
        }
    }

    private static bool TryReadPriorityCounts(string? value, out int p1, out int p2)
    {
        bool hasP1 = TryReadCountBeforeLabel(value, "P1", out p1);
        bool hasP2 = TryReadCountBeforeLabel(value, "P2", out p2);
        return hasP1 || hasP2;
    }

    private static bool TryReadCountBeforeLabel(string? value, string label, out int count)
    {
        count = 0;
        if (string.IsNullOrWhiteSpace(value))
        {
            return false;
        }

        int labelIndex = value.IndexOf(label, StringComparison.OrdinalIgnoreCase);
        if (labelIndex <= 0)
        {
            return false;
        }

        int index = labelIndex - 1;
        while (index >= 0 && char.IsWhiteSpace(value[index]))
        {
            index--;
        }

        int end = index + 1;
        while (index >= 0 && char.IsAsciiDigit(value[index]))
        {
            index--;
        }

        int start = index + 1;
        return start < end
            && int.TryParse(value[start..end], out count)
            && count > 0;
    }

    private static void ValidateRangeCoverage(
        ReadinessEvidenceDocument document,
        YamlMappingNode coverage,
        IEnumerable<YamlMappingNode> rows,
        string category,
        string identifierPrefix,
        List<ToolDiagnostic> diagnostics)
    {
        string? declaration = GetScalar(coverage, category);
        if (!TryReadRange(declaration, identifierPrefix, out int first, out int last))
        {
            AddDiagnostic(diagnostics, document, "HXE131", ToolFailureCategory.EvidencePolicy, $"validation.required_coverage.{category}", coverage);
            return;
        }

        HashSet<string> actualIdentifiers = rows
            .Where(row => string.Equals(GetScalar(row, "category"), category, StringComparison.Ordinal))
            .SelectMany(row => ReadSequence(row, "ids"))
            .ToHashSet(StringComparer.Ordinal);
        for (int number = first; number <= last; number++)
        {
            if (!actualIdentifiers.Contains($"{identifierPrefix}-{number}"))
            {
                AddDiagnostic(diagnostics, document, "HXE130", ToolFailureCategory.EvidencePolicy, $"validation.required_coverage.{category}", coverage);
                return;
            }
        }
    }

    private static bool TryReadFirstPositiveInteger(string? value, out int result)
    {
        result = 0;
        if (string.IsNullOrWhiteSpace(value))
        {
            return false;
        }

        int index = 0;
        while (index < value.Length && !char.IsAsciiDigit(value[index]))
        {
            index++;
        }

        int start = index;
        while (index < value.Length && char.IsAsciiDigit(value[index]))
        {
            index++;
        }

        return start < index
            && int.TryParse(value[start..index], out result)
            && result > 0;
    }

    private static bool TryReadRange(string? value, string prefix, out int first, out int last)
    {
        first = 0;
        last = 0;
        if (string.IsNullOrWhiteSpace(value))
        {
            return false;
        }

        string expectedPrefix = $"{prefix}-";
        int separatorIndex = value.IndexOf("..", StringComparison.Ordinal);
        if (separatorIndex <= expectedPrefix.Length
            || !value.StartsWith(expectedPrefix, StringComparison.Ordinal)
            || !value[(separatorIndex + 2)..].StartsWith(expectedPrefix, StringComparison.Ordinal))
        {
            return false;
        }

        string firstPart = value[expectedPrefix.Length..separatorIndex];
        string secondPart = value[(separatorIndex + 2 + expectedPrefix.Length)..];
        return int.TryParse(firstPart, out first)
            && int.TryParse(secondPart, out last)
            && first > 0
            && last >= first;
    }

    private static string FindRepositoryRoot(string fullPath)
    {
        DirectoryInfo? directory = new(Path.GetDirectoryName(fullPath)!);
        while (directory is not null)
        {
            string gitPath = Path.Combine(directory.FullName, ".git");
            if (Directory.Exists(gitPath) || File.Exists(gitPath))
            {
                return directory.FullName;
            }

            directory = directory.Parent;
        }

        return Path.GetDirectoryName(fullPath)!;
    }

    private static string ToRepositoryRelativePath(string fullPath, string repositoryRoot) =>
        Path.GetRelativePath(repositoryRoot, fullPath).Replace(Path.DirectorySeparatorChar, '/');
}