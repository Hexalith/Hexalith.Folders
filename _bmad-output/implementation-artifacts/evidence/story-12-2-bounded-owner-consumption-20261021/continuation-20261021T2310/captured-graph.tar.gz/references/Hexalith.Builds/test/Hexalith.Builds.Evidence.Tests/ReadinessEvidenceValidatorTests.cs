// <copyright file="ReadinessEvidenceValidatorTests.cs" company="ITANEO">
// Copyright (c) ITANEO (https://www.itaneo.com). All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.
// </copyright>

namespace Hexalith.Builds.Evidence.Tests;

using System.Text.Json;

using Hexalith.Builds.Tooling.Diagnostics;
using Hexalith.Builds.Tooling.Evidence;
using Hexalith.Builds.Tooling.Filesystem;

using Shouldly;

using Xunit;

/// <summary>
/// Verifies strict, deterministic readiness-evidence validation.
/// </summary>
public sealed class ReadinessEvidenceValidatorTests
{
    /// <summary>
    /// Verifies the canonical positive matrix resolves defaults, coverage, artifacts, and Markdown identities.
    /// </summary>
    /// <returns>A task that completes after the assertion.</returns>
    [Fact]
    public async Task PositiveFixturePassesAsync()
    {
        ToolCommandResult result = await ReadinessEvidenceValidator.ValidateAsync(
            EvidenceFixturePath.Get("positive/readiness.yaml"),
            TestContext.Current.CancellationToken).ConfigureAwait(true);

        result.Status.ShouldBe("passed");
        result.Outcome.ExitCode.ShouldBe(ToolExitCode.Success);
        result.Diagnostics.ShouldBeEmpty();
    }

    /// <summary>
    /// Verifies duplicate YAML keys fail before schema or policy evaluation.
    /// </summary>
    /// <returns>A task that completes after the assertion.</returns>
    [Fact]
    public async Task DuplicateYamlKeyFailsAsEvidenceSchemaAsync()
    {
        ToolCommandResult result = await ReadinessEvidenceValidator.ValidateAsync(
            EvidenceFixturePath.Get("negative/duplicate-key.yaml"),
            TestContext.Current.CancellationToken).ConfigureAwait(true);

        result.Outcome.ExitCode.ShouldBe(ToolExitCode.EvidenceSchemaOrPolicy);
        result.Outcome.Category.ShouldBe(ToolFailureCategory.EvidenceSchema);
        result.Outcome.RuleId.ShouldBe("HXE001");
        result.Diagnostics.Count.ShouldBe(1);
    }

    /// <summary>
    /// Verifies an unsupported schema fails before business rule evaluation.
    /// </summary>
    /// <returns>A task that completes after the assertion.</returns>
    [Fact]
    public async Task UnsupportedSchemaFailsAsEvidenceSchemaAsync()
    {
        ToolCommandResult result = await ReadinessEvidenceValidator.ValidateAsync(
            EvidenceFixturePath.Get("negative/unsupported-schema.yaml"),
            TestContext.Current.CancellationToken).ConfigureAwait(true);

        result.Outcome.Category.ShouldBe(ToolFailureCategory.EvidenceSchema);
        result.Diagnostics.Select(diagnostic => diagnostic.RuleId).ShouldContain("HXE004");
    }

    /// <summary>
    /// Verifies unknown schema fields fail closed without a policy evaluation.
    /// </summary>
    /// <returns>A task that completes after the assertion.</returns>
    [Fact]
    public async Task UnknownFieldFailsAsEvidenceSchemaAsync()
    {
        ToolCommandResult result = await ReadinessEvidenceValidator.ValidateAsync(
            EvidenceFixturePath.Get("negative/unknown-field.yaml"),
            TestContext.Current.CancellationToken).ConfigureAwait(true);

        result.Outcome.Category.ShouldBe(ToolFailureCategory.EvidenceSchema);
        result.Diagnostics.Select(diagnostic => diagnostic.RuleId).ShouldContain("HXE003");
    }

    /// <summary>
    /// Verifies a hash-matched artifact with only a schema marker cannot satisfy a passed readiness claim.
    /// </summary>
    /// <returns>A task that completes after the assertion.</returns>
    [Fact]
    public async Task IncompleteModuleRunArtifactFailsClosedAsync()
    {
        ToolCommandResult result = await ReadinessEvidenceValidator.ValidateAsync(
            EvidenceFixturePath.Get("negative/invalid-artifact.yaml"),
            TestContext.Current.CancellationToken).ConfigureAwait(true);

        result.Outcome.Category.ShouldBe(ToolFailureCategory.EvidencePolicy);
        result.Diagnostics.Select(diagnostic => diagnostic.RuleId).ShouldContain("HXE148");
    }

    /// <summary>
    /// Verifies an artifact link that points outside its repository root is rejected before it is read.
    /// </summary>
    [Fact]
    public void EscapingArtifactSymlinkIsRejectedByRepositoryResolver()
    {
        string repositoryRoot = Path.Combine(Path.GetTempPath(), $"hexalith-builds-evidence-root-{Guid.NewGuid():N}");
        string externalDirectory = Path.Combine(Path.GetTempPath(), $"hexalith-builds-evidence-external-{Guid.NewGuid():N}");

        try
        {
            _ = Directory.CreateDirectory(repositoryRoot);
            _ = Directory.CreateDirectory(externalDirectory);
            File.WriteAllText(Path.Combine(externalDirectory, "artifact.json"), "{}");
            _ = Directory.CreateSymbolicLink(Path.Combine(repositoryRoot, "evidence"), externalDirectory);

            RepositoryPathResolver.TryResolveExistingFile(repositoryRoot, "evidence/artifact.json", out _).ShouldBeFalse();
        }
        finally
        {
            Directory.Delete(repositoryRoot, true);
            Directory.Delete(externalDirectory, true);
        }
    }

    /// <summary>
    /// Verifies policy controls expose deterministic, metadata-only diagnostics.
    /// </summary>
    /// <returns>A task that completes after the assertion.</returns>
    [Fact]
    public async Task PolicyControlsFailWithStableSortedDiagnosticsAsync()
    {
        ToolCommandResult result = await ReadinessEvidenceValidator.ValidateAsync(
            EvidenceFixturePath.Get("negative/policy-controls.yaml"),
            TestContext.Current.CancellationToken).ConfigureAwait(true);

        result.Outcome.Category.ShouldBe(ToolFailureCategory.EvidencePolicy);
        result.Outcome.RuleId.ShouldBe("HXE141");
        IReadOnlyList<string> ruleIds = [.. result.Diagnostics.Select(diagnostic => diagnostic.RuleId)];
        ruleIds.ShouldContain("HXE124");
        ruleIds.ShouldContain("HXE140");
        ruleIds.ShouldContain("HXE141");
        ruleIds.ShouldContain("HXE142");
        ruleIds.ShouldContain("HXE145");
        ruleIds.ShouldContain("HXE151");
        result.Diagnostics[0].Row.ShouldBe("release-failed");
        result.Diagnostics.All(diagnostic => !diagnostic.Message.Contains("0123456789abcdef", StringComparison.Ordinal)).ShouldBeTrue();
    }

    /// <summary>
    /// Verifies a passed row cannot be satisfied by an artifact from a non-test (<c>down</c>) invocation.
    /// </summary>
    /// <returns>A task that completes after the assertion.</returns>
    [Fact]
    public Task PassedRowBoundToNonTestArtifactFailsClosedAsync() =>
        AssertRuleAsync("negative/binding-mismatch.yaml", "HXE152");

    /// <summary>
    /// Verifies every declared readiness input identity fails closed under the stable binding rule.
    /// </summary>
    /// <param name="fixture">The isolated identity-mismatch fixture.</param>
    /// <returns>A task that completes after the assertion.</returns>
    [Theory]
    [InlineData("negative/artifact-command-filter-mismatch.yaml")]
    [InlineData("negative/artifact-command-manifest-mismatch.yaml")]
    [InlineData("negative/artifact-command-profile-mismatch.yaml")]
    [InlineData("negative/artifact-duplicate-option-mismatch.yaml")]
    [InlineData("negative/artifact-raw-filter-equals-mismatch.yaml")]
    [InlineData("negative/artifact-raw-filter-mismatch.yaml")]
    [InlineData("negative/filter-hash-mismatch.yaml")]
    [InlineData("negative/fixture-hash-mismatch.yaml")]
    [InlineData("negative/fixture-path-mismatch.yaml")]
    [InlineData("negative/malformed-row-option-mismatch.yaml")]
    [InlineData("negative/manifest-hash-mismatch.yaml")]
    [InlineData("negative/manifest-path-mismatch.yaml")]
    [InlineData("negative/manifest-profile-fixture-mismatch.yaml")]
    [InlineData("negative/row-duplicate-option-mismatch.yaml")]
    [InlineData("negative/row-missing-filter-mismatch.yaml")]
    [InlineData("negative/row-missing-manifest-mismatch.yaml")]
    [InlineData("negative/row-profile-mismatch.yaml")]
    public Task PassedRowIdentityMismatchFailsClosedAsync(string fixture) =>
        AssertRuleAsync(fixture, "HXE152");

    /// <summary>
    /// Verifies a filter mismatch diagnostic retains neither the row's raw filter value nor a
    /// raw filter embedded in the artifact command.
    /// </summary>
    /// <param name="fixture">The isolated filter-mismatch fixture.</param>
    /// <param name="rawFilter">The raw filter value that must never reach a diagnostic.</param>
    /// <returns>A task that completes after the assertion.</returns>
    [Theory]
    [InlineData("negative/artifact-raw-filter-equals-mismatch.yaml", "Category=smoke")]
    [InlineData("negative/artifact-raw-filter-mismatch.yaml", "Category=smoke")]
    [InlineData("negative/filter-hash-mismatch.yaml", "Category=identity-drift")]
    public async Task FilterMismatchDoesNotExposeRawFilterAsync(string fixture, string rawFilter)
    {
        ToolCommandResult result = await ReadinessEvidenceValidator.ValidateAsync(
            EvidenceFixturePath.Get(fixture),
            TestContext.Current.CancellationToken).ConfigureAwait(true);

        result.Diagnostics.Select(diagnostic => diagnostic.RuleId).ShouldBe(["HXE152"]);
        JsonSerializer.Serialize(result.Diagnostics).Contains(rawFilter, StringComparison.Ordinal).ShouldBeFalse();
    }

    /// <summary>
    /// Verifies a passed row cannot be satisfied by a run that reported no executed tests.
    /// </summary>
    /// <returns>A task that completes after the assertion.</returns>
    [Fact]
    public Task PassedRowBackedByZeroTestsFailsClosedAsync() =>
        AssertRuleAsync("negative/no-executed-tests.yaml", "HXE153");

    /// <summary>
    /// Verifies a secret-bearing artifact cannot be treated as valid metadata-only evidence.
    /// </summary>
    /// <returns>A task that completes after the assertion.</returns>
    [Fact]
    public Task SecretBearingArtifactFailsClosedAsync() =>
        AssertRuleAsync("negative/secret-metadata.yaml", "HXE148");

    /// <summary>
    /// Verifies an artifact whose bytes do not match its declared hash is rejected.
    /// </summary>
    /// <returns>A task that completes after the assertion.</returns>
    [Fact]
    public Task ArtifactHashMismatchFailsClosedAsync() =>
        AssertRuleAsync("negative/artifact-hash-mismatch.yaml", "HXE147");

    /// <summary>
    /// Verifies an executed row missing its artifact schema and hash is rejected.
    /// </summary>
    /// <returns>A task that completes after the assertion.</returns>
    [Fact]
    public Task MissingArtifactMetadataFailsClosedAsync() =>
        AssertRuleAsync("negative/missing-artifact-metadata.yaml", "HXE146");

    /// <summary>
    /// Verifies a passed row reporting a non-passing outcome is rejected.
    /// </summary>
    /// <returns>A task that completes after the assertion.</returns>
    [Fact]
    public Task PassedOutcomeIntegrityFailsClosedAsync() =>
        AssertRuleAsync("negative/outcome-mismatch.yaml", "HXE143");

    /// <summary>
    /// Verifies incomplete required requirement coverage is rejected.
    /// </summary>
    /// <returns>A task that completes after the assertion.</returns>
    [Fact]
    public Task IncompleteCoverageFailsClosedAsync() =>
        AssertRuleAsync("negative/coverage-shortfall.yaml", "HXE130");

    /// <summary>
    /// Verifies the validator matches its checked-in deterministic result and ordered-diagnostic snapshots.
    /// </summary>
    /// <param name="fixture">The readiness fixture path.</param>
    /// <param name="expectedSnapshot">The expected outcome snapshot path.</param>
    /// <returns>A task that completes after the assertion.</returns>
    [Theory]
    [InlineData("negative/artifact-command-filter-mismatch.yaml", "negative/artifact-command-filter-mismatch.expected.json")]
    [InlineData("negative/artifact-command-manifest-mismatch.yaml", "negative/artifact-command-manifest-mismatch.expected.json")]
    [InlineData("negative/artifact-command-profile-mismatch.yaml", "negative/artifact-command-profile-mismatch.expected.json")]
    [InlineData("negative/artifact-duplicate-option-mismatch.yaml", "negative/artifact-duplicate-option-mismatch.expected.json")]
    [InlineData("negative/artifact-raw-filter-equals-mismatch.yaml", "negative/artifact-raw-filter-equals-mismatch.expected.json")]
    [InlineData("negative/artifact-raw-filter-mismatch.yaml", "negative/artifact-raw-filter-mismatch.expected.json")]
    [InlineData("negative/artifact-hash-mismatch.yaml", "negative/artifact-hash-mismatch.expected.json")]
    [InlineData("negative/binding-mismatch.yaml", "negative/binding-mismatch.expected.json")]
    [InlineData("negative/coverage-shortfall.yaml", "negative/coverage-shortfall.expected.json")]
    [InlineData("negative/duplicate-key.yaml", "negative/duplicate-key.yaml.expected.json")]
    [InlineData("negative/filter-hash-mismatch.yaml", "negative/filter-hash-mismatch.expected.json")]
    [InlineData("negative/fixture-hash-mismatch.yaml", "negative/fixture-hash-mismatch.expected.json")]
    [InlineData("negative/fixture-path-mismatch.yaml", "negative/fixture-path-mismatch.expected.json")]
    [InlineData("negative/invalid-artifact.yaml", "negative/invalid-artifact.expected.json")]
    [InlineData("negative/malformed-row-option-mismatch.yaml", "negative/malformed-row-option-mismatch.expected.json")]
    [InlineData("negative/manifest-hash-mismatch.yaml", "negative/manifest-hash-mismatch.expected.json")]
    [InlineData("negative/manifest-path-mismatch.yaml", "negative/manifest-path-mismatch.expected.json")]
    [InlineData("negative/manifest-profile-fixture-mismatch.yaml", "negative/manifest-profile-fixture-mismatch.expected.json")]
    [InlineData("negative/missing-artifact-metadata.yaml", "negative/missing-artifact-metadata.expected.json")]
    [InlineData("negative/no-executed-tests.yaml", "negative/no-executed-tests.expected.json")]
    [InlineData("negative/outcome-mismatch.yaml", "negative/outcome-mismatch.expected.json")]
    [InlineData("negative/policy-controls.yaml", "negative/policy-controls.yaml.expected.json")]
    [InlineData("negative/row-duplicate-option-mismatch.yaml", "negative/row-duplicate-option-mismatch.expected.json")]
    [InlineData("negative/row-missing-filter-mismatch.yaml", "negative/row-missing-filter-mismatch.expected.json")]
    [InlineData("negative/row-missing-manifest-mismatch.yaml", "negative/row-missing-manifest-mismatch.expected.json")]
    [InlineData("negative/row-profile-mismatch.yaml", "negative/row-profile-mismatch.expected.json")]
    [InlineData("negative/secret-metadata.yaml", "negative/secret-metadata.expected.json")]
    [InlineData("negative/unknown-field.yaml", "negative/unknown-field.yaml.expected.json")]
    [InlineData("negative/unsupported-schema.yaml", "negative/unsupported-schema.yaml.expected.json")]
    [InlineData("positive/readiness.yaml", "positive/readiness.yaml.expected.json")]
    public async Task ValidatorMatchesExpectedSnapshotAsync(string fixture, string expectedSnapshot)
    {
        ToolCommandResult result = await ReadinessEvidenceValidator.ValidateAsync(
            EvidenceFixturePath.Get(fixture),
            TestContext.Current.CancellationToken).ConfigureAwait(true);

        using JsonDocument expected = JsonDocument.Parse(
            await File.ReadAllTextAsync(
                EvidenceFixturePath.Get(expectedSnapshot),
                TestContext.Current.CancellationToken).ConfigureAwait(true));

        JsonElement expectedRoot = expected.RootElement;
        result.Status.ShouldBe(expectedRoot.GetProperty("status").GetString());
        ((int)result.Outcome.ExitCode).ShouldBe(expectedRoot.GetProperty("exitCode").GetInt32());
        result.Outcome.ExitCode.ToString().ShouldBe(expectedRoot.GetProperty("outcomeExitCode").GetString());
        result.Outcome.Phase.ToString().ShouldBe(expectedRoot.GetProperty("phase").GetString());
        result.Outcome.Category.ToString().ShouldBe(expectedRoot.GetProperty("category").GetString());

        JsonElement expectedRuleId = expectedRoot.GetProperty("outcomeRuleId");
        if (expectedRuleId.ValueKind == JsonValueKind.Null)
        {
            result.Outcome.RuleId.ShouldBeNull();
        }
        else
        {
            result.Outcome.RuleId.ShouldBe(expectedRuleId.GetString());
        }

        string[] expectedRuleIds = [.. expectedRoot.GetProperty("ruleIds").EnumerateArray().Select(item => item.GetString()!)];
        result.Diagnostics.Select(diagnostic => diagnostic.RuleId).ShouldBe(expectedRuleIds);
    }

    private static async Task AssertRuleAsync(string fixture, string expectedRuleId)
    {
        ToolCommandResult result = await ReadinessEvidenceValidator.ValidateAsync(
            EvidenceFixturePath.Get(fixture),
            TestContext.Current.CancellationToken).ConfigureAwait(true);

        result.Status.ShouldBe("failed");
        result.Outcome.ExitCode.ShouldBe(ToolExitCode.EvidenceSchemaOrPolicy);
        result.Diagnostics.Select(diagnostic => diagnostic.RuleId).ShouldContain(expectedRuleId);
    }
}