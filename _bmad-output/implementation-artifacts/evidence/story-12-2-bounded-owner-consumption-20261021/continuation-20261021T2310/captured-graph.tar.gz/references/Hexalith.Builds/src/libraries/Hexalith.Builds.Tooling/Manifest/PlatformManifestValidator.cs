// <copyright file="PlatformManifestValidator.cs" company="ITANEO">
// Copyright (c) ITANEO (https://www.itaneo.com). All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.
// </copyright>

namespace Hexalith.Builds.Tooling.Manifest;

using System.Globalization;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;

using Hexalith.Builds.Tooling.Diagnostics;
using Hexalith.Builds.Tooling.Runtime;

using Json.Schema;

/// <summary>
/// Validates local Platform enrollment without composing resources or executing lifecycle code.
/// </summary>
public static partial class PlatformManifestValidator
{
    private const int _maximumManifestBytes = 1_048_576;
    private const int _maximumFiles = 256;
    private const string _schemaResource = "Hexalith.Builds.Tooling.Manifest.hexalith.module-manifest.v2.json";
    private static readonly string _schemaText = ReadSchema();
    private static readonly JsonSchema _schema = JsonSchema.FromText(_schemaText, new BuildOptions
    {
        SchemaRegistry = new SchemaRegistry
        {
            Fetch = (_, _) => throw new InvalidOperationException("Platform validation cannot fetch remote schemas."),
        },
    });

    private static readonly JsonElement _schemaRoot = JsonSerializer.Deserialize<JsonElement>(_schemaText);

    /// <summary>
    /// Validates all files as one declaration set using the shipped, embedded schema.
    /// </summary>
    /// <param name="manifestPaths">The manifest file paths.</param>
    /// <param name="cancellationToken">The cancellation token.</param>
    /// <returns>An atomic validation result.</returns>
    public static PlatformManifestValidationResult Validate(
        IEnumerable<string> manifestPaths,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(manifestPaths);
        List<ToolDiagnostic> diagnostics = [];
        List<PlatformModuleDeclaration> declarations = [];
        Dictionary<string, List<(string Source, string Field)>> identities = new(StringComparer.Ordinal);
        int fileCount = 0;
        foreach (string path in manifestPaths)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (++fileCount > _maximumFiles)
            {
                Add(diagnostics, "HXP013", "manifest", "manifest", "Supply at most 256 manifest files in one validation request.");
                break;
            }

            ValidateFile(path, declarations, identities, diagnostics, cancellationToken);
        }

        if (fileCount == 0)
        {
            Add(diagnostics, "HXP015", "manifest", "manifest", "Supply at least one manifest file.");
        }

        foreach (List<(string Source, string Field)> occurrences in identities.Values.Where(value => value.Count > 1))
        {
            foreach ((string source, string field) in occurrences)
            {
                Add(diagnostics, "HXP003", source, field, "The identity is duplicated within the supplied declaration set; use a unique identity.");
            }
        }

        ToolDiagnostic[] ordered = [.. diagnostics.Distinct()
            .OrderBy(diagnostic => diagnostic.Source, StringComparer.Ordinal)
            .ThenBy(diagnostic => diagnostic.Field, StringComparer.Ordinal)
            .ThenBy(diagnostic => diagnostic.RuleId, StringComparer.Ordinal)
            .ThenBy(diagnostic => diagnostic.Message, StringComparer.Ordinal),
        ];
        return new PlatformManifestValidationResult(
            ordered.Length == 0 ? declarations.AsReadOnly() : null,
            Array.AsReadOnly(ordered));
    }

    private static void Add(List<ToolDiagnostic> diagnostics, string rule, string source, string field, string reason, string? location = null) =>
        diagnostics.Add(new ToolDiagnostic(rule, ToolPhase.Manifest, ToolFailureCategory.Manifest, reason, field.Length == 0 ? "$" : field, Source: source, Location: location));

    private static string ReadSchema()
    {
        using Stream stream = typeof(PlatformManifestValidator).Assembly.GetManifestResourceStream(_schemaResource)
            ?? throw new InvalidOperationException("The packaged Platform declaration schema is missing.");
        using StreamReader reader = new(stream, Encoding.UTF8);
        return reader.ReadToEnd();
    }

    private static void ValidateFile(
        string path,
        List<PlatformModuleDeclaration> declarations,
        Dictionary<string, List<(string Source, string Field)>> identities,
        List<ToolDiagnostic> diagnostics,
        CancellationToken cancellationToken)
    {
        string fullPath;
        string source = "manifest";
        try
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(path);
            fullPath = Path.GetFullPath(path);
            source = Path.GetRelativePath(Directory.GetCurrentDirectory(), fullPath).Replace('\\', '/');
            if (ContainsProhibitedSecret(source))
            {
                source = "[redacted manifest path]";
            }
        }
        catch (Exception exception) when (exception is ArgumentException or NotSupportedException or IOException or UnauthorizedAccessException)
        {
            Add(diagnostics, "HXP004", source, "manifest", "Supply a valid manifest file path.");
            return;
        }

        try
        {
            using FileStream stream = File.Open(fullPath, FileMode.Open, FileAccess.Read, FileShare.Read);
            int initialDiagnosticCount = diagnostics.Count;
            if (!stream.CanSeek)
            {
                Add(diagnostics, "HXP005", source, "manifest", "Supply an existing readable manifest file.");
                return;
            }

            if (stream.Length > _maximumManifestBytes)
            {
                Add(diagnostics, "HXP013", source, "$", "Keep the UTF-8 manifest at or below 1 MiB.");
                return;
            }

            byte[] buffer = new byte[_maximumManifestBytes + 1];
            int count = 0;
            int read;
            while (count < buffer.Length && (read = stream.Read(buffer, count, buffer.Length - count)) > 0)
            {
                count += read;
                cancellationToken.ThrowIfCancellationRequested();
            }

            if (count > _maximumManifestBytes)
            {
                Add(diagnostics, "HXP013", source, "$", "Keep the UTF-8 manifest at or below 1 MiB.");
                return;
            }

            // Reject malformed UTF-8 before JSON parsing; a UTF-8 BOM is permitted.
            int offset = count >= 3 && buffer[0] == 0xEF && buffer[1] == 0xBB && buffer[2] == 0xBF ? 3 : 0;
            string content = new UTF8Encoding(false, true).GetString(buffer, offset, count - offset);
            using JsonDocument document = JsonDocument.Parse(content, new JsonDocumentOptions { MaxDepth = 64 });
            JsonElement root = document.RootElement;
            if (!InspectValues(root, string.Empty, source, diagnostics, cancellationToken))
            {
                return;
            }

            string? schema = StringValue(root, "schema");
            if (!SupportedPlatformManifestSchemas.Eligible.Contains(schema, StringComparer.Ordinal))
            {
                Add(
                    diagnostics,
                    "HXP001",
                    source,
                    "schema",
                    $"Platform enrollment requires major {SupportedPlatformManifestSchemas.CurrentMajor}; eligible schemas: {string.Join(", ", SupportedPlatformManifestSchemas.Eligible)}. Legacy v1 is qualification-only.");
                return;
            }

            EvaluationResults evaluation = _schema.Evaluate(root, new EvaluationOptions { OutputFormat = OutputFormat.Hierarchical });
            if (!evaluation.IsValid)
            {
                int schemaDiagnosticCount = diagnostics.Count;
                CollectSchemaDiagnostics(evaluation, root, source, diagnostics);
                if (schemaDiagnosticCount == diagnostics.Count)
                {
                    Add(diagnostics, "HXP002", source, "$", "The document violates the Platform declaration schema.");
                }
            }

            int moduleIndex = 0;
            foreach (JsonElement module in ArrayValue(root, "modules"))
            {
                cancellationToken.ThrowIfCancellationRequested();
                string prefix = $"modules[{moduleIndex++}]";
                ValidateModule(module, prefix, source, fullPath, identities, diagnostics);
                if (module.ValueKind == JsonValueKind.Object && initialDiagnosticCount == diagnostics.Count)
                {
                    declarations.Add(new PlatformModuleDeclaration(source, ApplyDefaults(module))
                    {
                        SourceHash = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(buffer.AsSpan(0, count))),
                    });
                }
            }
        }
        catch (Exception exception) when (exception is IOException or UnauthorizedAccessException or NotSupportedException)
        {
            Add(diagnostics, "HXP005", source, "manifest", "Supply an existing readable manifest file.");
        }
        catch (DecoderFallbackException)
        {
            Add(diagnostics, "HXP011", source, "$", "Supply a valid UTF-8 JSON document.");
        }
        catch (JsonException exception)
        {
            Add(diagnostics, "HXP011", source, exception.Path ?? "$", "Supply valid JSON without comments or trailing commas and with nesting at most 64 levels.", FormatJsonLocation(exception));
        }
    }

    private static bool InspectValues(JsonElement value, string path, string source, List<ToolDiagnostic> diagnostics, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        bool validUnicode = true;
        if (value.ValueKind == JsonValueKind.Object)
        {
            HashSet<string> names = new(StringComparer.Ordinal);
            int propertyIndex = 0;
            foreach (JsonProperty property in value.EnumerateObject())
            {
                string name;
                try
                {
                    name = property.Name;
                }
                catch (InvalidOperationException)
                {
                    string invalidField = $"{(path.Length == 0 ? "$" : path)}[\"<invalid Unicode property name at index {propertyIndex++}>\"]";
                    Add(diagnostics, "HXP011", source, invalidField, "Supply a JSON property name with valid Unicode surrogate pairs.");
                    validUnicode = false;
                    continue;
                }

                propertyIndex++;
                string field = AppendField(path, name);
                if (!names.Add(name))
                {
                    Add(diagnostics, "HXP012", source, field, "Remove the duplicate JSON property.");
                }

                if (!InspectValues(property.Value, field, source, diagnostics, cancellationToken))
                {
                    validUnicode = false;
                }
            }
        }
        else if (value.ValueKind == JsonValueKind.Array)
        {
            int index = 0;
            foreach (JsonElement item in value.EnumerateArray())
            {
                validUnicode &= InspectValues(item, $"{path}[{index++}]", source, diagnostics, cancellationToken);
            }
        }
        else if (value.ValueKind == JsonValueKind.String)
        {
            string text;
            try
            {
                text = value.GetString()!;
            }
            catch (InvalidOperationException)
            {
                Add(diagnostics, "HXP011", source, path.Length == 0 ? "$" : path, "Supply a JSON string with valid Unicode surrogate pairs.");
                return false;
            }

            if (ContainsProhibitedSecret(text))
            {
                Add(diagnostics, "HXM007", source, path, "Remove credential material; declare a logical secret reference instead.");
            }
            else if (ManifestPathValidator.ContainsPlaceholder(text))
            {
                Add(diagnostics, "HXM006", source, path, "Resolve the placeholder before enrollment.");
            }
        }

        return validUnicode;
    }

    private static void CollectSchemaDiagnostics(EvaluationResults result, JsonElement root, string source, List<ToolDiagnostic> diagnostics)
    {
        string pointer = result.InstanceLocation.ToString();
        string path = PointerToPath(root, pointer);
        JsonElement instance = ResolvePointer(root, pointer);
        string schemaPointer = Uri.UnescapeDataString(result.SchemaLocation.Fragment.TrimStart('#'));
        JsonElement schema = ResolveSchemaNode(schemaPointer);
        if (result.Errors?.ContainsKey(string.Empty) == true)
        {
            // The evaluator reports a false subschema under an empty keyword. The parent's
            // additionalProperties diagnostic already reports unknown fields; the rest are
            // kind- or strategy-specific exclusions.
            if (!schemaPointer.Split('/').Contains("additionalProperties", StringComparer.Ordinal))
            {
                Add(diagnostics, "HXP002", source, path, "Remove the field; it does not apply to the declared kind or strategy.");
            }
        }
        else if (result.Errors is not null)
        {
            foreach (string keyword in result.Errors.Keys)
            {
                if (keyword == "required" && instance.ValueKind == JsonValueKind.Object && schema.ValueKind == JsonValueKind.Object
                    && schema.TryGetProperty("required", out JsonElement required))
                {
                    foreach (JsonElement name in required.EnumerateArray())
                    {
                        if (!instance.TryGetProperty(name.GetString()!, out _))
                        {
                            Add(diagnostics, "HXP015", source, AppendField(path == "$" ? string.Empty : path, name.GetString()!), "Supply the required field.");
                        }
                    }
                }
                else if (keyword == "additionalProperties" && instance.ValueKind == JsonValueKind.Object
                    && schema.ValueKind == JsonValueKind.Object && schema.TryGetProperty("properties", out JsonElement properties))
                {
                    foreach (string property in instance.EnumerateObject().Select(property => property.Name))
                    {
                        if (!properties.TryGetProperty(property, out _))
                        {
                            Add(diagnostics, "HXP002", source, AppendField(path == "$" ? string.Empty : path, property), "Remove the unknown field; JSON property names use strict camelCase.");
                        }
                    }
                }
                else if (keyword is not "$ref" and not "properties" and not "items" and not "allOf" and not "then" and not "if" and not "additionalProperties")
                {
                    string reason = keyword switch
                    {
                        "type" => "Use the JSON type declared by the schema.",
                        "required" => "Supply the required field.",
                        "enum" => "Use one of the values declared by the schema.",
                        "const" => "Use the fixed value declared by the schema.",
                        "pattern" or "minLength" or "maxLength" => "Use a nonblank value matching the schema's declared format and length.",
                        "minimum" or "exclusiveMinimum" or "maximum" => "Use a positive finite value within the schema's declared range.",
                        "uniqueItems" => "Remove duplicate collection entries.",
                        "minItems" or "maxItems" => "Use the collection size declared by the schema.",
                        _ => "The field violates the Platform declaration schema.",
                    };
                    string rule = path.EndsWith(".lifecycle.startup.override.timeoutSeconds", StringComparison.Ordinal) && keyword is "minimum" or "exclusiveMinimum" or "maximum" ? "HXP021" : "HXP002";
                    Add(diagnostics, rule, source, path, reason);
                }
            }
        }

        if (result.Details is not null)
        {
            foreach (EvaluationResults detail in result.Details.Where(detail => !detail.IsValid))
            {
                CollectSchemaDiagnostics(detail, root, source, diagnostics);
            }
        }
    }

    private static JsonElement ResolveSchemaNode(string pointer)
    {
        // Conditional applicators can append a synthetic branch index to their
        // schema location. Resolve the nearest real schema object for metadata.
        while (pointer.Length > 0)
        {
            JsonElement schema = ResolvePointer(_schemaRoot, pointer);
            if (schema.ValueKind == JsonValueKind.Object)
            {
                return schema;
            }

            int separator = pointer.LastIndexOf('/');
            pointer = separator > 0 ? pointer[..separator] : string.Empty;
        }

        return _schemaRoot;
    }

    private static JsonElement ResolvePointer(JsonElement root, string pointer)
    {
        JsonElement current = root;
        foreach (string escaped in pointer.Split('/').Skip(1))
        {
            string segment = escaped.Replace("~1", "/", StringComparison.Ordinal).Replace("~0", "~", StringComparison.Ordinal);
            if (current.ValueKind == JsonValueKind.Object && current.TryGetProperty(segment, out JsonElement property))
            {
                current = property;
            }
            else if (current.ValueKind == JsonValueKind.Array && int.TryParse(segment, CultureInfo.InvariantCulture, out int index) && index >= 0 && index < current.GetArrayLength())
            {
                current = current[index];
            }
            else
            {
                return default;
            }
        }

        return current;
    }

    private static string PointerToPath(JsonElement root, string pointer)
    {
        string path = string.Empty;
        JsonElement current = root;
        foreach (string escaped in pointer.Split('/').Skip(1))
        {
            string segment = escaped.Replace("~1", "/", StringComparison.Ordinal).Replace("~0", "~", StringComparison.Ordinal);
            if (current.ValueKind == JsonValueKind.Array && int.TryParse(segment, CultureInfo.InvariantCulture, out int index) && index >= 0 && index < current.GetArrayLength())
            {
                path = $"{path}[{index}]";
                current = current[index];
            }
            else
            {
                path = AppendField(path, segment);
                current = ObjectValue(current, segment);
            }
        }

        return path.Length == 0 ? "$" : path;
    }

    private static string AppendField(string path, string name)
    {
        if (name.Length == 0)
        {
            return $"{(path.Length == 0 ? "$" : path)}[\"\"]";
        }

        string safeName = ContainsProhibitedSecret(name) ? "[redacted field]" : name;
        bool simpleName = (char.IsAsciiLetter(safeName[0]) || safeName[0] == '_') && safeName.All(character => char.IsAsciiLetterOrDigit(character) || character == '_');
        string dottedPath = path.Length == 0 ? safeName : $"{path}.{safeName}";
        string parentPath = path.Length == 0 ? "$" : path;
        return simpleName ? dottedPath : $"{parentPath}[{JsonSerializer.Serialize(safeName)}]";
    }

    private static bool ContainsProhibitedSecret(string value)
    {
        string userInfo = value.Replace("%40", "@", StringComparison.OrdinalIgnoreCase);
        return ManifestSecretDetector.ContainsSecret(value)
            || CredentialUriAnywhereRegex().IsMatch(userInfo)
            || (userInfo.Contains("://", StringComparison.Ordinal) && Uri.TryCreate(userInfo, UriKind.Absolute, out Uri? uri) && uri.UserInfo.Length > 0);
    }

    [GeneratedRegex(@"(?:[a-z][a-z0-9+.-]*:)?//[^\s/?#@]+@", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant | RegexOptions.NonBacktracking)]
    private static partial Regex CredentialUriAnywhereRegex();

    private static string? FormatJsonLocation(JsonException exception) =>
        exception.LineNumber is long line && exception.BytePositionInLine is long column
            ? string.Concat(
                (line + 1).ToString(CultureInfo.InvariantCulture),
                ":",
                (column + 1).ToString(CultureInfo.InvariantCulture))
            : null;

    private static JsonElement ObjectValue(JsonElement element, string property) =>
        element.ValueKind == JsonValueKind.Object && element.TryGetProperty(property, out JsonElement value) ? value : default;

    private static string? StringValue(JsonElement element, string property)
    {
        JsonElement value = ObjectValue(element, property);
        return value.ValueKind == JsonValueKind.String ? value.GetString() : null;
    }

    private static JsonElement[] ArrayValue(JsonElement element, string property)
    {
        JsonElement value = ObjectValue(element, property);
        return value.ValueKind == JsonValueKind.Array ? [.. value.EnumerateArray()] : [];
    }

    private static JsonElement ApplyDefaults(JsonElement module)
    {
        JsonObject normalized = JsonNode.Parse(module.GetRawText())!.AsObject();
        if (normalized["runtime"] is JsonObject runtime && runtime["resources"] is JsonArray resources)
        {
            foreach (JsonObject resource in resources.OfType<JsonObject>().Where(resource => !resource.ContainsKey("replicas")))
            {
                resource["replicas"] = 1;
            }
        }

        if (normalized["lifecycle"] is JsonObject lifecycle && lifecycle["startup"] is JsonObject startup && !startup.ContainsKey("defaultTimeoutSeconds"))
        {
            startup["defaultTimeoutSeconds"] = SupportedPlatformManifestSchemas.DefaultStartupTimeoutSeconds;
        }

        return JsonSerializer.SerializeToElement(normalized);
    }

    private static void RegisterIdentity(string? value, string kind, string source, string field, Dictionary<string, List<(string Source, string Field)>> identities)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return;
        }

        string key = $"{kind}:{value}";
        if (!identities.TryGetValue(key, out List<(string Source, string Field)>? occurrences))
        {
            occurrences = [];
            identities.Add(key, occurrences);
        }

        occurrences.Add((source, field));
    }

    private static void ValidateModule(
        JsonElement module,
        string prefix,
        string source,
        string fullPath,
        Dictionary<string, List<(string Source, string Field)>> identities,
        List<ToolDiagnostic> diagnostics)
    {
        JsonElement identity = ObjectValue(module, "identity");
        RegisterIdentity(StringValue(identity, "moduleId"), "module", source, $"{prefix}.identity.moduleId", identities);
        JsonElement lifecycle = ObjectValue(module, "lifecycle");
        JsonElement[] readiness = [.. ArrayValue(lifecycle, "readiness")];
        HashSet<string> serverIds = new(StringComparer.Ordinal);
        int serverIndex = 0;
        foreach (JsonElement server in ArrayValue(identity, "servers"))
        {
            string serverPath = $"{prefix}.identity.servers[{serverIndex++}]";
            RegisterIdentity(StringValue(server, "appId"), "app", source, $"{serverPath}.appId", identities);
            RegisterIdentity(StringValue(server, "resourceId"), "resource", source, $"{serverPath}.resourceId", identities);
            string? id = StringValue(server, "id");
            if (id is not null && !serverIds.Add(id))
            {
                Add(diagnostics, "HXP003", source, $"{serverPath}.id", "Use a unique server identity within the module.");
            }

            if (ObjectValue(server, "required").ValueKind == JsonValueKind.True)
            {
                if (ObjectValue(server, "enabled").ValueKind == JsonValueKind.False)
                {
                    Add(diagnostics, "HXP020", source, $"{serverPath}.enabled", "A required server must be enabled.");
                }

                if (id is not null && !readiness.Any(probe => StringValue(probe, "server") == id && IsUsableReadiness(probe)))
                {
                    Add(diagnostics, "HXP020", source, $"{prefix}.lifecycle.readiness", $"Declare usable readiness for required server at {serverPath}.id.");
                }
            }
        }

        ValidateDaprBindings(module, prefix, source, serverIds, diagnostics);

        int interfaceIndex = 0;
        foreach (JsonElement surface in ArrayValue(ObjectValue(module, "surfaces"), "interfaces"))
        {
            if (string.Equals(StringValue(surface, "protocol"), "mcp", StringComparison.OrdinalIgnoreCase))
            {
                Add(diagnostics, "HXP023", source, $"{prefix}.surfaces.interfaces[{interfaceIndex}].protocol", "AD-11 rejects MCP endpoints mapped by an enrolled host, regardless of exposure; MVP MCP uses McpCli stdio.");
            }

            interfaceIndex++;
        }

        JsonElement startupOverride = ObjectValue(ObjectValue(lifecycle, "startup"), "override");
        if (startupOverride.ValueKind == JsonValueKind.Object)
        {
            JsonElement timeout = ObjectValue(startupOverride, "timeoutSeconds");
            if (timeout.ValueKind != JsonValueKind.Number || !timeout.TryGetDouble(out double seconds) || !CompositionStartupDeadlineResolver.IsRepresentableTimeout(seconds))
            {
                Add(diagnostics, "HXP021", source, $"{prefix}.lifecycle.startup.override.timeoutSeconds", "Use a finite startup override from 0.001 through 3600 seconds.");
            }
        }

        ValidateExecutablePaths(lifecycle, prefix, source, fullPath, diagnostics);
        HashSet<string> testNames = new(StringComparer.Ordinal);
        int testIndex = 0;
        foreach (JsonElement test in ArrayValue(module, "tests"))
        {
            string field = $"{prefix}.tests[{testIndex++}]";
            string? name = StringValue(test, "name");
            if (name is not null && !testNames.Add(name))
            {
                Add(diagnostics, "HXP003", source, field + ".name", "Use a unique test name within the module.");
            }

            string? entry = StringValue(test, "entry");
            string? executor = StringValue(test, "executor");
            if (entry is not null && (!ModuleTestSelection.IsOwnedEntry(ManifestPathValidator.FindRepositoryRoot(fullPath), entry)
                || !entry.EndsWith(executor == "python3" ? ".py" : ".csproj", StringComparison.Ordinal)))
            {
                Add(diagnostics, "HXP020", source, field + ".entry", "Use an existing module-owned entry of the executor's file type, without symlinks or dependency paths.");
            }

            if (executor == "python3" && StringValue(test, "mode") != "source")
            {
                Add(diagnostics, "HXP020", source, field + ".mode", "Python tests currently support source mode only; packaged candidate provenance is unavailable.");
            }
        }
    }

    private static void ValidateDaprBindings(JsonElement module, string prefix, string source, HashSet<string> servers, List<ToolDiagnostic> diagnostics)
    {
        JsonElement[] capabilities = ArrayValue(ObjectValue(module, "runtime"), "dapr");
        Dictionary<string, (string Kind, string Recovery)> roles = new(StringComparer.Ordinal);
        Dictionary<string, Dictionary<string, string>> keys = new(StringComparer.Ordinal);
        for (int index = 0; index < capabilities.Length; index++)
        {
            JsonElement capability = capabilities[index];
            string field = $"{prefix}.runtime.dapr[{index}]";
            string? role = StringValue(capability, "role");
            if (role is null)
            {
                continue;
            }

            (string Kind, string Recovery) binding = (Kind: StringValue(capability, "capability")!, Recovery: StringValue(capability, "recoveryClass")!);
            if (roles.TryGetValue(role, out (string Kind, string Recovery) previous) && previous != binding)
            {
                Add(diagnostics, "HXP024", source, field + ".role", "One logical role must use one capability and recovery class.");
            }

            roles[role] = binding;
            string[] selected = ObjectValue(capability, "servers").ValueKind == JsonValueKind.Array
                ? [.. ArrayValue(capability, "servers").Where(value => value.ValueKind == JsonValueKind.String).Select(value => value.GetString()!)]
                : [.. servers];
            foreach (string server in selected)
            {
                if (!servers.Contains(server))
                {
                    Add(diagnostics, "HXP024", source, field + ".servers", $"Unknown owner server '{server}'.");
                }

                if (StringValue(capability, "configurationKey") is not { } configurationKey)
                {
                    continue;
                }

                if (!keys.TryGetValue(server, out Dictionary<string, string>? serverKeys))
                {
                    serverKeys = new(StringComparer.OrdinalIgnoreCase);
                    keys.Add(server, serverKeys);
                }

                string key = configurationKey.Replace("__", ":", StringComparison.Ordinal);
                if (serverKeys.TryGetValue(key, out string? previousRole) && previousRole != role)
                {
                    Add(diagnostics, "HXP024", source, field + ".configurationKey", "Conflicting capabilities bind the same server configuration key.");
                }

                serverKeys[key] = role;
            }
        }

        HashSet<string> enabledServers = [.. ArrayValue(ObjectValue(module, "identity"), "servers")
            .Where(server => ObjectValue(server, "enabled").ValueKind == JsonValueKind.True)
            .Select(server => StringValue(server, "id"))
            .OfType<string>(),
        ];
        HashSet<string> subscriptions = new(StringComparer.Ordinal);
        JsonElement[] topics = ArrayValue(ObjectValue(module, "integration"), "topics");
        static string? PhysicalTopic(JsonElement topic) => StringValue(ObjectValue(topic, "subscription"), "topic") ?? StringValue(topic, "name");
        for (int index = 0; index < topics.Length; index++)
        {
            JsonElement topic = topics[index];
            string field = $"{prefix}.integration.topics[{index}]";
            if (!capabilities.Any(capability => StringValue(capability, "role") == StringValue(topic, "role") && StringValue(capability, "capability") == "pubsub"))
            {
                Add(diagnostics, "HXP024", source, field + ".role", "Bind the topic to a declared pubsub capability role.");
            }

            JsonElement subscription = ObjectValue(topic, "subscription");
            if (subscription.ValueKind == JsonValueKind.Object)
            {
                string server = StringValue(subscription, "server")!;
                if (!enabledServers.Contains(server))
                {
                    Add(diagnostics, "HXP024", source, field + ".subscription.server", "Receiving owner server is unknown or disabled.");
                }

                if (!subscriptions.Add(server + "/" + StringValue(topic, "role") + "/" + PhysicalTopic(topic)))
                {
                    Add(diagnostics, "HXP024", source, field + ".subscription", "Duplicate subscription for the same receiver, pubsub role and topic.");
                }

                if (!capabilities.Any(capability => StringValue(capability, "role") == StringValue(topic, "role") &&
                    (ObjectValue(capability, "servers").ValueKind != JsonValueKind.Array || ArrayValue(capability, "servers").Any(value => value.ValueKind == JsonValueKind.String && value.GetString() == server))))
                {
                    Add(diagnostics, "HXP024", source, field + ".subscription.server", "The receiving server is outside the pubsub capability scope.");
                }

                JsonElement deadLetter = ObjectValue(topic, "deadLetter");
                if (StringValue(deadLetter, "strategy") == "topic")
                {
                    string?[] targets = [.. topics.Where(target => StringValue(target, "name") == StringValue(deadLetter, "topic") && StringValue(target, "role") == StringValue(topic, "role"))
                        .Select(PhysicalTopic).Distinct(StringComparer.Ordinal),
                    ];
                    if (targets.Length != 1 || targets[0] is not { } target || target.Contains('*', StringComparison.Ordinal) || target == PhysicalTopic(topic))
                    {
                        Add(diagnostics, "HXP024", source, field + ".deadLetter.topic", "Reference an inventory name on the same pubsub role that resolves to one distinct concrete physical topic.");
                    }
                }
            }
        }

        int surfaceIndex = 0;
        foreach (JsonElement surface in ArrayValue(ObjectValue(module, "surfaces"), "interfaces"))
        {
            string field = $"{prefix}.surfaces.interfaces[{surfaceIndex++}]";
            if (!servers.Contains(StringValue(surface, "server")!))
            {
                Add(diagnostics, "HXP024", source, field + ".server", "Unknown receiving owner server.");
            }

            foreach (JsonElement rule in ArrayValue(surface, "invocationRules"))
            {
                if (StringValue(surface, "protocol") != "http" || StringValue(surface, "exposure") == "disabled")
                {
                    Add(diagnostics, "HXP024", source, field + ".invocationRules", "Invocation rules require an enabled HTTP interface.");
                }

                if (!ArrayValue(surface, "callers").Any(caller => caller.ValueKind == JsonValueKind.String && caller.GetString() == StringValue(rule, "caller")))
                {
                    Add(diagnostics, "HXP024", source, field + ".invocationRules", "Each explicit caller must be in the interface caller inventory.");
                }

                string? path = StringValue(rule, "path");
                string? route = StringValue(surface, "routePrefix");
                if (path is null || route is null)
                {
                    continue;
                }

                if (path.Contains('*', StringComparison.Ordinal) || path.Contains('{', StringComparison.Ordinal) || path.Contains('}', StringComparison.Ordinal) || (route != "/" && path != route && !path.StartsWith(route.TrimEnd('/') + "/", StringComparison.Ordinal)))
                {
                    Add(diagnostics, "HXP024", source, field + ".invocationRules", "Use a concrete invocation path within the interface route prefix.");
                }
            }
        }
    }

    private static bool IsUsableReadiness(JsonElement probe) => StringValue(probe, "kind") switch
    {
        "http" => StringValue(probe, "endpoint") is { Length: > 0 } endpoint && IsUsableHttpEndpoint(endpoint),
        "grpc" => !string.IsNullOrWhiteSpace(StringValue(probe, "service")),
        "command" => !string.IsNullOrWhiteSpace(StringValue(probe, "executable")),
        _ => false,
    };

    private static bool IsUsableHttpEndpoint(string endpoint) =>
        endpoint.StartsWith('/')
        && !string.IsNullOrWhiteSpace(endpoint)
        && !endpoint.Contains("//", StringComparison.Ordinal)
        && endpoint.Split('/').All(segment => segment is not "." and not "..");

    private static void ValidateExecutablePaths(JsonElement lifecycle, string prefix, string source, string fullPath, List<ToolDiagnostic> diagnostics)
    {
        foreach (string collection in new[] { "tasks", "readiness" })
        {
            int index = 0;
            foreach (JsonElement item in ArrayValue(lifecycle, collection))
            {
                string field = $"{prefix}.lifecycle.{collection}[{index++}].executable";
                string? executable = StringValue(item, "executable");
                if (executable is not null)
                {
                    List<ToolDiagnostic> pathDiagnostics = [];
                    _ = ManifestPathValidator.ValidateExistingFile(executable, ManifestPathValidator.FindRepositoryRoot(fullPath), field, pathDiagnostics);
                    diagnostics.AddRange(pathDiagnostics
                        .Where(diagnostic => diagnostic.RuleId is not "HXM006" and not "HXM007")
                        .Select(diagnostic => diagnostic with { Source = source }));
                }
            }
        }
    }
}