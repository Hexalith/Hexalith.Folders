﻿// <copyright file="AreSameEnumerationTest.cs" company="ITANEO">
// Copyright (c) ITANEO (https://www.itaneo.com). All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.
// </copyright>

namespace Hexalith.Commons.Tests.Common;

using Hexalith.Commons.Objects;

using Shouldly;

/// <summary>
/// Tests for the AreSame and AreSameDictionary extension methods.
/// </summary>
public class AreSameEnumerationTest
{
    /// <summary>
    /// Tests that AreSameDictionary and AreSame return false when dictionaries have different values.
    /// </summary>
    [Fact]
    public void EquatableDictionaryAreSameShouldReturnFalse()
    {
        Dictionary<int, DummyEquatable> a = new()
        {
            [100] = new DummyEquatable(),
            [101] = new DummyEquatable { Property3 = 10 },
        };
        Dictionary<int, DummyEquatable> b = new()
        {
            [100] = new DummyEquatable(),
            [101] = new DummyEquatable { Property3 = 11 },
        };
        a.AreSameDictionary(b).ShouldBeFalse();
        a.AreSame(b).ShouldBeFalse();
    }

    /// <summary>
    /// Tests that AreSameDictionary and AreSame return true when dictionaries have the same values regardless of insertion order.
    /// </summary>
    [Fact]
    public void EquatableDictionaryAreSameShouldReturnTrue()
    {
        Dictionary<int, DummyEquatable> a = new()
        {
            [100] = new DummyEquatable(),
            [101] = new DummyEquatable { Property3 = 10 },
        };
        Dictionary<int, DummyEquatable> b = new()
        {
            [101] = new DummyEquatable { Property3 = 10 },
            [100] = new DummyEquatable(),
        };
        a.AreSameDictionary(b).ShouldBeTrue();
        a.AreSame(b).ShouldBeTrue();
    }

    /// <summary>
    /// Tests that AreSameEnumeration and AreSame return false when lists have different values.
    /// </summary>
    [Fact]
    public void EquatableListAreSameShouldReturnFalse()
    {
        List<DummyEquatable> a = [new DummyEquatable(), new DummyEquatable { Property3 = 10 }];
        List<DummyEquatable> b = [new DummyEquatable(), new DummyEquatable { Property3 = 11 }];
        a.AreSameEnumeration(b).ShouldBeFalse();
        a.AreSame(b).ShouldBeFalse();
    }

    /// <summary>
    /// Tests that AreSameEnumeration and AreSame return true when lists have the same values.
    /// </summary>
    [Fact]
    public void EquatableListAreSameShouldReturnTrue()
    {
        var first = new DummyEquatable { Property1 = "Test1", Property2 = "Test2", Property3 = 10 };
        var second = new DummyEquatable { Property1 = "Test3", Property2 = "Test4", Property3 = 20 };
        List<DummyEquatable> a = [first, second];
        List<DummyEquatable> b = [
            new DummyEquatable { Property1 = "Test1", Property2 = "Test2", Property3 = 10 },
            new DummyEquatable { Property1 = "Test3", Property2 = "Test4", Property3 = 20 },
        ];
        a.AreSameEnumeration(b).ShouldBeTrue();
        a.AreSame(b).ShouldBeTrue();
    }

    /// <summary>
    /// Tests that AreSameDictionary and AreSame return false when simple dictionaries have different values.
    /// </summary>
    [Fact]
    public void SimpleDictionaryAreSameShouldReturnFalse()
    {
        Dictionary<int, string> a = new() { [10] = "Hello", [11] = "world" };
        Dictionary<int, string> b = new() { [10] = "Hello", [11] = "world*" };
        a.AreSameDictionary(b).ShouldBeFalse();
        a.AreSame(b).ShouldBeFalse();
    }

    /// <summary>
    /// Tests that AreSameDictionary and AreSame return true when simple dictionaries have the same values.
    /// </summary>
    [Fact]
    public void SimpleDictionaryAreSameShouldReturnTrue()
    {
        Dictionary<int, string> a = new() { [10] = "Hello", [11] = "world" };
        Dictionary<int, string> b = new() { [10] = "Hello", [11] = "world" };
        a.AreSameDictionary(b).ShouldBeTrue();
        a.AreSame(b).ShouldBeTrue();
    }

    /// <summary>
    /// Tests that AreSameEnumeration and AreSame return false when simple lists have different values.
    /// </summary>
    [Fact]
    public void SimpleListAreSameShouldReturnFalse()
    {
        List<string> a = ["Hello", "World"];
        List<string> b = ["Hello", "World*"];
        a.AreSameEnumeration(b).ShouldBeFalse();
        a.AreSame(b).ShouldBeFalse();
    }

    /// <summary>
    /// Tests that AreSameEnumeration and AreSame return true when simple lists have the same values.
    /// </summary>
    [Fact]
    public void SimpleListAreSameShouldReturnTrue()
    {
        List<string> a = ["Hello", "World"];
        List<string> b = ["Hello", "World"];
        a.AreSameEnumeration(b).ShouldBeTrue();
        a.AreSame(b).ShouldBeTrue();
    }
}