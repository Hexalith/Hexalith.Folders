import ast, datetime, hashlib, json, os, shutil, struct, subprocess, tarfile
from pathlib import Path

ROOT = Path('/home/administrator/projects/hexalith/folders')
BASE = ROOT / '_bmad-output/implementation-artifacts'
OUT = Path(__file__).parent
NAME = 'story-1-17-cli-4-38-runtime-resolution-2026-10-26'
PROPOSAL = BASE / 'evidence/story-1-17-cli-4-38-loader-proposal-2026-10-26'
def sha(path):
    with Path(path).open('rb') as stream: return hashlib.file_digest(stream, 'sha256').hexdigest()
def write(name, value): (OUT / name).write_text(json.dumps(value, indent=2) + '\n')
def bind(path):
    return dict(path=str(path.relative_to(ROOT)), bytes=path.stat().st_size, sha256=sha(path))
def git(repo, *args): return subprocess.check_output(['git', '-C', str(ROOT / repo), *args])

inputs = json.loads((PROPOSAL / 'inputs.json').read_text())
plan_path = BASE / 'story-1-17-cli-4-38-runtime-resolution-plan-2026-10-26.json'
plan = json.loads(plan_path.read_text())
for item in plan['artifacts'] + plan['supportingArtifacts'] + inputs['preservedFiles']:
    p = ROOT / item['path']; assert p.stat().st_size == item['bytes'] and sha(p) == item['sha256'], str(p)
for item in inputs['sdk']['files']:
    p = Path(item['path']); assert p.stat().st_size == item['bytes'] and sha(p) == item['sha256'], str(p)
for path in inputs['absentPaths']: assert not (ROOT / path).exists()
tree = ast.parse((PROPOSAL / 'execute_after_authorization.py').read_text())
nodes = []
for node in tree.body:
    if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id in ('instructions', 'filter_bytes') for t in node.targets): nodes.append(node)
    if isinstance(node, ast.For) and isinstance(node.target, ast.Name) and node.target.id == 'syscall': nodes.append(node)
    if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Attribute) and isinstance(node.value.func.value, ast.Name) and node.value.func.value.id == 'instructions': nodes.append(node)
namespace = dict(struct=struct)
exec(compile(ast.Module(body=nodes, type_ignores=[]), '<pure proposed BPF data construction>', 'exec'), namespace)
assert hashlib.sha256(namespace['filter_bytes']).hexdigest() == inputs['seccompSha256']
def policy(arch, number):
    accumulator = 0; index = 0
    while True:
        opcode, yes, no, value = namespace['instructions'][index]
        if opcode == 0x20: accumulator = arch if value == 4 else number
        elif opcode == 0x15: index += yes if accumulator == value else no
        elif opcode == 0x35: index += yes if accumulator >= value else no
        elif opcode == 0x06: return value
        else: raise AssertionError(opcode)
        index += 1
cases=[]
for arch, number, expected in [(0xc000003e, n, 0x50001) for n in [41,42,53,425]] + [(0xc000003e,n,0x7fff0000) for n in [1,56,59,257]] + [(0xc000003e,0x40000029,0x80000000),(0x40000003,102,0x80000000)]:
    actual=policy(arch,number);assert actual==expected;cases.append(dict(arch=arch,syscall=number,result=actual))
write('proposal-static-validation.json',dict(pythonAstParsed=True,planAndInputHashesMatch=True,
    seccompDataHash=inputs['seccompSha256'],pureDataPolicyCases=cases,
    targetAssemblyCompiled=False,targetAssemblyLoaded=False,runtimeProbeExecuted=False,
    sandboxCapabilityTested=False,limit='Static syntax, data and binding checks only; no C# compiler or sandbox process invoked.'))

initial=json.loads((OUT/'preflight.json').read_text())['repositories'];final={}
for rel, expected in initial.items():
    revision=git(rel,'rev-parse','HEAD').decode().strip()
    index=hashlib.sha256(git(rel,'ls-files','--stage')).hexdigest()
    status=git(rel,'status','--porcelain=v2','--untracked-files=all').decode()
    staged=git(rel,'diff','--cached','--raw').decode()
    assert revision==expected['revision'] and index==expected['indexEntriesSha256'] and staged==''
    assert git(rel,'diff','--name-only').decode()==''
    if rel!='.': assert status==''
    else: assert all(line.startswith('? _bmad-output/implementation-artifacts/') for line in status.splitlines())
    final[rel]=dict(revision=revision,indexEntriesSha256=index,status=status,staged=staged)
markers=[]
for rel in initial:
    if rel=='.': continue
    for current, dirs, files in os.walk(ROOT/rel,followlinks=False):
        if '.git' in dirs or '.git' in files:
            marker=str((Path(current)/'.git').relative_to(ROOT));markers.append(marker)
            assert Path(current)==ROOT/rel, marker
        dirs[:]=[d for d in dirs if d!='.git' and not (Path(current)/d).is_symlink()]
write('final-preservation.json',dict(recordedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    repositories=final,trackedDifferences=[],stagedDifferences=[],preservedBoundFiles=len(inputs['preservedFiles']),
    markersUnderDirectCheckouts=markers,additionalNestedMarkers=[],
    scope='Revisions, newline stage entries, Git statuses and exact explicitly bound file bytes; no whole-host or all-ignored-file preservation claim.'))
write('capture-completion.json',dict(verifiedArchiveMembers=[1083,18],priorCapsuleBindings=17,modelMembers=45,hostMembers=238,
    repositories=13,sourceFiles=20,runtimeSource='v10.0.13 tag, not installed-commit attestation',
    modelAndHostLoaded=False,newSdkCommandExecuted=False,newModelBuildExecuted=False,
    collectorCorrections=['First static collector stopped at a wrong receipt root-key lookup; fixed to preserved repository revision.',
        'An optional source lookup used the wrong EventStore subdirectory; corrected to root Aspire source path.',
        'Installed runtime commit source URL returned404; retained tag-source bytes with explicit equivalence limitation.'],
    collectorLimit='Failed collector stdout/stderr exist in the conversation, not as separate original files in this archive; no original failure records reconstructed.'))

authored=[BASE/'spec-1-17-cli-4-38-runtime-resolution-decision.md',
    BASE/'story-1-17-cli-4-38-runtime-resolution-decision-2026-10-26.md',plan_path,*sorted(PROPOSAL.iterdir())]
for source in authored:
    target=OUT/'proposal'/source.name;target.parent.mkdir(exist_ok=True);shutil.copyfile(source,target)
files=sorted(p for p in OUT.rglob('*') if p.is_file())
manifest=dict(format='sha256-file-members-v1',members=[dict(path=str(p.relative_to(OUT)),sha256=sha(p),bytes=p.stat().st_size) for p in files])
manifest_path=BASE/'evidence'/f'{NAME}.members.json';manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
archive_path=BASE/'evidence'/f'{NAME}.artifacts.tar.gz'
with tarfile.open(archive_path,'w:gz') as archive:
    for path in files: archive.add(path,arcname=str(path.relative_to(OUT)),recursive=False)
with tarfile.open(archive_path) as archive:
    members={m.name:m for m in archive.getmembers() if m.isfile()};assert len(members)==len(manifest['members'])
    for item in manifest['members']:
        member=members[item['path']];assert member.size==item['bytes']
        assert hashlib.file_digest(archive.extractfile(member),'sha256').hexdigest()==item['sha256']

receipt=dict(recordId='STORY-1-17-CLI-4-38-RUNTIME-RESOLUTION-2026-10-26',recordedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    status='STATIC_PREPARATION_COMPLETE_EXECUTION_UNAUTHORIZED',sourceTuple={k:v['revision'] for k,v in initial.items()},
    candidateSource='e171c5a788eab183b32683431b084198c9b8d373',
    selectedCatalog=dict(revision='022668ac2dd3b0ec4b1b8e99b243debef0eee374',sha256='140e161c0ac14183be0cca8babce5cc896355174e1c621979b92d49826bdadb2',redis='3.4.5'),
    priorCompileReceipt=bind(BASE/'evidence/story-1-17-cli-4-38-nonlaunch-qualification-2026-10-26.json'),
    priorProposalReceipt=bind(BASE/'evidence/story-1-17-current-platform-tool-catalog-qualification-2026-10-25.json'),
    artifactArchive=bind(archive_path),memberManifest=bind(manifest_path),membersVerified=len(manifest['members']),
    authoredArtifacts=[bind(p) for p in authored],
    staticFindings=dict(eventStore='Expected Default-context version/MVID conflict when3.128 demanded; no observed runtime failure or established Parties demand timing.',
        redis='No direct model Redis AssemblyRef or Redis output DLL. Host3 can satisfy assembly2 version floor; API/runtime behavior unproven.',
        missingModelAspire='Host exact13.6.3 identity available; absence alone is not a blocker.',
        missingHostServiceDefaults='Model3.128 fallback candidate exists; optional/transitive behavior unproven.',
        mvids=json.loads((OUT/'static-mvids.json').read_text())),
    reusedEvidence=json.loads((OUT/'reused-evidence.json').read_text()),
    validation=json.loads((OUT/'proposal-static-validation.json').read_text()),
    preservation=dict(revisionsAndIndicesPreserved=True,directCheckoutCount=12,exactPartiesPreserved=True,
        trackedDifferences=[],stagedDifferences=[],boundFilesPreserved=len(inputs['preservedFiles']),
        noNestedInitializationPerformed=True,scope='Git status/index/revisions and explicitly bound bytes only; no whole-host/all-ignored-files claim.'),
    limitations=['Actual host/model resolution, preloading/JIT order, API behavior, runtime prerequisites and ordinary Parties reachability not observed.',
        'New proposed helper uncompiled/unexecuted, sandbox capability untested. Static AST/BPF data validation is not execution evidence.',
        'Retained comparative runtime tag source does not attest installed runtime source equivalence; exact commit URL returned404.',
        'Historical incomplete immediate SDK gate, certificate first-use uncertainty, inherited-environment gap, overwritten original failure, optional missing PDB and process-observation limitations remain unchanged.'],
    ownerDecision=dict(decisionMaker='Jerome',status='PENDING',question='Authorize only the exact two-case loader-only experiment in the bound plan?',authority=None,plan=bind(plan_path)),
    proposedPatch=None,patchDisposition='No necessary dependency/build-property repair established; no operational patch proposed/applied.',
    ordinaryMapping=None,ContentHash=None,operationalControl=dict(routeMode='V1Only',T0=None,activationAuthority=None,publicationAuthorized=False,deploymentAuthorized=False,trackerTransitionAuthorized=False),
    parentStatus='in-progress',trackerStatus='backlog',stagingChecks=dict(total=14,executed=0),
    historicalAcceptedCli='4.35.2',candidateCli='4.38.0',currentTupleAccepted=False,packageAccepted=False,hostedAccepted=False,
    newSdkCommandsExecuted=0,newModelBuildsExecuted=0,runtimeLaunched=False,probeExecuted=False,
    dependenciesChanged=False,operationalSourceChanged=False,staged=False,committed=False,pushed=False,published=False,deployed=False)
receipt_path=BASE/'evidence'/f'{NAME}.json';receipt_path.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(receipt=str(receipt_path),members=receipt['membersVerified'],archiveBytes=archive_path.stat().st_size,
    planSha256=sha(plan_path),staticValidation='PASS; proposed helper not executed',gitPreservation='13 revisions/indices preserved; no staged entries')))
