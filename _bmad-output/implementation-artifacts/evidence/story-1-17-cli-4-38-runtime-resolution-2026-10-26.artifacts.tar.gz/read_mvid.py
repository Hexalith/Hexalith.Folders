from pathlib import Path
import struct,uuid
def mvid(path):
    b = Path(path).read_bytes()
    u16 = lambda off: struct.unpack_from('<H', b, off)[0]
    u32 = lambda off: struct.unpack_from('<I', b, off)[0]
    pe = u32(0x3c); opt = pe + 24
    dd = opt + (112 if u16(opt) == 0x20b else 96)
    sec = opt + u16(pe + 20)
    def rva(value):
        for i in range(u16(pe + 6)):
            off = sec + 40*i; va = u32(off+12)
            if va <= value < va + max(u32(off+8),u32(off+16)):
                return u32(off+20) + value-va
        raise ValueError('RVA outside sections')
    cli = rva(u32(dd + 14*8)); meta = rva(u32(cli+8))
    assert b[meta:meta+4] == b'BSJB'
    pos = (meta+16+u32(meta+12)+3) & ~3
    count = u16(pos+2); pos += 4; streams = {}
    for _ in range(count):
        off,size = u32(pos),u32(pos+4); end = b.index(0,pos+8)
        name = b[pos+8:end].decode(); streams[name] = (meta+off,size)
        pos = (end+4) & ~3
    table = streams.get('#~',streams.get('#-'))[0]
    heaps = b[table+6]; valid = struct.unpack_from('<Q',b,table+8)[0]
    assert valid & 1
    rows = table+24+4*valid.bit_count()
    index_off = rows+2+(4 if heaps & 1 else 2)
    index = u32(index_off) if heaps & 2 else u16(index_off)
    guid = streams['#GUID'][0] + 16*(index-1)
    return str(uuid.UUID(bytes_le=b[guid:guid+16]))
