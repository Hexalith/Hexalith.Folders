import datetime, hashlib, json, os, subprocess, tarfile, urllib.request, zipfile
from pathlib import Path

ROOT = Path('/home/administrator/projects/hexalith/folders')
OUT = Path(__file__).parent
OLD = Path('/tmp/story117-cli438-qualification-20261026-fk5qKp')
BASE = ROOT / '_bmad-output/implementation-artifacts'
def sha(data): return hashlib.sha256(data).hexdigest()
def write(name, data):
    p = OUT / name; p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2) + '\n')
def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(ROOT / repo), *args])
def binding(p):
    data = p.read_bytes(); return dict(path=str(p), bytes=len(data), sha256=sha(data))

r = json.loads((BASE / 'evidence/story-1-17-cli-4-38-nonlaunch-qualification-2026-10-26.json').read_text())
q = json.loads((BASE / 'evidence/story-1-17-current-platform-tool-catalog-qualification-2026-10-25.json').read_text())
verified = []
for label, rec in [('compile', r), ('prior-proposal', q)]:
    for key in ['artifactArchive', 'memberManifest']:
        expected = rec[key]; actual = binding(ROOT / expected['path'])
        assert (actual['sha256'], actual['bytes']) == (expected['sha256'], expected['bytes'])
    manifest = json.loads((ROOT / rec['memberManifest']['path']).read_text())['members']
    expected = {v['path']: v for v in manifest}
    with tarfile.open(ROOT / rec['artifactArchive']['path']) as archive:
        files = [v for v in archive.getmembers() if v.isfile()]
        assert len(files) == len(expected)
        for member in files:
            item = expected[member.name]
            assert hashlib.file_digest(archive.extractfile(member), 'sha256').hexdigest() == item['sha256']
            assert member.size == item['bytes']
    verified.append(dict(label=label, members=len(files), archive=rec['artifactArchive'], manifest=rec['memberManifest']))
for v in q['priorReceiptBindings']:
    actual = binding(ROOT / v['path'])
    assert (actual['sha256'], actual['bytes']) == (v['sha256'], v['bytes'])
write('reused-evidence.json', dict(archives=verified, priorBindings=q['priorReceiptBindings'],
    historicalVerifiersRerun=False, graphTestsRerun=False, adoptionAuditRerun=False,
    compileLimitations=r['evidenceLimitations']))

repos = {}
for rel, previous in r['preservation']['afterComparisonRaw']['repositories'].items():
    index = git(rel, 'ls-files', '--stage')
    revision = git(rel, 'rev-parse', 'HEAD').decode().strip()
    status = git(rel, 'status', '--porcelain=v2', '--untracked-files=all').decode()
    staged = git(rel, 'diff', '--cached', '--raw').decode()
    if rel != '.':
        assert revision == previous['revision'] and sha(index) == previous['indexEntriesSha256']
    assert status == '' and staged == '', (rel, status, staged)
    repos[rel] = dict(revision=revision, branch=git(rel, 'branch', '--show-current').decode().strip(),
        indexEntriesSha256=sha(index), status=status, staged=staged,
        gitlinks=[v for v in index.decode().splitlines() if v.startswith('160000 ')],
        remotes=git(rel, 'remote', '-v').decode(), recentHistory=git(rel, 'log', '-3', '--format=%H %s').decode())
write('preflight.json', dict(recordedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    repositories=repos, rootDeltaFromCompile=git('.', 'diff', '--name-status', r['preservation']['afterComparisonRaw']['repositories']['.']['revision'], 'HEAD').decode(),
    exactPartiesPreserved=True, indexEncoding='git ls-files --stage, newline bytes; no -z',
    rootStatusScope='Includes untracked nonignored files. No claim about whole-host or ignored-file preservation.'))

source_revisions = dict(builds='e171c5a788eab183b32683431b084198c9b8d373',
    platform='9869094acc21f9054960a573f884c60ddf3235cd', eventstore='c5d1c280d8c1c1a207cd159d817f614e93c93130')
sources = []
for key, repo, names in [
    ('builds', 'references/Hexalith.Builds', [
        'src/hosts/Hexalith.Builds.Module.AppHost/RunTopology.cs',
        'src/hosts/Hexalith.Builds.Module.AppHost/AppHostRunner.cs',
        'src/libraries/Hexalith.Builds.Tooling/Runtime/PlatformManifestCommand.cs',
        'src/libraries/Hexalith.Builds.Tooling/Runtime/CompositionCommandOptions.cs',
        'src/libraries/Hexalith.Builds.Tooling/Runtime/CompositionEngine.cs',
        'src/libraries/Hexalith.Builds.Tooling/Runtime/PersistedProfileStore.cs',
        'src/libraries/Hexalith.Builds.Tooling/Runtime/PersistedProfileExecutor.cs']),
    ('platform', 'references/Hexalith.Platform', [
        'Directory.Packages.props', 'global.json', 'hexalith-platform.json',
        'src/Hexalith.Platform.Composition/PlatformAppModel.cs',
        'src/Hexalith.Platform.Composition/PlatformTimesheetsBinding.cs',
        'src/Hexalith.Platform.Composition/PlatformServerBindings.cs',
        'src/Hexalith.Platform.Composition/PlatformRedisHealthCheck.cs',
        'src/Hexalith.Platform.Composition/PlatformHostedPublishing.cs',
        'src/Hexalith.Platform.Composition/Hexalith.Platform.Composition.csproj']),
    ('eventstore', 'references/Hexalith.EventStore', [
        'src/Hexalith.EventStore.Aspire/HexalithEventStoreAppChannelExtensions.cs',
        'src/Hexalith.EventStore.Aspire/EventStoreAppChannelTokenBindingAnnotation.cs',
        'src/Hexalith.EventStore.ServiceDefaults/Authentication/JwtBearerAuthenticationContract.cs',
        'src/Hexalith.EventStore.ServiceDefaults/Authentication/JwtBearerAuthenticationOptions.cs'])]:
    for name in names:
        try: data = git(repo, 'show', source_revisions[key] + ':' + name)
        except subprocess.CalledProcessError:
            if key == 'eventstore': continue
            raise
        output = OUT / 'source' / key / name; output.parent.mkdir(parents=True, exist_ok=True); output.write_bytes(data)
        sources.append(dict(repository=repo, revision=source_revisions[key], path=name,
            sha256=sha(data), retainedPath=str(output.relative_to(OUT))))
catalog = git('references/Hexalith.Builds', 'show', '022668ac2dd3b0ec4b1b8e99b243debef0eee374:Props/Directory.Packages.props')
assert sha(catalog) == '140e161c0ac14183be0cca8babce5cc896355174e1c621979b92d49826bdadb2'
(OUT / 'catalog.props').write_bytes(catalog)
write('source-bindings.json', sources)

package = OLD / 'download/hexalith.builds.module.cli.4.38.0.nupkg'
if not package.exists(): package = Path('/tmp/hexalith.builds.module.cli.4.38.0.nupkg')
assert binding(package)['sha256'] == r['candidate']['packageSha256']
prefix = 'tools/net10.0/any/g4-host/'
package_members = []
with zipfile.ZipFile(package) as archive:
    for name in archive.namelist():
        if name.startswith(prefix) and not name.endswith('/'):
            data = archive.read(name); actual = OLD / 'tool-4.38.0' / name
            assert actual.read_bytes() == data
            package_members.append(dict(path=name, sha256=sha(data), bytes=len(data)))
write('candidate-host-members.json', dict(package=binding(package), prefix=prefix, members=package_members))
manifest = json.loads((ROOT / r['memberManifest']['path']).read_text())['members']
model_members = [v for v in manifest if v['path'].startswith('hosts/platform-model/')]
for item in model_members:
    actual = binding(OLD / item['path']); assert (actual['sha256'], actual['bytes']) == (item['sha256'], item['bytes'])
write('model-members.json', dict(sourceArchive=r['artifactArchive'], members=model_members))
metadata = {}
for path in (OLD / 'logs').glob('metadata-*.stdout'):
    d = json.loads(path.read_text()); metadata[path.name] = d.get('assembly_info')
write('retained-assembly-info.json', metadata)
host = OLD / 'tool-4.38.0' / prefix
deps = json.loads((host / 'Hexalith.Builds.Module.AppHost.deps.json').read_text())
write('host-deps-selection.json', {target: {k:v for k,v in libs.items() if any(x in k for x in
    ['Hexalith.EventStore', 'StackExchange.Redis', 'Aspire.Hosting/', 'Aspire.Hosting.Redis/', 'Hexalith.Builds.Tooling/'])}
    for target, libs in deps['targets'].items()})
write('layout.json', dict(modelFiles=sorted(p.name for p in (OLD / 'hosts/platform-model').iterdir()),
    modelAspireHostingPresent=(OLD/'hosts/platform-model/Aspire.Hosting.dll').exists(),
    modelRedisPresent=(OLD/'hosts/platform-model/StackExchange.Redis.dll').exists(),
    hostServiceDefaultsPresent=(host/'Hexalith.EventStore.ServiceDefaults.dll').exists(),
    modelDirectRedisReference=any(v['name']=='StackExchange.Redis' for v in metadata['metadata-model.stdout']['references'])))
runtime_commit = (Path('/home/administrator/.dotnet/shared/Microsoft.NETCore.App/10.0.13/.version').read_text().splitlines()[0])
runtime_sources = []
for name in ['src/coreclr/binder/assemblybindercommon.cpp', 'src/libraries/System.Private.CoreLib/src/System/Runtime/Loader/AssemblyLoadContext.cs']:
    url = 'https://raw.githubusercontent.com/dotnet/runtime/v10.0.13/' + name
    data = urllib.request.urlopen(url, timeout=30).read()
    output = OUT / 'runtime-source' / Path(name).name; output.parent.mkdir(exist_ok=True); output.write_bytes(data)
    runtime_sources.append(dict(url=url, tag='v10.0.13', installedRuntimeReportedCommit=runtime_commit,
        installedCommitSourceUrlResult='404; tag source is comparative, not a binary/source equivalence attestation',
        sha256=sha(data), path=str(output.relative_to(OUT))))
write('runtime-source-bindings.json', runtime_sources)
sdk_paths = [Path(r['sdk']['dotnetPath']), ROOT / 'references/Hexalith.Platform/global.json',
    Path('/home/administrator/.dotnet/sdk/10.0.402/Roslyn/bincore/csc.dll')]
sdk_paths += sorted(Path('/home/administrator/.dotnet/packs/Microsoft.NETCore.App.Ref/10.0.13/ref/net10.0').glob('*.dll'))
sdk_paths += sorted(Path('/home/administrator/.dotnet/shared/Microsoft.NETCore.App/10.0.13').glob('*'))
sdk_paths += sorted(Path('/home/administrator/.dotnet/shared/Microsoft.AspNetCore.App/10.0.13').glob('*'))
write('sdk-inputs.json', dict(historicalGateIncomplete=True, runtimeVersion='10.0.13', runtimeCommit=runtime_commit,
    files=[binding(p) for p in sdk_paths if p.is_file()], newSdkCommandExecuted=False))
print(json.dumps(dict(verifiedArchiveMembers=[v['members'] for v in verified], priorBindings=len(q['priorReceiptBindings']),
    modelFiles=len(model_members), hostFiles=len(package_members), repositories=len(repos), sources=len(sources),
    runtimeCommit=runtime_commit, output=str(OUT))))
